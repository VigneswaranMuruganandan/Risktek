import 'package:flutter/material.dart';

class MenuItem {
  String title;
  IconData icon;
  String id;
  MenuItem(this.icon, this.id, this.title);
}
