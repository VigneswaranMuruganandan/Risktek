import 'package:flutter/material.dart';

class TimelineList extends StatelessWidget {
  final String title;
  final List<Object> data;

  TimelineList({@required this.title, @required this.data});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Stepper(
        steps: [
          Step(
              title: Text("Start"),
              content: Text("Before starting, we should create a page."),
              state: StepState.disabled),
          Step(
              title: Text("Constructor"),
              content: Text("Let's look at its construtor."),
              state: StepState.editing),
        ],
        controlsBuilder: (BuildContext context,
            {VoidCallback onStepContinue, VoidCallback onStepCancel}) {
          return Container();
        },
      ),
    );
  }
}
