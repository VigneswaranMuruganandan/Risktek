import 'package:flutter/material.dart';
import 'package:fabhr/utils/customIcon.dart';
import 'package:fabhr/common_widgets/TimelineList.dart';

class BottomDialogLayout {
  final String dialogType, message;
  final TextEditingController _textController = new TextEditingController();

  BottomDialogLayout({@required this.dialogType, this.message});

  void init(context) {
    _onButtonPressed(context);
  }

  void _onButtonPressed(context) {
    showModalBottomSheet(
        context: context,
        builder: (context) {
          return ConstrainedBox(
            constraints: new BoxConstraints(
              maxHeight: 283.0,
            ),
            child: Container(
              decoration: new BoxDecoration(
                  color: Color(0xFF737373),
                  border: new Border.all(color: Color(0xFF737373))),
              child: Column(
                children: <Widget>[
                  Center(
                    child: Container(
                        margin: EdgeInsets.only(bottom: 8),
                        width: 39,
                        height: 4,
                        decoration: BoxDecoration(
                          color: Color.fromRGBO(244, 248, 253, 1.0),
                          borderRadius: BorderRadius.circular(10),
                        )),
                  ),
                  Expanded(
                    child: Container(
                      child: dialogType == 'CUSTOM'
                          ? _buildTimelineBottomBar()
                          : _buildBottomBar(),
                      decoration: BoxDecoration(
                        color: Theme.of(context).canvasColor,
                        borderRadius: BorderRadius.only(
                          topLeft: const Radius.circular(30),
                          topRight: const Radius.circular(30),
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
          );
        });
  }

  _buildTimelineBottomBar() {
    final List<TimeLine> _timeLine = [
      TimeLine('Jack Townsend', 'SUBMITTED', new DateTime.now()),
    ];
    return TimelineList(title: 'Approval history', data: _timeLine);
  }

  Container _buildCustomBottomBar() {
    return Container(
      padding: EdgeInsets.only(left: 22, right: 36),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: <Widget>[
          Container(
            child: Text(
              'Please, comment before rejecting',
              style: TextStyle(
                  fontFamily: 'FSMatthew-Medium',
                  fontSize: 22,
                  letterSpacing: 0.05,
                  color: Color.fromRGBO(12, 35, 64, 1.0)),
            ),
          ),
          Container(
            child: Text(
              'FEEDBACK',
              style: TextStyle(
                  fontFamily: 'FSMatthew',
                  fontSize: 14,
                  letterSpacing: 1.11,
                  color: Color.fromRGBO(100, 121, 149, 1.0)),
            ),
          ),
          Container(
            child: Row(
              children: <Widget>[
                Flexible(
                  child: new TextField(
                    controller: _textController,
                    onSubmitted: _handleSubmitted,
                    decoration: new InputDecoration(
                        hintText: "Provide BCD attachment",
                        hintStyle: TextStyle(
                            fontFamily: 'FSMatthew',
                            fontSize: 14,
                            letterSpacing: 0.03,
                            color: Color.fromRGBO(12, 35, 64, 1.0))),
                  ),
                ),
                new Container(
                  child: new IconButton(
                      icon: new Icon(
                        Icons.send,
                        size: 18,
                        color: Color.fromRGBO(2, 113, 218, 1.0),
                      ),
                      onPressed: () => _handleSubmitted(_textController.text)),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  _handleSubmitted(String text) {}

  Column _buildBottomBar() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: <Widget>[
        CircleAvatar(
          backgroundColor: dialogType == 'SUCCESS'
              ? Color.fromRGBO(10, 189, 28, 1.0)
              : Color.fromRGBO(189, 10, 10, 1.0),
          radius: 35,
          child: Icon(
            dialogType == 'SUCCESS' ? Icons.done : Icons.close,
            size: 30,
            color: Color.fromRGBO(255, 255, 255, 1.0),
          ),
        ),
        Container(
          padding: EdgeInsets.only(left: 83, right: 83),
          child: Text(this.message,
              style: TextStyle(
                  fontFamily: 'FSMatthew-Medium',
                  fontSize: 22,
                  letterSpacing: 0.05,
                  color: Color.fromRGBO(12, 35, 64, 1.0)),
              textAlign: TextAlign.center),
        )
      ],
    );
  }
}

class TimeLine {
  String name;
  String status;
  DateTime date;
  TimeLine(this.name, this.status, this.date);
}
