import 'package:flutter/material.dart';
import '../utils/style.dart';

class CustomFlatButton extends StatelessWidget {
  const CustomFlatButton(
      {@required this.text,
      @required this.padding,
      @required this.textColor,
      @required this.onPress,
      this.borderColor,
      @required this.borderRadius,
      @required this.letterSpacing,
      @required this.fontSize,
      @required this.fontFamily});

  final String text;
  final EdgeInsets padding;
  final Color textColor;
  final Function onPress;
  final Color borderColor;
  final double fontSize;
  final double borderRadius;
  final double letterSpacing;
  final String fontFamily;

  @override
  Widget build(BuildContext context) {
    return FlatButton(
      onPressed: () {},
      textColor: textColor,
      shape: RoundedRectangleBorder(
        side: borderColor.toString() == 'Undefined'
            ? Null
            : BorderSide(
                width: 1,
                style: BorderStyle.solid,
                color: Color.fromRGBO(0, 43, 122, 1.0)),
        borderRadius: BorderRadius.circular(borderRadius),
      ),
      padding: padding,
      child: Text(text,
          style: TextStyle(
              fontSize: fontSize,
              fontFamily: fontFamily,
              letterSpacing: letterSpacing)),
    );
  }
}
