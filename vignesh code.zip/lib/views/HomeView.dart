import 'package:flutter/material.dart';
import 'package:fabhr/zoom_scaffold.dart';
import 'package:fabhr/MenuScreen.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:fabhr/common_widgets/DialogLayout.dart';
import 'package:fabhr/common_widgets/BottomDialogLayout.dart';

List<T> map<T>(List list, Function handler) {
  List<T> result = [];
  for (var i = 0; i < list.length; i++) {
    result.add(handler(i, list[i]));
  }

  return result;
}

final List<String> imgList = [
  'assets/images/banner1.png',
  'assets/images/banner1.png',
  'assets/images/banner1.png'
];

class HomeView extends StatefulWidget {
  @override
  _HomeViewState createState() => new _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  ZoomScaffold mainZoomScaffold;

  @override
  Widget build(BuildContext context) {
    //Future.delayed(Duration.zero, () => showAlert(context));

    mainZoomScaffold = new ZoomScaffold(
      menuScreen: MenuScreen(onButtonTap: () {
        _toggleMainMenu();
      }),
      contentScreen: Layout(
          contentBuilder: (cc) => Container(
                  child: new Stack(children: <Widget>[
                getFullScreenCarousel(context),
              ]))),
    );
    return mainZoomScaffold;
  }

  void showAlert(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) => DialogLayout(
          title: "Stay Tuned!",
          description:
              "Our team is consistently working on it. It will be launched soon.",
          buttonText: "Got it",
          imageUrl: AssetImage('assets/images/mail2Copy2@3x.png')),
    );
  }

  _toggleMainMenu() {
    mainZoomScaffold.doToggleMenu();
  }

  /*Positioned _test(BuildContext mediaContext) {
    return Positioned(
      top: 200.0,
      left: 0.0,
      right: 0.0,
      child: Container(
          child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: <Widget>[
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage("assets/images/leavsBox@3x.png"),
                fit: BoxFit.cover,
              ),
            ),
            child: Column(
              children: <Widget>[
                Container(
                  padding: EdgeInsets.only(top: 4),
                  child: Text(
                    'LEAVES',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Color.fromRGBO(255, 255, 255, 1.0),
                      letterSpacing: 0.78,
                      fontFamily: 'Graphik-Medium',
                      fontSize: 12,
                    ),
                  ),
                ),
                Container(
                  padding: EdgeInsets.only(top: 27, left: 32.5, right: 32.5),
                  child: Text(
                    '13',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Color.fromRGBO(0, 43, 122, 1.0),
                      letterSpacing: 0.07,
                      fontFamily: 'Graphik-Medium',
                      fontSize: 32,
                    ),
                  ),
                ),
                Container(
                  padding: EdgeInsets.only(top: 10, bottom: 15),
                  child: Text(
                    'Total',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Color.fromRGBO(185, 192, 202, 1.0),
                      letterSpacing: 0.03,
                      fontFamily: 'Graphik-Medium',
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
          ),
          //2nd area
          Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage("assets/images/group6@3x.png"),
                  fit: BoxFit.cover,
                ),
              ),
              child: Column(children: <Widget>[
                Container(
                  padding: EdgeInsets.only(top: 4),
                  child: Text(
                    'APPROVALS',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Color.fromRGBO(255, 255, 255, 1.0),
                      letterSpacing: 0.78,
                      fontFamily: 'Graphik-Medium',
                      fontSize: 12,
                    ),
                  ),
                ),
                Container(
                  child: Row(children: <Widget>[
                    Container(
                      child: Column(children: <Widget>[
                        Container(
                          padding:
                              EdgeInsets.only(top: 27, left: 32.5, right: 32.5),
                          child: Text(
                            '8',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Color.fromRGBO(0, 43, 122, 1.0),
                              letterSpacing: 0.07,
                              fontFamily: 'Graphik-Medium',
                              fontSize: 32,
                            ),
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.only(top: 10, bottom: 15),
                          child: Text(
                            'Leave',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Color.fromRGBO(185, 192, 202, 1.0),
                              letterSpacing: 0.03,
                              fontFamily: 'Graphik-Medium',
                              fontSize: 12,
                            ),
                          ),
                        ),
                      ]),
                    ),
                    Container(
                      child: Column(children: <Widget>[
                        Container(
                          padding:
                              EdgeInsets.only(top: 27, left: 32.5, right: 32.5),
                          child: Text(
                            '12',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Color.fromRGBO(0, 43, 122, 1.0),
                              letterSpacing: 0.07,
                              fontFamily: 'Graphik-Medium',
                              fontSize: 32,
                            ),
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.only(top: 10, bottom: 15),
                          child: Text(
                            'Requisition',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Color.fromRGBO(185, 192, 202, 1.0),
                              letterSpacing: 0.03,
                              fontFamily: 'Graphik-Medium',
                              fontSize: 12,
                            ),
                          ),
                        ),
                      ]),
                    ),
                    Container(
                      child: Column(children: <Widget>[
                        Container(
                          padding:
                              EdgeInsets.only(top: 27, left: 32.5, right: 32.5),
                          child: Text(
                            '14',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Color.fromRGBO(0, 43, 122, 1.0),
                              letterSpacing: 0.07,
                              fontFamily: 'Graphik-Medium',
                              fontSize: 32,
                            ),
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.only(top: 10, bottom: 15),
                          child: Text(
                            'Expense',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Color.fromRGBO(185, 192, 202, 1.0),
                              letterSpacing: 0.03,
                              fontFamily: 'Graphik-Medium',
                              fontSize: 12,
                            ),
                          ),
                        ),
                      ]),
                    )
                  ]),
                )
              ])),
        ],
      )),
    );
  }*/

  CarouselSlider getFullScreenCarousel(BuildContext mediaContext) {
    return CarouselSlider(
      autoPlay: true,
      height: 425.0,
      viewportFraction: 1.0,
      aspectRatio: MediaQuery.of(mediaContext).size.aspectRatio,
      items: imgList.map(
        (url) {
          return Container(
            width: MediaQuery.of(context).size.width,
            child: Stack(children: <Widget>[
              Image.asset(
                url,
                fit: BoxFit.fill,
                width: MediaQuery.of(context).size.width,
                height: 376.0,
              ),
              Positioned(
                  top: 122.0,
                  left: 20.0,
                  right: 0.0,
                  child: Container(
                      child: Text('Winners',
                          style: TextStyle(
                              color: Color.fromRGBO(255, 255, 255, 1.0),
                              fontSize: 50.0,
                              fontFamily: 'Graphik-Semibold',
                              letterSpacing: 1.11)))),
              Positioned(
                  top: 186.0,
                  left: 20.0,
                  right: 0.0,
                  child: Container(
                      padding: EdgeInsets.only(right: 138),
                      child: Text('Annual passes to Dubai parks and resorts',
                          style: TextStyle(
                              color: Color.fromRGBO(255, 255, 255, 1.0),
                              fontSize: 18,
                              fontFamily: 'Graphik',
                              letterSpacing: 0.04)))),
            ]),
          );
        },
      ).toList(),
    );
  }
}
