import 'package:flutter/material.dart';
import 'package:fabhr/utils/customIcon.dart';
import 'package:fabhr/common_widgets/BottomDialogLayout.dart';
import 'package:fabhr/views/RequisitionDetails.dart';

class ContactUs extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return new _ContactUsState();
  }
}

class _ContactUsState extends State<ContactUs> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        home: Scaffold(
      appBar: _buildAppBar(),
      body: _buildBody(),
    ));
  }

  Widget _buildAppBar() {
    return AppBar(
      //automaticallyImplyLeading: true,
      title: Text(
        'Ask HR',
        style: TextStyle(
          color: Color.fromRGBO(255, 255, 255, 1.0),
          fontSize: 16,
          letterSpacing: 0,
          fontFamily: 'FSMatthew',
        ),
      ),
      centerTitle: true,
      flexibleSpace: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
            colors: <Color>[
              Color.fromRGBO(0, 94, 188, 1.0),
              Color.fromRGBO(0, 48, 135, 1.0)
            ],
          ),
        ),
      ),
      leading: IconButton(
        icon: Icon(CustomIcon.back,
            size: 15.5, color: Color.fromRGBO(185, 192, 202, 1.0)),
        color: Color.fromRGBO(122, 125, 128, 1.0),
        onPressed: () => Navigator.pop(context, false),
      ),
      actions: <Widget>[
        new IconButton(
          icon: Icon(CustomIcon.close,
              size: 15.5, color: Color.fromRGBO(185, 192, 202, 1.0)),
          padding: EdgeInsets.all(6.8),
          color: Color.fromRGBO(122, 125, 128, 1.0),
          onPressed: () => Navigator.of(context).pop(null),
        ),
      ],
    );
  }

  Widget _buildBody() {
    return Container(
        decoration: BoxDecoration(color: Color.fromRGBO(246, 249, 252, 1.0)),
        margin: EdgeInsets.only(top: 44, left: 20, right: 20),
        child: Column(children: <Widget>[
          RaisedButton(
            child: Text('Show'),
            onPressed: () {
              BottomDialogLayout ob = new BottomDialogLayout(
                  dialogType: 'CUSTOM',
                  message: 'Requisition approved successfully');
              ob.init(context);
            },
          ),
          RaisedButton(
            child: Text('Show1'),
            onPressed: () {
              RequisitionDetails ob = new RequisitionDetails();
              ob.init(context);
            },
          ),
          _buildCallUsDetails(),
          _buildEmailUsDetails(),
        ]));
  }

  Container _buildCallUsDetails() {
    return Container(
        padding: EdgeInsets.only(top: 22, left: 13, bottom: 22),
        margin: EdgeInsets.only(bottom: 25),
        decoration: BoxDecoration(
            color: Color.fromRGBO(255, 255, 255, 1.0),
            borderRadius: BorderRadius.circular(8)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Container(
              padding: EdgeInsets.only(left: 6),
              child: Text(
                'CALL US',
                style: TextStyle(
                    fontFamily: 'FSMatthew-Bold',
                    color: Color.fromRGBO(0, 43, 122, 1.0),
                    fontSize: 18,
                    letterSpacing: 0.79),
              ),
            ),
            Container(
              child: Column(
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Container(
                          padding: const EdgeInsets.all(0.0),
                          width: 28.0,
                          child: IconButton(
                              padding: EdgeInsets.only(
                                  top: 6.3, bottom: 5.6, right: 5.6, left: 6.3),
                              icon: new Icon(CustomIcon.contactUs1),
                              iconSize: 16,
                              color: Color.fromRGBO(0, 43, 122, 1.0),
                              onPressed: () => {})),
                      Container(
                        padding: EdgeInsets.only(left: 9),
                        child: Text(
                          'Help center - ',
                          style: TextStyle(
                              fontFamily: 'FSMatthew-Light',
                              fontSize: 15,
                              letterSpacing: 0.66,
                              color: Color.fromRGBO(12, 35, 64, 1.0)),
                        ),
                      ),
                      Text(
                        '10884',
                        style: TextStyle(
                            fontFamily: 'FSMatthew',
                            fontSize: 15,
                            letterSpacing: 0.66,
                            color: Color.fromRGBO(12, 35, 64, 1.0)),
                      )
                    ],
                  ),
                  Row(
                    children: <Widget>[
                      Container(
                          padding: const EdgeInsets.all(0.0),
                          width: 28.0,
                          child: IconButton(
                              padding: EdgeInsets.only(
                                  top: 6.3, bottom: 5.6, right: 5.6, left: 6.3),
                              icon: new Icon(CustomIcon.contactUs1),
                              iconSize: 16,
                              color: Color.fromRGBO(0, 43, 122, 1.0),
                              onPressed: () => {})),
                      Container(
                          padding: EdgeInsets.only(left: 9),
                          child: Text(
                            'Outside UAE - ',
                            style: TextStyle(
                                fontFamily: 'FSMatthew-Light',
                                fontSize: 15,
                                letterSpacing: 0.66,
                                color: Color.fromRGBO(12, 35, 64, 1.0)),
                          )),
                      Text(
                        '+97126811511',
                        style: TextStyle(
                            fontFamily: 'FSMatthew',
                            fontSize: 15,
                            letterSpacing: 0.66,
                            color: Color.fromRGBO(12, 35, 64, 1.0)),
                      )
                    ],
                  )
                ],
              ),
            )
          ],
        ));
  }

  Container _buildEmailUsDetails() {
    return Container(
        padding: EdgeInsets.only(top: 22, left: 13, bottom: 22),
        margin: EdgeInsets.only(bottom: 25),
        //padding: EdgeInsets.all(22),
        decoration: BoxDecoration(
            color: Color.fromRGBO(255, 255, 255, 1.0),
            borderRadius: BorderRadius.circular(8)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Container(
              padding: EdgeInsets.only(left: 6),
              child: Text(
                'EMAIL US',
                style: TextStyle(
                    fontFamily: 'FSMatthew-Bold',
                    color: Color.fromRGBO(0, 43, 122, 1.0),
                    fontSize: 18,
                    letterSpacing: 0.79),
              ),
            ),
            Container(
              child: Column(
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Container(
                          padding: const EdgeInsets.all(0.0),
                          width: 28.0,
                          child: IconButton(
                              padding: EdgeInsets.only(
                                  top: 9.5,
                                  bottom: 10.5,
                                  right: 8.7,
                                  left: 7.7),
                              icon: new Icon(CustomIcon.email),
                              iconSize: 11.5,
                              color: Color.fromRGBO(0, 43, 122, 1.0),
                              onPressed: () => {})),
                      Container(
                          padding: EdgeInsets.only(left: 9),
                          child: Text(
                            'Email - ',
                            style: TextStyle(
                                fontFamily: 'FSMatthew-Light',
                                fontSize: 15,
                                letterSpacing: 0.66,
                                color: Color.fromRGBO(12, 35, 64, 1.0)),
                          )),
                      Text(
                        'askhr@bankfab.com',
                        style: TextStyle(
                            fontFamily: 'FSMatthew',
                            fontSize: 15,
                            letterSpacing: 0.66,
                            color: Color.fromRGBO(12, 35, 64, 1.0)),
                      )
                    ],
                  ),
                ],
              ),
            )
          ],
        ));
  }
}
