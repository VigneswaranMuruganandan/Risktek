import 'package:flutter/material.dart';
import '../utils/style.dart';
import '../common_widgets/labeled_checkbox.dart';
import '../common_widgets/custom_flatbutton.dart';

class AddAbsence extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _AddAbsenceState();
  }
}

class _AddAbsenceState extends State<AddAbsence> {
  final _formKey = new GlobalKey<FormState>();
  DateTime _date = new DateTime.now();
  List<String> _leaveTypes = [
    'Annual leave',
    'Maternity Leave',
    'Unpaid Leave',
    'Sick Leave'
  ];
  String _leaveType;
  bool _isCheckBoxSelected = false;

  _onChangedDropDown(String value) {
    setState(() {
      _leaveType = value;
    });
  }

  _onChangedCheckBox(bool value) {
    setState(() {
      _isCheckBoxSelected = value;
    });
  }

  _onSaveLaterPress() {}

  Future<Null> _selectedDate(BuildContext context) async {
    final DateTime picked = await showDatePicker(
        context: context,
        initialDate: _date,
        firstDate: new DateTime(2018),
        lastDate: new DateTime(2020));
    if (picked != null && picked != _date) {
      setState(() {
        _date = picked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Form(
        key: _formKey,
        child: Container(
          margin: EdgeInsets.symmetric(horizontal: 34),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              _labelText(context, 'Leave Type'),
              _customDropDown(context),
              SizedBox(
                height: 20,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Flexible(
                      child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      _labelText(context, 'Start Date'),
                      _customDatePicker(context),
                    ],
                  )),
                  SizedBox(
                    width: 20,
                  ),
                  Flexible(
                      child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      _labelText(context, 'End Date'),
                      _customDatePicker(context),
                    ],
                  )),
                ],
              ),
              LabeledCheckbox(
                label: 'Request salary advance',
                padding: EdgeInsets.symmetric(vertical: 20),
                value: _isCheckBoxSelected,
                onChanged: _onChangedCheckBox,
              ),
              Row(
                //mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Expanded(
                    flex: 3,
                    child: FlatButton(
                      onPressed: () {},
                      textColor: Color.fromRGBO(255, 255, 255, 1.0),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8)),
                      padding: EdgeInsets.symmetric(vertical: 17),
                      color: Color.fromRGBO(0, 43, 122, 1.0),
                      child: Text('Apply',
                          style: TextStyle(
                              fontSize: 16,
                              fontFamily: 'FSMatthew',
                              letterSpacing: 0.04)),
                    ),
                  ),
                  SizedBox(
                    width: 16,
                  ),
                  Expanded(
                    flex: 2,
                    child: FlatButton(
                      onPressed: () {},
                      textColor: Color.fromRGBO(0, 43, 122, 1.0),
                      shape: RoundedRectangleBorder(
                        side: BorderSide(
                            width: 1,
                            style: BorderStyle.solid,
                            color: Color.fromRGBO(0, 43, 122, 1.0)),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      padding: EdgeInsets.symmetric(vertical: 17),
                      child: Text('Discard',
                          style: TextStyle(
                              fontSize: 16,
                              fontFamily: 'FSMatthew',
                              letterSpacing: 0.04)),
                    ),
                  )
                ],
              ),
              /*  SizedBox(
                height: 30,
              ),
              Container(
                child: CustomFlatButton(
                  text: 'Save for Later',
                  padding: EdgeInsets.symmetric(vertical: 17),
                  textColor: Color.fromRGBO(2, 113, 218, 1.0),
                  onPress: _onSaveLaterPress,
                  borderColor: Color.fromRGBO(2, 113, 218, 1.0),
                  borderRadius: 8,
                  letterSpacing: 0.94,
                  fontSize: 16,
                  fontFamily: 'FSMatthew-Light',
                ),
              ) */
            ],
          ),
        ));
  }

  Container _customDropDown(BuildContext context) {
    return Container(
      decoration: InputFormDecoration,
      padding: EdgeInsets.only(left: 18, top: 10, bottom: 10, right: 8),
      child: DropdownButtonFormField(
        decoration: InputDecoration(
          border: InputBorder.none,
        ),
        value: _leaveType,
        onChanged: (String newValue) {
          _onChangedDropDown(newValue);
        },
        hint: Text('Select'),
        items: _leaveTypes.map((String value) {
          return DropdownMenuItem(
            value: value,
            child: Text(value),
          );
        }).toList(),
      ),
    );
  }

  Container _customDatePicker(BuildContext context) {
    return Container(
      decoration: InputFormDecoration,
      padding: EdgeInsets.fromLTRB(18, 10, 8, 10),
      child: GestureDetector(
        onTap: () {
          _selectedDate(context);
        },
        child: AbsorbPointer(
            child: Row(
          children: <Widget>[
            Flexible(
              child: TextFormField(
                initialValue: (_date.day.toString() +
                    ' ' +
                    _date.month.toString() +
                    ', ' +
                    _date.year.toString()),
                decoration: InputDecoration(border: InputBorder.none),
                keyboardType: null,
              ),
            ),
            Icon(
              Icons.calendar_today,
              size: 15,
              color: Color.fromRGBO(214, 218, 225, 1.0),
            )
          ],
        )),
      ),
    );
  }

  Container _labelText(BuildContext context, String label) {
    return Container(
      padding: EdgeInsets.only(left: 8, bottom: 10),
      child: Text(label, style: InputFormLabelStyle),
    );
  }
}
