import 'package:flutter/material.dart';

class ChatMessage extends StatelessWidget {
  ChatMessage({this.text, this.type});
  final String text;
  final String type;
  //static const String _name = "Your Name";
  @override
  Widget build(BuildContext context) {
    return new Container(
      margin: const EdgeInsets.symmetric(vertical: 10.0),
      child: new Row(
        //crossAxisAlignment: CrossAxisAlignment.end,
        children: type == 'SENDER'
            ? getSentMessageLayout()
            : getReceiveMessageLayout(),
      ),
    );
  }

  List<Widget> getSentMessageLayout() {
    return <Widget>[
      new Expanded(
        child: new Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: <Widget>[
            Container(
              margin: EdgeInsets.only(right: 20),
              padding: EdgeInsets.fromLTRB(22, 15, 17, 15),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(22),
                      topLeft: Radius.circular(22),
                      topRight: Radius.circular(22)),
                  gradient: LinearGradient(
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                    colors: <Color>[
                      Color.fromRGBO(0, 48, 135, 1.0),
                      Color.fromRGBO(0, 114, 218, 1.0)
                    ],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Color.fromRGBO(231, 239, 251, 1.0),
                      spreadRadius: 0.0,
                      blurRadius: 8,
                      offset: Offset(
                        0.0,
                        2.0,
                      ),
                    )
                  ]),
              child: Text(
                text,
                style: TextStyle(
                    fontFamily: 'Graphik-Regular',
                    fontSize: 14,
                    letterSpacing: 0.03,
                    color: Color.fromRGBO(255, 255, 255, 1.0)),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Container(
              margin: EdgeInsets.only(right: 20),
              child: Text(
                '11:50 AM',
                style: TextStyle(
                    fontFamily: 'Graphik-Regular',
                    fontSize: 12,
                    letterSpacing: 0.03,
                    color: Color.fromRGBO(185, 192, 202, 1.0)),
              ),
            ),
          ],
        ),
      ),
    ];
  }

  List<Widget> getReceiveMessageLayout() {
    return <Widget>[
      new Expanded(
        child: new Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Container(
              margin: EdgeInsets.only(left: 20),
              padding: EdgeInsets.fromLTRB(22, 15, 17, 15),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                      bottomRight: Radius.circular(22),
                      topLeft: Radius.circular(22),
                      topRight: Radius.circular(22)),
                  color: Color.fromRGBO(255, 255, 255, 1.0),
                  boxShadow: [
                    BoxShadow(
                      color: Color.fromRGBO(231, 239, 251, 1.0),
                      spreadRadius: 0.0,
                      blurRadius: 8,
                      offset: Offset(
                        0.0,
                        2.0,
                      ),
                    )
                  ]),
              child: Text(
                text,
                style: TextStyle(
                    fontFamily: 'Graphik-Regular',
                    fontSize: 14,
                    letterSpacing: 0.03,
                    color: Color.fromRGBO(12, 35, 64, 1.0)),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Container(
              margin: EdgeInsets.only(left: 20),
              child: Text(
                '11:50 AM',
                style: TextStyle(
                    fontFamily: 'Graphik-Regular',
                    fontSize: 12,
                    letterSpacing: 0.03,
                    color: Color.fromRGBO(185, 192, 202, 1.0)),
              ),
            ),
          ],
        ),
      ),
    ];
  }
}
