import 'package:fabhr/views/Chat/chatmessage.dart';
import 'package:flutter/material.dart';
import 'package:fabhr/utils/customIcon.dart';

class ChatBot extends StatefulWidget {
  @override
  State createState() => new ChatScreenState();
}

class ChatScreenState extends State<ChatBot> {
  final List<ChatMessage> _messages = <ChatMessage>[];
  final TextEditingController _textController = new TextEditingController();

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
        backgroundColor: Color.fromRGBO(246, 249, 252, 1.0),
        appBar: _buildAppBar(),
        body: Column(
          children: <Widget>[
            new Flexible(
              // child: Container(
              //margin: EdgeInsets.all(20),
              //padding: EdgeInsets.fromLTRB(22, 15, 17, 15),
              child: new ListView.builder(
                reverse: true,
                itemBuilder: (_, int index) => _messages[index],
                itemCount: _messages.length,
              ),
            ),
            _buildTextComposer()
            // Container(
            //child: _buildTextComposer(),
            // )
          ],
        ));
  }

  Widget _buildAppBar() {
    return AppBar(
      //automaticallyImplyLeading: true,
      title: Text(
        'Chatbot',
        style: TextStyle(
          color: Color.fromRGBO(255, 255, 255, 1.0),
          fontSize: 16,
          letterSpacing: 0,
          fontFamily: 'FSMatthew',
        ),
      ),
      centerTitle: true,
      flexibleSpace: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
            colors: <Color>[
              Color.fromRGBO(0, 94, 188, 1.0),
              Color.fromRGBO(0, 48, 135, 1.0)
            ],
          ),
        ),
      ),
      leading: IconButton(
        icon: Icon(CustomIcon.back,
            size: 18, color: Color.fromRGBO(185, 192, 202, 1.0)),
        color: Color.fromRGBO(122, 125, 128, 1.0),
        onPressed: () => Navigator.pop(context, false),
      ),
      actions: <Widget>[
        new IconButton(
          icon: Icon(CustomIcon.search,
              size: 18, color: Color.fromRGBO(185, 192, 202, 1.0)),
          padding: EdgeInsets.all(6.8),
          color: Color.fromRGBO(122, 125, 128, 1.0),
          onPressed: () => Navigator.of(context).pop(null),
        ),
      ],
    );
  }

  Widget _buildTextComposer() {
    return new Container(
      margin: const EdgeInsets.all(20),
      padding: EdgeInsets.only(left: 12),
      decoration: BoxDecoration(
          color: Color.fromRGBO(254, 255, 255, 1.0),
          borderRadius: BorderRadius.circular(19),
          border:
              Border.all(color: Color.fromRGBO(185, 192, 202, 1.0), width: 1)),
      child: new Row(
        children: <Widget>[
          new Flexible(
            child: new TextField(
              controller: _textController,
              onSubmitted: _handleSubmitted,
              decoration: new InputDecoration.collapsed(
                  hintText: "Message..",
                  hintStyle: TextStyle(
                      fontFamily: 'Graphik-Regular',
                      fontSize: 12,
                      letterSpacing: 0.03,
                      color: Color.fromRGBO(185, 192, 202, 1.0))),
            ),
          ),
          new Container(
            margin: new EdgeInsets.symmetric(horizontal: 10),
            child: new IconButton(
                icon: new Icon(
                  Icons.send,
                  size: 24,
                  color: Color.fromRGBO(185, 192, 202, 1.0),
                ),
                onPressed: () => _handleSubmitted(_textController.text)),
          ),
        ],
      ),
    );
  }

  void _handleSubmitted(String text) {
    _textController.clear();
    ChatMessage message = new ChatMessage(text: text, type: 'SENDER');
    ChatMessage message1 =
        new ChatMessage(text: 'hello how r u doing?', type: 'Receiver');
    setState(() {
      _messages.insert(0, message);
      _messages.insert(0, message1);
    });
  }
}
