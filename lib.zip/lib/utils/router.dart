const String APPROVALREQUESTS = "/approvalRequests";
const String CONTACTUS = "/contactUs";
const String APPLYLEAVE = "/applyLeave";
const String CHATBOT = "/chatBot";
