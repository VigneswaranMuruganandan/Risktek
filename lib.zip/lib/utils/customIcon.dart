import 'package:flutter/widgets.dart';

class CustomIcon {
  static const IconData approveRequisition = const _CustomIconData(0xe900);
  static const IconData contactUs = const _CustomIconData(0xe901);
  static const IconData logOut = const _CustomIconData(0xe902);
  static const IconData menuIcon = const _CustomIconData(0xe903);
  static const IconData notifications = const _CustomIconData(0xe904);
  static const IconData approveLeave = const _CustomIconData(0xe905);
  static const IconData approveExpenses = const _CustomIconData(0xe907);
  static const IconData notificationsRed = const _CustomIconData(0xe906);
  static const IconData search = const _CustomIconData(0xe908);
  static const IconData close = const _CustomIconData(0xe909);
  static const IconData contactUs1 = const _CustomIconData(0xe910);
  static const IconData email = const _CustomIconData(0xe911);
  static const IconData applyLeave = const _CustomIconData(0xe912);
  static const IconData back = const _CustomIconData(0xe913);
}

class _CustomIconData extends IconData {
  const _CustomIconData(int codePoint)
      : super(codePoint, fontFamily: 'customIcon');
}
