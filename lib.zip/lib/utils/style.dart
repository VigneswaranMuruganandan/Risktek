import 'package:flutter/material.dart';

const MenuGradient = BoxDecoration(
    gradient: LinearGradient(colors: [
  Color.fromRGBO(0, 114, 218, 1.0),
  Color.fromRGBO(0, 48, 135, 1.0)
], stops: [
  0,
  1
]));
const EmployeeName = TextStyle(
    color: const Color(0xffffffff),
    fontWeight: FontWeight.w500,
    fontFamily: "Graphik",
    fontStyle: FontStyle.normal,
    fontSize: 22.0);

const EmployeeRole = TextStyle(
    color: const Color.fromRGBO(255, 255, 255, 0.5),
    fontWeight: FontWeight.w500,
    fontFamily: "Graphik",
    fontStyle: FontStyle.normal,
    fontSize: 14.0);

const MenuText = TextStyle(
    color: const Color(0xffffffff),
    fontWeight: FontWeight.w500,
    fontFamily: "Graphik",
    fontStyle: FontStyle.normal,
    fontSize: 16.0);

const InputFormLabelStyle = TextStyle(
    fontSize: 12,
    fontFamily: 'FSMatthew',
    letterSpacing: 0.03,
    color: Color.fromRGBO(146, 148, 158, 1.0));

const InputFormDecoration = ShapeDecoration(
    color: Color.fromRGBO(255, 255, 255, 1.0),
    shape: RoundedRectangleBorder(
      side: BorderSide(
          width: 1.0,
          style: BorderStyle.solid,
          color: Color.fromRGBO(214, 218, 225, 1.0)),
      borderRadius: BorderRadius.all(Radius.circular(8)),
    ));

const CheckboxLabelStyle = TextStyle(
    color: Color.fromRGBO(146, 148, 158, 1.0),
    fontFamily: 'FSMatthew',
    letterSpacing: 0.03,
    fontSize: 15);

const LoginTextStyle1 = TextStyle(
    fontFamily: 'Graphik-Extralight',
    fontSize: 36,
    letterSpacing: 0.08,
    color: Color.fromRGBO(12, 35, 64, 1.0));
const LoginTextStyle2 = TextStyle(
    fontFamily: 'Graphik-Semibold',
    fontSize: 36,
    letterSpacing: 0.08,
    color: Color.fromRGBO(12, 35, 64, 1.0));
const LoginTextStyle3 = TextStyle(
    fontFamily: 'Graphik',
    fontSize: 17,
    letterSpacing: 0.04,
    color: Color.fromRGBO(100, 121, 149, 1.0));
const formHintTextStyle = TextStyle(
    fontFamily: 'FSMatthew',
    fontSize: 16,
    letterSpacing: 0.53,
    color: Color.fromRGBO(113, 123, 135, 1.0));
BoxDecoration inputBoxDecorationLogin = BoxDecoration(
    borderRadius: BorderRadius.only(
        bottomLeft: Radius.circular(6), bottomRight: Radius.circular(6)),
    border: Border.all(color: Color.fromRGBO(216, 221, 226, 1.0), width: 1));
