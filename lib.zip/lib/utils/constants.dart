import 'package:flutter/material.dart';
import 'package:fabhr/utils/style.dart';
import 'package:fabhr/utils/router.dart' as routingUrl;

const EdgeInsets employeeNamePadding = EdgeInsets.only(top: 66);
const Color SAVED = Color.fromRGBO(2, 113, 218, 1.0);
const Color PENDING = Color.fromRGBO(254, 183, 10, 1.0);
const Color COMPLETED = Color.fromRGBO(10, 191, 54, 1.0);
const Color WITHDRAWAL = Color.fromRGBO(245, 38, 16, 1.0);
