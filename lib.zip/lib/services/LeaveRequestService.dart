//import 'package:http/http.dart' as http;
import 'dart:async';
//import 'package:flutter_json/model/post_model.dart';
import 'dart:io';

class LeaveRequestService {
  /*Future<List<Leave>> getAllLeaves() async {
    final response = await http.get(url);
    print(response.body);
    return allLeavesFromJson(response.body);
  }*/
}