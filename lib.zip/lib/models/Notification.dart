class Notification {
  final String title;
  final String body;

  Notification(this.title, this.body);

}