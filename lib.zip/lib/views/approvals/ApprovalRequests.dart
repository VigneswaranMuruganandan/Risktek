import 'package:flutter/material.dart';
import './LeaveTemplate.dart';
import './RequisitionPage.dart';

class ApprovalRequests extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return new _ApprovalRequestsState();
  }
}

class _ApprovalRequestsState extends State<ApprovalRequests>
    with SingleTickerProviderStateMixin {
  static List<Leave> _leaves = [
    Leave('12', '26', 'Julia Holit', '7', 'DAYS', 'Jun', 'Jun', 'Unpaid Leave'),
    Leave(
        '06', '15', 'Sridhar A', '12', 'DAYS', 'Aug', 'Aug', 'Maternity Leave'),
    Leave('24', '28', 'Vigneswaran M', '2', 'WEEKS', 'Apr', 'Apr',
        'Vacation Leave'),
    Leave('12', '26', 'Julia Holit', '7', 'DAYS', 'Jun', 'Jun', 'Unpaid Leave'),
    Leave(
        '06', '15', 'Sridhar A', '12', 'DAYS', 'Aug', 'Aug', 'Maternity Leave'),
    Leave('24', '28', 'Vigneswaran M', '2', 'WEEKS', 'Apr', 'Apr',
        'Vacation Leave'),
    Leave('12', '26', 'Julia Holit', '7', 'DAYS', 'Jun', 'Jun', 'Unpaid Leave'),
    Leave(
        '06', '15', 'Sridhar A', '12', 'DAYS', 'Aug', 'Aug', 'Maternity Leave'),
    Leave('24', '28', 'Vigneswaran M', '2', 'WEEKS', 'Apr', 'Apr',
        'Vacation Leave'),
  ];

  static List<Requisition> _requisition = [
    Requisition('Manuel Roberson', 'FAB-BNK-234234', 'USD', '8700',
        'Joshi Mathew', 'Extension of SOW for IOS Arcthicect 1-Jun-19.....'),
    Requisition('Jessie Fields', 'FAB-BNK-234234', 'USD', '5300',
        'Joshi Mathew', 'Extension of SOW for IOS Arcthicect 1-Jun-19.....'),
    Requisition('Nathaniel Jenkins', 'FAB-BNK-234234', 'AED', '800',
        'Joshi Mathew', 'Extension of SOW for IOS Arcthicect 1-Jun-19.....')
  ];

//Leave(this.startDay,this.endDay,this.name,this.leaveNumber,this.leavePeriod,this.startMonth,this.endMonth,this.leaveType);

  // List<Tab> myTabs = <Tab>[
  //   Tab(child: LeaveTemplate(_leaves),text: 'Leave',),
  //   Tab(child: Text('Requisition'),text: 'Requisition',),
  //   Tab(child: Text('Expense'),text: 'Expense',)
  // ];

  TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(vsync: this, length: 3);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    List<Widget> children = new List();
    children.add(_buildAppBar());
    children.add(_buildApprovalRequestBody());
    return Scaffold(
      appBar: _buildAppBar(),
      body: _buildApprovalRequestBody(),
    );
  }

  Widget _buildAppBar() {
    return PreferredSize(
        preferredSize: Size.fromHeight(60),
        child: AppBar(
          automaticallyImplyLeading: true,
          title: Text('Approval Requests',
              style: TextStyle(
                  color: Color.fromRGBO(12, 35, 64, 1.0), letterSpacing: 0.44)),
          centerTitle: true,
          backgroundColor: Color.fromRGBO(255, 255, 255, 1.0),
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            iconSize: 24,
            color: Color.fromRGBO(122, 125, 128, 1.0),
            onPressed: () => Navigator.pop(context, false),
          ),
          actions: <Widget>[
            new IconButton(
              icon: new Icon(Icons.close),
              iconSize: 24,
              color: Color.fromRGBO(122, 125, 128, 1.0),
              onPressed: () => Navigator.of(context).pop(null),
            ),
          ],
        ));
  }

  Widget _buildApprovalRequestBody() {
    return Container(
        decoration: BoxDecoration(color: Color.fromRGBO(238, 243, 247, 1.0)),
        child: DefaultTabController(
            length: 3,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: <Widget>[
                Container(
                  margin: EdgeInsets.only(left: 20, right: 20, bottom: 27),
                  padding: EdgeInsets.only(bottom: 18, top: 12),
                  decoration: BoxDecoration(
                    borderRadius: new BorderRadius.circular(8),
                    gradient: LinearGradient(colors: [
                      Color.fromRGBO(0, 94, 188, 1.0),
                      Color.fromRGBO(0, 48, 135, 1.0)
                    ]),
                  ),
                  child: TabBar(
                    controller: _tabController,
                    labelStyle: TextStyle(
                        fontSize: 14,
                        fontFamily: 'FSMatthew',
                        letterSpacing: 0.03),
                    tabs: <Widget>[
                      Tab(text: 'Leave'),
                      Tab(text: 'Requistion'),
                      Tab(text: 'Expense')
                    ],
                  ),
                ),
                Expanded(
                  child: TabBarView(
                    controller: _tabController,
                    // children: myTabs.map((Tab tab) {
                    //   return tab.child;
                    // }).toList(),
                    children: <Widget>[
                      LeaveTemplate(_leaves),
                      RequisitionPage(_requisition),
                      Text('Expense')
                    ],
                  ),
                )
              ],
            )));
  }
}

class Leave {
  String startDay;
  String endDay;
  String name;
  String leaveNumber;
  String leavePeriod;
  String startMonth;
  String endMonth;
  String leaveType;
  Leave(this.startDay, this.endDay, this.name, this.leaveNumber,
      this.leavePeriod, this.startMonth, this.endMonth, this.leaveType);
}

class Requisition {
  String name;
  String id;
  String currency;
  String amount;
  String approver;
  String reason;
  Requisition(this.name, this.id, this.currency, this.amount, this.approver,
      this.reason);
}
