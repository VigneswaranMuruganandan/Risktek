<?php 
require_once '../model/customersModel.php';

function customerList(){
  $customer = new customersStores();
  $customerList = $customer->getall();
  return $customerList;
}

function insertCustomer($data){
	$customer = new customersStores();
	$status = $customer->insertCustomerRecord($data);
	switch($status) 
  {
    case 1:
      $msg = array('message' =>'data created successfully');
      break;
    case 2:
      $msg = array('message' =>'Error Message');
      break;
    case 3:
      $msg = array('message'=>$data['email'].'Category already available');
      break;
    default:
       $msg = array('message' => 'unavailable');
  }
	return $msg;
}

?>