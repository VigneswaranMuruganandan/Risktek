<?php 
	require_once '../model/productModel.php';

	function productList(){
	  $product = new productStores();
	  $productList = $product->getAll();
	  return $productList;
	}

	function productsQuantityList(){
	  $product = new productStores();
	  $productQunatityList = $product->getProductQunatityAll();
	  return $productQunatityList;
	}

	function insertProduct($data){
		$product = new productStores();
		$status = $product->insertProductRecord($data);
		switch($status) 
		{
		    case 1:
		      $msg = array('message' =>'data created successfully');
		      break;
		    case 2:
		      $msg = array('message' =>'Error Message');
		      break;
		    case 3:
		      $msg = array('message'=>$data['categoryDesc'].'Category already available');
		      break;
		    default:
		       $msg = array('message' => 'unavailable');
		}
		return $msg;
	}
?>