<?php 
require_once '../model/categoriesModel.php';

function categoryList(){
  $category = new categoriesStores();
  $categoryList = $category->getall();
  return $categoryList;
}

function insertCategory($data){
	$category = new categoriesStores();
	$status = $category->insertCategoryRecord($data);
	switch($status) 
  {
    case 1:
      $msg = array('message' =>'data created successfully');
      break;
    case 2:
      $msg = array('message' =>'Error Message');
      break;
    case 3:
      $msg = array('message'=>$data['categoryDesc'].'Category already available');
      break;
    default:
       $msg = array('message' => 'unavailable');
  }
	return $msg;
}
?>