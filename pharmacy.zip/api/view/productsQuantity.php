<?php
  require_once '../controller/productController.php';

  if(isset($_GET)){
  	$lists = productsQuantityList();
  	print json_encode($lists);
  }

?>