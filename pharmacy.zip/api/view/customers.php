<?php
  require_once '../controller/customersController.php';

  if(isset($_GET['type']) == 'LIST_CUSTOMER'){
  	$lists = customerList();
  	print json_encode($lists);
  }

  if(isset($_POST['type']) == 'ADD_CUSTOMER'){
  	$status = insertCustomer($_POST);
  	print json_encode($status);
  }

?>