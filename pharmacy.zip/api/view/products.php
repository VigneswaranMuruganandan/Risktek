<?php
  require_once '../controller/productController.php';

  if(isset($_GET['type']) == 'LIST_PRODUCT'){
  	$lists = productList();
  	print json_encode($lists);
  }

  if(isset($_POST['type']) == 'ADD_CATEGORY'){
  	$status = insertProduct($_POST);
  	print json_encode($status);
  }

?>