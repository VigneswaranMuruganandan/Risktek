<?php
  require_once '../controller/categoriesController.php';

  if(isset($_GET['type']) == 'LIST_CATEGORY'){
  	$lists = categoryList();
  	print json_encode($lists);
  }

  if(isset($_POST['type']) == 'ADD_CATEGORY'){
  	$status = insertCategory($_POST);
  	print json_encode($status);
  }

?>