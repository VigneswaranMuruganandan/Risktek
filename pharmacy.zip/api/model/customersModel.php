<?php
session_start();
function db_connect(){
    $localhost = "localhost";
    $username = "root";
    $password = "";
    $dbname = "pharmacy";

    $connect = new mysqli($localhost, $username, $password, $dbname);
    if($connect->connect_error) {
        die("connection failed : " . $connect->connect_error);
    }else {
      //echo "Successfully Connected";
    }
    return $connect;
}

class customersStores {
    public function getall(){
        $con = db_connect();
        $query="SELECT * FROM customers ORDER BY userId asc";
        $res_count =mysqli_query($con,$query);
        $result = $res_count->fetch_all(MYSQLI_ASSOC);
        return $result;
    }

    public function insertCustomerRecord($field) {
        $con = db_connect();
        $sql = "SELECT * FROM customers WHERE email= '".$field['email']."'";
        $res1 =  mysqli_query($con, $sql);
        $rec = $res1->fetch_all(MYSQLI_ASSOC);

        if(is_array($rec) && !empty($rec) )
        {
            return 3;
        }
        $insertData = "INSERT INTO customers(username, email, mobileNumber, createdOn, updatedOn) VALUES ('".$field['username']."','".$field['email']."','".$field['mobileNumber']."',curdate(),curdate())";
        if (mysqli_query($con,$insertData)) {
            return 1;     
        } else {
            return 2;     
        } 
        mysqli_close($con);
    }
} 
?>