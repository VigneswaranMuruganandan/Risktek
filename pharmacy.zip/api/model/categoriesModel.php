<?php
session_start();
function db_connect(){
    $localhost = "localhost";
    $username = "root";
    $password = "";
    $dbname = "pharmacy";

    $connect = new mysqli($localhost, $username, $password, $dbname);
    if($connect->connect_error) {
        die("connection failed : " . $connect->connect_error);
    }else {
      //echo "Successfully Connected";
    }
    return $connect;
}



class categoriesStores {
    public function getall(){
        $con = db_connect();
        $query="SELECT * FROM categories ORDER BY id asc";
        $res_count =mysqli_query($con,$query);
        $result = $res_count->fetch_all(MYSQLI_ASSOC);
        return $result;
    }

    public function insertCategoryRecord($field) {
        $con = db_connect();
        $sql = "SELECT * FROM categories WHERE categoryCode= '".$field['categoryCode']."'";
        $res1 =  mysqli_query($con, $sql);
        $rec = $res1->fetch_all(MYSQLI_ASSOC);

        if(is_array($rec) && !empty($rec) )
        {
            return 3;
        }
        $insertData = "INSERT INTO categories(categoryCode, categoryDesc, createdOn, updatedOn) VALUES ('".$field['categoryCode']."','".$field['categoryDesc']."',curdate(),curdate())";
        if (mysqli_query($con,$insertData)) {
            return 1;     
        } else {
            return 2;     
        } 
        mysqli_close($con);
    }
} 
?>