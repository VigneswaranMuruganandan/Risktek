<?php
session_start();
function db_connect(){
    $localhost = "localhost";
    $username = "root";
    $password = "";
    $dbname = "pharmacy";

    $connect = new mysqli($localhost, $username, $password, $dbname);
    if($connect->connect_error) {
        die("connection failed : " . $connect->connect_error);
    }else {
      //echo "Successfully Connected";
    }
    return $connect;
}



class productStores {
    public function getAll(){
        $con = db_connect();
        $query="SELECT p.*, c.categoryDesc FROM products p, categories c where c.id = p.categoryId ORDER BY p.id asc";
        $res_count =mysqli_query($con,$query);
        $result = $res_count->fetch_all(MYSQLI_ASSOC);
        return $result;
    }

    public function getProductQunatityAll(){
        $con = db_connect();
        $query="SELECT p.productDesc, c.categoryDesc, q.stockCount FROM products p, categories c, quantity q where c.id = p.categoryId and c.id = q.productId ORDER BY p.id asc";
        $res_count =mysqli_query($con,$query);
        $result = $res_count->fetch_all(MYSQLI_ASSOC);
        return $result;
    }

    public function insertProductRecord($field) {
        $con = db_connect();
        $sql = "SELECT * FROM products WHERE productCode= '".$field['productCode']."'";
        $res1 =  mysqli_query($con, $sql);
        $rec = $res1->fetch_all(MYSQLI_ASSOC);

        if(is_array($rec) && !empty($rec) )
        {
            return 3;
        }
        $insertData = "INSERT INTO products(productCode, productDesc, categoryId, createdOn, updatedOn) VALUES ('".$field['productCode']."','".$field['productDesc']."','".$field['categoryId']."',curdate(),curdate())";
        
        if (mysqli_query($con,$insertData)) {
            $last_id = mysqli_insert_id($con);
           $insertQData = "INSERT INTO quantity(categoryId, productId, stockCount) VALUES ('".$field['categoryId']."','".$last_id."','".$field['quantity']."')";
           if (mysqli_query($con,$insertQData)) {
            return 1;
           }else{
                return 2;     
           }
        } else {
            return 2;     
        } 
        mysqli_close($con);
    }
} 
?>