<!DOCTYPE html>
<html>
<head>
  <title>Categories</title>
  <link rel="stylesheet" type="text/css" href="./assets/css/style.css">
</head>
<body onload="fetchProducts();">

<ul>
  <li><a href="index.php">Home</a></li>
  <li><a class="active" href="product.php">Products</a></li>
  <li><a href="quantity.php">Quantity</a></li>
  <li><a href="customer.php">Customers</a></li>
</ul>

<div class="wrapper">
  <h2>Product List</h2>
  <button class="button fright" id="addProduct">Add New Product</button>
  <table class="users" id="productList">
    <thead>
      <tr>
        <th class="row-1">ID</th>
        <th class="row-4">Category Description</th>
        <th class="row-2">Product Code</th>
        <th class="row-3">Product Description</th>
      </tr>
    </thead>
    <tbody> </tbody>
  </table>
</div>
<div id="addProductModal" class="modal">
  <div class="modal-content">
    <span class="close">&times;</span>
    <h3>Add Product</h3>
    <div class="container">
      <form name="addProductForm" id="addProductForm">
        <label for="fname">Product code</label>
        <input type="text" name="productCode" placeholder="Your Product code..">
        
        <label for="lname">Product Description</label>
        <input type="text" name="productDesc" placeholder="Your Product Description..">
        
        <label for="country">Category</label>
        <select id="categoryListOption" name="categoryId">
          <option>Select Category</option>
        </select>
        
        <label for="lname">Quantity</label>
        <input type="text" name="productQuantity" placeholder="Your Product Quantity..">
        
        <input class="fright" type="button" value="Save" id="newProduct">
        <div class="clear"></div>
      </form>
    </div>
  </div>
</div>
<script
  src="https://code.jquery.com/jquery-3.4.1.min.js"
  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
  crossorigin="anonymous"></script>
<script type="text/javascript" src="./assets/js/script.js"></script>
</body>
</html>
