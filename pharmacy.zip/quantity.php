<!DOCTYPE html>
<html>
<head>
  <title>Quantity</title>
  <link rel="stylesheet" type="text/css" href="./assets/css/style.css">
</head>
<body onload="fetchProductQuantity();">

<ul>
  <li><a href="index.php">Home</a></li>
  <li><a href="product.php">Products</a></li>
  <li><a class="active" href="quantity.php">Quantity</a></li>
  <li><a href="customer.php">Customers</a></li>
</ul>

<div class="wrapper">
  <h2>Stocks available</h2>
  <table class="users" id="categoryList">
  <thead>
    <tr>
      <th class="row-4">Category Description</th>
      <th class="row-2">Product Description</th>
      <th class="row-3">Stocks Avaialble</th>
    </tr>
  </thead>
  <tbody> </tbody>
</table>
</div>
<script
  src="https://code.jquery.com/jquery-3.4.1.min.js"
  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
  crossorigin="anonymous"></script>
<script type="text/javascript" src="./assets/js/script.js"></script>
</body>
</html>
