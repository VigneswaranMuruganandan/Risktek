<!DOCTYPE html>
<html>
<head>
  <title>Categories</title>
  <link rel="stylesheet" type="text/css" href="./assets/css/style.css">
</head>
<body onload="fetchCustomers();">

<ul>
  <li><a href="index.php">Home</a></li>
  <li><a href="product.php">Products</a></li>
  <li><a href="quantity.php">Quantity</a></li>
  <li><a class="active" href="customer.php">Customers</a></li>
</ul>

<div class="wrapper">
  <h2>Customers List</h2>
  <button class="button fright" id="addCustomer">Add New Customer</button>
  <table class="users" id="customerList">
    <thead>
      <tr>
        <th class="row-1">UserID</th>
        <th class="row-2">UserName</th>
        <th class="row-3">Email</th>
        <th class="row-4">Mobile Number</th>
      </tr>
    </thead>
    <tbody> </tbody>
  </table>
</div>
<div id="addCustomerModal" class="modal">
  <div class="modal-content">
    <span class="close">&times;</span>
    <h3>Add Category</h3>
    <div class="container">
      <form name="addCustomerForm" id="addCustomerForm">
        <label for="fname">Customer Username</label>
        <input type="text" name="username" placeholder="Your UserName..">

        <label for="lname">Customer email</label>
        <input type="text" name="email" placeholder="Your email..">

        <label for="lname">Customer Mobilenumber</label>
        <input type="text" name="mobilenumber" placeholder="Your MobileNumber..">

        <input class="fright" type="button" value="Save" id="newCustomer">
        <div class="clear"></div>
      </form>
    </div>
  </div>
</div>
<script
  src="https://code.jquery.com/jquery-3.4.1.min.js"
  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
  crossorigin="anonymous"></script>
<script type="text/javascript" src="./assets/js/script.js"></script>
</body>
</html>
