-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 08, 2019 at 03:04 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pharmacy`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(200) NOT NULL,
  `categoryCode` varchar(500) NOT NULL,
  `categoryDesc` varchar(500) NOT NULL,
  `createdOn` date NOT NULL,
  `updatedOn` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `categoryCode`, `categoryDesc`, `createdOn`, `updatedOn`) VALUES
(1, 'CATEGORY_1', 'Category 1', '2019-09-08', '2019-09-08'),
(2, 'CATEGORY_2', 'Category 2', '2019-09-08', '2019-09-08'),
(3, 'CATEGORY_3', 'Category 3', '2019-09-08', '2019-09-08'),
(4, '', '', '2019-09-08', '2019-09-08');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `userId` int(11) NOT NULL,
  `username` varchar(500) NOT NULL,
  `email` varchar(200) NOT NULL,
  `mobileNumber` varchar(500) NOT NULL,
  `createdOn` date NOT NULL,
  `updatedOn` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`userId`, `username`, `email`, `mobileNumber`, `createdOn`, `updatedOn`) VALUES
(1, 'Anitha S', 'anitha@gmail.com', '7667082719', '0000-00-00', '0000-00-00'),
(2, 'vigneswaran', 'Vignesh.vigi.90@gmail.com', '', '2019-09-08', '2019-09-08');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(200) NOT NULL,
  `categoryId` int(200) NOT NULL,
  `productCode` varchar(500) NOT NULL,
  `productDesc` varchar(500) NOT NULL,
  `createdOn` date NOT NULL,
  `updatedOn` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `categoryId`, `productCode`, `productDesc`, `createdOn`, `updatedOn`) VALUES
(1, 1, '10372_4022167170415', 'vicks vaporub', '2019-09-08', '2019-09-08'),
(2, 1, '10372_4671704375984375', 'Axe Universal Oil 3ml', '2019-09-08', '2019-09-08'),
(3, 2, '10454_438758438574375', 'Tiger Balm White Ointment, 30g', '2019-09-08', '2019-09-08'),
(14, 1, '10372_4022167170419', 'Action500', '2019-09-08', '2019-09-08'),
(15, 2, '10372_4671704375984', 'Moov', '2019-09-08', '2019-09-08');

-- --------------------------------------------------------

--
-- Table structure for table `quantity`
--

CREATE TABLE `quantity` (
  `categoryId` int(200) NOT NULL,
  `productId` int(200) NOT NULL,
  `stockCount` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quantity`
--

INSERT INTO `quantity` (`categoryId`, `productId`, `stockCount`) VALUES
(1, 1, 20),
(1, 2, 30),
(1, 14, 25),
(2, 15, 52);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`userId`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `userId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
