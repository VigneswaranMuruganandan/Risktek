var modal,span;

function fetchCategories(){
	$.ajax({
	  url: "./api/view/categories.php",
	  dataType: "json",
	  type: "GET",
	  data: {"type": "LIST_CATEGORY"},
	  success: function(data) {
	  	var rowData = '';
        for(var i=0;i<data.length;i++){
        	rowData = rowData+ "<tr><td>"+data[i].id+"</td><td>"+data[i].categoryCode+"</td><td>"+data[i].categoryDesc+"</td><td></td><tr>";
        }
        $('#categoryList tbody').append(rowData);
      }
	});
}

$('#newCategory').click(function(){
	var data = {
		"type": "ADD_CATEGORY",
		"categoryCode": $('#addCategoryForm').find('input[name="categoryCode"]').val(),
		"categoryDesc":$('#addCategoryForm').find('input[name="categoryDesc"]').val() 
	};
	$.ajax({
	  url: "./api/view/categories.php",
	  dataType: "json",
	  data: data,
	  type: "POST",
	  success: function(data) {
	  	modal.style.display = "none";
      }
	});
});

$('#addCategory').click(function(){
	modal = document.getElementById("addCategoryModal");
	modal.style.display = "block";
});

$('#addProduct').click(function(){
	modal = document.getElementById("addProductModal");
	modal.style.display = "block";
});




$('span.close').bind("click", function() { 
    modal.style.display = "none";
}); 

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}

function fetchProducts(){
	$.ajax({
	  url: "./api/view/products.php",
	  dataType: "json",
	  type: "GET",
	  data: {"type": "LIST_PRODUCT"},
	  success: function(data) {
	  	var rowData = '';
        for(var i=0;i<data.length;i++){
        	rowData = rowData+ "<tr><td>"+data[i].id+"</td><td>"+data[i].categoryDesc+"</td><td>"+data[i].productCode+"</td><td>"+data[i].productDesc+"</td><tr>";
        }
        $('#productList tbody').append(rowData);
      }
	});

	$.ajax({
	  url: "./api/view/categories.php",
	  dataType: "json",
	  type: "GET",
	  data: {"type": "LIST_CATEGORY"},
	  success: function(data) {
	  	$.each(data, function (i, item) {
		    $('#categoryListOption').append($('<option>', { 
		        value: item.id,
		        text : item.categoryDesc 
		    }));
		});
      }
	});
}

$('#newProduct').click(function(){
	var data = {
		"type": "ADD_PRODUCT",
		"productCode": $('#addProductForm').find('input[name="productCode"]').val(),
		"productDesc":$('#addProductForm').find('input[name="productDesc"]').val(),
		"categoryId": $('#addProductForm').find('select[name="categoryId"]').val(),
		"quantity":$('#addProductForm').find('input[name="productQuantity"]').val() 
	};
	$.ajax({
	  url: "./api/view/products.php",
	  dataType: "json",
	  data: data,
	  type: "POST",
	  success: function(data) {
	  	modal.style.display = "none";
      }
	});
});

function fetchProductQuantity(){
	$.ajax({
	  url: "./api/view/productsQuantity.php",
	  dataType: "json",
	  type: "GET",
	  success: function(data) {
	  	var rowData = '';
        for(var i=0;i<data.length;i++){
        	rowData = rowData+ "<tr><td>"+data[i].categoryDesc+"</td><td>"+data[i].productDesc+"</td><td>"+data[i].stockCount+"</td><tr>";
        }
        $('#categoryList tbody').append(rowData);
      }
	});
}

function fetchCustomers(){
	$.ajax({
	  url: "./api/view/customers.php",
	  dataType: "json",
	  type: "GET",
	  data: {"type": "LIST_CUSTOMER"},
	  success: function(data) {
	  	var rowData = '';
        for(var i=0;i<data.length;i++){
        	rowData = rowData+ "<tr><td>"+data[i].userId+"</td><td>"+data[i].username+"</td><td>"+data[i].email+"</td><td>"+data[i].mobileNumber+"</td><tr>";
        }
        $('#customerList tbody').append(rowData);
      }
	});
}


$('#addCustomer').click(function(){
	modal = document.getElementById("addCustomerModal");
	modal.style.display = "block";
});


$('#newCustomer').click(function(){
	var data = {
		"type": "ADD_CUSTOMER",
		"username": $('#addCustomerForm').find('input[name="username"]').val(),
		"email":$('#addCustomerForm').find('input[name="email"]').val(),
		"mobileNumber": $('#addCustomerForm').find('input[name="mobilenumber"]').val()
	};
	$.ajax({
	  url: "./api/view/customers.php",
	  dataType: "json",
	  data: data,
	  type: "POST",
	  success: function(data) {
	  	modal.style.display = "none";
      }
	});
});