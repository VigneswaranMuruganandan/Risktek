import 'package:flutter/material.dart';
import './ApprovalRequests.dart';

class RequisitionPage extends StatelessWidget {

  final List<Requisition> requisitions;

  RequisitionPage(this.requisitions);
  @override
  Widget build(BuildContext context) {
    return Container(
        child: Container(
          margin: EdgeInsets.only(left:20,right:20),
          child: Column(
            children:requisitions.map((element)=>requisitionDetailRow(element)).toList()
          ),
    ));
  }
}

Container requisitionDetailRow(Requisition requisition){
  return Container(
      padding: EdgeInsets.only(top:8,right: 8,left:13,bottom:10),
      margin: EdgeInsets.only(bottom: 20),
      decoration: BoxDecoration(color: Color.fromRGBO(255, 255, 255, 1.0),borderRadius: BorderRadius.circular(8)),
      child: Column(
        children: <Widget>[
          Row(
            children: <Widget>[
              _rowNameDisplay(requisition.name,requisition.id),
              _rowExpenseDisplay(requisition.currency,requisition.amount)
            ],
          ),
          Row(
            children: <Widget>[
              _requisitionDescription(requisition.approver,requisition.reason)
            ],
          ),
        ],
      )
  );
}
  
Expanded _rowNameDisplay(String name, String id) {
  return Expanded(
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Container(
          padding: EdgeInsets.only(bottom:6,top:7),
          child: Text(
            name,
            style:TextStyle(
              fontSize: 18,
              fontFamily: 'FSMatthew-Medium',
              letterSpacing: 0.04,
              color: Color.fromRGBO(12 ,35 ,64, 1.0)
            )
          ),
        ),
        Text(
          id,
          style: TextStyle(
              fontSize: 13,
              fontFamily: 'FSMatthew',
              letterSpacing: 0.03,
              color: Color.fromRGBO(10 ,189 ,28, 1.0)),
        ),
      ],
    ),
  );
}

Column _rowExpenseDisplay(String currency,String amount){
  return  Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: <Widget>[
          Icon(Icons.info,color:Color.fromRGBO(238 ,243 ,247, 1.0),size: 17,),
          Container(
            padding: EdgeInsets.only(right:12,top:7),
            child: Row(
              children: <Widget>[
                Text(
                  'USD',
                  textAlign: TextAlign.right,
                  style:TextStyle(
                    fontSize: 20,
                    letterSpacing: 0.04,
                    fontFamily: 'FSMatthew-Light',
                    color: Color.fromRGBO(2 ,113 ,218, 1.0)),
                ),
                Text(
                  '8700',
                  textAlign: TextAlign.right,
                  style:TextStyle(
                    fontSize: 20,
                    letterSpacing: 0.04,
                    fontFamily: 'FSMatthew-Light',
                    color: Color.fromRGBO(2 ,113 ,218, 1.0)),
                )
              ],
            ),
          )
        ],
      );
}

Expanded _requisitionDescription(String approvedBy, String reason) {
  return Expanded(
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Container(
          padding: EdgeInsets.only(bottom:6,top:8),
          child: Text(
            'Last Approved By '+approvedBy,
            style:TextStyle(
              fontSize: 10,
              fontFamily: 'FSMatthew-Italic',
              letterSpacing: 0.02,
              color: Color.fromRGBO(12 ,35 ,64, 1.0)
            )
          ),
        ),
        Text(
          reason,
          style: TextStyle(
              fontSize: 12,
              fontFamily: 'FSMatthew',
              letterSpacing: 0.03,
              color: Color.fromRGBO(100 ,121 ,149, 1.0)),
        ),
      ],
    ),
  );
}
