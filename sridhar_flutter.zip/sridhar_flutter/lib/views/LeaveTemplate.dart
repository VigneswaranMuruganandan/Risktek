import 'package:flutter/material.dart';
import './ApprovalRequests.dart';

class LeaveTemplate extends StatelessWidget {
  final List<Leave> leaves;
  LeaveTemplate(this.leaves);
  @override
  Widget build(BuildContext context) {
    return Column(
      children: leaves.map((element) => _leaveDetailRow(element)).toList(),
    );
  }

  Container _leaveDetailRow(Leave leave) {
    return Container(
      height: 90,
      padding: EdgeInsets.all(10),
      margin: EdgeInsets.only(bottom: 20, left: 20, right: 20),
      decoration: BoxDecoration(
        color: Color.fromRGBO(255, 255, 255, 1.0),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: <Widget>[
          _dateDisplay('Start Date', leave.startDay, leave.startMonth),
          _dash(),
          _dateDisplay('End Date', leave.endDay, leave.endMonth),
          Expanded(child: _leaveDescription(leave.name, leave.leaveType)),
          _totalLeave(leave.leaveNumber, leave.leavePeriod)
        ],
      ),
    );
  }

  Container _dateDisplay(String label, String day, String month) {
    return Container(
      height: 57,
      width: 57,
      decoration: BoxDecoration(
        color: Color.fromRGBO(246, 249, 252, 1.0),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: <Widget>[
          Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
                fontSize: 8,
                letterSpacing: 0.02,
                color: Color.fromRGBO(100, 121, 149, 1.0)),
          ),
          Text(
            day,
            textAlign: TextAlign.center,
            style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                letterSpacing: 0.04,
                color: Color.fromRGBO(2, 113, 218, 1.0)),
          ),
          Text(
            month,
            textAlign: TextAlign.center,
            style: TextStyle(
                fontSize: 12,
                letterSpacing: 0.03,
                color: Color.fromRGBO(2, 113, 218, 1.0)),
          ),
        ],
      ),
    );
  }

  Container _dash() {
    return Container(
        child: Column(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: <Widget>[
        Container(
          height: 4,
          width: 7,
          decoration: BoxDecoration(
            color: Color.fromRGBO(238, 243, 247, 1.0),
            borderRadius: BorderRadius.circular(4),
          ),
        ),
      ],
    ));
  }

  Container _leaveDescription(String name, String description) {
    return Container(
      margin: EdgeInsets.only(left: 9),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            //padding: const EdgeInsets.only(bottom: 8),
            child: Text(
              name,
              style: TextStyle(
                  fontSize: 18,
                  letterSpacing: 0.04,
                  fontWeight: FontWeight.bold,
                  color: Color.fromRGBO(12, 35, 64, 1.0)),
            ),
          ),
          Text(
            description,
            style: TextStyle(
                fontSize: 13,
                letterSpacing: 0.03,
                color: Color.fromRGBO(100, 121, 149, 1.0)),
          ),
        ],
      ),
    );
  }

  Container _totalLeave(String leaveNumber, String leavePeriod) {
    return Container(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: <Widget>[
          Container(
            margin: EdgeInsets.only(bottom: 5),
            padding: EdgeInsets.all(5),
            decoration: BoxDecoration(
              color: Color.fromRGBO(246, 249, 252, 1.0),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              leaveNumber + ' ' + leavePeriod,
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontSize: 10,
                  letterSpacing: 0.02,
                  color: Color.fromRGBO(10, 189, 28, 1.0)),
            ),
          ),
        ],
      ),
    );
  }
}

// class Leave {
//   String startDay;
//   String endDay;
//   String name;
//   String leaveNumber;
//   String leavePeriod;
//   String startMonth;
//   String endMonth;
//   String leaveType;
//   Leave(this.startDay,this.endDay,this.name,this.leaveNumber,this.leavePeriod,this.startMonth,this.endMonth,this.leaveType);
// }
