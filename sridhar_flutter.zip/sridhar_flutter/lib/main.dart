import 'package:flutter/material.dart';
import 'package:fabhr/views/HomeView.dart';
import 'package:fabhr/views/ApprovalRequests.dart';
import 'package:flutter/services.dart';
import './views/ApplyLeave.dart';

void main() {
  SystemChrome.setPreferredOrientations(
      [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
  return runApp(new MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      title: 'FAB HR',
      theme: new ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: new HomeView(),
      routes: <String, WidgetBuilder>{
        '/approvalRequests': (BuildContext context) => new ApprovalRequests(),
        '/applyLeave': (BuildContext context) => new ApplyLeave()
      },
    );
  }
}
