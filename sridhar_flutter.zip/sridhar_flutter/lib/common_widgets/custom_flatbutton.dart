import 'package:flutter/material.dart';
import '../utils/style.dart';

class CustomFlatButton extends StatelessWidget {
  const CustomFlatButton({
    this.text,
    this.padding,
    this.textColor,
    this.onChanged,
  });

  final String text;
  final EdgeInsets padding;
  final Color textColor;
  final Function onChanged;

  @override
  Widget build(BuildContext context) {
    return InkWell();
  }
}
