import { Component, OnInit, Input, Output, EventEmitter, ViewChild, OnDestroy } from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { ErrorService} from '../../shared/services/error.service';
import { SharedService } from '../../shared/services/shared.service';

@Component({
  templateUrl: './../templates/baseCreateIsave.html'
})
export class BaseCreateIsaveComponent implements OnInit {
	public stepValue: number;
	
	constructor( private errorService: ErrorService,
				 private sharedService: SharedService){}

	ngOnInit() {
        this.stepValue = 1;
    }

    createIsaveAccount(){
    	this.stepValue = 2;
    }

    submitIsaveAccount(){
    	this.stepValue = 3;
    }
}