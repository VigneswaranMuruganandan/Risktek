import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  templateUrl: './../templates/viewSavingsPlan.html'
})
export class ViewSavingsPlanComponent implements OnInit {

	ngOnInit() { 
    	//test
    }
   
}