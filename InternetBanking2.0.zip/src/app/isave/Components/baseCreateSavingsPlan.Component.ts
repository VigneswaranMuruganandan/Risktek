import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  templateUrl: './../templates/baseCreateSavingsPlan.html'
})
export class BaseCreateSavingsPlanComponent implements OnInit {

	ngOnInit() { 
    	//test
    }
   
}