import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'createSavingsPlanReview-component',
  templateUrl: './../templates/createSavingsPlanReview.html'
})
export class CreateSavingsPlanReviewComponent implements OnInit {

	ngOnInit() { 
    	//test
    }
}