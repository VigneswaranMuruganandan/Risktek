import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'createSavingsPlanSuccess-component',
  templateUrl: './../templates/createSavingsPlanSuccess.html'
})
export class CreateSavingsPlanSuccessComponent implements OnInit {

	ngOnInit() { 
    	//test
    }
}