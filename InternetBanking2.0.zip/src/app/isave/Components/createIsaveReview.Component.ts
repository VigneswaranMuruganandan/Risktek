import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { ErrorService} from '../../shared/services/error.service';

@Component({
  selector: 'createIsaveReview-component',
  templateUrl: './../templates/createIsaveReview.html'
})
export class CreateIsaveReviewComponent{
	@Output() submitIsaveAccountEvent = new EventEmitter();

	constructor( private errorService: ErrorService ){}

	confirmIsave() {
		this.submitIsaveAccountEvent.emit();
	}

}