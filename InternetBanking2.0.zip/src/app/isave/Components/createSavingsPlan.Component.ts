import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'createSavingsPlan-component',
  templateUrl: './../templates/createSavingsPlan.html'
})
export class CreateSavingsPlanComponent implements OnInit {

	ngOnInit() { 
    	//test
    }
   
}