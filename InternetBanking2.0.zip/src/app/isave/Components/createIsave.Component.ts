import { Component, OnInit, Input, Output, EventEmitter, ViewChild, OnDestroy } from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { ErrorService} from '../../shared/services/error.service';
import { SharedService } from '../../shared/services/shared.service';

@Component({
  selector: 'createIsave-component',
  templateUrl: './../templates/createIsave.html'
})
export class CreateIsaveComponent{
	@Output() createIsaveAccountEvent = new EventEmitter();

	constructor( private errorService: ErrorService,
				 private sharedService: SharedService){}

	createiSave(){
		this.createIsaveAccountEvent.emit();
	}
}