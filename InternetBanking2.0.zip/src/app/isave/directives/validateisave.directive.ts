import { Component, ElementRef, Directive, HostListener, NgZone, Input, Output, EventEmitter } from '@angular/core';
import * as $ from 'jquery';
import {TemplateService} from '../../shared/services/template.service';
import 'app/assets/js/jquery.validate.js';
/*
* Customer Identification validation for Registration
*/
/*@Directive({
    selector: '[ValidateRegisterDirective]',
})
export class ValidateCustomerIdentificationRegister {
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let registrationCusIDValidationSubmit;
        this.zone.runOutsideAngular(() => {
            var registrationCusIDValidation = (<any>$("#registrationCusIDForm")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    customerIdentificationNo: {
                        required: true
                    }
                },
                messages: {
                    customerIdentificationNo: {
                        required: "Please enter Customer Identification Number"
                    }
                }
            });
            registrationCusIDValidationSubmit = registrationCusIDValidation.form();
            this.templateService.setFormValidatorFlag(registrationCusIDValidationSubmit);
        });
    }
}
*/