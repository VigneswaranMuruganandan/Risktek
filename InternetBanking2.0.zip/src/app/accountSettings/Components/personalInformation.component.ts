import { Component, OnInit, Input} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { TemplateService } from '../../shared/services/template.service';
import { AccountSettingsService } from '../services/accountSettings.service';
import { APIResponse } from '../../shared/model/apiResponse';
import { ErrorService } from '../../shared/services/error.service';
import { SharedService } from '../../shared/services/shared.service';
import {SpinnerService } from '../../shared/services/spinner.service';
import { UserContext} from '../../shared/model/userContext';

@Component({
  selector: 'personalinformation-component',
  templateUrl: './../templates/personalInformation.html'
})
export class PersonalInformationComponent implements OnInit{
	@Input() userProfileDetails:any;
	email : string;
	editEmail : boolean;

	constructor( private templateService: TemplateService,
				 private errorService: ErrorService,
				 private sharedService: SharedService,
				 private accountSettingsService: AccountSettingsService,
				 private spinnerService: SpinnerService) {}

	ngOnInit() {
        this.email = this.userProfileDetails.email;
        this.editEmail = false;
    }
    /*
    * Edit the Email by the customer.
    */
	editUserEmailId(){		
		this.email = this.userProfileDetails.unmaskedEmail;
		this.editEmail = true;
	}
	/*
	* Cancel the edit option for editing the Email ID
	*/
	cancelUserEmailId(){
		(<any>$("#personalInfoForm")).validate().resetForm();
		this.email = this.userProfileDetails.email;
		this.editEmail = false;
	}
	/*
	* Save the Updated Email ID 
	*/
	saveEamilId(valid: boolean){		
		if(valid){
			this.spinnerService.startSpinner('loader');
			this.errorService.resetErrorResp();
			let data = { "email":this.email };
			this.accountSettingsService.updateEmailID(data)
	        .subscribe(
	           resp => this.handleUpdateEmailIDResp(resp),
	           error => this.sharedService.handleError(error) 
	        );
		}		
	}
	/*
	* Handle the response of save email
	*/
	handleUpdateEmailIDResp(resp: any){
		this.spinnerService.stopSpinner('loader');
		if(resp && resp.result.status == 'success'){
            let userContext = UserContext.getInstance().userDetails;
            userContext.email = resp.email;
            userContext.unmaskedEmail = resp.unmaskedEmail;
            this.editEmail = false;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
	}
}