import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AccountSettingsComponent } from './Components/accountSettings.component';
import { AuthGuard } from '../auth-guard.service';

const routes: Routes = [
    {
        path: '',
        component: AccountSettingsComponent,
        canActivate: [AuthGuard]
    },
    {
        path: '',
        redirectTo: '',
        pathMatch: 'full'
    }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
