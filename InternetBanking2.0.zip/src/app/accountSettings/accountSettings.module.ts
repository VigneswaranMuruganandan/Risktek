import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { routing } from './accountSettings.routing';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '../shared/shared.module';
import {SharedService} from '../shared/services/shared.service';
import {TemplateService} from '../shared/services/template.service';
import { FormsModule } from '@angular/forms';
import { AccountSettingsComponent }   from './Components/accountSettings.component';

import { PersonalInformationComponent }   from './Components/personalInformation.component';
import { MyAccountsComponent }   from './Components/myAccounts.component';
import { MyCardsComponent }   from './Components/myCards.component';
import { MyAlertsComponent }   from './Components/myAlerts.component';
import { AlertCentreComponent }   from './Components/alertCentre.component';
import { EStatementModalComponent }   from './Components/estatementModal.component';
import {AccountsService} from '../accounts/services/accounts.service';
import {AccountSettingsService} from './services/accountSettings.service';

import { 
  ValidatePersonalInfo
} from './directives/validateAccountSettings.directive';

const ACCOLUNTSETTINGS_COMPONENTS = [
    AccountSettingsComponent,
    PersonalInformationComponent,
    MyAccountsComponent,
    MyCardsComponent,
    MyAlertsComponent,
    AlertCentreComponent,
    EStatementModalComponent
];

const ACCOLUNTSETTINGS_PROVIDERS = [
   SharedService,
   TemplateService,
   AccountsService,
   AccountSettingsService
];

const ACCOLUNTSETTINGS_DIRECTIVES = [
    ValidatePersonalInfo
];

@NgModule({
  	imports: [
	    routing,
	    TranslateModule.forChild(),
	    SharedModule,
	    FormsModule,
      CommonModule
	],
  	declarations: [
	    ...ACCOLUNTSETTINGS_COMPONENTS,
	    ...ACCOLUNTSETTINGS_DIRECTIVES
	],
  	providers: [
  		...ACCOLUNTSETTINGS_PROVIDERS
  	]
})
export class AccountSettingsModule {}
