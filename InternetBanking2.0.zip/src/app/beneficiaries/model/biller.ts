
export class Biller{
	
  templateId:string;
  billerId:string;
  billerName:string;
  consumerNo:string;
  description:string;

}

