import { Component, OnInit, Input, ViewChild} from '@angular/core';
import { Router } from '@angular/router';
import { BeneficiariesService} from '../services/beneficiaries.service';
import { SharedService} from '../../shared/services/shared.service';
import {TemplateService} from '../../shared/services/template.service';
import {BeneListResp} from '../model/beneListResp';
import {Beneficiary} from '../model/beneficiary';
import { ErrorService } from '../../shared/services/error.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { GlobalVariable} from '../../shared/services/global';
import * as $ from 'jquery';

@Component({
  selector: 'beneficiaries-transfers',
  templateUrl: './../templates/beneficiariesTransfers.html'
})
export class BeneficiariesTransfersComponent implements OnInit{

  @ViewChild('table') tableElem: any;
  beneListResp:BeneListResp;
  transferTypes:any;
  temp: any = [];
  rows: any = [];
  beneficiary:Beneficiary;

  constructor(private beneficiariesService:BeneficiariesService,
              private sharedService: SharedService,
              public templateService: TemplateService,
              private errorService: ErrorService,
              private spinnerService: SpinnerService,
              private router: Router) {}

	ngOnInit() { 
      this.spinnerService.startSpinner('loader');
      this.getBeneTransferList();
      this.errorService.resetErrorResp();
      this.transferTypes = GlobalVariable.TRANSFER_TYPE_DESCRIPTION;
    
    }


  getBeneTransferList(){
      this.beneficiariesService.fetchBeneTransferList()
        .subscribe(
            resp => this.handleBeneTransferResp(resp),
            error => this.sharedService.handleError(error)
        );
  }

  handleBeneTransferResp(resp:BeneListResp){
      this.spinnerService.stopSpinner('loader');
      if (resp.result.status == "success") {
          this.beneListResp = new BeneListResp();
          this.beneListResp = resp;
          this.initTableData(resp);
      }else if (resp.result.status == 'error') {
          this.errorService.setErrorResp(resp.result);
      }
  }

  initTableData(beneList:BeneListResp){
      this.rows=beneList.beneficiaryList;
      this.temp=beneList.beneficiaryList;
      this.tableElem.offset = 0;
  }

  beneTypeSelection(event,beneType:string){
    if(beneType!=="ALL"){
        this.beneListResp.beneficiaryList = this.temp.filter(beneItem => 
                                                beneItem.type == beneType);
        this.rows = this.beneListResp.beneficiaryList;
        $( "#filterDropDown" ).html(event.currentTarget.text);
        this.tableElem.offset = 0;
    }else{
      this.beneListResp.beneficiaryList = this.temp;
      this.rows = this.beneListResp.beneficiaryList;
      $( "#filterDropDown" ).html(event.currentTarget.text);
      this.tableElem.offset = 0;
    }
  }

  listView(event){
    $('#grid-filter').show();
    $(event.currentTarget).hide();
    $('.grid-wrapper').hide();
    $('.list-wrapper').show();
  }

  gridView(event){
    $('#list-filter').show();
    $(event.currentTarget).hide();
    $('.grid-wrapper').show();
    $('.list-wrapper').hide();
  }

  detailDrawer(event,bene:Beneficiary){
    this.beneficiary = new Beneficiary();
    this.beneficiary = bene;
    $('#info-drawer').toggleClass('slider-drawer-closed');
    $(event.currentTarget).toggleClass('active');
    
  };
  closeDrawer(){
    $('#info-drawer').toggleClass('slider-drawer-closed');
    $('.grid-view').removeClass('active');
  };

  addBeneficiary(beneType:string){
        this.router.navigate(['/beneficiaries/'+beneType]);
        this.templateService.setBeneAddType(GlobalVariable.BENE_ADD_TYPE.BENE_ADD_WITHOUT_TRANSFER)
    }
}