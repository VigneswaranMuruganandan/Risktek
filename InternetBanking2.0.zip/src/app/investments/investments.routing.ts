import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ApplyProductComponent }   from './Components/applyProduct.component';
import { InvestmentsMainComponent }   from './Components/investmentsMain.component';
import { AuthGuard } from '../auth-guard.service';

const routes: Routes = [   
    {
        path: '',
        component: InvestmentsMainComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'applyProducts',
        component: ApplyProductComponent,
        canActivate: [AuthGuard]
    },
    {
        path: '',
        redirectTo: '',
        pathMatch: 'full'
    }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
