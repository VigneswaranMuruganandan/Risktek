import { Component,EventEmitter,Output  } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';


@Component({
  selector: 'investmentsDetails-component',
  templateUrl: './../templates/investmentsDetails.html'
})
export class InvestmentsDetailsComponent {
@Output() nextToAboutUsEvent = new EventEmitter();
@Output() ourProductsEvent = new EventEmitter();
   
   
    nextToAboutUs(){
    	this.nextToAboutUsEvent.emit();
    }
    ourProducts(){
    	this.ourProductsEvent.emit();
    }

}