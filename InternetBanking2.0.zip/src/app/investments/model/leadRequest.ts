export class LeadRequest{
	emirates : string;
	phoneNumber : string;
	email : string;
	products: string [];
	name: string;
}
