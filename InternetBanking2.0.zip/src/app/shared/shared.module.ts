import { NgModule } from '@angular/core';
import { CommonModule, DecimalPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpModule, JsonpModule } from '@angular/http';
import { TranslateModule } from '@ngx-translate/core';
import { SharedService} from './services/shared.service';
import { TemplateService} from './services/template.service';
import { ErrorService} from './services/error.service';
import { SpinnerService} from './services/spinner.service';
import { EncryptionService} from './services/encryption.service';
import { ServiceInvoker} from './connector/serviceInvoker.service';
import { GlobalVariable} from './services/global';
import { ErrorComponent }   from './Components/error.component';
import { LoginHeaderComponent }   from './Components/loginHeader.component';
import { LoginFooterComponent }   from './Components/loginFooter.component';
import { CommonHeaderComponent }   from './Components/commonHeader.component';
import { RegisterFooterComponent }   from './Components/registerFooter.component';
import { ForgotPasswordFooterComponent }   from './Components/forgotPasswordFooter.component';
import { DashboardHeaderComponent }   from './Components/dashboardHeader.component';
import { DashboardFooterComponent }   from './Components/dashboardFooter.component';
import { SearchHeaderComponent }   from './Components/searchHeader.component';
import { AccountSettingsHeaderComponent }   from './Components/accountSettingsHeader.component';
import { NavigationComponent }   from './Components/navigation.component';
import { BaseViewComponent }   from './Components/baseView.component';
import { MultipleLoginSessionComponent }   from './Components/multipleLoginSession.component';
import { DownloadMobileAppComponent }   from './Components/downloadMobileApp.component';
import { OfferCategoriesComponent }   from './Components/offerCategories.component';
import {
  SlickCarouselComponent, 
  SlickCarouselItem, 
  SlickCarouselDestroy, 
  SlickCarouselInit,
  SlickCarouselPause,
  SlickCarouselPlay,
  SlickCarouselRefresh,
  SlickCarouselResize
} from './Components/slickCarousel.component'
import { OTPComponent, OTPKeypress, ResendOTP } from './Components/otp.component';
import { GoogleMapComponent } from './Components/googleMap.component';
import { PinFourDigitComponent, PinKeypress } from './Components/pinFourDigit.component';
import { Autofocus } from './directives/autoFocus.directive';
import { DatePicker, SingleDatePicker } from './directives/datePicker.directive';

import {
    HamburgerMenu,
    HamburgerInitDirective,
    LastLogin,
    Navigation,
    AccountSettings,
    ClickOutside,
    WindowScroll
} from './directives/stylers.directive';

import {
    OnlyNumber,
    OnlyEmail,
    OnlyLetter,
    OnlyAlphanumeric,
    PreventSpace
} from './directives/validator.directive';

import {
    AccountNumberFormatPipe,
    CardNumberFormatPipe,
    AccountNumberMaskPipe,
    NumberSeparatorPipe,
    NameCardPipe
} from './directives/stylers.pipe';

import { 
  ValidateCustomerIdentificationRegister, 
  ValidateUsernameRegister,
  ValidatePasswordRegister,
  ValidateConfirmPasswordRegister,
  ValidateCustID
} from '../register/directives/validateRegister.directive';

const SHARED_COMPONENTS = [
    LoginHeaderComponent,
    LoginFooterComponent,
    CommonHeaderComponent,
    RegisterFooterComponent,
    ForgotPasswordFooterComponent,
    DashboardHeaderComponent,
    DashboardFooterComponent,
    SearchHeaderComponent,
    AccountSettingsHeaderComponent,
    NavigationComponent,
    BaseViewComponent,
    MultipleLoginSessionComponent,
    DownloadMobileAppComponent,
    OfferCategoriesComponent,
    SlickCarouselComponent,
    OTPComponent,
    GoogleMapComponent,
    ErrorComponent,
    PinFourDigitComponent
];

const SHARED_DIRECTIVES = [
    DatePicker,
    SingleDatePicker,
    Navigation,
    HamburgerMenu,
    AccountSettings,
    ClickOutside,
    WindowScroll,
    HamburgerInitDirective,
    LastLogin,
    SlickCarouselItem,
    SlickCarouselDestroy,
    SlickCarouselInit,
    SlickCarouselPause,
    SlickCarouselPlay,
    SlickCarouselRefresh,
    SlickCarouselResize,
    Autofocus,
    OTPKeypress,
    ResendOTP,
    PinKeypress,
    ValidateCustomerIdentificationRegister,
    ValidateUsernameRegister,
    ValidatePasswordRegister,
    ValidateConfirmPasswordRegister,
    ValidateCustID,
    OnlyNumber,
    OnlyEmail,
    OnlyLetter,
    OnlyAlphanumeric,
    PreventSpace
];

const SHARED_PIPES = [
    AccountNumberFormatPipe,
    CardNumberFormatPipe,
    AccountNumberMaskPipe,
    NumberSeparatorPipe,
    NameCardPipe
];

const SHARED_PROVIDERS = [
   SharedService,
   TemplateService,
   ErrorService,
   SpinnerService,
   EncryptionService,
   DecimalPipe,
   ServiceInvoker
];

@NgModule({
  	imports: [
  	  TranslateModule.forChild(),
      CommonModule,
      RouterModule,
      FormsModule
  	],
  	declarations: [
  	  ...SHARED_COMPONENTS,
      ...SHARED_DIRECTIVES,
      ...SHARED_PIPES  
  	],
  	providers: [ 
  		...SHARED_PROVIDERS
  	],
  	exports: [
  		...SHARED_COMPONENTS,
      ...SHARED_DIRECTIVES,
      ...SHARED_PIPES 
  	]
})
export class SharedModule {}
