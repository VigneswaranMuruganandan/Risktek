export const GlobalURL = Object.freeze({
    SERVICE_URL: {
        REGISTRATION: {
            REGISTERDEVICE: "/registration/device/register",
            VERIFYCUSTOMER: "/registration/customer/verify",
            VERIFYOTP: "/registration/otp/verify",
            RESENDOTP: "/registration/otp/resend",
            VERIFYUSERNAME: "/registration/uname/verify",
            REGISTERPASSWORD: "/registration/pwd/register",
            SAVETNC:"/registration/tnc/save",
            TXNOTP:"/registration/txnotp/send"
            
        },
        LOGIN: {
             VERIFYLOGIN: "/accesscontrol/cred/verify",
             AUTHENTICATIONMETHOD: "/registration/auth2/update",
             VERIFYCUSTOMERID:"/registration/customer/id/verify",
             MULTILGNVERIFY:"/accesscontrol/multi/login/verify",
             LOGOUT: "/accesscontrol/cred/logout"
        },
        FORGOT_PASSWORD: {
             RESETPASSWORD:"/accesscontrol/cred/reset",
             VERIFYPASSWORD: "/authcred/pwd/verify",
             CUST_PWDRECOVERY:"/registration/customer/pwdrecovery"
        },
        DASHBOARD: {
            DASHBOARD_DETAILS: "/cust/dashboard",
            ALL_PRODUCTS: "/pref/products/fetch",
            SAVE_FAVOURITIES: "/pref/products/update",
            UN_FAVOURITIE: "/pref/prodfavstate/update",
            UPDATE_ALL_FAVOURITIES: "/pref/update/all/favourite",
            ATMBRANCH: "/bnk/atmbranch/fetch"
        },
        SHARED: {
            //PROXY
            //API_URL: "../PersonalBankingWeb/rest/api",
            //API_URL_DOWNLOAD: "../PersonalBankingWeb/rest/api/content/",
            //LOCAL
            API_URL: "http://localhost:9080/PersonalBankingAPI/pbapp/",
            API_URL_DOWNLOAD: "http://localhost:9080/PersonalBankingAPI/content/",
            //BUILD
            //API_URL: "http://172.20.238.125:9081/PersonalBankingAPI/pbapp/",
            //API_URL_DOWNLOAD: "http://172.20.238.125:9081/PersonalBankingAPI/content/",
            //DEV
            //API_URL: "http://172.20.238.125:9080/PersonalBankingAPI/pbapp/",
            //API_URL_DOWNLOAD: "http://172.20.238.125:9080/PersonalBankingAPI/content/",
            //SIT
            //API_URL: "http://172.20.223.91:9080/PersonalBankingAPI/pbapp/", 
            //API_URL_DOWNLOAD: "http://172.20.223.91:9080/PersonalBankingAPI/content/",  
            //SIT HTTPS
            //API_URL: "https://172.20.223.91:9443/PersonalBankingAPI/pbapp/", 
            //API_URL_DOWNLOAD: "https://172.20.223.91:9443/PersonalBankingAPI/content/",   
            //Ashu
            //API_URL: "http://10.230.9.41:9080/PersonalBankingAPI/pbapp/",
            //API_URL_DOWNLOAD: "http://10.230.9.41:9080/PersonalBankingAPI/content/",
            ATM_BRANCH_LOCATIONS: "https://www.fgbgroup.com/fgb-group/about-fgb/branch-locator",
            STATICDATA:"/bnk/data"
        },
        ACCOUNTS: {
            CUSTOMERACCOUNTS: "/account/custpos/fetch",
            ACCOUNTDETAIL: "/account/detail/fetch",
            ACCOUNT_TRANSACTIONS:"/account/txn/history",
            FT_DETAIL:"/account/ft/detail",
            POS_TRANSACTIONS:"/account/unbilledpos",
            DOWNLOAD_ACCOUNT_ESTATEMENT:"/statement/accountstatement",
            DOWNLOAD_ACCOUNT_TRANSACTIONS:"/statement/accounthistory"
        },
        ISAVE: {

        },
        ACCOUNTSETTINGS: {
            UPDATENICKNAME: "/pref/update/nickname/fav",
            UPDATEEMAILID: "/pref/email/update",
            ACTIVATEESTATEMENT:"/pref/estmt/activate",
            DEACTIVATEESTATEMENT:"/pref/estmt/deactivate" ,
            ALERTS_PREFERENCE_FETCH:"/pref/alerts/fetch",
            ALERTS_PREFERENCE_UPDATE:"/pref/alerts/activity/update",
            GET_ALERTS_HISTORY:"/pref/alerts/history"
        },
        INVESTMENTS: {
            VIEW_PRODUCTS: "/bnk/data",
            APPLY_NOW:"/lead/apply"
        },
        SERVICES: {
            FETCHACCOUNTS: "/rba/evaluateRisk",
            FETCHCHEQUEBOOKCHARGES: "/chequebook/charge",
            REQUESTCHEQUEBOOK: "/chequebook/request"
        }, 
        OFFERS: {
            SEARCHOFFERS: "/campaign/offers",
            MERHCHANTS: "/campaign/merchants",
            CATEGORIES: "/campaign/categories"
        },
        RBA: {
            EVALUATERISK: "/rba/evaluateRisk",
            POSTEVALUATE: "/rba/postEvaluate"
        }, 
        BENEFICIARIES: {
            BENE_CHARITY_FETCH: "/benef/charity/fetch",
            BENE_TRANSFER_FETCH: "/benef/transfersetup/fetch",
            BENE_PAYMENT_FETCH: "/benef/paymentsetup/fetch",
            CREATE_BENEF:"/benef/transfertemplate/add",
            DELETE_BENEF: "/benef/transfertemplate/delete",
            CREATE_BILLPAY_TEMPLATE:"/billpaytemplate/add",
            DELETE_BILLPAY_TEMPLATE:"/billpaytemplate/delete"

        },
        TRANSFERS: {
            SETUP_FOR_TRANSFER: "/setup",
            EXECUTE_TRANSFER:"/execute",
            FETCH_FX_RATE:"/fxrate/fetch"
        },
        OTP:{
            SEND_TRAN_OTP:"/txnotp/send"
        }          
    },
    PROPERTIES: {
        STUBS: "N",
        TIMEOUT:120000,
        ALLOWMULTIPLELOGIN:"Y",
        MULTILOGININTERVAL:30000
    }
 });

