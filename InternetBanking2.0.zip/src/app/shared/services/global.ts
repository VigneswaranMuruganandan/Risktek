export const GlobalVariable = Object.freeze({
    ROUTE_MAPPING: {
     	DASHBOARD:"/dashboard",
      ACCOUNT:"/accounts",
      DEBITCARDS:"javascript:void(0);",
      CREDITCARDS:"javascript:void(0);",
      LOANS:"javascript:void(0);",
      INVESTMENTS:"/investments",
      APPLY_FOR_PRODUCT:"apply-for-product",
      TRANSFER_MONEY:"/transfers",
      PAYMENTS:"javascript:void(0);",
      BENEFICIARIES:"/beneficiaries",
      ATM_BRANCH_LOCATIONS:"atm",
      CONTACT_US:"/others/contactUs",
      FAB_OFFERS:"/offers",
      ISAVE:"/iSaveAccount",
      ISAVE_WELCOME:"/welcomeIsave",
      LANGUAGE:""
    },
    URL_MAPPING: {
     	ACCOUNT:{
     		OPEN_TERM_DEPOSIT: "opentermdeposit.json",
     		OFFER_BANNER: "offer_content.json",
     		VERIFY_ACCESS_TOKEN: "verifyaccesstoken.json"
     	}
    },
    IMAGE_URL: {
    	ACTIVATE_DEBIT_CARD: "fgb-activation-credit-card.png",
      OWN_ACCT_FUNDS_TRANSFER: "app/assets/images/svg-icons/between-accounts.svg",
      WITHIN_BANK_FUNDS_TRANSFER: "app/assets/images/svg-icons/within-fab.svg",
      WITHIN_UAE_FUNDS_TRANSFER: "app/assets/images/svg-icons/within-uae.svg",
      INTERNATIONAL_FUNDS_TRANSFER: "app/assets/images/svg-icons/international-transfer.svg",
      SMS_CASH: "app/assets/images/svg-icons/sms-cash.svg",
      ETISALAT : "app/assets/images/utility-billers/etisalat.png",
      ADDC : "app/assets/images/utility-billers/aadc.png",
      DEWA : "app/assets/images/utility-billers/dewa.png",
      AADC : "app/assets/images/utility-billers/addc.png",
      SEWA : "app/assets/images/utility-billers/sewa.png",
      SALIK : "app/assets/images/utility-billers/salik.png",
      DU : "app/assets/images/utility-billers/du.png",
      FEWA : "app/assets/images/utility-billers/fewa.png",
      GEMS : "app/assets/images/utility-billers/fewa.png"
    },
    MENU_ICON_MAPPING:{
    	DASHBOARD:"home",
    	ACCOUNT:"accounts",
    	DEBITCARDS:"debit-cards",
    	CREDITCARDS:"credit-cards",
    	LOANS:"loans",
    	INVESTMENTS:"investments",
    	APPLY_FOR_PRODUCT:"apply-for-product",
      TRANSFER_MONEY:"transfer",
      PAYMENTS:"payments",
      BENEFICIARIES:"beneficiaries",
      ATM_BRANCH_LOCATIONS:"atm",
      CONTACT_US:"contact",
      FAB_OFFERS:"offers",
      LANGUAGE:"language",
      ISAVE:"isave-coin"
    },
    OFFER_MERCHANTS:{      
      "CAR_RENTAL":"Car_Rental.png",
      "SERVICES":"Services.png",
      "FURNITURE":"Furniture.png",
      "FASHION":"Fashion.png",
      "HEALTH_AND__WELLNESS":"Health.png",
      "FUN_&_ADVENTURE":"Adventure.png",
      "CAKES_AND_CONFECTIONARIES":"Cakes.png",
      "ENTERTAINMENT":"Entertainment.png",
      "FLOWERS":"Flowers.png",
      "GIFT_IDEAS":"Gifts.png",
      "HOTELS":"Hotel.png",
      "LEARNING":"Learning.png",
      "OPTICAL_AND_SUNGLASSES":"Opticals.png",
      "SPA":"Spa.png",
      "DINING":"Dining.png",
      "GENERAL":"General.png",
      "0%_OFFERS":"0 Offers.png",
      "BUY_1_GET_1_OFFERS":"Buy_1_get_1.png",
      "BEST_OF_THE_MONTH":"Best_of_the_month.png"
    },
    SLIDER_PROPERTIES:{
                  'favourites': {
                      'rtl': false,
                      'dots':false,
                      'arrows': true,
                      'appendArrows': '#slick-carousel-dots-fav',
                      'slidesToShow': 3,
                      'slidesToScroll': 3,
                      'responsive': [{
                              'breakpoint': 1500,
                              'settings': {
                                  'slidesToShow': 3,
                                  'slidesToScroll': 3,
                                  'infinite': true,
                                  'dots': false
                              }
                          },
                          {
                              'breakpoint': 1100,
                              'settings': {
                                  'slidesToShow': 2,
                                  'slidesToScroll': 2,
                                  'infinite': true,
                                  'dots': false
                              }
                          },
                          {
                              'breakpoint': 600,
                              'settings': {
                                  'slidesToShow': 2,
                                  'slidesToScroll': 2
                              }
                          },
                          {
                              'breakpoint': 520,
                              'settings': {
                                  'slidesToShow': 1,
                                  'slidesToScroll': 1
                              }
                          }
                      ]
                  },
                  'accountsInfo': {
                      'rtl': false,
                      'dots':false,
                      'arrows': true,
                      'appendArrows': '#slick-carousel-dots-acc',
                      'slidesToShow': 3,
                      'slidesToScroll': 3,
                      'responsive': [{
                              'breakpoint': 1500,
                              'settings': {
                                  'slidesToShow': 3,
                                  'slidesToScroll': 3,
                                  'infinite': true,
                                  'dots': false
                              }
                          },
                          {
                              'breakpoint': 1100,
                              'settings': {
                                  'slidesToShow': 2,
                                  'slidesToScroll': 2,
                                  'infinite': true,
                                  'dots': false
                              }
                          },
                          {
                              'breakpoint': 600,
                              'settings': {
                                  'slidesToShow': 2,
                                  'slidesToScroll': 2
                              }
                          },
                          {
                              'breakpoint': 520,
                              'settings': {
                                  'slidesToShow': 1,
                                  'slidesToScroll': 1
                              }
                          }
                      ]
                  },
                  'cardsInfo': {
                      'rtl': false,
                      'dots':false,
                      'arrows': true,
                      'appendArrows': '#slick-carousel-dots-card',
                      'slidesToShow': 3,
                      'slidesToScroll': 3,
                      'responsive': [{
                              'breakpoint': 1500,
                              'settings': {
                                  'slidesToShow': 3,
                                  'slidesToScroll': 3,
                                  'infinite': true,
                                  'dots': false
                              }
                          },
                          {
                              'breakpoint': 1100,
                              'settings': {
                                  'slidesToShow': 2,
                                  'slidesToScroll': 2,
                                  'infinite': true,
                                  'dots': false
                              }
                          },
                          {
                              'breakpoint': 600,
                              'settings': {
                                  'slidesToShow': 2,
                                  'slidesToScroll': 2
                              }
                          },
                          {
                              'breakpoint': 520,
                              'settings': {
                                  'slidesToShow': 1,
                                  'slidesToScroll': 1
                              }
                          }
                      ]
                  },
                  'loansInfo': {
                      'rtl': false,
                      'dots':false,
                      'arrows': true,
                      'appendArrows': '#slick-carousel-dots-loan',
                      'slidesToShow': 3,
                      'slidesToScroll': 3,
                      'responsive': [{
                              'breakpoint': 1500,
                              'settings': {
                                  'slidesToShow': 3,
                                  'slidesToScroll': 3,
                                  'infinite': true,
                                  'dots': false
                              }
                          },
                          {
                              'breakpoint': 1100,
                              'settings': {
                                  'slidesToShow': 2,
                                  'slidesToScroll': 2,
                                  'infinite': true,
                                  'dots': false
                              }
                          },
                          {
                              'breakpoint': 600,
                              'settings': {
                                  'slidesToShow': 2,
                                  'slidesToScroll': 2
                              }
                          },
                          {
                              'breakpoint': 520,
                              'settings': {
                                  'slidesToShow': 1,
                                  'slidesToScroll': 1
                              }
                          }
                      ]
                  },
                  'depositsInfo': {
                      'rtl': false,
                      'dots':false,
                      'arrows': true,
                      'appendArrows': '#slick-carousel-dots-deposit',
                      'slidesToShow': 3,
                      'slidesToScroll': 3,
                      'responsive': [{
                              'breakpoint': 1500,
                              'settings': {
                                  'slidesToShow': 3,
                                  'slidesToScroll': 3,
                                  'infinite': true,
                                  'dots': false
                              }
                          },
                          {
                              'breakpoint': 1100,
                              'settings': {
                                  'slidesToShow': 2,
                                  'slidesToScroll': 2,
                                  'infinite': true,
                                  'dots': false
                              }
                          },
                          {
                              'breakpoint': 600,
                              'settings': {
                                  'slidesToShow': 2,
                                  'slidesToScroll': 2
                              }
                          },
                          {
                              'breakpoint': 520,
                              'settings': {
                                  'slidesToShow': 1,
                                  'slidesToScroll': 1
                              }
                          }
                      ]
                  },
                  'dashboard_transfers': {
                      'dots':false,
                      'rtl': false,
                      'arrows': true,
                      'appendArrows': '#sliderArrows-transfers',
                      'dotsClass': 'carousel-dots',
                      'slidesToShow': 3,
                      'slidesToScroll': 3,
                      'infinite': false,
                      'responsive': [
                        {
                          'breakpoint': 1500,
                          'settings': {
                            'slidesToShow': 4,
                            'slidesToScroll': 3,
                            'infinite': true,
                            'dots': true
                          }
                        },
                        {
                          'breakpoint': 1100,
                          'settings': {
                            'slidesToShow': 3,
                            'slidesToScroll': 3,
                            'infinite': true,
                            'dots': true
                          }
                        },
                        {
                          'breakpoint': 500,
                          'settings': {
                            'slidesToShow': 3,
                            'slidesToScroll': 1,
                            'infinite': true,
                          }
                        },
                      ]
                  },
                  'dashboard_payments': {
                      'dots':false,
                      'rtl': false,
                      'arrows': true,
                      'appendArrows': '#sliderArrows-payments',
                      'dotsClass': 'carousel-dots',
                      'slidesToShow': 4,
                        'slidesToScroll': 3,
                      'infinite': false,
                      'responsive': [
                        {
                          'breakpoint': 1500,
                          'settings': {
                            'slidesToShow': 4,
                            'slidesToScroll': 3,
                            'infinite': true,
                            'dots': true
                          }
                        },
                        {
                          'breakpoint': 1100,
                          'settings': {
                            'slidesToShow': 3,
                            'slidesToScroll': 3,
                            'infinite': true,
                            'dots': true
                          }
                        },
                        {
                          'breakpoint': 500,
                          'settings': {
                            'slidesToShow': 3,
                            'slidesToScroll': 1,
                            'infinite': true,
                          }
                        },
                      ]
                  },
                  'dashboard_offers':{
                      'dots':false,
                      'rtl': false,
                      'arrows': true,
                      'appendArrows': '#sliderArrows-offers',
                      'dotsClass': 'carousel-dots',
                      'slidesToShow': 4,
                        'slidesToScroll': 3,
                      'infinite': false,
                      'responsive': [
                        {
                          'breakpoint': 1500,
                          'settings': {
                            'slidesToShow': 4,
                            'slidesToScroll': 3,
                            'infinite': true,
                            'dots': true
                          }
                        },
                        {
                          'breakpoint': 1100,
                          'settings': {
                            'slidesToShow': 3,
                            'slidesToScroll': 3,
                            'infinite': true,
                            'dots': true
                          }
                        },
                        {
                          'breakpoint': 500,
                          'settings': {
                            'slidesToShow': 3,
                            'slidesToScroll': 1,
                            'infinite': true,
                          }
                        },
                      ]
                  },
                  'bulletins': {
                    'rtl': false,
                    'arrows': false,
                    'slidesToShow': 1,
                    'slidesToScroll': 1,
                    'autoplay': true,
                    'autoplaySpeed': 2000
                  },
                  'rightContent':{
                    'rtl': false,
                    'dots':true,
                    'appendDots': '#accountRightContent',
                    'dotsClass': 'carousel-dots',
                    'slidesToShow': 1,
                    'slidesToScroll': 1,
                    'arrows': false
                  },
                  'rightContentOffer':{
                    'rtl': false,
                    'dots':true,
                    'appendDots': '#accountRightContentOffer',
                    'dotsClass': 'carousel-dots',
                    'slidesToShow': 1,
                    'slidesToScroll': 1,
                    'arrows': false
                  },
                  'downloadApp':{
                    'rtl': false,
                    'dots':true,
                    'appendDots': '#carousel-dots-downloadapp',
                    'dotsClass': 'carousel-dots',
                    'slidesToShow': 1,
                    'slidesToScroll': 1,
                    'arrows': false,
                    'refresh': true
                  }
    },
    ERROR_CODES:{
    	USERNAME_PASSWORD_WRONG : "Invalid username/password. You have MESSAGE_DISPLAY remaining attempts for login",
    	VRFY_OTP_MTCH_FLD : "Invalid OTP. You have MESSAGE_DISPLAY remaining attempts"
    },
    TRANSFER_TYPES:{
      OWN_ACCT_FUNDS_TRANSFER:"OWN_ACCT_FUNDS_TRANSFER",
      WITHIN_BANK_FUNDS_TRANSFER : "WITHIN_BANK_FUNDS_TRANSFER",
      WITHIN_UAE_FUNDS_TRANSFER : "WITHIN_UAE_FUNDS_TRANSFER",
      INTERNATIONAL_FUNDS_TRANSFER:"INTERNATIONAL_FUNDS_TRANSFER",
      SMS_CASH:"SMS_CASH"
    },
    TRANSFER_TYPE_DESCRIPTION:{
      OWN_ACCT_FUNDS_TRANSFER:"Own Account",
      WITHIN_BANK_FUNDS_TRANSFER : "Within FAB",
      WITHIN_UAE_FUNDS_TRANSFER : "Within UAE",
      INTERNATIONAL_FUNDS_TRANSFER:"Outside UAE",
      SMS_CASH:"SMS Cash"
    },
    BENE_ADD_TYPE:{
      BENE_ADD_WITHOUT_TRANSFER:"B",
      BENE_ADD_WITH_TRANSFER:"B_T"
    },
    TRANSACTION_CODES :{
      BENEF_ADD_OWN_ACCT_FUNDS_TRANSFER:"BENEF_ADD_OWN_ACCT_FUNDS_TRANSFER",
      BENEF_ADD_WITHIN_BANK_FUNDS_TRANSFER:"BENEF_ADD_WITHIN_BANK_FUNDS_TRANSFER",
      BENEF_ADD_WITHIN_UAE_FUNDS_TRANSFER:"BENEF_ADD_WITHIN_UAE_FUNDS_TRANSFER",
      BENEF_ADD_INTERNATIONAL_FUNDS_TRANSFER:"BENEF_ADD_INTERNATIONAL_FUNDS_TRANSFER",
      BENEF_ADD_SMS_CASH:"BENEF_ADD_SMS_CASH"

    }
 });

