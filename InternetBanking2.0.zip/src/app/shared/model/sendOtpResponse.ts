import {APIResponse} from '../../shared/model/apiResponse';
export class SendOtpResponse extends APIResponse{

	otpRef:string;
	otpDuration:number;
	emailMasked:string;
	mobileNumberMasked:string;
	remainingOtpAttempts:number;

}