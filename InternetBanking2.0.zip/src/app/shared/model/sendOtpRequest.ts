
export class SendOtpRequest {
	txnCode:string;
}