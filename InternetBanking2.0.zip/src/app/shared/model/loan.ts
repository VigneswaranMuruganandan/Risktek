import { Amount } from './amount';

export class Loan{
    loanNumber : string;
	availableBal : Amount;
	ledgerBal : Amount;
	currency : string;
	holderName : string;
	categoryCode : string;
	type : string;
	purpose : string;
	nickName : string;
	displaySequence : string;
	isFavorite : boolean;
}