import { Component, OnInit } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { GlobalURL} from '../../shared/services/globalURL';
import { GlobalVariable} from '../../shared/services/global';

@Component({
  selector: 'navigation-component',
  templateUrl: './../templates/navigation.html'
})
export class NavigationComponent implements OnInit {
	globalURL: any;
	public menus :any;
	public menuIcon :any;
	public routeURL :any;

	ngOnInit() {
		this.globalURL = GlobalURL;
		this.menuIcon = GlobalVariable.MENU_ICON_MAPPING;
		this.routeURL = GlobalVariable.ROUTE_MAPPING;
		this.menus = [
					   {
					      "title":"MY PRODUCTS",
					      "child":[
					         {
					            "id":"DASHBOARD",
					            "title":"My Dashboard"
					         },
					         {
					            "id":"ACCOUNT",
					            "title":"Accounts",
					            "child":[]
					         },
					         {
					            "id":"DEBITCARDS",
					            "title":"Debit Cards"
					         },
					         {
					            "id":"CREDITCARDS",
					            "title":"Credit Cards"
					         },
					         {
					            "id":"LOANS",
					            "title":"Loans",
					            "flag":"y"
					         },
					         {
					            "id":"ISAVE",
					            "title":"ISave"
					         },
					         {
					            "id":"INVESTMENTS",
					            "title":"Investments"
					         },
					         {
					            "id":"APPLY_FOR_PRODUCT",
					            "title":"Apply for Product"
					         }
					      ]
					   },
					   {
					      "title":"TRANSFERS & PAYMENTS",
					      "child":[
					         {
					            "id":"TRANSFER_MONEY",
					            "title":"Transfer Money"
					         },
					         {
					            "id":"PAYMENTS",
					            "title":"Payments"
					         },
					         {
					            "id":"BENEFICIARIES",
					            "title":"Beneficiaries"
					         }
					      ]
					   },
					   {
					      "title":"OTHERS",
					      "child":[
					         {
					            "id":"ATM_BRANCH_LOCATIONS",
					            "title":"ATM & Branch Locations"
					         },
					         {
					            "id":"CONTACT_US",
					            "title":"Contact Us"
					         },
					         {
					            "id":"FAB_OFFERS",
					            "title":"FAB Offers"
					         },
					         {
					            "id":"LANGUAGE",
					            "title":"Language"
					         }
					      ]
					   }
					];
	}
	/*
	* Open Download mobile App
	*/
	openDownloadMobileApp(){
		(<any>$('#mobileAppModal')).modal('show');
		(<any>$('#carouselRefresh')).click();
	}	
}