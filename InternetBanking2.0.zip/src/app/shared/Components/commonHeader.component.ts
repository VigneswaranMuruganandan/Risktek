import { Component } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'common-header',
  templateUrl: './../templates/commonHeader.html'
})
export class CommonHeaderComponent {
	constructor(private translate: TranslateService) {}
	
	changeLanguage(lang : string){
    	this.translate.use(lang);
    	(lang == 'en') ? $('body').removeClass('arabic-design') :$('body').addClass('arabic-design');
	}
}