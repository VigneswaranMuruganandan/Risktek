import { Component, OnInit } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { SpinnerService } from '..//services/spinner.service';

@Component({
  selector: 'download-mobileapp',
  templateUrl: './../templates/downloadMobileApp.html'
})
export class DownloadMobileAppComponent implements OnInit {
	public showQRCode:boolean

	constructor( private spinnerService: SpinnerService) {}

	ngOnInit() {
		this.showQRCode = false;
        this.spinnerService.startSpinner('downloadAppLoader');
        setTimeout(()=>{ 
          this.showQRCode = true;
          this.spinnerService.stopSpinner('downloadAppLoader');
        }, 4000);
    }
}