import { Directive,ElementRef,Output,EventEmitter} from '@angular/core';
import * as $ from 'jquery';
import 'app/assets/js/jquery-ui.min.js';

@Directive({
    selector: '[datePicker]'
})
export class DatePicker {
    constructor(private el: ElementRef) {}

    ngOnInit() {}

    ngAfterViewInit() {
        let dateFormat = "dd/mm/yy",
            from = ( < any > $("#from"))
            .datepicker({
                //defaultDate: "+1w",
                maxDate: "+0D" ,
                dateFormat: 'dd/mm/yy'
                // changeMonth: true,
                // showButtonPanel: true
               // numberOfMonths: 3
            })
            .on("change", function() {
                to.datepicker("option", "minDate", getDate(this));
                $('#dateButton').trigger( "click" );

            }),
            to = ( < any > $("#to")).datepicker({
                //defaultDate: "+1w",
                maxDate: "+0D" ,
                dateFormat: 'dd/mm/yy'
                // changeMonth: true,
                // showButtonPanel: true
                // numberOfMonths: 3
            })
            .on("change", function() {
                from.datepicker("option", "maxDate", getDate(this));
                 $('#dateButton').trigger( "click" );
            });

        function getDate(element: any) {
            var date;
            try {
                date = ( < any > $).datepicker.parseDate(dateFormat, element.value);
            } catch (error) {
                date = null;
            }
            return date;
        }
    }
}

@Directive({
    selector: '[singleDatePicker]'
})
export class SingleDatePicker {
    constructor(private el: ElementRef) {}

    ngOnInit() {
    console.log("singledatepicker ----------------->");
    }

    ngAfterViewInit() {
            console.log("singledatepicker ----------------->");
        let el = (<any>$(this.el.nativeElement));
        el.datepicker({
          changeMonth: true,
          changeYear: true,
          minDate: "+0D",
          dateFormat: 'dd/mm/yy'
        });
    }
}