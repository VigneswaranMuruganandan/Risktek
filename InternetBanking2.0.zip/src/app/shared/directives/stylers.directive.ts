import { Directive, ElementRef, HostListener, Input, OnInit, Inject } from '@angular/core';
import * as $ from 'jquery';
import { DOCUMENT } from '@angular/platform-browser';
import {TemplateService} from '../../shared/services/template.service';

@Directive({
  selector: '[HamburgerMenuDirective]'
})
export class HamburgerMenu {

  constructor(private el: ElementRef, 
  			  private templateService: TemplateService) { }

  @HostListener('click', ['$event']) 
  onClick(event: any) {
	    $('.hamburger').toggleClass('animate');
	    this.templateService.checkMenuState();
  }
}

@Directive({
  selector: '[HamburgerInitDirective]'
})
export class HamburgerInitDirective  implements OnInit{

  constructor( private el: ElementRef, 
  			       private templateService: TemplateService) { }

  ngOnInit() { 
	    this.templateService.showHideMenu();
      this.templateService.checkMenuState();
  }

}

@Directive({
  selector: '[LastLogin]'
})
export class LastLogin  implements OnInit{

  constructor( private el: ElementRef, 
               private templateService: TemplateService) { }

  ngOnInit() { 
      let _index = 1;
        setInterval(function () {
        if($(".last-login p span").length>1){
          var _adverImgL = $(".last-login p span").length - 1;
              $(".last-login p span").hide();
              if (_index == _adverImgL) {
                  $(".last-login p span").eq(_index).show();
                  _index = 0;
              } else {
                  $(".last-login p span").eq(_index++).show();
              }
        }else{
           $(".last-login p span").eq(0).show();
        }
          
      }, 2000);
  }
}


@Directive({
  selector: '[NavigationDirective]'
})
export class Navigation {

  constructor(private el: ElementRef) { }

  @HostListener('click', ['$event']) 
  onClick(event: any) {
        event.preventDefault();
      var el = $(this.el.nativeElement);
      if (el.next().hasClass('show')) {
          el.next().removeClass('show');
          el.next().slideUp(350);
          el.parent().find('a').removeClass('active');
      } else {
          el.parent().parent().find('li .inner').removeClass('show');
          el.parent().parent().find('li .inner').slideUp(350);
          el.parent().find('a').addClass('active');
          el.next().toggleClass('show');
          el.next().slideToggle(350);
      }
  }
}

@Directive({
  selector: '[AccountSettings]'
})
export class AccountSettings {

  constructor(private el: ElementRef) { }

  @HostListener('click', ['$event']) 
  onClick(event: any) {
      event.preventDefault();
      $(".logged-in-menu").toggleClass( "show" );
  }
}

@Directive({
  selector: '[clickOutside]'
})
export class ClickOutside {
  constructor(private el: ElementRef) {}

  @HostListener('click', ['$event']) 
  onClick(event: any) {
        let showFlag = $(".logged-in-menu").hasClass("show");
        if(showFlag){
          $(".logged-in-menu").removeClass( "show" );
        }
  }
}

@Directive({
  selector: '[WindowScroll]'
})
export class WindowScroll {
  constructor(@Inject(DOCUMENT) private document: Document) {}
  @HostListener('window:scroll', ['$event']) 
  onWindowScroll(event) {  
    let number = this.document.body.scrollTop;
    if (number >= 75) {
        $(".sidebar").addClass("fixed");
    } else {
        $(".sidebar").removeClass("fixed");
    }
  }
}