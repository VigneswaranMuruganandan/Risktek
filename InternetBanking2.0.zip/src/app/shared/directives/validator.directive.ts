import { Directive, ElementRef, HostListener, Input, OnInit } from '@angular/core';
import * as $ from 'jquery';
import 'app/assets/js/inputValidator.js';
import {TemplateService} from '../../shared/services/template.service';

/*
* Only Number Directive
*/
@Directive({
  selector: '[only-number]'
})
export class OnlyNumber implements OnInit {
  constructor(private el: ElementRef) {}
    ngOnInit() {
	  (<any>$(this.el.nativeElement)).onlyNumber();
  	}
}
/*
* Only Email Directive
*/
@Directive({
  selector: '[only-email]'
})
export class OnlyEmail implements OnInit {
  constructor(private el: ElementRef) {}
    ngOnInit() {
	  (<any>$(this.el.nativeElement)).onlyEmail();
  	}
}
/*
* Only Letter Directive
*/
@Directive({
  selector: '[only-letter]'
})
export class OnlyLetter implements OnInit {
  constructor(private el: ElementRef) {}
    ngOnInit() {
	  (<any>$(this.el.nativeElement)).onlyLetter();
  	}
}
/*
* Only Alphanumeric Directive
*/
@Directive({
  selector: '[only-alphanumeric]'
})
export class OnlyAlphanumeric implements OnInit {
  constructor(private el: ElementRef) {}
    ngOnInit() {
	  (<any>$(this.el.nativeElement)).onlyAlphaNumeric();
  	}
}
/*
* Prevent Space Directive
*/
@Directive({
  selector: '[prevent-space]'
})
export class PreventSpace {
  constructor(private el: ElementRef) { }
  @HostListener('keydown', ['$event']) onKeyDown(event: any) {
    let e = <KeyboardEvent> event;
        if (e.which == 32){
        	e.preventDefault();
        	return false;
        }
    }
}