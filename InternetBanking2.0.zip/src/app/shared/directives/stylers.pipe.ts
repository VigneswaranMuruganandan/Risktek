import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'accountNumberFormat'})
export class AccountNumberFormatPipe implements PipeTransform {
  transform(value: string, args: string[]): any {
    if (!value) return value;

    return value.replace(/\w\S*/g, function(txt) {
      if(txt.length == 16){
    	  let split_txt : Array<string> = /^(\d{3})(\d{8})(\d{5})$/.exec(txt);
        return split_txt[1] + '-' + split_txt[2] + '-' + split_txt[3] ;
      }else{
        return txt;
      }
    });
  }
}

@Pipe({name: 'cardNumberFormat'})
export class CardNumberFormatPipe implements PipeTransform {
  transform(value: string, args: string[]): any {
    if (!value) return value;
    return value.replace(/\w\S*/g, function(txt) {
      if(txt.length == 16){
        let split_txt : Array<string> = /^(\d{4})(\d{4})(\d{4})(\d{4})$/.exec(txt);
        return split_txt[1] + ' ' + split_txt[2] + ' ' + split_txt[3] + ' ' + split_txt[4];
      }else{
        return txt;
      }
    });
  }
}

@Pipe({name: 'accountNumberMask'})
export class AccountNumberMaskPipe implements PipeTransform {
  transform(value: string, args: string[]): any {
    if (!value) return value;

    return value.replace(/\w\S*/g, function(txt) {
        let split_txt : Array<string> = /^(\d{4})(\d{4})(\d{4})(\d{4})$/.exec(txt);
        return '**** **** **** ' + split_txt[4] ;
    });
  }
}

@Pipe({name: 'numberSeparator'})
export class NumberSeparatorPipe implements PipeTransform {
  transform(value: string, args: string[]): any {
    if (!value) return value;
    return value.toLocaleString();
  }
}

@Pipe({name: 'nameCard'})
export class NameCardPipe implements PipeTransform {
  transform(value: string, args: string[]): any {
    if (!value) return value;
    let temp = value.split(" ");
    let nameCard
    if(temp.length>1){
      nameCard = temp[0].charAt(0)+temp[1].charAt(0);
    }else{
      nameCard = temp[0].charAt(0);
    }
    return nameCard;
  }
}