import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {CustomerData} from '../model/customerData';

@Component({
  selector: 'registrationstep5-component',
  templateUrl: './../templates/registrationStep5.html'
})
export class RegistrationStep5Component implements OnInit {
	public authenticationMethod: string;
	@Output() saveRegistrationEvent = new EventEmitter();
	@Input() customerData: CustomerData;

	ngOnInit() { 
    	this.authenticationMethod = 'SMS_OTP';
    }
    
	validateAuthenticationType(){
		console.log(this.authenticationMethod);
		if(this.authenticationMethod){
			this.saveRegistrationEvent.emit(this.authenticationMethod);
		}
	}
}