import { Component, OnInit, Input,EventEmitter,Output} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {TemplateService} from '../../shared/services/template.service';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Component({
  selector: 'resetPinDebitCardStep4-component',
  templateUrl: './../templates/resetPinDebitCardStep4.html'
})
export class ResetPinDebitCardStep4Component{
	@Output() validateConfirmPinDebitCardEvent = new EventEmitter();
	constructor(private templateService: TemplateService) {}	

	validateConfirmPin(event:any){
		this.validateConfirmPinDebitCardEvent.emit();
	}
	
}