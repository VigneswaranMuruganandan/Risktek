import { Component, OnInit, Input} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';


@Component({
  selector: '[debitcarddetails-component]',
  templateUrl: './../templates/debitCardsDetails.html'
})
export class DebitCardsDetailsComponent{
	
	
	
}