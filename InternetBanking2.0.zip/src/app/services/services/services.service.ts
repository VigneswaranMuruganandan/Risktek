import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';
import {AppSession} from '../../shared/model/appSession';
import {ServiceInvoker} from '../../shared/connector/serviceInvoker.service';
import {EncryptionService} from '../../shared/services/encryption.service';
import { SharedService } from '../../shared/services/shared.service';
import {ErrorService} from '../../shared/services/error.service';
import {SessionContext} from '../../shared/model/sessionContext';
import {GlobalURL} from '../../shared/services/globalURL';


@Injectable()
export class ServicesService {
    
    constructor(private serviceInvoker: ServiceInvoker, 
                private encryptionService: EncryptionService,
                private errorService: ErrorService,
                private sharedService: SharedService) {}

    fetchAccounts(authRequest: any): Observable < any > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.SERVICES.FETCHACCOUNTS, authRequest)
                                  .map(resp => JSON.parse(resp));
    }

}