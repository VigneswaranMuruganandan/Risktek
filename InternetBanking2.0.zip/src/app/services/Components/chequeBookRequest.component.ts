import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { ServicesService } from '../services/services.service';
import { SharedService } from '../../shared/services/shared.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { ErrorService } from '../../shared/services/error.service';
import { SessionContext } from '../../shared/model/sessionContext';

import { Router } from '@angular/router';
import { Observable } from 'rxjs/Rx';

@Component({
    templateUrl: './../templates/chequeBookRequest.html'
})
export class chequeBookRequestComponent implements OnInit {
	public stepValue: number;
	
    constructor( private servicesService: ServicesService, 
    			 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService,
    			 private router: Router) {}

    ngOnInit() {
        this.stepValue = 1;
    }

    validateChequeBookReq(){
        this.stepValue = 2;
    }

    reviewChequeBookReq(){
        this.stepValue = 3;
    }

    validateOTPChequeBookReq(otp: string){
        console.log(otp);
        this.submitChequeBookReq();        
    }

    submitChequeBookReq(){
        this.stepValue = 4;
    }

    backChequeBookReq(step){
        this.stepValue = step;
    }
    
}