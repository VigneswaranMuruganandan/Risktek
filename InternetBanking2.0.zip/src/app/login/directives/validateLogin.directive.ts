import { Component, ElementRef, Directive, HostListener, NgZone, Input, Output, EventEmitter } from '@angular/core';
import * as $ from 'jquery';
import {TemplateService} from '../../shared/services/template.service';

import 'app/assets/js/jquery.validate.js';

/*
* Login Form validation for Registration
*/
@Directive({
    selector: '[ValidateLoginDirective]',
})
export class ValidateLogin {
    //private x = require('jquery-validator');
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}

    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let loginValidationSubmit;
        this.zone.runOutsideAngular(() => {
            var loginValidation = (<any>$("#loginForm")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    userName: {
                        required: true
                    },
                    password: {
                        required: true
                    }
                },
                messages: {
                    userName: {
                        required: "Please enter Customer Identification Number"
                    },
                    password: {
                        required: "Please enter Password"
                    }
                }
            });
            loginValidationSubmit = loginValidation.form();
            this.templateService.setFormValidatorFlag(loginValidationSubmit);
        });
    }
}