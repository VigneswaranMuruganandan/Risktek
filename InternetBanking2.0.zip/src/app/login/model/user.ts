export class User{
	userName: string;
    pwd: string;

    caDeviceDNA:string;
    deviceIP:string;
    caDeviceID:string;

}