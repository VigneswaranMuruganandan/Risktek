import { CategorieItems } from './categorieItems';
import { APIResponse } from '../../shared/model/apiResponse';

export class Categories extends APIResponse{
    items : CategorieItems[];
}