import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'withinFABTransferStep1-component',
  templateUrl: './../templates/withinFABTransferStep1.html'
})
export class WithinFABTransferStep1Component {

	@Output() validateFormNextButtonEvent = new EventEmitter();

	validateForm(){
		this.validateFormNextButtonEvent.emit();
	}
    
    
}
