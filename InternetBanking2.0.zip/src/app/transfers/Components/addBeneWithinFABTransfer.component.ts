import { Component, OnInit, Input} from '@angular/core';
import { SharedService} from '../../shared/services/shared.service';
import { ErrorService } from '../../shared/services/error.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { GlobalVariable} from '../../shared/services/global';

@Component({
  templateUrl: './../templates/addBeneWithinFABTransfer.html'
})
export class AddBeneWithinFABTransferComponent implements OnInit{
	public stepValue: number;
   
  constructor(private sharedService: SharedService,
              private errorService: ErrorService,
              private spinnerService: SpinnerService){}

	ngOnInit() { 
    	this.stepValue = 1;
    }

    validateFormNextButton(){
    	this.stepValue = 2;
    }

    confirmReviewButton(){
    	this.stepValue = 3;
    }

    backReviewButton(){
        this.stepValue = 1;
    }

    validateOTP(){
    	this.stepValue = 4;
    }

    backOTPButton(){
        this.stepValue = 2;
    }


   
    
}
