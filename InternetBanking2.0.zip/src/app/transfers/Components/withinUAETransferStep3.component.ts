import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'withinUAETransferStep3-component',
  templateUrl: './../templates/withinUAETransferStep3.html'
})
export class WithinUAETransferStep3Component {

	@Output() validateOTPEvent = new EventEmitter();
	@Output() backOTPButtonEvent = new EventEmitter();

	validateOTP(){
		this.validateOTPEvent.emit();
	}

	backOTP(){
		this.backOTPButtonEvent.emit();
	}
    
}
