import { Component, OnInit, Input} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'outsideUAETransferStep4-component',
  templateUrl: './../templates/outsideUAETransferStep4.html'
})
export class OutsideUAETransferStep4Component {
 
    
}
