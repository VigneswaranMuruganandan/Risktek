import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'addBeneOutsideUAETransferStep2-component',
  templateUrl: './../templates/addBeneOutsideUAETransferStep2.html'
})
export class AddBeneOutsideUAETransferStep2Component {

	@Output() validateTransferFormNextButtonEvent = new EventEmitter();
	@Output() backToBeneFormButtonEvent = new EventEmitter();


	validateTransferForm(){
		this.validateTransferFormNextButtonEvent.emit();
	}

	backToBeneForm(){
		this.backToBeneFormButtonEvent.emit();
	}
    
    
}
