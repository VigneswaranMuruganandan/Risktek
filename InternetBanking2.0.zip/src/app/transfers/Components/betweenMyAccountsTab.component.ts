import { Component, OnInit, Input} from '@angular/core';

@Component({
  selector: 'betweenMyAccounts-tab',
  templateUrl: './../templates/betweenMyAccountsTab.html'
})
export class BetweenMyAccountsTabComponent implements OnInit{

	ngOnInit() { 
    
    }

}