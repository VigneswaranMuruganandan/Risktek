import { Component, OnInit, Input} from '@angular/core';
import { Router } from '@angular/router';

@Component({
	selector: 'smsCash-tab',
  templateUrl: './../templates/smsCashTab.html'
})
export class SmsCashTabComponent {
    
}
