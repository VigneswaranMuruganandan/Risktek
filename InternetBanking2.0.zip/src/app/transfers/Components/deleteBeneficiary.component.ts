import { Component, OnInit, Input} from '@angular/core';
import { Router } from '@angular/router';

@Component({
	selector: 'deleteBeneficiary-modal',
  templateUrl: './../templates/deleteBeneficiary.html'
})
export class DeleteBeneficiaryComponent {
    
}
