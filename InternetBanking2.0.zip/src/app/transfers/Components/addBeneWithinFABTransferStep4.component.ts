import { Component, OnInit, Input} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'addBeneWithinFABTransferStep4-component',
  templateUrl: './../templates/addBeneWithinFABTransferStep4.html'
})
export class AddBeneWithinFABTransferStep4Component {


    
    
}
