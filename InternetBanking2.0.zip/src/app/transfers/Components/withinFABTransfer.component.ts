import { Component, OnInit, Input} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  templateUrl: './../templates/withinFABTransfer.html'
})
export class WithinFABTransferComponent implements OnInit{

	public stepValue: number;
    constructor() {}

	ngOnInit() { 
    	this.stepValue = 1;
    }

    validateFormNextButton(){
    	this.stepValue = 2;
    }

    confirmReviewButton(){
    	this.stepValue = 3;
    }

    backReviewButton(){
        this.stepValue = 1;
    }

    validateOTP(){
    	this.stepValue = 4;
    }

    backOTPButton(){
        this.stepValue = 2;
    }


   
    
}
