import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { Router } from '@angular/router';

@Component({
	selector: 'addBeneWithinFABTransferStep2-component',
  templateUrl: './../templates/addBeneWithinFABTransferStep2.html'
})
export class AddBeneWithinFABTransferStep2Component {

	@Output() confirmReviewButtonEvent = new EventEmitter();
	@Output() backReviewButtonEvent = new EventEmitter();

	confirmReview(){
		this.confirmReviewButtonEvent.emit();
	}

	backReview(){
		this.backReviewButtonEvent.emit();
	}
    

    
}
