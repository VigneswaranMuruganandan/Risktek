import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { routing } from './transfers.routing';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '../shared/shared.module';
import {SharedService} from '../shared/services/shared.service';
import {TemplateService} from '../shared/services/template.service';
import { FormsModule } from '@angular/forms';
import { TransfersComponent } from './Components/transfers.component';
import { BetweenMyAccountsTabComponent } from './Components/betweenMyAccountsTab.component';
import { SmsCashTabComponent } from './Components/smsCashTab.component';
import { WithinFABTabComponent } from './Components/withinFABTab.component';
import { WithinUAETabComponent } from './Components/withinUAETab.component';
import { InternationalTransferTabComponent } from './Components/internationalTransferTab.component';
import { DeleteBeneficiaryComponent } from './Components/deleteBeneficiary.component';
import { WithinFABTransferComponent } from './Components/withinFABTransfer.component';
import { WithinFABTransferStep1Component } from './Components/withinFABTransferStep1.component';
import { WithinFABTransferStep2Component } from './Components/withinFABTransferStep2.component';
import { WithinFABTransferStep3Component } from './Components/withinFABTransferStep3.component';
import { WithinFABTransferStep4Component } from './Components/withinFABTransferStep4.component';
import { WithinUAETransferComponent } from './Components/withinUAETransfer.component';
import { WithinUAETransferStep1Component } from './Components/withinUAETransferStep1.component';
import { WithinUAETransferStep2Component } from './Components/withinUAETransferStep2.component';
import { WithinUAETransferStep3Component } from './Components/withinUAETransferStep3.component';
import { WithinUAETransferStep4Component } from './Components/withinUAETransferStep4.component';
import { OutsideUAETransferComponent } from './Components/outsideUAETransfer.component';
import { OutsideUAETransferStep1Component } from './Components/outsideUAETransferStep1.component';
import { OutsideUAETransferStep2Component } from './Components/outsideUAETransferStep2.component';
import { OutsideUAETransferStep3Component } from './Components/outsideUAETransferStep3.component';
import { OutsideUAETransferStep4Component } from './Components/outsideUAETransferStep4.component';

import { AddBeneWithinFABTransferComponent }      from './Components/addBeneWithinFABTransfer.component';
import { AddBeneWithinFABTransferStep1Component } from './Components/addBeneWithinFABTransferStep1.component';
import { AddBeneWithinFABTransferStep2Component } from './Components/addBeneWithinFABTransferStep2.component';
import { AddBeneWithinFABTransferStep3Component } from './Components/addBeneWithinFABTransferStep3.component';
import { AddBeneWithinFABTransferStep4Component } from './Components/addBeneWithinFABTransferStep4.component';
import { AddBeneWithinUAETransferComponent }      from './Components/addBeneWithinUAETransfer.component';
import { AddBeneWithinUAETransferStep1Component } from './Components/addBeneWithinUAETransferStep1.component';
import { AddBeneWithinUAETransferStep2Component } from './Components/addBeneWithinUAETransferStep2.component';
import { AddBeneWithinUAETransferStep3Component } from './Components/addBeneWithinUAETransferStep3.component';
import { AddBeneWithinUAETransferStep4Component } from './Components/addBeneWithinUAETransferStep4.component';
import { AddBeneOutsideUAETransferComponent }     from './Components/addBeneOutsideUAETransfer.component';
import { AddBeneOutsideUAETransferStep1Component } from './Components/addBeneOutsideUAETransferStep1.component';
import { AddBeneOutsideUAETransferStep2Component } from './Components/addBeneOutsideUAETransferStep2.component';
import { AddBeneOutsideUAETransferStep3Component } from './Components/addBeneOutsideUAETransferStep3.component';
import { AddBeneOutsideUAETransferStep4Component } from './Components/addBeneOutsideUAETransferStep4.component';
import { AddBeneOutsideUAETransferStep5Component } from './Components/addBeneOutsideUAETransferStep5.component';



const TRANSFERS_COMPONENTS = [
    TransfersComponent,
    BetweenMyAccountsTabComponent,
    SmsCashTabComponent,
    WithinFABTabComponent,
    WithinUAETabComponent,
    InternationalTransferTabComponent,
    DeleteBeneficiaryComponent,
    WithinFABTransferComponent,
    WithinFABTransferStep1Component,
    WithinFABTransferStep2Component,
    WithinFABTransferStep3Component,
    WithinFABTransferStep4Component,
    WithinUAETransferComponent,
    WithinUAETransferStep1Component,
    WithinUAETransferStep2Component,
    WithinUAETransferStep3Component,
    WithinUAETransferStep4Component,
    OutsideUAETransferComponent,
    OutsideUAETransferStep1Component,
    OutsideUAETransferStep2Component,
    OutsideUAETransferStep3Component,
    OutsideUAETransferStep4Component,
    AddBeneWithinFABTransferComponent,
    AddBeneWithinFABTransferStep1Component,
    AddBeneWithinFABTransferStep2Component,
    AddBeneWithinFABTransferStep3Component,
    AddBeneWithinFABTransferStep4Component,
    AddBeneWithinUAETransferComponent,
    AddBeneWithinUAETransferStep1Component,
    AddBeneWithinUAETransferStep2Component,
    AddBeneWithinUAETransferStep3Component,
    AddBeneWithinUAETransferStep4Component,
    AddBeneOutsideUAETransferComponent,
    AddBeneOutsideUAETransferStep1Component,
    AddBeneOutsideUAETransferStep2Component,
    AddBeneOutsideUAETransferStep3Component,
    AddBeneOutsideUAETransferStep4Component,
    AddBeneOutsideUAETransferStep5Component

];

const TRANSFERS_PROVIDERS = [
   SharedService,
   TemplateService
];

@NgModule({
  	imports: [
	    routing,
	    TranslateModule.forChild(),
	    SharedModule,
	    FormsModule,
		CommonModule
	],
  	declarations: [
	    ...TRANSFERS_COMPONENTS
	],
  	providers: [
  		...TRANSFERS_PROVIDERS
  	]
})
export class TransfersModule {}
