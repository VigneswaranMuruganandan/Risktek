import { Component, OnInit, Input, ElementRef, Output, EventEmitter} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import * as $ from 'jquery';
import {AccountDetailsResponse} from '../model/accountDetailsResponse';

@Component({
  selector: 'accounts-detail',
  templateUrl: './../templates/accountsDetail.html'
})
export class AccountsDetailComponent {
	@Input() account:any;
	@Input() accountDetails:AccountDetailsResponse;
	@Output() favouriteSelectedAccountEvent = new EventEmitter();
	
	constructor(){}

	viewMoreDetails (event:ElementRef){
		$('.more-details').slideToggle();
	}

	handleFavouriteSelected(data :any){
		this.favouriteSelectedAccountEvent.emit(data);
	}
}
