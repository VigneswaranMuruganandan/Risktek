import { Component, OnInit, Input,EventEmitter,Output} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import * as $ from 'jquery';



@Component({
  selector: '[accounts-rightcontent]',
  templateUrl: './../templates/accountsRightContent.html'
})
export class AccountsRightContentComponent {
	@Output() carouselAccountEvent = new EventEmitter();
	@Input() accountsData:any;


	slides = [
	    {caption: "Restaurent",imageUrl:"http://devlabs.synechron.com/fab/Front-End/assets/images/steak.png"},
	    {caption: "Hotel",imageUrl:"http://devlabs.synechron.com/fab/Front-End/assets/images/steak.png"},
	    {caption: "lounge",imageUrl:"http://devlabs.synechron.com/fab/Front-End/assets/images/steak.png"},
	    
	  ];

	  carouselAccount(account:any){
	  	this.carouselAccountEvent.emit(account);
	  }



}