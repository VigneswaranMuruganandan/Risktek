import { PersonalBankingPage } from './app.po';

describe('personal-banking App', () => {
  let page: PersonalBankingPage;

  beforeEach(() => {
    page = new PersonalBankingPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
