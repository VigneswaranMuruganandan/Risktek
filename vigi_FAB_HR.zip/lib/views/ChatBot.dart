import 'package:flutter/material.dart';
import 'package:fabhr/utils/customIcon.dart';

class ChatBot extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return new _ChatBotState();
  }
}

class _ChatBotState extends State<ChatBot> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        home: Scaffold(
      appBar: _buildAppBar(),
      body: _buildBody(),
    ));
  }

  Widget _buildAppBar() {
    return AppBar(
      //automaticallyImplyLeading: true,
      title: Text(
        'Chatbot',
        style: TextStyle(
          color: Color.fromRGBO(255, 255, 255, 1.0),
          fontSize: 16,
          letterSpacing: 0,
          fontFamily: 'FSMatthew',
        ),
      ),
      centerTitle: true,
      flexibleSpace: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
            colors: <Color>[
              Color.fromRGBO(0, 94, 188, 1.0),
              Color.fromRGBO(0, 48, 135, 1.0)
            ],
          ),
        ),
      ),
      leading: IconButton(
        icon: Icon(CustomIcon.back,
            size: 15.5, color: Color.fromRGBO(255, 255, 255, 1.0)),
        padding: EdgeInsets.all(5),
        onPressed: () => Navigator.pop(context, false),
      ),
      actions: <Widget>[
        new IconButton(
          icon: Icon(CustomIcon.search,
              size: 20, color: Color.fromRGBO(255, 255, 255, 1.0)),
          padding: EdgeInsets.all(4.7),
          onPressed: () => Navigator.of(context).pop(null),
        ),
      ],
    );
  }

  Widget _buildBody() {
    return Container(
      padding: EdgeInsets.only(left: 20, right: 20),
      child: new Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          new Expanded(
            child: new Material(
              color: Colors.red,
              child: new Text("Filled"),
            ),
          ),
          new Container(
            child: new TextField(
              decoration: new InputDecoration(
                  hintText: 'Message…',
                  suffixIcon: Icon(Icons.print),
                  hintStyle: TextStyle(
                      fontFamily: 'Graphik-Regular',
                      fontSize: 12,
                      color: Color.fromRGBO(185, 192, 202, 1.0))),
            ),
          ),
        ],
      ),
    );
  }
}
