import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:fabhr/utils/customIcon.dart';
import 'package:fabhr/utils/constants.dart';

class ManageAbsence extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return new _ManageAbsenceState();
  }
}

class _ManageAbsenceState extends State<ManageAbsence> {
  static List<Absence> _absenceList = [
    Absence('Unpaid Leave', AbsenceStatus.Saved, '8 May', '14 April'),
    Absence('Sick Leave', AbsenceStatus.withdrawal, '8 May', '14 April'),
    Absence('Maternity Leave', AbsenceStatus.Pending, '8 May', '14 April'),
    Absence('Sick Leave', AbsenceStatus.Completed, '8 May', '14 April'),
  ];

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        home: Scaffold(
      appBar: _buildAppBar(),
      body: SingleChildScrollView(child: _buildBody()),
    ));
  }

  Widget _buildAppBar() {
    return AppBar(
      //automaticallyImplyLeading: true,
      title: Text(
        'Ask HR',
        style: TextStyle(
          color: Color.fromRGBO(255, 255, 255, 1.0),
          fontSize: 16,
          letterSpacing: 0,
          fontFamily: 'FSMatthew',
        ),
      ),
      centerTitle: true,
      flexibleSpace: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
            colors: <Color>[
              Color.fromRGBO(0, 94, 188, 1.0),
              Color.fromRGBO(0, 48, 135, 1.0)
            ],
          ),
        ),
      ),
      leading: IconButton(
        icon: Icon(CustomIcon.close,
            size: 15.5, color: Color.fromRGBO(185, 192, 202, 1.0)),
        color: Color.fromRGBO(122, 125, 128, 1.0),
        onPressed: () => Navigator.pop(context, false),
      ),
      actions: <Widget>[
        new IconButton(
          icon: Icon(CustomIcon.close,
              size: 15.5, color: Color.fromRGBO(185, 192, 202, 1.0)),
          padding: EdgeInsets.all(6.8),
          color: Color.fromRGBO(122, 125, 128, 1.0),
          onPressed: () => Navigator.of(context).pop(null),
        ),
      ],
    );
  }

  Widget _buildBody() {
    return Container(
        decoration: BoxDecoration(color: Color.fromRGBO(246, 249, 252, 1.0)),
        margin: EdgeInsets.only(top: 33, left: 20, right: 20),
        child: Column(
            children: _absenceList
                .map((element) => absenceDetailRow(element))
                .toList()));
  }

  Container absenceDetailRow(Absence absence) {
    return Container(
      width: MediaQuery.of(context).size.width,
      decoration: BoxDecoration(
          color: Color.fromRGBO(255, 255, 255, 1.0),
          borderRadius: BorderRadius.circular(10),
          boxShadow: [
            new BoxShadow(
                color: Color.fromRGBO(185, 192, 202, 0.26),
                offset: new Offset(0.0, 24.0),
                blurRadius: 36.0,
                spreadRadius: 0)
          ]),
      padding: EdgeInsets.only(left: 28, bottom: 18),
      margin: EdgeInsets.only(bottom: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            width: 40,
            height: 4,
            color: _setColor(absence.status),
          ),
          Container(
            padding: EdgeInsets.only(bottom: 12, top: 12),
            child: Text(
              describeEnum(absence.status),
              style: TextStyle(
                  fontFamily: 'FSMatthew',
                  fontSize: 14,
                  letterSpacing: 0.83,
                  color: Color.fromRGBO(2, 113, 218, 1.0)),
            ),
          ),
          Container(
            padding: EdgeInsets.only(bottom: 12, top: 12),
            child: Text(
              absence.typeDesc,
              style: TextStyle(
                  fontFamily: 'FSMatthew-Medium',
                  fontSize: 16,
                  letterSpacing: 0.04,
                  color: Color.fromRGBO(12, 35, 64, 1.0)),
            ),
          ),
          Container(
            padding: EdgeInsets.only(top: 2, bottom: 2),
            child: Row(
              children: <Widget>[
                Container(
                  padding: EdgeInsets.only(right: 7),
                  child: Icon(
                    CustomIcon.approveLeave,
                    color: Color.fromRGBO(185, 192, 202, 1.0),
                    size: 15,
                  ),
                ),
                Container(
                  child: Row(
                    children: <Widget>[
                      Container(
                        child: Text('From: ',
                            style: TextStyle(
                                fontFamily: 'FSMatthew',
                                fontSize: 12,
                                letterSpacing: 0.03,
                                color: Color.fromRGBO(100, 121, 149, 1.0))),
                      ),
                      Container(
                        child: Text(absence.fromDate,
                            style: TextStyle(
                                fontFamily: 'FSMatthew',
                                fontSize: 12,
                                letterSpacing: 0.03,
                                color: Color.fromRGBO(100, 121, 149, 1.0))),
                      ),
                      Container(
                        padding: EdgeInsets.only(left: 7),
                        child: Text('To: ',
                            style: TextStyle(
                                fontFamily: 'FSMatthew',
                                fontSize: 12,
                                letterSpacing: 0.03,
                                color: Color.fromRGBO(100, 121, 149, 1.0))),
                      ),
                      Container(
                        child: Text(absence.toDate,
                            style: TextStyle(
                                fontFamily: 'FSMatthew',
                                fontSize: 12,
                                letterSpacing: 0.03,
                                color: Color.fromRGBO(100, 121, 149, 1.0))),
                      )
                    ],
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }

  Color _setColor(AbsenceStatus status) {
    Color val;
    switch (status) {
      case AbsenceStatus.Saved:
        val = SAVED;
        break;
      case AbsenceStatus.Pending:
        val = PENDING;
        break;
      case AbsenceStatus.Completed:
        val = COMPLETED;
        break;
      case AbsenceStatus.withdrawal:
        val = WITHDRAWAL;
        break;
      default:
    }
    return val;
  }
}

class Absence {
  String typeDesc;
  AbsenceStatus status;
  String fromDate;
  String toDate;
  Absence(this.typeDesc, this.status, this.fromDate, this.toDate);
}

enum AbsenceStatus { Saved, Pending, Completed, withdrawal }
