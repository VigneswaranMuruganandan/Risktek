import 'package:flutter/material.dart';
import 'package:fabhr/utils/customIcon.dart';

class BottomDialogLayout extends StatefulWidget {
  _BottomDialogLayoutState createState() => _BottomDialogLayoutState();
}

class _BottomDialogLayoutState extends State<BottomDialogLayout> {
  String _selectedItem = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            RaisedButton(
              child: Text('Show'),
              onPressed: () => _onButtonPressed(),
            ),
            Text(
              _selectedItem,
              style: TextStyle(fontSize: 30),
            ),
          ],
        ),
      ),
    );
  }

  void _onButtonPressed() {
    showModalBottomSheet(
        context: context,
        builder: (context) {
          return ConstrainedBox(
            constraints: new BoxConstraints(
              maxHeight: 283.0,
            ),
            child: Container(
              decoration: new BoxDecoration(
                  color: Color(0xFF737373),
                  border: new Border.all(color: Color(0xFF737373))),
              child: Column(
                children: <Widget>[
                  Center(
                    child: Container(
                        margin: EdgeInsets.only(bottom: 8),
                        width: 39,
                        height: 4,
                        decoration: BoxDecoration(
                          color: Color.fromRGBO(244, 248, 253, 1.0),
                          borderRadius: BorderRadius.circular(10),
                        )),
                  ),
                  Expanded(
                    child: Container(
                      child: _buildBottomFailureBar(),
                      decoration: BoxDecoration(
                        color: Theme.of(context).canvasColor,
                        borderRadius: BorderRadius.only(
                          topLeft: const Radius.circular(30),
                          topRight: const Radius.circular(30),
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
          );
        });
  }

  Column _buildBottomSuccessBar() {
    return Column(
      children: <Widget>[
        SizedBox(
          height: 46,
        ),
        Center(
            child: CircleAvatar(
          backgroundColor: Color.fromRGBO(10, 189, 28, 1.0),
          radius: 30,
          child: Icon(
            Icons.done,
            size: 22,
            color: Color.fromRGBO(255, 255, 255, 1.0),
          ),
        )),
        Container(
          padding: EdgeInsets.only(top: 39, bottom: 34, left: 83, right: 83),
          child: Text('Requisition approved successfully',
              style: TextStyle(
                  fontFamily: 'FSMatthew-Medium',
                  fontSize: 22,
                  letterSpacing: 0.05,
                  color: Color.fromRGBO(12, 35, 64, 1.0)),
              textAlign: TextAlign.center),
        )
      ],
    );
  }

  Column _buildBottomFailureBar() {
    return Column(
      children: <Widget>[
        SizedBox(
          height: 46,
        ),
        Center(
            child: CircleAvatar(
          backgroundColor: Color.fromRGBO(189, 10, 10, 1.0),
          radius: 30,
          child: Icon(
            Icons.close,
            size: 22,
            color: Color.fromRGBO(255, 255, 255, 1.0),
          ),
        )),
        Container(
          padding: EdgeInsets.only(top: 39, bottom: 34, left: 83, right: 83),
          child: Text('Requisition rejected successfully',
              style: TextStyle(
                  fontFamily: 'FSMatthew-Medium',
                  fontSize: 22,
                  letterSpacing: 0.05,
                  color: Color.fromRGBO(12, 35, 64, 1.0)),
              textAlign: TextAlign.center),
        )
      ],
    );
  }
}
