import 'package:flutter/material.dart';
import 'package:fabhr/views/HomeView.dart';
import 'package:fabhr/views/ApprovalRequests.dart';
import 'package:fabhr/views/ContactUs.dart';
import 'package:fabhr/BottomDialogLayout.dart';
import 'package:fabhr/views/ManageAbsence.dart';
import 'package:fabhr/views/ChatBot.dart';

void main() => runApp(new MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new MaterialApp(
      title: 'FAB HR',
      theme: new ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: new HomeView(),
      routes: <String, WidgetBuilder>{
        '/approvalRequests': (BuildContext context) => new ApprovalRequests(),
        '/contactUs': (BuildContext context) => new ChatBot(),
      },
    );
  }
}
