import 'package:fabhr/utils/router.dart';
import 'package:fabhr/utils/style.dart';
import 'package:flutter/material.dart';
import 'package:fabhr/utils/constants.dart';
import 'package:fabhr/models/MenuItem.dart';
import 'package:fabhr/utils/customIcon.dart';

class MenuScreen extends StatelessWidget {
  MenuScreen({
    this.onButtonTap,
  });
  final VoidCallback onButtonTap;
  final List<MenuItem> options = [
    MenuItem(CustomIcon.applyLeave, 'APPROVALREQUESTS', 'Apply leave'),
    MenuItem(CustomIcon.approveLeave, 'APPROVALREQUESTS', 'Approve leave'),
    MenuItem(
        CustomIcon.approveExpenses, 'APPROVALREQUESTS', 'Approve expenses'),
    MenuItem(CustomIcon.approveRequisition, 'APPROVALREQUESTS',
        'Approve requsition'),
    MenuItem(CustomIcon.contactUs, CONTACTUS, 'Contact us'),
  ];

  Widget fABLogo(BuildContext context) {
    return new Container(
        child: Row(
      children: <Widget>[
        Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Container(
              height: 43.0,
              width: 74.0,
              decoration: BoxDecoration(
                  image: DecorationImage(
                image: AssetImage('assets/images/logo.png'),
                fit: BoxFit.fill,
              )),
            )),
        Spacer(),
      ],
    ));
  }

  Widget staffName(BuildContext context) {
    return new Container(
        child: Row(
      children: <Widget>[
        Padding(
            padding: const EdgeInsets.only(top: 66),
            child: Text(
              'Elizabeth Cruz',
              style: EmployeeName,
            )),
      ],
    ));
  }

  Widget staffTitle(BuildContext context) {
    return new Container(
        child: Row(
      children: <Widget>[
        Padding(
            padding: const EdgeInsets.only(top: 7),
            child: Text(
              'Project Manager',
              style: EmployeeRole,
            )),
      ],
    ));
  }

  Widget menuItems(BuildContext context) {
    return new Container(
        child: Column(
      children: options.map((item) {
        return ListTile(
            onTap: () {
              triggerMenuTap(context, item.id);
            },
            leading: Padding(
              padding: EdgeInsets.all(9.0),
              child: Icon(
                item.icon,
                color: Colors.white,
                size: 23,
              ),
            ),
            title: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                item.title,
                style: MenuText,
              ),
            ));
      }).toList(),
    ));
  }

  Widget logout(BuildContext context) {
    return new Container(
        child: Column(
      children: <Widget>[
        ListTile(
          leading: Padding(
              padding: EdgeInsets.all(9.0),
              child: Icon(
                CustomIcon.logOut,
                color: Colors.white,
                size: 23,
              )),
          title: Align(
              alignment: Alignment.centerLeft,
              child: Text('Logout', style: MenuText)),
        )
      ],
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
          top: 68,
          left: 15,
          bottom: 81,
          right: MediaQuery.of(context).size.width / 2.9),
      decoration: MenuGradient,
      child: Column(
        children: <Widget>[
          fABLogo(context),
          staffName(context),
          staffTitle(context),
          Spacer(),
          menuItems(context),
          Spacer(),
          logout(context),
        ],
      ),
    );
  }

  triggerMenuTap(context, String id) {
    Navigator.of(context).pushNamed(id);
    this.onButtonTap();
  }
}
