<?php 
require_once 'book_data/db_connect1.php';
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>PHP</title>

	<style type="text/css">
		.manageMember {
			width: 50%;
			margin: auto;
		}

		table {
			width: 100%;
			margin-top: 20px;
		}

	</style>

</head>
<body>

<div class="manageMember">
	<a href="create2.php"><button type="button">Add </button></a>
	<table border="1" cellspacing="0" cellpadding="0">
		<thead>
			<tr>
				<th>id</th>
				<th>Name</th>
				<th>Description</th>
				<th>Author_name</th>
				<th>Price</th>
				<th>Review points</th>
			</tr>
		</thead>
		<tbody>
			<?php
			 $con = db_connect1();
			$sql = "SELECT * FROM books";
			$result =$con->query($sql);
          if($result->num_rows>0) {
				while($row = $result->fetch_assoc()) {
					echo "<tr>
						<td>".$row['id']." </td>
						<td>".$row['Name']."</td>
						<td>".$row['Description']."</td>
						<td>".$row['Author_name']."</td>
						<td>".$row['Price']."</td>
						<td>".$row['Review_points']."</td>
						<td>
							<a href='edit2.php?id=".$row['id']."'><button type='button'>Edit</button></a>
							<a href='delete2.php?id=".$row['id']."'><button type='button'>delete</button></a>
						</td>
					</tr>";
				}
			} else {
				echo "<tr><td colspan='5'><center>No Data Avaliable</center></td></tr>";
			}
			?>
		</tbody>
	</table>
</div>

</body>
</html>