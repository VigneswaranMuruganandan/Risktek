<?php 
//require_once '../controller/book_controller.php';
$servername = "localhost";
$username = "root";
$password = "";

// Create connection
$conn = new mysqli($servername, $username, $password, "php_book");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
echo "Connected successfully";
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>PHP</title>
	<style type="text/css">
		.manageMember {
			width: 50%;
			margin: auto;
		}

		table {
			width: 100%;
			margin-top: 20px;
		}
	</style>
</head>
<body>
<div class="manageMember">
	<a href="create2.php"><button type="button">Add </button></a>
	<table border="1" cellspacing="0" cellpadding="0">
		<thead>
			<tr>
				<th>id</th>
				<th>Name</th>
				<th>Description</th>
				<th>Author_name</th>
				<th>Price</th>
				<th>Review points</th>
			</tr>
		</thead>
		<tbody>
		</tbody>
	</table>
</div>
</body>
</html>