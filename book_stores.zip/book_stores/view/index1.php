<?php
  require_once '../controller/book_controller.php';
  if (isset($_POST['submit'])) {
    $status = insertBook($_POST);
    var_dump($status);
  }
  /*elseif(isset($_SESSION['per_page'])) {
      $per_page = $_SESSION['per_page'];
  } else {
      $per_page = 5;
  }
  $_SESSION['per_page'] = $per_page;

  // print_r($_SESSION['pageno']);
  if (isset($_GET['pageno'])) {
      $pageno = $_GET['pageno'];
  }
  elseif(isset($_SESSION['pageno'])) {
      $pageno = $_SESSION['pageno'];
  } else {
      $pageno = 1;
  }
  $_SESSION['pageno'] = $pageno;*/

  //$books = new stores();
  //$lists = $books -> getall(5, $per_page);
 
?>
