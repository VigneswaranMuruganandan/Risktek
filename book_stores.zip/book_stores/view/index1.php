<?php
   
  require_once '../controller/book_controller.php';

   if(isset($_POST['submit'])){
        $per_page = $_POST['data'];
  } elseif(isset($_SESSION['per_page'])){
        $per_page = $_SESSION['per_page'];
 }else {
        $per_page = 5;
  }
       $_SESSION['per_page']= $per_page;
      
  // print_r($_SESSION['pageno']);
   if (isset($_GET['pageno'])) {
            $pageno = $_GET['pageno'];
  }elseif(isset($_SESSION['pageno'])){
           $pageno = $_SESSION['pageno'];
  } else {
            $pageno = 1;
        }
           $_SESSION['pageno']= $pageno;
      
$books = new stores();
$lists = $books->getall($pageno,$per_page);

?>

<!DOCTYPE html>
<html>
<head>
  
  
    <title>PHP CRUD</title>
    <style type="text/css">
    .pagination{
 list-style: none;
}
.pagination li{
 float: left;
 /*border: 1px solid #000;*/
 padding: 5px 5px;
 margin-right: 5px;
 border-radius: 5px;
}

.pagination li a{
  text-decoration: none;
  color:black;
  /*border: 1px solid black;*/
  background-color: lightblue;
  padding-top: 10px;
  padding-right: 15px;
  padding-bottom: 15px;
  padding-left: 15px;
}

.active{
 color: red !important;
}
</style>
 
    <style type="text/css">
        .book {
            width: 50%;
            margin: auto;
        }
 
        table {
            width: 100%;
            margin-top: 20px;
        }
 
    </style>
 
</head>
<body>
 <div class="books">
    <a href="create1.php">Add Book</a> <br> <br>
    <?php
     echo "The total number of records are  ". $lists['total'];
 // print_r($lists['result']);

     ?> <br> <br>
      <table border="1" cellspacing="0" cellpadding="0">
        <form method="post" name="myform" action="index1.php">
        <select name="data">
            <option value="pageno">page</option>
             <option value="5" <?php if($_SESSION['per_page'] == 5){ echo 'selected'; } ?> >5</option> 
            <option value="10" <?php if($_SESSION['per_page'] == 10){ echo 'selected'; } ?> >10</option>
            <option value="15" <?php if($_SESSION['per_page'] == 15){ echo 'selected'; } ?> >15</option>
      </select> 
      <input type="submit" value="submit" name="submit">
            <!-- <button type="submit" name="Submit">Submit</button> -->
      </form>
      
  
  
      <thead>
            <tr>
                <th>book_id</th>
                <th>book_name</th>
                <th>book_description</th>
                <th>book_status</th>
                <th>created_at</th>
                <th>updated_at</th>
                <th>Action</th>
            </tr>
      </thead>

   
<?php
 $cnt=1

    
     
      if(count($lists)){ 
  // date_default_timezone_set('Asia/Shanghai'); 
  // $a = '2016-03-01T03:00:00Z';
 foreach ($lists['result'] as $row) { ?>
        <tr>
        <td> <?php echo $row['book_id']; ?> </td>
          <td> <?php echo ucfirst($row['book_name']); ?> </td>
          <td> <?php echo $row['book_description']; ?> </td>
          <td> <?php echo ucfirst($row['book_status']); ?> </td>
        <td> <?php echo date("d/m/Y H:i A",strtotime($a)($row['created_at'])) ; ?> </td>
          <td> <?php echo date("d/m/Y H:i A",strtotime($a)($row['updated_at'])); ?> </td>
          <<td> <?php echo $cnt; ?> </td>   
            
             <td> <a href="edit1.php?book_id=<?php echo $row['book_id']?>"><button type = "button">Edit-book</button></a> &nbsp; &nbsp;
              <a href="delete1.php?book_id=<?php echo $row['book_id']?>"><button type = 'button'>Delete</button></a>
          </td>
    </tr>
    
<?php } } ?>
                 
<?php
$cnt++;
?>
</table>  
  <div align="center">
    <ul class="pagination" >
        <li><a href="index1.php?pageno=1">First</a></li>
        <li class="<?php if($pageno <= 1){ echo 'disabled'; } ?>">
            <a href="<?php if($pageno <= 1){ echo '#'; } else { echo "?pageno=".($pageno - 1); } ?>">Prev</a>
        </li>
        </li>


   <li class="page-item"><a href="index1.php?pageno=2#" class="page-link">1</a></li>
            <li class="page-item"><a href="index1.php?pageno=3#" class="page-link">2</a></li>
            <li class="page-item"><a href="index1.php?pageno=4#" class="page-link">3</a></li>

        <li class="<?php if($pageno >= $total_pages){ echo 'disabled'; } ?>">
            <a href="index1.php?pageno=<?php if($pageno >= $total_pages){ echo '#'; } else { echo "?pageno=".($pageno + 1); } ?>">Next</a>
        </li>
        <li><a href="index1.php?pageno=?pageno=<?php echo $total_pages; ?>">Last</a></li>
    </ul>
</div>


</body>
</html>
