<!DOCTYPE html>
<html>
<head>
	<title>Add</title>
	<style type="text/css">
		/*fieldset {
			margin: auto;
			margin-top: 100px;
			width: 50%;
		}

		table tr th {
			padding-top: 20px;
		}*/
	</style>
</head>
<body>
	<fieldset>
		<legend>Add</legend>
		<form action="index1.php" method="post">
			<table cellspacing="0" cellpadding="0">
				<tr>
					<th valign="top">Book Name</th>
					<td><input type="text " name="bookName"/></td>
				</tr>
				<tr>
					<th valign="top">Book Description</th>
					<td><input type="text area" name="bookDescription"/></td>
				</tr>
				<tr>
					<th valign="top">Book Status</th>
					<td><input type="radio" name="book_status" values="active"/> Active</td>
					<td><input type="radio" name="bookStatus" values="inactive"/> Inactive</td>
					<br/><br/>
				</tr>
				<tr>
					<td><button type="submit" name="save_changes">Save Changes</button></td>
					<td><a href="index1.php"><button type="button">Back</button></a></td>
				</tr>
			</table>
		</form>
	</fieldset>
</body>
</html>