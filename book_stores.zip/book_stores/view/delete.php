<?php 

require_once '../controller/book_controller.php';
if(isset($_GET['id'])) {
	$emp_id = $_GET['id'];
	// echo $book_id; die;
	// $sql = "SELECT * FROM book_list Where book_id = {$id}";
	// $result = $connect->query($sql);
	// $data = $result->fetch_assoc();

	// $connect->close();
?>

<!DOCTYPE html>
<html>
<head>
	<title>delete</title>
</head>
<body>
	<h3>Do you really want to remove ?</h3>
<form action="book_data/delete.php" method="post">

	<input type="hidden" name="emp_id" value="<?php echo $emp_id; ?>" />
	
	<button type="submit">Save Changes</button>
	<a href="list.php"><button type="button">Back</button></a>
</form>

</body>
</html>

<?php
}
?>
