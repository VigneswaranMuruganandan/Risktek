<!DOCTYPE html>
<html>
<head>
	<title>Add</title>
	<style type="text/css">
		fieldset {
			margin: auto;
			margin-top: 100px;
			width: 50%;
		}
		.mbt10{
			padding-bottom: 20px;
		}
		.width-50{
			width:50%;
		}

	</style>
</head>
<body>
	<fieldset>
		<legend>Add</legend>
		<form action="index1.php" method="post">
			<table cellspacing="0" cellpadding="0">
				<tr>
					<td class="mbt10 width-50">Book Name</td>
					<td class="mbt10"><input type="text " name="bookName"/></td>
				</tr>
				<tr>
					<td class="mbt10 width-50">Book Description</td>
					<td class="mbt10"><input type="text area" name="bookDescription"/></td>
				</tr>
				<tr>
					<td class="mbt10 width-50">Book Status</td>
					<td class="mbt10"><input type="radio" name="bookStatus" values="active"/> Active</td>
					<td class="mbt10"><input type="radio" name="bookStatus" values="inactive"/> Inactive</td>
				</tr>
				<tr>
					<td align="right">
						<a href="index1.php"><button type="button">Back</button></a>
						<td><button type="submit" value="Submit" name="submit">Save Changes</button></td>
					</td>
				</tr>
			</table>
		</form>
	</fieldset>
</body>
</html>