<!DOCTYPE html>
<html>
<head>
	<title>Add</title>

	<style type="text/css">
		fieldset {
			margin: auto;
			margin-top: 100px;
			width: 50%;
		}

		table tr th {
			padding-top: 20px;
		}
	</style>

</head>
<body>

<fieldset>
	<legend>Add</legend>

	<form action="index1.php" method="post">
		<table cellspacing="0" cellpadding="0">
			<tr>
				<th>Book Name</th>
				<td><input type="text " name="book_name"/></td>
			</tr>
			<tr>
				<th>Book Description</th>
				<td><input type="text area" name="book_description"/></td>
			</tr>
			<tr>
				<th>Book Status</th>
				<td>active<input type="radio" name="book_status" values="active"/></td>
				<td>inactive<input type="radio" name="book_status" values="inactive"/></td>
				<br/>
			</tr>
			<tr>
				<td><button type="submit" name="save_changes">Save Changes</button></td>
				<td><a href="index1.php"><button type="button">Back</button></a></td>
			</tr>
		</table>
	</form>

</fieldset>

</body>
</html>