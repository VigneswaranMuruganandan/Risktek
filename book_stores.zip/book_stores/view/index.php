<?php
  require_once '../controller/book_controller.php';
  if (isset($_POST['submit'])) {
    var_dump($_POST['submit']);
    switch ($_POST['submit']) {
      case 'create':
        $status = insertBook($_POST);
      break;
      case 'update':
        $status = updateBook($_POST);
      break;
      case 'delete':
        $status = deleteBook($_POST);
      break;
    }
  }
  $lists = bookList();
?>
<!DOCTYPE html>
<html>
<head>
  <title>PHP MVC Pattern</title>
  <link rel="stylesheet" type="text/css" href="../assets/style.css">
</head>
<body>
  <div class="books">
    <div class="bookList">
      <button class="button fright" onclick="create();">Add Book</button>
      <table border="1" cellspacing="0" cellpadding="0">
        <thead>
          <tr>
              <th>Book ID</th>
              <th>Book Name</th>
              <th>Book Description</th>
              <th>Book Status</th>
              <th>Created on</th>
              <th>Update on</th>
              <th>Action</th>
          </tr>
      </thead>
      <?php
        if(count($lists)){
           foreach ($lists as $row) { 
      ?>
      <tr>
        <td> <?php echo $row['id']; ?> </td>
        <td> <?php echo ucfirst($row['name']); ?> </td>
        <td> <?php echo $row['description']; ?> </td>
        <td> <?php echo $row['status']; ?> </td>
        <td> <?php echo $row['createdOn']; ?> </td>
        <td> <?php echo $row['updatedOn']; ?> </td>
        <td align="center">
          <button class="button button2" onclick="update(<?php echo $row['id'].",'".$row['name']."','".$row['description']."','".$row['status']."'" ?>);">Update</button>
          <button class="button button3" onclick="deleteConfirmation(<?php echo $row['id']?>);">Delete</button>
        </td>
      </tr>
      <?php 
          }
        }
      ?>
    </table>
    </div>
    <div id="createModal" class="modal">
      <div class="modal-content">
        <span class="close">&times;</span>
        <form action="index.php" method="post">
          <label for="bookName">Book Name</label>
          <input type="text" name="bookName" placeholder="Your Book Name..">

          <label for="bookDescription">Book Description</label>
          <input type="text" name="bookDescription" placeholder="Your Book Description..">

          <label for="bookStatus">Book Status</label>
          <select name="bookStatus">
            <option value="">Select</option>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
          <button class="button fright" type="submit" value="create" name="submit">Create</button>
          <div class="clear"></div>
        </form>
      </div>
    </div>
    <div id="updateModal" class="modal">
      <div class="modal-content">
        <div class="modal-header">
          <span class="close">&times;</span>
        </div>
        <form name="updateBook" action="index.php" method="post">
          <label for="bookName">Book Name</label>
          <input type="hidden" name="bookId">
          <input type="text" name="bookName">

          <label for="bookDescription">Book Description</label>
          <input type="text" name="bookDescription" placeholder="Your Book Description..">

          <label for="bookStatus">Book Status</label>
          <select name="bookStatus">
            <option value="">Select</option>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
          <button class="button fright" type="submit" value="update" name="submit">Update</button>
          <div class="clear"></div>
        </form>
      </div>
    </div>
    <div id="deleteModal" class="modal">
      <div class="modal-content">
        <div class="modal-header">
          <span class="close">&times;</span>
        </div>
        <form name="deleteBook" action="index.php" method="post">
          <input type="hidden" name="bookId">
          <p>Are you sure to delete the Book ?</p>
          <button class="button fright" type="submit" value="delete" name="submit">Delete</button>
          <div class="clear"></div>
        </form>
      </div>
    </div>
  </div>
<script type="text/javascript" src="../assets/script.js"></script>
</body>
</html>
