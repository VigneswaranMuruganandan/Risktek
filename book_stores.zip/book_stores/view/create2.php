<!DOCTYPE html>
<html>
<head>
	<title>Add</title>

	<style type="text/css">
		fieldset {
			margin: auto;
			margin-top: 100px;
			width: 50%;
		}

		table tr th {
			padding-top: 20px;
		}
	</style>

</head>
<body>

<fieldset>
	<legend>Add data</legend>

	<form action="management/create2.php" method="post">
		<table cellspacing="0" cellpadding="0">
			<tr>
				<th>Name</th>
				<td><input type="text " name="book_name"/></td>
			</tr>
			<tr>
				<th>Description</th>
				<td><input type="text area" name="Description"/></td>
			</tr>
			<tr>
				<th>Author name</th>
				<td><input type="text" name="Author_name"/></td>
			</tr>
			<tr>
				<th>Price</th>
				<td><input type="number" name="Price"/></td>
			</tr>
			<tr>
				<th>Review points</th>
				<td><input type="number" name="Review_points"/></td>
			</tr>
			<tr>
				<th>Publish status</th>

				<td>active<input type="radio" name="publish_status" values="active"/></td>
				<td>inactive<input type="radio" name="publish_status" values="inactive"/></td>
				<br/>
			</tr>
			<tr>
				<td><button type="submit" name="save_changes">Save Changes</button></td>
				<td><a href="index2.php"><button type="button">Back</button></a></td>
			</tr>
		</table>
	</form>

</fieldset>

</body>
</html>