<?php 
require_once '../controller/book_controller.php';

if(isset($_GET['id '])) {
	// $id = $_GET['id'];
	$id = $_GET['id '];
	$sql = "SELECT * FROM book_list WHERE book_id=" .$id;
	$result = $connect->query($sql);

		$data = $result->fetch_assoc();

    $connect->close();
}


?>

<!DOCTYPE html>
<html>
<head>
	<title>Edit data</title>

	<style type="text/css">
		fieldset {
			margin: auto;
			margin-top: 100px;
			width: 50%;
		}

		table tr th {
			padding-top: 20px;
		}
	</style>

</head>
<body>

<fieldset>
	<legend>Edit data</legend>

	<form action="books_data/update1.php" method="post">
		<table cellspacing="0" cellpadding="0">
			<tr>
				<th>book_id</th>
				<td><input type="text" name="book_id" value="<?php echo ['book_id'] ?>" /></td>
			</tr>		
			<tr>
				<th>book_name</th>
				<td><input type="text" name="book_name"value="<?php echo $data['book_name'] ?>" /></td>
			</tr>
			<tr>
				<th>book_description</th>
				<td><input type="text" name="book_description" value="<?php echo $data['book_description'] ?>" /></td>
			</tr>
			<tr>
				<th>book_status</th>
				<td><input type="text" name="book_status" value="<?php echo $data['book_status'] ?>" /></td>
			</tr>
			<tr>
				<th>created_at</th>
				<td><input type="numeric" name="created_at" value="<?php echo $data['created_at'] ?>" /></td>
			</tr>
			<tr>
				<th>updated_at</th>
				<td><input type="numeric" name="updated_at" value="<?php echo $data['updated_at'] ?>" /></td>
			</tr>
			<tr>
				<input type="hidden" name="id" value="<?php echo $data['id']?>" />
				<td><button type="submit">Save Changes</button></td>
				<td><a href="index1.php"><button type="button">Back</button></a></td>
			</tr>
		</table>
	</form>

</fieldset>

</body>
</html>

