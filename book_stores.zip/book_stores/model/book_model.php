<?php
session_start();
function db_connect(){
    $localhost = "localhost";
    $username = "root";
    $password = "";
    $dbname = "php_book";

    $connect = new mysqli($localhost, $username, $password, $dbname);
    if($connect->connect_error) {
        die("connection failed : " . $connect->connect_error);
    }else {
      //echo "Successfully Connected";
    }
    return $connect;
}



class stores {
    public function getall(){
        $con = db_connect();
        $query="SELECT * FROM books";
        $res_count =mysqli_query($con,$query);
        $result = $res_count->fetch_all(MYSQLI_ASSOC);
        return $result;
    }

    public function insertBook_rec($field) {
        $con = db_connect();
        $sql = "SELECT name FROM books WHERE name= '".$field['bookName']."'";
        $res1 =  mysqli_query($con, $sql);
        $rec = $res1->fetch_all(MYSQLI_ASSOC);

        if(is_array($rec) && !empty($rec) )
        {
            return 3;
        }
        $dt = new DateTime();
        $insertData = "INSERT INTO books(name, description, status, createdOn) VALUES ('" . $field['bookName'] . "', '" .$field['bookDescription']. "','" .$field['bookStatus']."',".$dt->format('m/d/Y').")";
        if (mysqli_query($con,$insertData)) {
            return 1;     
        } else {
            return 2;     
        } 
        mysqli_close($con);
    }

    public function deleteBook_rec($field) {
        $con = db_connect();
        $sql = "DELETE from books where id= '".$field['bookId']."'";
        if($con->query($sql) === TRUE) {
            header('Refresh: 0');
            return 1;
        }else {
            return 0;
        }        
    }

    public function updateBook_rec($field) {
        $con = db_connect();
        $sql = "UPDATE books SET name = '".$field['bookName']."', description = '".$field['bookDescription']."', status = '".$field['bookStatus']."' WHERE id =" .$field['bookId'];
        if ($con->query($sql) === TRUE) {
            header('Refresh: 0');
            return 1;
        } else {
            return 0;
        }
    }
} 
?>