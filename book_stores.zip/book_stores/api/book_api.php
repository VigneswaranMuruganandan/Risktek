<?php
require('../controller/book_api_controller.php');

$single = rec_book();
$msg=insert_api($field);
die;


// $date = date("M d, Y");
// print json_encode($date); 
date_default_timezone_set('Asia/Shanghai'); 
$a = '2016-03-01T03:00:00Z';
//echo json_encode(date("d/m/Y H:i A",strtotime($a)));
// print_r($single);
  $myJSON = json_encode($single);
//  // $myJSON = json_encode($double);
 echo $myJSON;

?>