<?php
require('../controller/book_api_controller.php');
	//$single = rec_book();
	$msg = insert_api($field);
	die;
	// $date = date("M d, Y");
	// print json_encode($date); 
	date_default_timezone_set('Asia/Shanghai'); 
  	//$myJSON = json_encode($single);
 	//echo $myJSON;
?>