<?php
require('../controller/book_api_controller.php');

    $book_name =" ";
    $book_description =" ";
    $book_status =" ";


    if(isset($_POST['book_name'])){
       $book_name = $_POST['book_name'];
   }

    if(isset($_POST['book_description'])){
       $book_description=$_POST['book_description'];
    }

    if(isset($_POST['book_status'])){
       $book_status =$_POST['book_status'];
    }
    


    $field = array('book_name'=> $book_name, 
    	           'book_description'=> $book_description, 
    	            'book_status'=> $book_status);
print_r($field);
 // $field = insert_api($shop);
    $msg=insert_api($field);
   $alert = json_encode($msg);

   echo $alert;


?>
