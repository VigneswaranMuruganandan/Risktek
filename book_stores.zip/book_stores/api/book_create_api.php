<? php
session_start();

function db_connect1() {

    $localhost = "127.0.0.1";
    $username = "root";
    $password = "";
    $dbname = "php_book";


    // create connection
    $connect = new mysqli($localhost, $username, $password, $dbname);

    // check connection
    if ($connect - > connect_error) {
        die("connection failed : ".$connect - > connect_error);
    } else {
        // echo "Successfully Connected";
    }
    return $connect;

}

/*class stores {

    public function getall($pageno, $per_page) {
      $con = db_connect1();
      $no_of_records_per_page = $per_page;
      $offset = ($pageno - 1) * $no_of_records_per_page;


      $query = "SELECT SQL_CALC_FOUND_ROWS * FROM book_list LIMIT  $offset,$no_of_records_per_page; ";
      $res_count = mysqli_query($con, $query);
      $result = $res_count - > fetch_all(MYSQLI_ASSOC);

      $found = " SELECT FOUND_ROWS() AS NumberOfRowsFound";

      $res_found = mysqli_query($con, $found);
      // $result2 = $res_found->fetch_all(MYSQLI_ASSOC);
      $results2 = mysqli_fetch_assoc($res_found);
      $total_rows = $results2['NumberOfRowsFound'];
      $total_pages = ceil($total_rows / $no_of_records_per_page);
      // $results2=mysqli_fetch_assoc($total_pages);
      $lists = array(
          "result" => $result,
          "total" => $total_rows
      );
      return $lists;
    }

    public function update_book($book_id, $book_name, $book_description, $book_status) {
      if ($_POST) {
          $book_id = $_POST['book_id'];
          $book_name = $_POST['book_name'];
          $book_description = $_POST['book_description'];
          $book_status = $_POST['book_status'];
          $created_at = $_POST['created_at'];
          $updated_at = $_POST['updated_at'];
          $id = $_POST['id'];
          $con = db_connect1();
          if (count($_POST) > 0) {
              $sql = "UPDATE book_list SET book_name = '".$book_name.
              "', book_descrip = '".$book_descrip.
              "', book_status = '".$book_status.
              "' WHERE book_id =".$book_id;

              $addbook = mysqli_query($con, $sql);
              $con-> close();
          }
      }
    }
    public function add_detail($book_name, $book_description, $book_status) {
      if (isset($_POST["save_changes"])) {
          $book_name = isset($_POST['book_name']) ? $_POST['book_name'] : '';
          $book_description = isset($_POST['book_description']);
          $book_status = isset($_POST['book_status']);

          $con = db_connect();
          $insertData = "INSERT INTO book_list(book_name, book_descrip, book_status) VALUES ('".$book_name."', '".$book_description."', '".$book_status."')";
          if (mysqli_query($con, $insertData)) {
              echo "New record created successfully";
              header("Location: index1.php");
          } else {
              echo "Error: ".$sql.
              "<br>".mysqli_error($con);
          }
          mysqli_close($con);
      }
    }


    public function delete_data($id) {
        if (isset($_POST['book_id'])) {
            $id = $_POST['book_id'];
            $sql = "DELETE from book_list where book_id = $id;";
            if ($connect - > query($sql) === TRUE) {
                echo "<p>Successfully deleted!!</p>";
                echo "<a href='../index1.php'><button type='button'>Back</button></a>";
            } else {
                echo "Error updating record : ".$connect - > error;
            }
            $con-> close();
        }
    }


    public function book_rec() {
      $con = db_connect1();
      $sql = "SELECT book_id,book_name,book_description, book_status, created_at FROM book_list ";
      $results = mysqli_query($con, $sql);
      // $data=mysqli_fetch_assoc($results);
      $record = $results-> fetch_all(MYSQLI_ASSOC);
      return $record;
    }


    public function http_api($field) {
      $con = db_connect1();
      $sql2 = "SELECT book_name FROM book_list WHERE book_name= '".$field['book_name']."'";

      $res1 = mysqli_query($con, $sql2);
      $rec = $res1 -> fetch_all(MYSQLI_ASSOC);
      if (is_array($rec) && !empty($rec))
      {
          return '3';
      }
      $insertData1 = "INSERT INTO book_list(book_name, book_description, book_status) VALUES ('".$field['book_name']."', '".$field['book_description']."','".$field['book_status']."')";
      // $api= mysqli_query($con, $insertData1);
      if (mysqli_query($con, $insertData1)) {
          return '1';
          // echo "New record created successfully";
      } else {
          return '2';
          // echo "Error: " . $sql . "<br>" . mysqli_error($con);      // Error message
      }
      mysqli_close($con);
  }
} 
?>*/