<?php 
require_once '../model/book_model.php';

function book_list($pageno){
$books = new stores();
$lists = $books->getall($pageno);
return $lists;

}


 




// if(array($rec) && !empty($rec)){
// $book="book is already availbale";
// }
// else if(mysqli_query->$insert_book==1)
// {

// $msg="Your data succesfully inserted";
// }
// else 
// {
// $error="Your current message is wrong";  
// }
// ?>