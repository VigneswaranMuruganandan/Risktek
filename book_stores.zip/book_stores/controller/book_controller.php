<?php 
require_once '../model/book_model.php';

function bookList(){
  $books = new stores();
  $lists = $books->getall();
  return $lists;
}

function insertBook($data){
	$books = new stores();
	$status = $books->insertBook_rec($data);
	switch($status) 
  {
    case 1:
      $msg = array('message' =>'data created successfully');
      break;
    case 2:
      $msg = array('message' =>'Error Message');
      break;
    case 3:
      $msg = array('message'=>$data['bookName'].'book already available');
      break;
    default:
       $msg = array('message' => 'unavailable');
  }
	return $msg;
}

function deleteBook($data){
  $books = new stores();
  $status = $books->deleteBook_rec($data);
  switch($status) 
  {
    case 0:
      $msg = array('message' =>'Book delete successfully');
      break;
    case 1:
      $msg = array('message' =>'Book delete failed');
      break;
  }
  return $msg;
}

function updateBook($data){
  $books = new stores();
  $status = $books->updateBook_rec($data);
  switch($status) 
  {
    case 0:
      $msg = array('message' =>'Book updated successfully');
      break;
    case 1:
      $msg = array('message' =>'Book update failed');
      break;
  }
  return $msg;
}

?>