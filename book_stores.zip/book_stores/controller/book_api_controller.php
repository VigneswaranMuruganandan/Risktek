<?php
 require('../model/book_model.php');
function rec_book(){

$stores = new stores();
$record = $stores-> book_rec();
if(count($record)){ 

 foreach ($record as $row){
            // echo"<pre>";
            // print_r($row);
            // echo"</pre>";
 $single[$row['book_id']] = 
           array ('book_name'=> $row['book_name'],
                   'book_description'=> $row['book_description'],
                   'book_status'=> $row['book_status'],
                    'created_at' =>($row['created_at']));
                  
       }

       
 
   }  

    return $single;     
}


  function insert_api($field){

  $stores = new stores();
  $field = $stores->http_api($field);
 
        switch($field) 
        {
            case '1':
                $msg=array('message' =>'data created successfully');
                break;
            case '2':
                $msg=array('message' =>'Error Message');
                break;
            case '3':
                 
          $text1='book already available';             
          $msg=array('message'=>'".$field['book_name']."'.$text1);
           // $msg=array('message'=>'".$field['book_name']."'.$text1);
                break;
            
            default:
               $msg=array('message' => 'unavailable');
        }
    
    return $msg;

}


?>