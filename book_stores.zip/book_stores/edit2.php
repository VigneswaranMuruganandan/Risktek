<?php 
require_once 'book_data/db_connect1.php';
if($_GET['id']) {
	$id = $_GET['id'];

	$sql = "SELECT * FROM books WHERE id= {$id}";
	$result = $con->query($sql);

		$data = $result->fetch_assoc();

    $connect->close();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Edit data</title>

	<style type="text/css">
		fieldset {
			margin: auto;
			margin-top: 100px;
			width: 50%;
		}

		table tr th {
			padding-top: 20px;
		}
	</style>

</head>
<body>

<fieldset>
	<legend>Edit data</legend>

	<form action="management/update2.php" method="post">
		<table cellspacing="0" cellpadding="0">
			<tr>
				<th>id</th>
				<td><input type="text" name="id" value="<?php echo $data['id'] ?>" /></td>
			</tr>		
			<tr>
				<th>Name</th>
				<td><input type="text" name="Name"value="<?php echo $data['Name'] ?>" /></td>
			</tr>
			<tr>
				<th>Description</th>
				<td><input type="text" name="Description" value="<?php echo $data['Description'] ?>" /></td>
			</tr>
			<tr>
				<th>Author name</th>
				<td><input type="text" name="Author_name" value="<?php echo $data['Author_name'] ?>" /></td>
			</tr>
			<tr>
				<th>Price</th>
				<td><input type="numeric" name="Price" value="<?php echo $data['Price'] ?>" /></td>
			</tr>
			<tr>
				<th>Review points</th>
				<td><input type="numeric" name="Review_points" value="<?php echo $data['Review_points'] ?>" /></td>
			</tr>
			<tr>
				<input type="hidden" name="id" value="<?php echo $data['id']?>" />
				<td><button type="submit">Save Changes</button></td>
				<td><a href="index2.php"><button type="button">Back</button></a></td>
			</tr>
		</table>
	</form>

</fieldset>

</body>
</html>

<?php
}
?>