function deleteConfirmation(id){
  modal = document.getElementById("deleteModal");
  var form = document.forms["deleteBook"];
  form.bookId.value = id;
  modal.style.display = "block";
}
var modal;

function create(){
  modal = document.getElementById("createModal");
  modal.style.display = "block";
}

function update(id, name, desc, status){
  modal = document.getElementById("updateModal");
  var form = document.forms["updateBook"];
  form.bookId.value = id;
  form.bookName.value = name;
  form.bookDescription.value = desc;
  form.bookStatus.value = status;
  modal.style.display = "block";
}





var span = document.getElementsByClassName("close")[0];


span.onclick = function() {
  modal.style.display = "none";
}

window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}