import 'dart:collection';

import 'package:flutter/widgets.dart';

class LeaveModel extends ChangeNotifier {
  /*final List<Leave>  _leaves = [];

  UnmodifiableListView get leaves => UnmodifiableListView(leaves);

  void add(Leave leave){

  }*/
}
