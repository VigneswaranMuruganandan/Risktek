import 'package:flutter/material.dart';
import './AddAbsence.dart';
import './ManageAbsence.dart';

class ApplyLeave extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _ApplyLeaveState();
  }
}

class _ApplyLeaveState extends State<ApplyLeave> with SingleTickerProviderStateMixin {

  TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(vsync: this, length: 2);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return MaterialApp(
      home: Scaffold(
        appBar: _buildAppBar(),
        body: _buildApplyLeaveBody() ,
      ),
    );
  }

  Widget _buildAppBar() {
    return PreferredSize(
        preferredSize: Size.fromHeight(60),
        child: AppBar(
          automaticallyImplyLeading: true,
          title: Text('Approval Requests',
              style: TextStyle(
                  color: Color.fromRGBO(12, 35, 64, 1.0), letterSpacing: 0.44)),
          centerTitle: true,
          backgroundColor: Color.fromRGBO(255 ,255 ,255, 1.0),
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            iconSize: 24,
            color: Color.fromRGBO(122, 125, 128, 1.0),
            onPressed: () => Navigator.pop(context, false),
          ),
          actions: <Widget>[
            new IconButton(
              icon: new Icon(Icons.close),
              iconSize: 24,
              color: Color.fromRGBO(122, 125, 128, 1.0),
              onPressed: () => Navigator.of(context).pop(null),
            ),
          ],
        ));
  }

  Widget _buildApplyLeaveBody() {
    return Container(
      decoration: BoxDecoration(color: Color.fromRGBO( 238 ,243 ,247, 1.0)),
      child:DefaultTabController(
        length: 2,
        child: Column(
          children: <Widget>[
            Container(
              margin: EdgeInsets.only(left: 20, right: 20, bottom: 27),
              padding: EdgeInsets.only(bottom:18,top:12),
              decoration: BoxDecoration(
                borderRadius: new BorderRadius.circular(8),
                gradient: LinearGradient(colors: [
                  Color.fromRGBO( 0 ,94 ,188, 1.0),
                  Color.fromRGBO(0 ,48 ,135, 1.0)
                ]),
              ),
              child: TabBar(
                controller: _tabController,
                labelStyle: TextStyle(fontSize: 14,fontFamily: 'FSMatthew',letterSpacing: 0.03),
                tabs: <Widget>[Tab(text:'Add absence'),Tab(text:'Manage Absence')],
              ),
            ),
            Expanded(
              child: TabBarView(
                controller: _tabController,
                // children: myTabs.map((Tab tab) {
                //   return tab.child;
                // }).toList(),
                children: <Widget>[AddAbsence(),ManageAbsence()],
              ),
            )
          ],
        ))
      ) ;
    }
}


