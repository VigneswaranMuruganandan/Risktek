import 'package:flutter/material.dart';

class DialogLayout extends StatelessWidget {
  final String title, description, buttonText;
  final AssetImage imageUrl;

  DialogLayout({
    @required this.title,
    @required this.description,
    @required this.buttonText,
    this.imageUrl,
  });

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      elevation: 0.0,
      backgroundColor: Colors.transparent,
      content: dialogContent(context),
    );
  }

  dialogContent(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        image: DecorationImage(
          fit: BoxFit.fill,
          image: AssetImage("assets/images/bg@3x.png"),
        ),
      ),
      padding: EdgeInsets.only(top: 19, left: 35.0, right: 35.0, bottom: 28),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Container(
            height: 51,
            width: 52,
            margin: EdgeInsets.only(bottom: 12),
            decoration: BoxDecoration(
                image: DecorationImage(
              image: imageUrl,
              fit: BoxFit.fill,
            )),
          ),
          Container(
            padding: EdgeInsets.only(bottom: 28),
            child: Text(
              description,
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontFamily: 'Graphik-Regular',
                  fontSize: 14,
                  letterSpacing: 0.19,
                  color: Color.fromRGBO(100, 121, 149, 1.0)),
            ),
          ),
          FlatButton(
            onPressed: () {},
            textColor: Colors.white,
            padding: EdgeInsets.only(
              bottom: 28.0,
            ),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: new BorderRadius.circular(10.0),
                gradient: LinearGradient(
                  colors: <Color>[
                    Color.fromRGBO(0, 94, 188, 1.0),
                    Color.fromRGBO(0, 48, 135, 1.0),
                  ],
                ),
              ),
              padding:
                  EdgeInsets.only(left: 30.0, right: 31, top: 13, bottom: 12),
              child: Text(buttonText,
                  style: TextStyle(
                      fontFamily: 'Graphik-Regular',
                      fontSize: 15,
                      letterSpacing: 0.2,
                      color: Colors.white)),
            ),
          ),
        ],
      ),
    );
  }
}
