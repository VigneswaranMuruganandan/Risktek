import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { routing } from './userPreference.routing';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '../shared/shared.module';
import {SharedService} from '../shared/services/shared.service';
import {TemplateService} from '../shared/services/template.service';
import { FormsModule } from '@angular/forms';
import { UserPreferenceComponent }   from './Components/userPreference.component';



const USEPREFERENCE_COMPONENTS = [
    UserPreferenceComponent
];

const USEPREFERENCE_PROVIDERS = [
   SharedService,
   TemplateService
];

@NgModule({
  	imports: [
	    routing,
	    TranslateModule.forChild(),
	    SharedModule,
	    FormsModule,
      CommonModule
	],
  	declarations: [
	    ...USEPREFERENCE_COMPONENTS
	],
  	providers: [
  		...USEPREFERENCE_PROVIDERS
  	]
})
export class UserPreferenceModule {}
