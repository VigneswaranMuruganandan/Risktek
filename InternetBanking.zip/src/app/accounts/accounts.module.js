"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var common_1 = require("@angular/common");
var accounts_routing_1 = require("./accounts.routing");
var core_2 = require("@ngx-translate/core");
var shared_module_1 = require("../shared/shared.module");
var shared_service_1 = require("../shared/services/shared.service");
var template_service_1 = require("../shared/services/template.service");
var accounts_component_1 = require("./Components/accounts.component");
var accountsDetail_component_1 = require("./Components/accountsDetail.component");
var accountsTransactions_component_1 = require("./Components/accountsTransactions.component");
var accountsRightContent_component_1 = require("./Components/accountsRightContent.component");
var ngx_datatable_1 = require("@swimlane/ngx-datatable");
var accounts_service_1 = require("./services/accounts.service");
var forms_1 = require("@angular/forms");
var ACCOUNTS_COMPONENTS = [
    accounts_component_1.AccountsComponent,
    accountsDetail_component_1.AccountsDetailComponent,
    accountsTransactions_component_1.AccountsTransactionsComponent,
    accountsRightContent_component_1.AccountsRightContentComponent
];
var ACCOUNTS_PROVIDERS = [
    shared_service_1.SharedService,
    template_service_1.TemplateService,
    accounts_service_1.AccountsService
];
var AccountsModule = (function () {
    function AccountsModule() {
    }
    AccountsModule = __decorate([
        core_1.NgModule({
            imports: [
                accounts_routing_1.routing,
                core_2.TranslateModule.forChild(),
                shared_module_1.SharedModule,
                forms_1.FormsModule,
                common_1.CommonModule,
                ngx_datatable_1.NgxDatatableModule
            ],
            declarations: ACCOUNTS_COMPONENTS.slice(),
            providers: ACCOUNTS_PROVIDERS.slice()
        })
    ], AccountsModule);
    return AccountsModule;
}());
exports.AccountsModule = AccountsModule;
//# sourceMappingURL=accounts.module.js.map