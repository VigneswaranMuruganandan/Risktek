import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';
import {AppSession} from '../../shared/model/appsession';
import {AuthKey} from '../../shared/model/authkey';
import {AuthData} from '../../shared/model/authdata';
import {ServiceInvoker} from '../../shared/connector/serviceinvoker.service';
import {EncryptionService} from '../../shared/services/encryption.service';
import {SessionContext} from '../../shared/model/sessioncontext';
import {GlobalURL} from '../../shared/services/globalURL';
import {CustomerAccountsResponse} from '../model/customerAccountsResponse';




@Injectable()
export class AccountsService{

  constructor(private serviceInvoker: ServiceInvoker, 
                private encryptionService: EncryptionService) {}

   customerAccounts(): Observable < CustomerAccountsResponse > {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ACCOUNTS.CUSTOMERACCOUNTS,null)
                                .map(resp => this.populateAcctsResp(resp));
    }


    private populateAcctsResp(resp: string) {
        console.log("cust resp " + resp);
        let respObj = JSON.parse(resp);
        console.log("res " + respObj.result.status);
        let responseObj = new CustomerAccountsResponse();
        return responseObj;
        
    }


}


