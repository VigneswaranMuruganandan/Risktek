import { Component, OnInit, Input} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import {AccountsService} from '../services/accounts.service';
import {CustomerAccountsResponse} from '../model/customerAccountsResponse';



@Component({
  templateUrl: 'app/accounts/templates/accounts.html'
})
export class AccountsComponent implements OnInit {

	constructor(private accountsService: AccountsService) {}

	ngOnInit() {
		this.fetchAccounts();
	}

	fetchAccounts(){
		this.accountsService.customerAccounts()
	        .subscribe(
	           resp => this.handleCustAcctsResp(resp),
	           error => this.handleError(error)
	        );
	
	}
	

	private handleCustAcctsResp(resp:CustomerAccountsResponse){
       console.log('CustomerAccountsResponse '+resp);
       
    }

    private handleError(error: any){
       console.log('handleVerifyCustIDError '+error);
    }
}