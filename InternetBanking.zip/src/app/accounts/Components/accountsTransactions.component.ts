import { Component, OnInit, Input,ViewChild,ElementRef} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import * as $ from 'jquery';



@Component({
  selector: 'accounts-transactions',
  templateUrl: 'app/accounts/templates/accountsTransactions.html'
})
export class AccountsTransactionsComponent {
	@ViewChild('table') tableElem: ElementRef;
	 temp:any = [];
   transaction:any={};

	constructor() {
      this.temp = [...this.rows];
 	 }

    onFilterTransactionType(event:any){
       const type = this.transaction.type;
       if(this.transaction.type=='Debit'){
         const temp = this.temp.filter(function(d:any) {
          return  d.amount.indexOf('-') !== -1;
          });
         this.rows = temp;
       }if(this.transaction.type=='Credit'){
         const temp = this.temp.filter(function(d:any) {
          return  d.amount.indexOf('-') == -1;
          });
         this.rows = temp;
        }if(this.transaction.type=='All'){
          const temp= this.temp;
          this.rows = temp;
        }
    }

	rows = [
    { date: '10 - 06 - 2017', description: 'Apple 1234 2345 3456 4567', amount: '33,111.98 AED',balance :'40,500.00 AED'},
    { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '-24,317.98 AED',balance :'38,500.00 AED'},
    { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '24,317.98 AED',balance :'38,500.00 AED'},
    { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '-24,317.98 AED',balance :'38,500.00 AED'},
    { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '24,317.98 AED',balance :'38,500.00 AED'},
    { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '24,317.98 AED',balance :'38,500.00 AED'},
    { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '-24,317.98 AED',balance :'38,500.00 AED'},
    { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '24,317.98 AED',balance :'38,500.00 AED'},
    { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '-24,317.98 AED',balance :'38,500.00 AED'},
    { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '24,317.98 AED',balance :'38,500.00 AED'},
    { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '24,317.98 AED',balance :'38,500.00 AED'},
    { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '24,317.98 AED',balance :'38,500.00 AED'},
    { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '24,317.98 AED',balance :'38,500.00 AED'},
    { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '-24,317.98 AED',balance :'38,500.00 AED'},
    { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '24,317.98 AED',balance :'38,500.00 AED'},
    { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '24,317.98 AED',balance :'38,500.00 AED'},
    { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '24,317.98 AED',balance :'38,500.00 AED'},
    { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '24,317.98 AED',balance :'38,500.00 AED'}
  ];
  columns = [
    { name: 'Date' },
    { name: 'Description' },
    { name: 'Amount' },
    { name: 'Balance' }
  ];

   updateFilter(event:any) {
    const val = event.target.value.toLowerCase();

    // filter our data
    const temp = this.temp.filter(function(d:any) {
      return (
      			(d.description.toLowerCase().indexOf(val) !== -1) || 
      			(d.amount.toLowerCase().indexOf(val) !== -1) ||
      			(d.balance.toLowerCase().indexOf(val) !== -1) ||
      			!val
      		);
    });

    // update the rows
    this.rows = temp;
    // Whenever the filter changes, always go back to the first page
    //$(this.tableElem).offset = 0;
  }

  	filterOptions(event:ElementRef) {
  		
            $('.search-transactions').hide();
            $('.transactions-filters').show();
            //$(event.currentTarget).hide();
            $('.download').hide();   
  	}
  	closeFilter(event:ElementRef){
  			$('.search-transactions').show();
            $('.transactions-filters').hide();
            $('.apply-filter').show();
            $('.download').show();
  	}
  	downloadTransactions(event:ElementRef){

  		$('.download-popover').slideToggle();
  	}

}