import { Component, OnInit, Input,ElementRef} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import * as $ from 'jquery';



@Component({
  selector: 'accounts-detail',
  templateUrl: 'app/accounts/templates/accountsDetail.html'
})
export class AccountsDetailComponent {

	viewMoreDetails (event:ElementRef){
		$('.more-details').slideToggle();
	}

}