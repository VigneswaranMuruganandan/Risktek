"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var $ = require("jquery");
var AccountsTransactionsComponent = (function () {
    function AccountsTransactionsComponent() {
        this.temp = [];
        this.transaction = {};
        this.rows = [
            { date: '10 - 06 - 2017', description: 'Apple 1234 2345 3456 4567', amount: '33,111.98 AED', balance: '40,500.00 AED' },
            { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '-24,317.98 AED', balance: '38,500.00 AED' },
            { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '24,317.98 AED', balance: '38,500.00 AED' },
            { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '-24,317.98 AED', balance: '38,500.00 AED' },
            { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '24,317.98 AED', balance: '38,500.00 AED' },
            { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '24,317.98 AED', balance: '38,500.00 AED' },
            { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '-24,317.98 AED', balance: '38,500.00 AED' },
            { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '24,317.98 AED', balance: '38,500.00 AED' },
            { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '-24,317.98 AED', balance: '38,500.00 AED' },
            { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '24,317.98 AED', balance: '38,500.00 AED' },
            { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '24,317.98 AED', balance: '38,500.00 AED' },
            { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '24,317.98 AED', balance: '38,500.00 AED' },
            { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '24,317.98 AED', balance: '38,500.00 AED' },
            { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '-24,317.98 AED', balance: '38,500.00 AED' },
            { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '24,317.98 AED', balance: '38,500.00 AED' },
            { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '24,317.98 AED', balance: '38,500.00 AED' },
            { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '24,317.98 AED', balance: '38,500.00 AED' },
            { date: '10 - 06 - 2017', description: 'MAC 1234 2345 3456 4567', amount: '24,317.98 AED', balance: '38,500.00 AED' }
        ];
        this.columns = [
            { name: 'Date' },
            { name: 'Description' },
            { name: 'Amount' },
            { name: 'Balance' }
        ];
        this.temp = this.rows.slice();
    }
    AccountsTransactionsComponent.prototype.onFilterTransactionType = function (event) {
        var type = this.transaction.type;
        if (this.transaction.type == 'Debit') {
            var temp = this.temp.filter(function (d) {
                return d.amount.indexOf('-') !== -1;
            });
            this.rows = temp;
        }
        if (this.transaction.type == 'Credit') {
            var temp = this.temp.filter(function (d) {
                return d.amount.indexOf('-') == -1;
            });
            this.rows = temp;
        }
        if (this.transaction.type == 'All') {
            var temp = this.temp;
            this.rows = temp;
        }
    };
    AccountsTransactionsComponent.prototype.updateFilter = function (event) {
        var val = event.target.value.toLowerCase();
        // filter our data
        var temp = this.temp.filter(function (d) {
            return ((d.description.toLowerCase().indexOf(val) !== -1) ||
                (d.amount.toLowerCase().indexOf(val) !== -1) ||
                (d.balance.toLowerCase().indexOf(val) !== -1) ||
                !val);
        });
        // update the rows
        this.rows = temp;
        // Whenever the filter changes, always go back to the first page
        //$(this.tableElem).offset = 0;
    };
    AccountsTransactionsComponent.prototype.filterOptions = function (event) {
        $('.search-transactions').hide();
        $('.transactions-filters').show();
        //$(event.currentTarget).hide();
        $('.download').hide();
    };
    AccountsTransactionsComponent.prototype.closeFilter = function (event) {
        $('.search-transactions').show();
        $('.transactions-filters').hide();
        $('.apply-filter').show();
        $('.download').show();
    };
    AccountsTransactionsComponent.prototype.downloadTransactions = function (event) {
        $('.download-popover').slideToggle();
    };
    __decorate([
        core_1.ViewChild('table'),
        __metadata("design:type", core_1.ElementRef)
    ], AccountsTransactionsComponent.prototype, "tableElem", void 0);
    AccountsTransactionsComponent = __decorate([
        core_1.Component({
            selector: 'accounts-transactions',
            templateUrl: 'app/accounts/templates/accountsTransactions.html'
        }),
        __metadata("design:paramtypes", [])
    ], AccountsTransactionsComponent);
    return AccountsTransactionsComponent;
}());
exports.AccountsTransactionsComponent = AccountsTransactionsComponent;
//# sourceMappingURL=accountsTransactions.component.js.map