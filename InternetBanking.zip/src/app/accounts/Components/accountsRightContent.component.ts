import { Component, OnInit, Input} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import * as $ from 'jquery';



@Component({
  selector: '[accounts-rightcontent]',
  templateUrl: 'app/accounts/templates/accountsRightContent.html'
})
export class AccountsRightContentComponent {

	slides = [
	    {caption: "Restaurent",imageUrl:"http://devlabs.synechron.com/fab/Front-End/assets/images/steak.png"},
	    {caption: "Hotel",imageUrl:"http://devlabs.synechron.com/fab/Front-End/assets/images/steak.png"},
	    {caption: "lounge",imageUrl:"http://devlabs.synechron.com/fab/Front-End/assets/images/steak.png"},
	    
	  ];


	ngAfterViewInit() {

		var conf = {
			dots:true,
			//appendDots: $('carousel slider-buttons'),
			//dotsClass: 'carousel slider-buttons',
			slidesToShow: 1,
  			slidesToScroll: 1,
			arrows: false,
		};

		//$('.my-offers').slick(conf);
	}
}