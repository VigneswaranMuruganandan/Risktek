
import {APIResponse} from '../../shared/model/apiresponse';

export class CustomerAccountsResponse extends APIResponse{

}

