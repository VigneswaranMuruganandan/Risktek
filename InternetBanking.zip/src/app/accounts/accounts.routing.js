"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var router_1 = require("@angular/router");
var accounts_component_1 = require("./Components/accounts.component");
var routes = [
    {
        path: '',
        component: accounts_component_1.AccountsComponent
    },
    {
        path: '',
        redirectTo: '',
        pathMatch: 'full'
    }
];
exports.routing = router_1.RouterModule.forChild(routes);
//# sourceMappingURL=accounts.routing.js.map