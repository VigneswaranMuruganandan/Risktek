import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { routing } from './accounts.routing';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '../shared/shared.module';
import {SharedService} from '../shared/services/shared.service';
import {TemplateService} from '../shared/services/template.service';
import { AccountsComponent }   from './Components/accounts.component';




import { FormsModule } from '@angular/forms';

const ACCOUNTS_COMPONENTS = [
    AccountsComponent
];

const ACCOUNTS_PROVIDERS = [
   SharedService,
   TemplateService
];

@NgModule({
  	imports: [
	    routing,
	    TranslateModule.forChild(),
	    SharedModule,
	    FormsModule,
		CommonModule
	],
  	declarations: [
	    ...ACCOUNTS_COMPONENTS
	],
  	providers: [
  		...ACCOUNTS_PROVIDERS
  	]
})
export class AccountsModule {}
