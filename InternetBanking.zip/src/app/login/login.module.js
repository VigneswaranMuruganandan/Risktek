"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var common_1 = require("@angular/common");
var forms_1 = require("@angular/forms");
var login_routing_1 = require("./login.routing");
var core_2 = require("@ngx-translate/core");
var shared_module_1 = require("../shared/shared.module");
var shared_service_1 = require("../shared/services/shared.service");
var template_service_1 = require("../shared/services/template.service");
var login_component_1 = require("./Components/login.component");
var loginform1_component_1 = require("./Components/loginform1.component");
var registerSoftToken_component_1 = require("./Components/registerSoftToken.component");
var validatelogin_directive_1 = require("./directives/validatelogin.directive");
var LOGIN_COMPONENTS = [
    login_component_1.LoginComponent,
    loginform1_component_1.LoginForm1Component,
    registerSoftToken_component_1.RegisterSoftTokenComponent
];
var LOGIN_DIRECTIVES = [
    validatelogin_directive_1.ValidateLogin
];
var LOGIN_PROVIDERS = [
    shared_service_1.SharedService,
    template_service_1.TemplateService
];
var LoginModule = (function () {
    function LoginModule() {
    }
    LoginModule = __decorate([
        core_1.NgModule({
            imports: [
                login_routing_1.routing,
                core_2.TranslateModule.forChild(),
                shared_module_1.SharedModule,
                forms_1.FormsModule,
                common_1.CommonModule
            ],
            declarations: LOGIN_COMPONENTS.concat(LOGIN_DIRECTIVES),
            providers: LOGIN_PROVIDERS.slice()
        })
    ], LoginModule);
    return LoginModule;
}());
exports.LoginModule = LoginModule;
//# sourceMappingURL=login.module.js.map