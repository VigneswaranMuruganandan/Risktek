import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {TemplateService} from '../../shared/services/template.service';
import { FormsModule} from '@angular/forms';

@Component({
  selector: 'loginform1-component',
  templateUrl: 'app/login/templates/loginform1.html'
})
export class LoginForm1Component  implements OnInit{
    @Output() validateCredentialsEvent = new EventEmitter();
    public credentials:any;

    constructor(private templateService: TemplateService) {}

    ngOnInit() { 
        this.credentials = {
            "userName":"",
            "password":""
        };
    }
    
    validateUserNamePwd(valid: boolean){
        if(valid){
            this.templateService.setFromValidatorFlag(false);
            this.validateCredentialsEvent.emit(this.credentials);
        }        
    }
}