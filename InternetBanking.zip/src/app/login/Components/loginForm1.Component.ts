import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {TemplateService} from '../../shared/services/template.service';
import {User} from '../model/user';
import { FormsModule} from '@angular/forms';

@Component({
  selector: 'loginform1-component',
  templateUrl: 'app/login/templates/loginform1.html'
})
export class LoginForm1Component{
    @Output() validateCredentialsEvent = new EventEmitter();
    @Input() user: User;

    constructor(private templateService: TemplateService) {}

    
    validateUserNamePwd(valid: boolean){
        if(valid){
            this.templateService.resetFromValidatorFlag();
            this.validateCredentialsEvent.emit();
        }        
    }
}