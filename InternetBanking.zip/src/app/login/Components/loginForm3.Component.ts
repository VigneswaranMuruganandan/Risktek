import { Component } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'loginform3-component',
  templateUrl: 'app/login/templates/loginform3.html'
})
export class LoginForm3Component {
	
}