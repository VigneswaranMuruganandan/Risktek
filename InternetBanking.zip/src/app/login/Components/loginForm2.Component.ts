import { Component } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'loginform2-component',
  templateUrl: 'app/login/templates/loginform2.html'
})
export class LoginForm2Component {
	
}