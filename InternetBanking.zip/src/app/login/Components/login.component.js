"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var login_service_1 = require("../services/login.service");
var router_1 = require("@angular/router");
var loginrequest_1 = require("../model/loginrequest");
var shared_service_1 = require("../../shared/services/shared.service");
var user_1 = require("../model/user");
require("rxjs/add/operator/catch");
require("rxjs/add/operator/map");
var LoginComponent = (function () {
    function LoginComponent(loginService, sharedService, router) {
        this.loginService = loginService;
        this.sharedService = sharedService;
        this.router = router;
    }
    LoginComponent.prototype.ngOnInit = function () {
        this.user = new user_1.User();
    };
    /*
    * Step 1: Initate the Register Device before verifying the Credentials
    */
    LoginComponent.prototype.validateCredentials = function () {
        var _this = this;
        console.log("Login Username::" + this.user.userName);
        var registerDeviceData = this.sharedService.setupAuthKeys();
        console.log("Register Device Data ::" + registerDeviceData);
        if (registerDeviceData && registerDeviceData.deviceID != '') {
            this.sharedService.registerDevice(registerDeviceData)
                .subscribe(function (resp) { return _this.handleRegisterDeviceDataResp(resp); }, function (error) { return _this.sharedService.handleError(error); });
        }
    };
    /*
    * Step 2: With Username , fetch the CIF ID
    */
    LoginComponent.prototype.handleRegisterDeviceDataResp = function (resp) {
        var _this = this;
        if (resp.authKey.convID != '') {
            var data = new loginrequest_1.LoginRequest();
            data.customerID = this.user.userName;
            this.loginService.fetchCIFNumber(data)
                .subscribe(function (resp) { return _this.handleFetchCIFNumberLogin(resp); }, function (error) { return _this.sharedService.handleError(error); });
        }
    };
    /*
    * Step 3: Verify the Username and Password
    */
    LoginComponent.prototype.handleFetchCIFNumberLogin = function (respObj) {
        var _this = this;
        if (respObj.result.status == "success") {
            this.loginService.verifyLogin(this.user)
                .subscribe(function (resp) { return _this.handleVerifyLogin(resp); }, function (error) { return _this.sharedService.handleError(error); });
        }
    };
    /*
    * Step 4: Mange the Succes of verify Login
    */
    LoginComponent.prototype.handleVerifyLogin = function (resp) {
        if (resp.action == "VIEW_DASH_BOARD") {
            this.router.navigate(['/dashboard']);
        }
    };
    LoginComponent = __decorate([
        core_1.Component({
            templateUrl: 'app/login/templates/login.html'
        }),
        __metadata("design:paramtypes", [login_service_1.LoginService,
            shared_service_1.SharedService,
            router_1.Router])
    ], LoginComponent);
    return LoginComponent;
}());
exports.LoginComponent = LoginComponent;
//# sourceMappingURL=login.component.js.map