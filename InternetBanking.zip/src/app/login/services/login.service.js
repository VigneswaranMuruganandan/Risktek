"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
require("rxjs/add/operator/toPromise");
var authkey_1 = require("../../shared/model/authkey");
var authdata_1 = require("../../shared/model/authdata");
var serviceinvoker_service_1 = require("../../shared/connector/serviceinvoker.service");
var encryption_service_1 = require("../../shared/services/encryption.service");
var sessioncontext_1 = require("../../shared/model/sessioncontext");
var globalURL_1 = require("../../shared/services/globalURL");
var LoginService = (function () {
    function LoginService(serviceInvoker, encryptionService) {
        this.serviceInvoker = serviceInvoker;
        this.encryptionService = encryptionService;
    }
    LoginService.prototype.verifyLogin = function (authRequest) {
        var _this = this;
        console.log(sessioncontext_1.SessionContext.getInstance().userID);
        var pwdHash = this.encryptionService.generatePwdHash(sessioncontext_1.SessionContext.getInstance().userID, authRequest.pwd);
        authRequest.pwd = this.encryptionService.convertToBase64(pwdHash);
        return this.serviceInvoker.invoke(globalURL_1.GlobalURL.SERVICE_URL.LOGIN.VERIFYLOGIN, authRequest)
            .map(function (resp) { return _this.populateAuthReq(resp); });
    };
    LoginService.prototype.fetchCIFNumber = function (authRequest) {
        var _this = this;
        return this.serviceInvoker.invoke(globalURL_1.GlobalURL.SERVICE_URL.LOGIN.VERIFYCUSTOMERID, authRequest)
            .map(function (resp) { return _this.populateCustomerIDReq(resp); });
    };
    LoginService.prototype.populateAuthReq = function (resp) {
        var authData = new authdata_1.AuthData();
        var respObj = JSON.parse(resp);
        console.log("result " + respObj.result.status);
        if (respObj.result.status == 'success') {
            authData.authKey = new authkey_1.AuthKey();
            authData.action = respObj.action[0];
            authData.authKey.encIV = respObj.data.encIV;
            authData.authKey.encKey = respObj.data.encKey;
            authData.authKey.convID = respObj.data.convID;
            authData.authKey.macKey = respObj.data.macKey;
            authData.authKey.ec = respObj.data.eventCtr;
            console.log("convid " + authData.authKey.convID);
            var sessCtx = sessioncontext_1.SessionContext.getInstance();
            sessCtx.authKey = authData.authKey;
        }
        return authData;
    };
    LoginService.prototype.populateCustomerIDReq = function (resp) {
        var respObj = JSON.parse(resp);
        sessioncontext_1.SessionContext.getInstance().userID = respObj.cif;
        return respObj;
    };
    LoginService = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [serviceinvoker_service_1.ServiceInvoker,
            encryption_service_1.EncryptionService])
    ], LoginService);
    return LoginService;
}());
exports.LoginService = LoginService;
//# sourceMappingURL=login.service.js.map