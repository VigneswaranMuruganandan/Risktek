import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';
import {AppSession} from '../../shared/model/appsession';
import {AuthRequest} from '../../register/model/authrequest';
import {VerifyCustomerResponse} from '../../register/model/verifycustomerresponse';
import {RegisterPwdResponse} from '../../register/model/registerpwdresponse';
import {VerifyOtpResponse} from '../../shared/model/verifyotpresponse';
import {ResendOtpResponse} from '../../register/model/resendotpresponse';
import {AuthKey} from '../../shared/model/authkey';
import {AuthData} from '../../shared/model/authdata';
import {ServiceInvoker} from '../../shared/connector/serviceinvoker.service';
import {EncryptionService} from '../../shared/services/encryption.service';
import {SessionContext} from '../../shared/model/sessioncontext';
import {GlobalURL} from '../../shared/services/globalURL';
import {User} from '../model/user';

@Injectable()
export class LoginService {
    
    constructor(private serviceInvoker: ServiceInvoker, 
                private encryptionService: EncryptionService) {}

    verifyLogin(authRequest: User): Observable < AuthData > {
        console.log(SessionContext.getInstance().userID);
        let pwdHash = this.encryptionService.generatePwdHash(SessionContext.getInstance().userID, authRequest.pwd);
        authRequest.pwd = this.encryptionService.convertToBase64(pwdHash);
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.LOGIN.VERIFYLOGIN, authRequest)
                                  .map(resp => this.populateAuthReq(resp));
    }

    fetchCIFNumber(authRequest: User): Observable < string > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.LOGIN.VERIFYCUSTOMERID, authRequest)
                                  .map(resp => this.populateCustomerIDReq(resp));
    }

    private populateAuthReq(resp: string) {
        var authData = new AuthData();
        let respObj = JSON.parse(resp);
        console.log("result " + respObj.result.status);
        if (respObj.result.status == 'success') {
            authData.authKey = new AuthKey();
            authData.action = respObj.action[0];
            authData.authKey.encIV = respObj.data.encIV;
            authData.authKey.encKey = respObj.data.encKey;
            authData.authKey.convID = respObj.data.convID;
            authData.authKey.macKey = respObj.data.macKey;
            authData.authKey.ec = respObj.data.eventCtr;
            console.log("convid " + authData.authKey.convID);
            var sessCtx = SessionContext.getInstance();
            sessCtx.authKey = authData.authKey;
        }
        return authData;
    }

    private populateCustomerIDReq(resp: string){
        let respObj = JSON.parse(resp);
        SessionContext.getInstance().userID = respObj.cif;
        return respObj;
    }
    
}
