import { Directive, ElementRef, HostListener, Input } from '@angular/core';
import * as $ from 'jquery';
import {TemplateService} from '../../shared/services/template.service';

@Directive({
  selector: '[ValidateLoginDirective]'
})
export class ValidateLogin {
	private jqueryValidator = require('jquery-validator');
  	constructor(private el: ElementRef, 
  			  private templateService: TemplateService) { }

  @HostListener('click', ['$event']) 
  onClick(event: any) {
  	//console.log($('#loginForm1').validate())
    


    this.templateService.setFromValidatorFlag(true);
  }
}