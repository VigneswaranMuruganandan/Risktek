"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var LoginRequest = (function () {
    function LoginRequest() {
    }
    return LoginRequest;
}());
exports.LoginRequest = LoginRequest;
//# sourceMappingURL=loginrequest.js.map