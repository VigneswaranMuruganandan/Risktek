import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './auth-guard.service';


const routes: Routes = [
    {
        path: '',
        redirectTo: 'login',
        pathMatch: 'full'
    },
    {
        path: 'login',
        canActivate: [AuthGuard],
        loadChildren: 'app/login/login.module#LoginModule',
    },
    {
        path: 'registration',
        canActivate: [AuthGuard],
        loadChildren: 'app/register/register.module#RegisterModule'
    },
    {
        path: 'forgotPassword',
        canActivate: [AuthGuard],
        loadChildren: 'app/forgotPassword/forgotPassword.module#ForgotPasswordModule'
    },
    {
        path: '',
        canActivate: [AuthGuard],
        loadChildren: 'app/dashboard/dashboard.module#DashboardModule'
    }    
];

export const routing = RouterModule.forRoot(routes);
