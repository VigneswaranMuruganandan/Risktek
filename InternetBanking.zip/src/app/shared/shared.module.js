"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var common_1 = require("@angular/common");
var router_1 = require("@angular/router");
var core_2 = require("@ngx-translate/core");
var shared_service_1 = require("./services/shared.service");
var template_service_1 = require("./services/template.service");
var encryption_service_1 = require("./services/encryption.service");
var serviceinvoker_service_1 = require("./connector/serviceinvoker.service");
var loginHeader_component_1 = require("./Components/loginHeader.component");
var loginFooter_component_1 = require("./Components/loginFooter.component");
var registerHeader_component_1 = require("./Components/registerHeader.component");
var registerFooter_component_1 = require("./Components/registerFooter.component");
var forgotPasswordHeader_component_1 = require("./Components/forgotPasswordHeader.component");
var forgotPasswordFooter_component_1 = require("./Components/forgotPasswordFooter.component");
var dashboardHeader_component_1 = require("./Components/dashboardHeader.component");
var dashboardFooter_component_1 = require("./Components/dashboardFooter.component");
var searchHeader_component_1 = require("./Components/searchHeader.component");
var accountSettingsHeader_component_1 = require("./Components/accountSettingsHeader.component");
var navigation_component_1 = require("./Components/navigation.component");
var baseView_component_1 = require("./Components/baseView.component");
var slickCarousel_component_1 = require("./Components/slickCarousel.component");
var otp_component_1 = require("./Components/otp.component");
var autofocus_directive_1 = require("./directives/autofocus.directive");
var onlynumber_directive_1 = require("./directives/onlynumber.directive");
var navigation_directive_1 = require("./directives/navigation.directive");
var hamburgermenu_directive_1 = require("./directives/hamburgermenu.directive");
var SHARED_COMPONENTS = [
    loginHeader_component_1.LoginHeaderComponent,
    loginFooter_component_1.LoginFooterComponent,
    registerHeader_component_1.RegisterHeaderComponent,
    registerFooter_component_1.RegisterFooterComponent,
    forgotPasswordHeader_component_1.ForgotPasswordHeaderComponent,
    forgotPasswordFooter_component_1.ForgotPasswordFooterComponent,
    dashboardHeader_component_1.DashboardHeaderComponent,
    dashboardFooter_component_1.DashboardFooterComponent,
    searchHeader_component_1.SearchHeaderComponent,
    accountSettingsHeader_component_1.AccountSettingsHeaderComponent,
    navigation_component_1.NavigationComponent,
    baseView_component_1.BaseViewComponent,
    slickCarousel_component_1.SlickCarouselComponent,
    otp_component_1.OTPComponent
];
var SHARED_DIRECTIVES = [
    onlynumber_directive_1.OnlyNumber,
    navigation_directive_1.Navigation,
    hamburgermenu_directive_1.HamburgerMenu,
    slickCarousel_component_1.SlickCarouselItem,
    autofocus_directive_1.Autofocus,
    otp_component_1.OTPKeypress
];
var SHARED_PROVIDERS = [
    shared_service_1.SharedService,
    template_service_1.TemplateService,
    encryption_service_1.EncryptionService,
    common_1.DecimalPipe,
    serviceinvoker_service_1.ServiceInvoker
];
var SharedModule = (function () {
    function SharedModule() {
    }
    SharedModule = __decorate([
        core_1.NgModule({
            imports: [
                core_2.TranslateModule.forChild(),
                common_1.CommonModule,
                router_1.RouterModule
            ],
            declarations: SHARED_COMPONENTS.concat(SHARED_DIRECTIVES),
            providers: SHARED_PROVIDERS.slice(),
            exports: SHARED_COMPONENTS.concat(SHARED_DIRECTIVES)
        })
    ], SharedModule);
    return SharedModule;
}());
exports.SharedModule = SharedModule;
//# sourceMappingURL=shared.module.js.map