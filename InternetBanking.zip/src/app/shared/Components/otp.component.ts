import {Component, Input, ContentView, ElementRef, ContentChild, Renderer,
Directive, HostListener, Host, NgZone,
Output, EventEmitter} from '@angular/core';
import * as $ from 'jquery';


@Component({
  selector: 'otp-component',
  template: `<ng-content></ng-content>`
})
export class OTPComponent {
  private x = require('jquery-validator');
  private CryptoJS = require('crypto-js');
  constructor(private el:ElementRef) {
  }
  
  changeFocus(id: number){
    console.log(id);
    let el = this.el.nativeElement.children[0];    
    let nextElement = $(el).find('ul li input:text')[id];
    if(id < 6)
    $(nextElement).focus();
    
  }

  ngAfterViewInit() {
    var el = this.el.nativeElement.children[0];
    var otpe1 = $(el).find('ul li input:text')[0];
    $(otpe1).focus();    
    
  }
}



@Directive({
  selector: '[otpkeypress]',
})
export class OTPKeypress {

  @Input() otpkeypress: number;
  @Output() validateOTPEvent = new EventEmitter();

  constructor(private el: ElementRef, @Host() private otp: OTPComponent, private zone: NgZone) {
  }
  ngAfterViewInit() {
    
  }
  @HostListener('keyup', ['$event']) 
    onKeyDown(event: any) {
      var el = $(this.el.nativeElement);
      if(this.otpkeypress == 6){
        let otpFormSubmit;
        this.zone.runOutsideAngular(() => {
            let otpFormValidation = $("#otpForm").validate({
              highlight: function (element) {
                var field = $(element);
                field.addClass("field-error");
              },
              unhighlight: function (element, errorClass) {
                var field = $(element);
                field.removeClass("field-error");
              },
              errorPlacement: function (error, element) {
                if (element.is("input")) {
                  $('.error-msg').append(error);
                }
              },
              rules: {
                otpBox1: {required: true},
                otpBox2: {required: true},
                otpBox3: {required: true},
                otpBox4: {required: true},
                otpBox5: {required: true},
                otpBox6: {required: true}
              },
              groups: {
                OTPBoxError: "otpBox1 otpBox2 otpBox3 otpBox4 otpBox5 otpBox6"
              },
              messages: {
                otpBox1: {required: "Please enter the correct OTP"},
                otpBox2: {required: "Please enter the correct OTP"},
                otpBox3: {required: "Please enter the correct OTP"},
                otpBox4: {required: "Please enter the correct OTP"},
                otpBox5: {required: "Please enter the correct OTP"},
                otpBox6: {required: "Please enter the correct OTP"}
              }
            });
            otpFormSubmit = otpFormValidation.form();
            console.log(otpFormSubmit);
            this.validateOTPEvent.emit();
            return true;
          });
          
        
      }
      if(el.val() !=''){        
        this.otp.changeFocus(this.otpkeypress);        
      }
    }
}



