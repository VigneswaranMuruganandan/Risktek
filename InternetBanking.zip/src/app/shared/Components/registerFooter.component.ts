import { Component } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'register-footer',
  templateUrl: 'app/shared/templates/registerFooter.html'
})
export class RegisterFooterComponent {
	
}