import { Component } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: '[accountsettings-component]',
  templateUrl: 'app/shared/templates/accountSettingsHeader.html'
})
export class AccountSettingsHeaderComponent {
	
}