import { Component } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: '[search-component]',
  templateUrl: 'app/shared/templates/searchHeader.html'
})
export class SearchHeaderComponent {
	
}