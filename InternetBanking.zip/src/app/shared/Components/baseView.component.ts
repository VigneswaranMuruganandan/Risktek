import { Component, Input, OnInit} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {TemplateService} from '../services/template.service';


@Component({
  selector: 'baseview-component',
  templateUrl: 'app/shared/templates/baseView.html'
})
export class BaseViewComponent {
	constructor(private templateService: TemplateService) {}
}