import { Component } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'baseview-component',
  templateUrl: 'app/shared/templates/baseView.html'
})
export class BaseViewComponent {
	
}