"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
require('slick-carousel');
var SlickCarouselComponent = (function () {
    function SlickCarouselComponent(el, zone) {
        this.el = el;
        this.zone = zone;
        this.initialized = false;
        this.slides = [];
    }
    SlickCarouselComponent.prototype.initCarousel = function () {
        this.zone.runOutsideAngular(function () {
            //this.$carousel = $(this.el.nativeElement).slick({});
        });
        this.initialized = true;
    };
    SlickCarouselComponent.prototype.addSlide = function (slide) {
        !this.initialized && this.initCarousel();
        this.slides.push(slide);
        this.$carousel.slick('slickAdd', slide.el.nativeElement);
    };
    SlickCarouselComponent.prototype.removeSlide = function (slide) {
        var idx = this.slides.indexOf(slide);
        this.$carousel.slick('slickRemove', idx);
        this.slides = this.slides.filter(function (s) { return s != slide; });
    };
    SlickCarouselComponent = __decorate([
        core_1.Component({
            selector: 'slick-carousel',
            template: "<ng-content></ng-content>"
        }),
        __metadata("design:paramtypes", [core_1.ElementRef, core_1.NgZone])
    ], SlickCarouselComponent);
    return SlickCarouselComponent;
}());
exports.SlickCarouselComponent = SlickCarouselComponent;
var SlickCarouselItem = (function () {
    function SlickCarouselItem(el, carousel) {
        this.el = el;
        this.carousel = carousel;
    }
    SlickCarouselItem.prototype.ngAfterViewInit = function () {
        this.carousel.addSlide(this);
    };
    SlickCarouselItem.prototype.ngOnDestroy = function () {
        this.carousel.removeSlide(this);
    };
    SlickCarouselItem = __decorate([
        core_1.Directive({
            selector: '[slick-carousel-item]',
        }),
        __param(1, core_1.Host()),
        __metadata("design:paramtypes", [core_1.ElementRef, SlickCarouselComponent])
    ], SlickCarouselItem);
    return SlickCarouselItem;
}());
exports.SlickCarouselItem = SlickCarouselItem;
//# sourceMappingURL=slickCarousel.component.js.map