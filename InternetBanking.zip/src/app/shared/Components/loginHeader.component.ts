import { Component } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'login-header',
  templateUrl: 'app/shared/templates/loginHeader.html'
})
export class LoginHeaderComponent {
	
}