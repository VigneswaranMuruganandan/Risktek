import { Component } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'register-header',
  templateUrl: 'app/shared/templates/registerHeader.html'
})
export class RegisterHeaderComponent {
	
}