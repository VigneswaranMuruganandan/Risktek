import { Component } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'navigation-component',
  templateUrl: 'app/shared/templates/navigation.html'
})
export class NavigationComponent {
	
}