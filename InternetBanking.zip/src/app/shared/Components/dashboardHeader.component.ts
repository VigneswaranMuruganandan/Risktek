import { Component } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'dashboard-header',
  templateUrl: 'app/shared/templates/dashboardHeader.html'
})
export class DashboardHeaderComponent {
	
}