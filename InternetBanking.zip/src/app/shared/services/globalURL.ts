export const GlobalURL = Object.freeze({
    SERVICE_URL: {
     	REGISTRATION: {
            REGISTERDEVICE: "/registration/device/register",
            VERIFYCUSTOMER: "/registration/customer/verify",
            VERIFYOTP: "/registration/otp/verify",
            RESENDOTP: "/registration/otp/resend",
            REGISTERPASSWORD: "/registration/pwd/register"
     	},
     	LOGIN: {
             VERIFYLOGIN: "/accesscontrol/cred/verify",
             AUTHENTICATIONMETHOD: "/registration/auth2/update",
             VERIFYCUSTOMERID:"/registration/customer/id/verify"
     	},
     	FORGOT_PASSWORD: {
             RESETPASSWORD:"/accesscontrol/cred/reset"
     	},
        DASHBOARD: {
            FETCH_DASHBOARD_DETAILS: "/cust/dashboard"
        },
     	SHARED: {
     		API_URL: "http://10.230.9.50:9080/PersonalBankingAPI/pbapp/"
     	},
        ACCOUNTS: {
            CUSTOMERACCOUNTS: "/cred/accounts",
        }
    },
    PROPERTIES: {
        STUBS: "N"
    }
 });

