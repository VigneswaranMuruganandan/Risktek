import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';



@Injectable()
export class EncryptionService {
    private CryptoJS = require('crypto-js');
    private keySize = 128 / 32;
    private iterationCount = 1000;
    constructor(private http: Http) {}
	
    public generatePwdHash(salt:string, cleartext:string):string{
       let hash = this.CryptoJS.PBKDF2(cleartext, salt, { keySize: 512/32, iterations: 50 });
       return hash;
    }

    public getEncodedKey(clearText: string){
        console.log("encoding text "+clearText);
        //var textString = 'Hello world'; // Utf8-encoded string
        var words = this.CryptoJS.enc.Utf8.parse(clearText); // WordArray object
        return words;//this.CryptoJS.enc.Base64.stringify(words);
        
    }

    public convertToBase64(words:any):string{
       return this.CryptoJS.enc.Base64.stringify(words);
    }

    public convertWordsToUtf8(words:any):string{
       return this.CryptoJS.enc.Utf8.stringify(words);
    }

    public getDecodedKey(encKey: string){
        console.log("decoding text "+encKey);

        let words = this.CryptoJS.enc.Base64.parse(encKey);
        return words;
    }
	/* Encrypt */
    public encrypt(plainText: any,encKey: any, encIv: any) {
        
        var key =  this.getDecodedKey(encKey);
        var iv  = this.getDecodedKey(encIv);
        console.log("key "+key);
        console.log("iv "+iv);
        var encrypted = this.CryptoJS.AES.encrypt(
            plainText,
            key, {
                mode: this.CryptoJS.mode.CBC,
                padding: this.CryptoJS.pad.Pkcs7,
                iv: iv //this.CryptoJS.enc.Hex.parse(iv)
            });
        //return btoa(encrypted.ciphertext);  
        let encrB64 = this.CryptoJS.enc.Base64.stringify(encrypted.ciphertext);  
        // CryptoJS.enc.Base64.toString(encrypted.ciphertext);
        console.log("encr b64 "+encrB64);
        return encrB64;  
        //return encrypted.ciphertext.toString(this.CryptoJS.enc.Base64);
    }
	/* Decrypt */
    public decrypt(cipherText: any,encKey: any, encIv: any) {
        console.log('decrypting ...'+ cipherText);
        let key =  this.getDecodedKey(encKey);// this.generateKey(salt, passPhrase);
        let iv  = this.getDecodedKey(encIv);
        
        let decrypted = this.CryptoJS.AES.decrypt(
            {
              ciphertext: this.getDecodedKey(cipherText)
            },
            key, {
                mode: this.CryptoJS.mode.CBC,
                padding: this.CryptoJS.pad.Pkcs7,
                iv: iv //this.CryptoJS.enc.Hex.parse(iv)
            });
        let decryptedText = decrypted.toString(this.CryptoJS.enc.Utf8);    
        console.log("decryptedText "+decryptedText);    
        return decryptedText;
    }
	/* Key Generation */
    private generateKey(salt: any, passPhrase: any) {
        var key = this.CryptoJS.PBKDF2(
            passPhrase,
            this.CryptoJS.enc.Hex.parse(salt), {
                keySize: this.keySize,
                iterations: this.iterationCount
            });
        return key;
    }
}