"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var http_1 = require("@angular/http");
var $ = require("jquery");
var global_1 = require("./global");
var TemplateService = (function () {
    function TemplateService(http) {
        this.http = http;
        this.validFormFlag = false;
    }
    /* Setting the Flag for form validation */
    TemplateService.prototype.setFromValidatorFlag = function (flag) {
        this.validFormFlag = flag;
    };
    /* Setting the Flag for form validation */
    TemplateService.prototype.resetFromValidatorFlag = function () {
        this.validFormFlag = false;
    };
    /* Getting the Image source*/
    TemplateService.prototype.getImageURL = function (id) {
        return 'app/assets/images/' + global_1.GlobalVariable.IMAGE_URL[id];
    };
    /* Checking the Menu status to
    make the alignment for Navigation bar*/
    TemplateService.prototype.checkMenuState = function () {
        if ($('.hamburger').hasClass("animate")) {
            if ($(window).width() >= 960) {
                $('.main').addClass('push');
            }
            $('.sidebar').css('left', '0');
        }
        else {
            $('.main').removeClass('push');
            $('.sidebar').css('left', '-300px');
        }
    };
    /* Show or hide menu */
    TemplateService.prototype.showHideMenu = function () {
        if ($(window).width() < 959) {
            $('.hamburger').removeClass('animate');
        }
        else {
            $('.hamburger').addClass('animate');
        }
    };
    TemplateService = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [http_1.Http])
    ], TemplateService);
    return TemplateService;
}());
exports.TemplateService = TemplateService;
//# sourceMappingURL=template.service.js.map