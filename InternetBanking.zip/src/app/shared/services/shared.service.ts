import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';
import {AppSession} from '../model/appsession';
import {AuthRequest} from '../../register/model/authrequest';
import {VerifyCustomerResponse} from '../../register/model/verifycustomerresponse';
import {RegisterPwdResponse} from '../../register/model/registerpwdresponse';
import {VerifyOtpResponse} from '../model/verifyotpresponse';
import {ResendOtpResponse} from '../../register/model/resendotpresponse';
import {AuthKey} from '../model/authkey';
import {AuthData} from '../model/authdata';
import {ServiceInvoker} from '../connector/serviceinvoker.service';
import {EncryptionService} from '../services/encryption.service';
import {SessionContext} from '../model/sessioncontext';
import {GlobalURL} from '../services/globalURL';
import {GlobalVariable} from './global';

@Injectable()
export class SharedService {

    private baseUrl: string = 'app/_assets/stubs/';

    constructor(private serviceInvoker: ServiceInvoker,
        private encryptionService: EncryptionService) {}

    registerDevice(authRequest: AuthRequest): Observable < AuthData > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.REGISTRATION.REGISTERDEVICE, authRequest)
            .map(resp => this.populateAuthReq(resp));
    }

    private populateAuthReq(resp: string) {
        var authData = new AuthData();
        let respObj = JSON.parse(resp);
        console.log("result " + respObj.result.status);
        if (respObj.result.status == 'success') {
            authData.authKey = new AuthKey();
            authData.authKey.encIV = respObj.data.encIV;
            authData.authKey.encKey = respObj.data.encKey;
            authData.authKey.convID = respObj.data.convID;
            authData.authKey.macKey = respObj.data.macKey;
            authData.authKey.ec = respObj.data.eventCtr;
            console.log("convid " + authData.authKey.convID);
            var sessCtx = SessionContext.getInstance();
            sessCtx.authKey = authData.authKey;
        }
        return authData;
    }

    setupAuthKeys() {
        let data = new AuthRequest();
        let sessCtx = SessionContext.getInstance();
        let jsonResp = "";
        if (sessCtx.authKey == null) {
            data.deviceID = "br_" + this.createGuid();
            console.log("in constructor dev id " + data.deviceID);
        }
        return data;
    }

    createGuid(): string {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            var r = Math.random() * 16 | 0,
                v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }

    handleError(error: any){
        console.log('handleVerifyCustIDError ' + error);
    }
}