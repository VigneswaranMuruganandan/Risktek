import { Injectable } from '@angular/core';
import { DecimalPipe } from '@angular/common';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import {GlobalVariable} from './global';

@Injectable()
export class SharedService{
  private baseUrl: string = 'app/_assets/stubs/';

  constructor(private http : Http, private decimalPipe: DecimalPipe){}

  getOfferAndBanner(): Observable<any>{
    return this.http
      .get(`${this.baseUrl}`+GlobalVariable.URL_MAPPING.ACCOUNT.OFFER_BANNER, {headers: this.getHeaders()})
      .map((response: Response) => <any>response.json())
            .catch(this.handleError);      
  }


  getaccountUiSelectOptions(){
    return {
        escapeMarkup: function(m :any) {
            return m;
        },
        templateResult: function(state :any) {
            if (state) {
                var originalOption = $(state.element);
                if (originalOption.data('first') == true) {
                    return '<span class="landingTxt">' + state.text + '</span>';
                } else {

                    return '<img class="selectImg" src="' + originalOption.data('img') + '" />' +
                        '<span class="selectTxt">' + originalOption.data('text') + '</span>' +
                        '<span class="selectaccnumber">' + originalOption.data('acc-number') + '</span>' +
                        '<span class="selectacctotal">' + originalOption.data('account-total') + '</span>' +
                        '<div class="c"></div>';
                }
            }
        },
        templateSelection: function(state :any) {
            if (state) {
                var originalOption = $(state.element);
                if (originalOption.data('first') == true) {
                    return '<span class="landingTxt">' + state.text + '</span>';
                } else {

                    return '<img class="selectImg" src="' + originalOption.data('img') + '" />' +
                        '<span class="selectTxt">' + originalOption.data('text') + '</span>' +
                        '<span class="selectaccnumber">' + originalOption.data('acc-number') + '</span>' +
                        '<span class="selectacctotal">' + originalOption.data('account-total') + '</span>' +
                        '<div class="c"></div>';
                }
            }
        }
    };
    
  }










  private getHeaders(){
    let headers = new Headers();
    headers.append('Accept', 'application/json');
    return headers;
  }
  private handleError(error: Response) {
        console.error(error);
        return Observable.throw(error.json().error || 'Server error');
  }
}


