import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import * as $ from 'jquery';

@Injectable()
export class TemplateService{
  validFormFlag : boolean;
  constructor(private http : Http){
    this.validFormFlag = false;
  }

  /* Setting the Flag for form validation */
  setFromValidatorFlag(flag: boolean){
    this.validFormFlag = flag;
  }
  /* Checking the Menu status to 
  make the alignment for Navigation bar*/
  checkMenuState(){
    if( $( '.hamburger').hasClass( "animate" ) ){
      if ($(window).width() >= 960) {
         $('.main').addClass('push');
      }
      $('.sidebar').css('left','0');
    }else{
      $('.main').removeClass('push');
      $('.sidebar').css('left','-300px');
    }
  }
  /* Show or hide menu */
  showHideMenu(){
    if ($(window).width() < 959) {
       $('.hamburger').removeClass('animate');
    }
    else {
       $('.hamburger').addClass('animate');
    }
  }

  
}


