import { Directive, ElementRef, HostListener, Input, Output, EventEmitter } from '@angular/core';
@Directive({ 
	selector: '[myHighlight]' 
})
export class HighlightDirective {
	@Input('myHighlight') highlightColor: string;  
	@Output() notify: EventEmitter<string> = new EventEmitter<string>();

    constructor(private el: ElementRef) { }


     @HostListener('document:click', ['$event'])
	  clickout(event:any) {
	    this.notify.emit("vignesh");
	  }
}