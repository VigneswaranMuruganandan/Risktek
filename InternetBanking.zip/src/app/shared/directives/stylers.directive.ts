import { Directive, ElementRef, HostListener, Input, OnInit } from '@angular/core';
import * as $ from 'jquery';
import {TemplateService} from '../../shared/services/template.service';

@Directive({
  selector: '[HamburgerMenuDirective]'
})
export class HamburgerMenu {

  constructor(private el: ElementRef, 
  			  private templateService: TemplateService) { }

  @HostListener('click', ['$event']) 
  onClick(event: any) {
	    $('.hamburger').toggleClass('animate');
	    this.templateService.checkMenuState();
  }
}

@Directive({
  selector: '[HamburgerInitDirective]'
})
export class HamburgerInitDirective  implements OnInit{

  constructor( private el: ElementRef, 
  			       private templateService: TemplateService) { }

  ngOnInit() { 
	    this.templateService.showHideMenu();
      this.templateService.checkMenuState();
  }
}

@Directive({
  selector: '[NavigationDirective]'
})
export class Navigation {

  constructor(private el: ElementRef) { }

  @HostListener('click', ['$event']) 
  onClick(event: any) {
        event.preventDefault();
      var el = $(this.el.nativeElement);
      if (el.next().hasClass('show')) {
          el.next().removeClass('show');
          el.next().slideUp(350);
          el.parent().find('a').removeClass('active');
      } else {
          el.parent().parent().find('li .inner').removeClass('show');
          el.parent().parent().find('li .inner').slideUp(350);
          el.parent().find('a').addClass('active');
          el.next().toggleClass('show');
          el.next().slideToggle(350);
      }
  }
}