import { Directive, ElementRef, HostListener, Input } from '@angular/core';
import * as $ from 'jquery';
import {TemplateService} from '../../shared/services/template.service';

@Directive({
  selector: '[HamburgerMenuDirective]'
})
export class HamburgerMenu {

  constructor(private el: ElementRef, 
  			  private templateService: TemplateService) { }

  @HostListener('click', ['$event']) 
  onClick(event: any) {
	    $('.hamburger').toggleClass('animate');
	    this.templateService.checkMenuState();
  }
}