import {Directive, ElementRef} from '@angular/core';
import * as $ from 'jquery';

@Directive({
    selector: '[datePicker]'
})
export class DatePicker
{
    private datePicker = require('date-picker');
    constructor(private el: ElementRef)
    {        
    }

    ngOnInit()
    {        
    }

    /*ngAfterViewInit()
    {
        let dateFormat = "mm/dd/yy",
          from = $( "#from" )
            .datepicker({
              defaultDate: "+1w",
             // changeMonth: true,
             // showButtonPanel: true
             // numberOfMonths: 3
            })
            .on( "change", function() {
              to.datepicker( "option", "minDate", getDate( this ) );
            }),
          to = $( "#to" ).datepicker({
            defaultDate: "+1w",
           // changeMonth: true,
           // showButtonPanel: true
           // numberOfMonths: 3
          })
          .on( "change", function() {
            from.datepicker( "option", "maxDate", getDate( this ) );
          });
     
        function getDate( element:any ) {
          var date;
          try {
            date = $.datepicker.parseDate( dateFormat, element.value );
          } catch( error ) {
            date = null;
          }
     
          return date;
        }
        
    }*/
}