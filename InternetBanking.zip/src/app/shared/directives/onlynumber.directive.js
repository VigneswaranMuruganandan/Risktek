"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var OnlyNumber = (function () {
    function OnlyNumber(el) {
        this.el = el;
    }
    OnlyNumber.prototype.onKeyDown = function (event) {
        var e = event;
        if (this.OnlyNumber) {
            console.log(e);
            console.log((e.key).length);
            if (((e.key).match(/^[0-9+$]/)) != null) {
                return;
            }
            if ((e.key).length > 1) {
                return;
            }
            else {
                e.preventDefault();
            }
        }
    };
    __decorate([
        core_1.Input(),
        __metadata("design:type", Boolean)
    ], OnlyNumber.prototype, "OnlyNumber", void 0);
    __decorate([
        core_1.HostListener('keydown', ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], OnlyNumber.prototype, "onKeyDown", null);
    OnlyNumber = __decorate([
        core_1.Directive({
            selector: '[OnlyNumber]'
        }),
        __metadata("design:paramtypes", [core_1.ElementRef])
    ], OnlyNumber);
    return OnlyNumber;
}());
exports.OnlyNumber = OnlyNumber;
//# sourceMappingURL=onlynumber.directive.js.map