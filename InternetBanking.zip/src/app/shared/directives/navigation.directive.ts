import { Directive, ElementRef, HostListener, Input } from '@angular/core';
import * as $ from 'jquery';

@Directive({
  selector: '[NavigationDirective]'
})
export class Navigation {

  constructor(private el: ElementRef) { }

  @HostListener('click', ['$event']) 
  onClick(event: any) {
      	event.preventDefault();
	    var el = $(this.el.nativeElement);
	    if (el.next().hasClass('show')) {
	        el.next().removeClass('show');
	        el.next().slideUp(350);
	        el.parent().find('a').removeClass('active');
	    } else {
	        el.parent().parent().find('li .inner').removeClass('show');
	        el.parent().parent().find('li .inner').slideUp(350);
	        el.parent().find('a').addClass('active');
	        el.next().toggleClass('show');
	        el.next().slideToggle(350);
	    }
  }
}