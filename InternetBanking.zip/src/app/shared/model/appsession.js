"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var AppSession = (function () {
    function AppSession() {
    }
    return AppSession;
}());
exports.AppSession = AppSession;
//# sourceMappingURL=appsession.js.map