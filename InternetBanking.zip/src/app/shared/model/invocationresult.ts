import {ErrorInfo} from './errorinfo';

export class InvocationResult{
	status: string;
	errorInfo: ErrorInfo;
}