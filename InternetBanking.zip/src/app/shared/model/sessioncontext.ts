import {AuthKey} from './authkey';

export class SessionContext{
    private static _instance:SessionContext;

    authKey:AuthKey;
    data:any[] = [];
    userID:string;

    public static getInstance():SessionContext{
        return SessionContext._instance||(SessionContext._instance = new SessionContext());
    };
}