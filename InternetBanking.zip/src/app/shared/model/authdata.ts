import {APIResponse} from '../../shared/model/apiresponse';
import {AuthKey} from '../../shared/model/authkey';

export class AuthData extends APIResponse{

	authKey:AuthKey;
	action:string;

}