export interface Scope{
    validatorFormFlag: boolean;
    formData : {}
}