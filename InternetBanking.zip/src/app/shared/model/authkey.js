"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var AuthKey = (function () {
    function AuthKey() {
    }
    return AuthKey;
}());
exports.AuthKey = AuthKey;
//# sourceMappingURL=authkey.js.map