"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var InvocationResult = (function () {
    function InvocationResult() {
    }
    InvocationResult.prototype.isSuccess = function () {
        return status == "success";
    };
    return InvocationResult;
}());
exports.InvocationResult = InvocationResult;
//# sourceMappingURL=invocationresult.js.map