"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var InvocationResult = (function () {
    function InvocationResult() {
    }
    return InvocationResult;
}());
exports.InvocationResult = InvocationResult;
//# sourceMappingURL=invocationresult.js.map