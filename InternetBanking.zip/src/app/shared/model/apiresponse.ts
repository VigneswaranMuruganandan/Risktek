import {InvocationResult} from './invocationresult';

export class APIResponse{
    result: InvocationResult; 
	
}