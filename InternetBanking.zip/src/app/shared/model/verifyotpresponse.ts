import {APIResponse} from '../../shared/model/apiresponse';
export class VerifyOtpResponse extends APIResponse{
	userName: string
	remainingOtpAttempts:number;
}