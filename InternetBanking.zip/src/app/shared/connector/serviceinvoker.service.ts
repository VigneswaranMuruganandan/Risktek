import { Injectable } from '@angular/core';
import { Http, Response, Headers , URLSearchParams, RequestOptions} from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';

import {AppSession} from '../model/appsession';
import {SessionContext} from '../model/sessioncontext';
import {StubResponse} from './stubresponse';


import {EncryptionService} from '../services/encryption.service';

@Injectable()
export class ServiceInvoker {

    private apiUrl = 'https://192.168.1.103:9443/PersonalBankingAPI/pbapp/'; 
    //private apiUrl = 'PersonalBankingAPI/pbapp/';
    private stubEnabled = 'N';
    private  encServ:EncryptionService = null;

    constructor(private http: Http,private encryptionService: EncryptionService) { 
       this.encServ = encryptionService;
    }
    
    invoke(op:string, data:any): Observable<any>{
         console.log("executing "+op + " with data "+data);
         let invResult = null;
         console.log("enc serv "+this.encServ);
         if(this.stubEnabled == 'N'){
            invResult = this.getHttpReq(op,data)
                         .map(res=>this.extractData(res,this.encryptionService))
                         .catch(this.handleError) ;
         }else{
            invResult = this.getMockHttpReq(op,data)
                         .map(this.extractMockData)
                         .catch(this.handleError) ;
         }
         return invResult ;
    }

    private extractMockData(res: string) {
      console.log("extracting data "+res);
      var jsonResp = res;//atob(body);
      return jsonResp;
    }

    private extractData(res: Response,encServ:EncryptionService) {
      console.log("extracting data "+res);
      let body = res.text();
      console.log("enc serv "+encServ);
      console.log("body "+body);
      var sessCtx = SessionContext.getInstance();
      var jsonResp = "";
      if (sessCtx.authKey==null){
         console.log("decoding resp..."+encServ);
         jsonResp = atob(body); 
      
         console.log("decoded jsonResp  "+jsonResp);
      }else{
          console.log("decr req...");
          let key = sessCtx.authKey.encKey;
          let iv = sessCtx.authKey.encIV;
          console.log('before decrypt '+key+' '+iv);
          jsonResp = encServ.decrypt(body,key,iv);
          console.log('afer decrypt '+jsonResp);
      }
      
      //var respObj = JSON.parse(jsonResp);
      return jsonResp;
    }

 
    private getHttpReq(op:string,data:any){
      let headers = new Headers();
      //headers.append('Content-type', 'application/x-www-form-urlencoded');
      headers.append('Content-type', 'text/plain');
      headers.append('Accept', 'application/json');

      var sessCtx = SessionContext.getInstance();
      if (sessCtx.authKey!=null){
         headers.append('Authorization', sessCtx.authKey.convID);
      }
      
      headers.append('op', op);
      headers.append('rc', '1234578');

      const options = new RequestOptions({ headers: headers }); 
      const body: URLSearchParams = new URLSearchParams(); 
      const req = JSON.stringify(data);

      var encReq = '';
      var sessCtx = SessionContext.getInstance();

      if (sessCtx.authKey==null){
          console.log("encoding req...");
          let words = this.encryptionService.getEncodedKey(req); //  btoa(req);
          encReq = this.encryptionService.convertToBase64(words);
          
          console.log("encReq  "+encReq);
      }else{
          console.log("encry req...");
          let key = sessCtx.authKey.encKey;
          let iv = sessCtx.authKey.encIV;
          encReq = this.encryptionService.encrypt(req,key,iv);
      }
      
      console.log("enc req sent: "+encReq );
      //body.set('request', encReq);  
      
      return this.http.post(this.apiUrl, encReq, options);  
      //return this.http.post(this.apiUrl, body.toString(), options);    
    }

    private getMockHttpReq(op:string,data:any):Observable<String>{
      let headers = new Headers();
      headers.append('Content-type', 'application/x-www-form-urlencoded');
      headers.append('Accept', 'application/json');
      headers.append('op', op);

      const options = new RequestOptions({ headers: headers }); 
      const body: URLSearchParams = new URLSearchParams(); 
      const req = JSON.stringify(data);
      
      
      const encReq = btoa(req);
      console.log("enc "+encReq + " "+atob(encReq));
      body.set('request', encReq);  
      let stubResponse = new StubResponse();
      let dataList = stubResponse.getData();
      let urlKey = dataList[op];
      console.log("data "+urlKey);
      let resp = dataList[urlKey+'_RES_1']; 

      return  Observable.of(resp); 
    }

    private populateMockResponse(res:any):String{
        let jsonMap = res.json();
        console.log("json map "+jsonMap);
        return "";

    }

  
 

    private handleError (error: Response | any) {
        console.log("in error "+error);
        let errMsg: string;
        if (error instanceof Response) {
          const body = error.json() || '';
          const err = body.error || JSON.stringify(body);
          errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
        } else {
          errMsg = error.message ? error.message : error.toString();
        }
        console.error(errMsg);
        return Observable.throw(errMsg);
    }

}