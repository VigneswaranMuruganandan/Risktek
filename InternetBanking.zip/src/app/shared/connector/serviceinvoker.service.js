"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var http_1 = require("@angular/http");
var Rx_1 = require("rxjs/Rx");
require("rxjs/add/operator/toPromise");
require("rxjs/add/operator/catch");
var sessioncontext_1 = require("../model/sessioncontext");
var stubresponse_1 = require("./stubresponse");
var encryption_service_1 = require("../services/encryption.service");
var ServiceInvoker = (function () {
    function ServiceInvoker(http, encryptionService) {
        this.http = http;
        this.encryptionService = encryptionService;
        this.apiUrl = 'https://192.168.1.103:9443/PersonalBankingAPI/pbapp/';
        //private apiUrl = 'PersonalBankingAPI/pbapp/';
        this.stubEnabled = 'N';
        this.encServ = null;
        this.encServ = encryptionService;
    }
    ServiceInvoker.prototype.invoke = function (op, data) {
        var _this = this;
        console.log("executing " + op + " with data " + data);
        var invResult = null;
        console.log("enc serv " + this.encServ);
        if (this.stubEnabled == 'N') {
            invResult = this.getHttpReq(op, data)
                .map(function (res) { return _this.extractData(res, _this.encryptionService); })
                .catch(this.handleError);
        }
        else {
            invResult = this.getMockHttpReq(op, data)
                .map(this.extractMockData)
                .catch(this.handleError);
        }
        return invResult;
    };
    ServiceInvoker.prototype.extractMockData = function (res) {
        console.log("extracting data " + res);
        var jsonResp = res; //atob(body);
        return jsonResp;
    };
    ServiceInvoker.prototype.extractData = function (res, encServ) {
        console.log("extracting data " + res);
        var body = res.text();
        console.log("enc serv " + encServ);
        console.log("body " + body);
        var sessCtx = sessioncontext_1.SessionContext.getInstance();
        var jsonResp = "";
        if (sessCtx.authKey == null) {
            console.log("decoding resp..." + encServ);
            jsonResp = atob(body);
            console.log("decoded jsonResp  " + jsonResp);
        }
        else {
            console.log("decr req...");
            var key = sessCtx.authKey.encKey;
            var iv = sessCtx.authKey.encIV;
            console.log('before decrypt ' + key + ' ' + iv);
            jsonResp = encServ.decrypt(body, key, iv);
            console.log('afer decrypt ' + jsonResp);
        }
        //var respObj = JSON.parse(jsonResp);
        return jsonResp;
    };
    ServiceInvoker.prototype.getHttpReq = function (op, data) {
        var headers = new http_1.Headers();
        //headers.append('Content-type', 'application/x-www-form-urlencoded');
        headers.append('Content-type', 'text/plain');
        headers.append('Accept', 'application/json');
        var sessCtx = sessioncontext_1.SessionContext.getInstance();
        if (sessCtx.authKey != null) {
            headers.append('Authorization', sessCtx.authKey.convID);
        }
        headers.append('op', op);
        headers.append('rc', '1234578');
        var options = new http_1.RequestOptions({ headers: headers });
        var body = new http_1.URLSearchParams();
        var req = JSON.stringify(data);
        var encReq = '';
        var sessCtx = sessioncontext_1.SessionContext.getInstance();
        if (sessCtx.authKey == null) {
            console.log("encoding req...");
            var words = this.encryptionService.getEncodedKey(req); //  btoa(req);
            encReq = this.encryptionService.convertToBase64(words);
            console.log("encReq  " + encReq);
        }
        else {
            console.log("encry req...");
            var key = sessCtx.authKey.encKey;
            var iv = sessCtx.authKey.encIV;
            encReq = this.encryptionService.encrypt(req, key, iv);
        }
        console.log("enc req sent: " + encReq);
        //body.set('request', encReq);  
        return this.http.post(this.apiUrl, encReq, options);
        //return this.http.post(this.apiUrl, body.toString(), options);    
    };
    ServiceInvoker.prototype.getMockHttpReq = function (op, data) {
        var headers = new http_1.Headers();
        headers.append('Content-type', 'application/x-www-form-urlencoded');
        headers.append('Accept', 'application/json');
        headers.append('op', op);
        var options = new http_1.RequestOptions({ headers: headers });
        var body = new http_1.URLSearchParams();
        var req = JSON.stringify(data);
        var encReq = btoa(req);
        console.log("enc " + encReq + " " + atob(encReq));
        body.set('request', encReq);
        var stubResponse = new stubresponse_1.StubResponse();
        var dataList = stubResponse.getData();
        var urlKey = dataList[op];
        console.log("data " + urlKey);
        var resp = dataList[urlKey + '_RES_1'];
        return Rx_1.Observable.of(resp);
    };
    ServiceInvoker.prototype.populateMockResponse = function (res) {
        var jsonMap = res.json();
        console.log("json map " + jsonMap);
        return "";
    };
    ServiceInvoker.prototype.handleError = function (error) {
        console.log("in error " + error);
        var errMsg;
        if (error instanceof http_1.Response) {
            var body = error.json() || '';
            var err = body.error || JSON.stringify(body);
            errMsg = error.status + " - " + (error.statusText || '') + " " + err;
        }
        else {
            errMsg = error.message ? error.message : error.toString();
        }
        console.error(errMsg);
        return Rx_1.Observable.throw(errMsg);
    };
    ServiceInvoker = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [http_1.Http, encryption_service_1.EncryptionService])
    ], ServiceInvoker);
    return ServiceInvoker;
}());
exports.ServiceInvoker = ServiceInvoker;
//# sourceMappingURL=serviceinvoker.service.js.map