import { NgModule } from '@angular/core';
import { CommonModule, DecimalPipe } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HttpModule, JsonpModule } from '@angular/http';
import { TranslateModule } from '@ngx-translate/core';

import {SharedService} from './services/shared.service';
import {TemplateService} from './services/template.service';
import {EncryptionService} from './services/encryption.service';

import {ServiceInvoker} from './connector/serviceinvoker.service';


import {GlobalVariable} from './services/global';


import { LoginHeaderComponent }   from './Components/loginHeader.component';
import { LoginFooterComponent }   from './Components/loginFooter.component';
import { RegisterHeaderComponent }   from './Components/registerHeader.component';
import { RegisterFooterComponent }   from './Components/registerFooter.component';
import { ForgotPasswordHeaderComponent }   from './Components/forgotPasswordHeader.component';
import { ForgotPasswordFooterComponent }   from './Components/forgotPasswordFooter.component';
import { DashboardHeaderComponent }   from './Components/dashboardHeader.component';
import { DashboardFooterComponent }   from './Components/dashboardFooter.component';
import { SearchHeaderComponent }   from './Components/searchHeader.component';
import { AccountSettingsHeaderComponent }   from './Components/accountSettingsHeader.component';
import { NavigationComponent }   from './Components/navigation.component';
import { BaseViewComponent }   from './Components/baseView.component';
import {SlickCarouselComponent, SlickCarouselItem} from './Components/slickCarousel.component'

import { OTPComponent, OTPKeypress } from './Components/otp.component';
import { Autofocus } from './directives/autofocus.directive';
import { OnlyNumber } from './directives/onlynumber.directive';
import { Navigation } from './directives/navigation.directive';
import { HamburgerMenu } from './directives/hamburgermenu.directive';

const SHARED_COMPONENTS = [
    LoginHeaderComponent,
    LoginFooterComponent,
    RegisterHeaderComponent,
    RegisterFooterComponent,
    ForgotPasswordHeaderComponent,
    ForgotPasswordFooterComponent,
    DashboardHeaderComponent,
    DashboardFooterComponent,
    SearchHeaderComponent,
    AccountSettingsHeaderComponent,
    NavigationComponent,
    BaseViewComponent,
    SlickCarouselComponent,
    OTPComponent
];

const SHARED_DIRECTIVES = [
    OnlyNumber,
    Navigation,
    HamburgerMenu,
    SlickCarouselItem,
    Autofocus,
    OTPKeypress
];

const SHARED_PROVIDERS = [
   SharedService,
   TemplateService,
   EncryptionService,
   DecimalPipe,
   ServiceInvoker
];

@NgModule({
  	imports: [
  		TranslateModule.forChild(),
      CommonModule,
      RouterModule
  	],
  	declarations: [
  		...SHARED_COMPONENTS,
      ...SHARED_DIRECTIVES  
  	],
  	providers: [ 
  		...SHARED_PROVIDERS
  	],
  	exports: [
  		...SHARED_COMPONENTS,
      ...SHARED_DIRECTIVES 
  	]
})
export class SharedModule {}
