import { Component, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'registrationstep1-component',
  templateUrl: 'app/register/templates/registrationStep1.html'
})
export class RegistrationStep1Component {
	@Output() validateCustomerIdentificationEvent = new EventEmitter();

	validateCustomer(){
		this.validateCustomerIdentificationEvent.emit();
	}
}