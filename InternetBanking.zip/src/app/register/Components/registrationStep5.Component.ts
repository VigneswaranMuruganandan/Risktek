import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'registrationstep5-component',
  templateUrl: 'app/register/templates/registrationStep5.html'
})
export class RegistrationStep5Component implements OnInit {
	public authenticationMethod: number;
	@Output() SaveRegistrationEvent = new EventEmitter();

	ngOnInit() { 
    	this.authenticationMethod = 1;
    }
    
	validateAuthenticationType(){
		this.SaveRegistrationEvent.emit();
	}
}