import { Component, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'registrationstep5-component',
  templateUrl: 'app/register/templates/registrationStep5.html'
})
export class RegistrationStep5Component {
	@Output() SaveRegistrationEvent = new EventEmitter();

	validateAuthenticationType(){
		this.SaveRegistrationEvent.emit();
	}
}