import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {CustomerData} from '../model/customerData';

@Component({
  selector: 'registrationstep3-component',
  templateUrl: 'app/register/templates/registrationStep3.html'
})
export class RegistrationStep3Component{
	@Input() validUsernameFlag: boolean;
	@Output() validateRegistrationUsernameEvent = new EventEmitter();
	@Input() customerData: CustomerData;

	private userName:string;

    usernameValidations(flag :boolean){
    	this.validUsernameFlag = flag;
    }


	validateUsername(valid: boolean){
		if(valid){
			this.validateRegistrationUsernameEvent.emit(this.userName);
		}		
	}
}