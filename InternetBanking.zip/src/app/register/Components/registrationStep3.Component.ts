import { Component, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'registrationstep3-component',
  templateUrl: 'app/register/templates/registrationStep3.html'
})
export class RegistrationStep3Component {
	@Input() validUsernameFlag: boolean;
	@Output() validateRegistrationUsernameEvent = new EventEmitter();



    usernameValidations(){
    	this.validUsernameFlag = true;
    }


	validateUsername(){
		this.validateRegistrationUsernameEvent.emit();
	}
}