import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {CustomerData} from '../model/customerData';
import {TemplateService} from '../../shared/services/template.service';

@Component({
  selector: 'registrationstep4-component',
  templateUrl: 'app/register/templates/registrationStep4.html'
})
export class RegistrationStep4Component implements OnInit{
	public showConfirmPassword: boolean;
	@Input() validPasswordFlag: boolean;
	@Output() validateRegistrationPasswordEvent = new EventEmitter();
	@Input() customerData: CustomerData;
	public passwordData : any;

	constructor(private templateService: TemplateService) {}

	ngOnInit() {
		this.passwordData = {"password":"","confirmPassword":""};
		this.showConfirmPassword = false;
	}

	passwordValidations(){
		this.validPasswordFlag = true;
	}

	validatePassword(){
		this.showConfirmPassword=true;
	}
	validateConfirmPassword(valid: boolean){
		if(valid){
			this.validateRegistrationPasswordEvent.emit(this.passwordData.password);
		}
	}
}