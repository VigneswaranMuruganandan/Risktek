import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'registrationstep4-component',
  templateUrl: 'app/register/templates/registrationStep4.html'
})
export class RegistrationStep4Component implements OnInit{
	public showConfirmPassword: boolean;
	@Input() validPasswordFlag: boolean;
	@Output() validateRegistrationPasswordEvent = new EventEmitter();


	passwordValidations(){
		this.validPasswordFlag = true;
	}

	ngOnInit() {
		this.showConfirmPassword = false;
	}

	validatePassword(){
		this.showConfirmPassword=true;
	}
	validateConfirmPassword(){
		this.validateRegistrationPasswordEvent.emit();
	}
}