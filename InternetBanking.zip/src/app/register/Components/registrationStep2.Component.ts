import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {CustomerData} from '../model/customerData';

@Component({
  selector: 'registrationstep2-component',
  templateUrl: 'app/register/templates/registrationStep2.html'
})
export class RegistrationStep2Component implements OnInit{
	@Output() validateRegistrationOTPEvent = new EventEmitter();
	@Input() customerData: CustomerData;
	public otp:string;

	public otpList :Array<string>;

	ngOnInit() { 
    	this.otpList = ['','','','','','']
    }

	validateOTP(){
		this.otp = this.otpList.join('');
		this.validateRegistrationOTPEvent.emit(this.otp);
	}
}