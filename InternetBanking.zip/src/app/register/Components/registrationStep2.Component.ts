import { Component, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'registrationstep2-component',
  templateUrl: 'app/register/templates/registrationStep2.html'
})
export class RegistrationStep2Component {
	@Output() validateRegistrationOTPEvent = new EventEmitter();

	validateOTP(){
		this.validateRegistrationOTPEvent.emit();
	}
}