import { Component, OnInit, Input} from '@angular/core';
import {RegisterService} from '../services/register.service';
import {SharedService} from '../../shared/services/shared.service';
import {SessionContext} from '../../shared/model/sessioncontext';
import {AuthRequest} from '../model/authrequest';
import {CustomerData} from '../model/customerData';
import {VerifyCustomerResponse} from '../model/verifycustomerresponse';
import {VerifyOtpResponse} from '../../shared/model/verifyotpresponse';
import {ResendOtpResponse} from '../model/resendotpresponse';
import {Router} from '@angular/router';
import { Observable } from 'rxjs/Rx';
import {AuthKey} from '../../shared/model/authkey';
import {AuthData} from '../../shared/model/authdata';

@Component({
    templateUrl: 'app/register/templates/register.html'
})
export class RegisterComponent implements OnInit {

    public stepFlag: number;
    public validUsername: boolean;
    public validPassword: boolean;

    public customerData: CustomerData;

    constructor( private registerService: RegisterService, 
    			 private sharedService: SharedService,
    			 private router: Router) {}

    ngOnInit() {
        this.stepFlag = 1;
        this.validUsername = false;
        this.customerData = new CustomerData();
    }

    ViewRegisterTermsandConditions() {

    }

    /*
    * Step 1: Register the Device ID
    */
    validateCustomerIdentification(customerID: string) {
    	this.customerData.customerID = customerID;
    	let registerDeviceData = this.sharedService.setupAuthKeys();
	    console.log("Register Device Data ::"+registerDeviceData);
	    if(registerDeviceData && registerDeviceData.deviceID !=''){
	        this.sharedService.registerDevice(registerDeviceData)
	            .subscribe(
	                resp => this.handleRegisterDeviceDataResp(resp),
	                error => this.sharedService.handleError(error)
	            );
	    }
    }
    /*
    * Step 2: Verify the customer ID to get the CIF number
    */
    private handleRegisterDeviceDataResp(resp: AuthData){
    	if(resp.authKey.convID != ''){
    		console.log("validating customer identification " + this.customerData.customerID);
	        let data = new AuthRequest();
	        data.customerID = this.customerData.customerID;
	        this.registerService.verifyCustomer(data)
	            .subscribe(
	                resp => this.handleVerifyCustIDResp(resp),
	                error => this.sharedService.handleError(error)
	            );
    	}
    }

    /*
    * Handle the Response of Verify Customer ID
    * to get Mobile number and email and move to OTP Page
    */
    private handleVerifyCustIDResp(resp: VerifyCustomerResponse) {
        console.log('handleVerifyCustIDResp ' + resp);
        this.stepFlag = 2;
        this.customerData.mobileNumber = resp.mobileNumberMasked;
        this.customerData.emailID = resp.emailMasked;
    }

    /*
    * Step 3: Verify the OTP 
    */
    validateRegistrationOTP(otp: string) {
        console.log("validating OTP " + otp);
        let data = new AuthRequest();
        data.otp = otp;
        this.registerService.verifyOtp(data)
            .subscribe(
                resp => this.handleVerifyOtpResp(resp),
                error => this.sharedService.handleError(error)
            );
    }

    /*
    * Handle the Verify OTP Response
    */
    private handleVerifyOtpResp(resp: any) {
        console.log('handleVerifyOtpResp ' + resp);
        this.customerData.name = resp.userName;
        this.stepFlag = 3;
    }

    /*
    * Handle the Username 
    */
    validateRegistrationUsername(userName: string) {
        this.customerData.userName = userName;
        this.stepFlag = 4;
    }

    /*
    * Step 4: Register the  Username and Hashed Password 
    */
    validateRegistrationPassword(pwd: string) {
        console.log("validating Password " + pwd);
        this.customerData.pwd = pwd;
        let data = new AuthRequest();
        data.pwd = pwd;
        data.userName = this.customerData.userName;
        this.registerService.registerPwd(data)
            .subscribe(
                resp => this.handleVerifyPwdResp(resp),
                error => this.sharedService.handleError(error)
            );
    }

    /*
    * Step 5: Verify the Username and Hashed Password 
    */
    private handleVerifyPwdResp(resp: any) {
        console.log('handleVerifyPwdResp ' + resp);
        if (resp.result.status == "success") {
            let data = new AuthRequest();
            data.userName = this.customerData.userName;
            data.pwd = this.customerData.pwd;
            this.registerService.verifyLogin(data)
                .subscribe(
                    resp => this.handleLoginResp(resp),
                    error => this.sharedService.handleError(error)
                );
        }
    }

    /*
    * Handle the verify Login based on actions
    */
    private handleLoginResp(resp: any) {
        if (resp.result.status == 'success') {
            if (resp.action[0] == 'VIEW_SECOND_FACTOR') {
                this.stepFlag = 5;
            }
        }
    }

    /*
    * Based on Action, if VIEW_SECOND_FACTOR, 
    * Save the Authentication Method and take the user to dashboard
    */
    saveRegistration(authenticationMethod: string) {
        let data = new AuthRequest();
        data.otpMethod = authenticationMethod;
        this.registerService.saveAuthenticationMethod(data)
            .subscribe(
                resp => this.handleVerifyAuthenticationResp(resp),
                error => this.sharedService.handleError(error)
            );
    }

    private handleVerifyAuthenticationResp(resp: any) {
        if (resp.result.status == 'success') {
            this.router.navigate(['/dashboard']);
        }
    }
}