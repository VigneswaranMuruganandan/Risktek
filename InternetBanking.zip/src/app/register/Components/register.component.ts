import { Component, OnInit, Input} from '@angular/core';
import {RegisterService} from '../services/register.service';
import {AuthRequest} from '../model/authrequest';

@Component({
  templateUrl: 'app/register/templates/register.html'
})
export class RegisterComponent implements OnInit{
	
	public stepFlag: number;
	public validUsername:boolean;
	public validPassword:boolean;

    constructor(private registerService: RegisterService) {}

	ngOnInit() { 
    	this.stepFlag = 1;
    	this.validUsername = false;
        let data = new AuthRequest();
        data.deviceID = 'jkfhjdskfhdsfh';
        this.registerService.registerDevice(data).subscribe();

    }


    validateCustomerIdentification(){
    	this.stepFlag = 2;
    	console.log("validated customer identification");
    }

    validateRegistrationOTP(){
    	this.stepFlag = 3;
    	console.log("validated OTP");
    }

    validateRegistrationUsername(){
    	this.stepFlag = 4;
    	console.log("validated Username");
    }

    validateRegistrationPassword(){
    	this.stepFlag = 5;
    }

    /*validateRegistrationConfirmPassword(){
    	
    }*/

    SaveRegistration(){

    }

}