"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var $ = require("jquery");
var template_service_1 = require("../../shared/services/template.service");
/*
* Customer Identification validation for Registration
*/
var ValidateCustomerIdentificationRegister = (function () {
    function ValidateCustomerIdentificationRegister(el, zone, templateService) {
        this.el = el;
        this.zone = zone;
        this.templateService = templateService;
        this.x = require('jquery-validator');
    }
    ValidateCustomerIdentificationRegister.prototype.ngAfterViewInit = function () {
    };
    ValidateCustomerIdentificationRegister.prototype.onClick = function (event) {
        var _this = this;
        var el = $(this.el.nativeElement);
        var registrationCusIDValidationSubmit;
        this.zone.runOutsideAngular(function () {
            var registrationCusIDValidation = $("#registrationCusIDForm").validate({
                highlight: function (element) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function (element, errorClass) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function (error, element) {
                    if (element.is("input")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    customerIdentificationNo: {
                        required: true
                    }
                },
                messages: {
                    customerIdentificationNo: {
                        required: "Please enter Customer Identification Number"
                    }
                }
            });
            registrationCusIDValidationSubmit = registrationCusIDValidation.form();
            _this.templateService.setFromValidatorFlag(registrationCusIDValidationSubmit);
        });
    };
    __decorate([
        core_1.HostListener('click', ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], ValidateCustomerIdentificationRegister.prototype, "onClick", null);
    ValidateCustomerIdentificationRegister = __decorate([
        core_1.Directive({
            selector: '[ValidateRegisterDirective]',
        }),
        __metadata("design:paramtypes", [core_1.ElementRef, core_1.NgZone, template_service_1.TemplateService])
    ], ValidateCustomerIdentificationRegister);
    return ValidateCustomerIdentificationRegister;
}());
exports.ValidateCustomerIdentificationRegister = ValidateCustomerIdentificationRegister;
/*
* Username validation for Registration
*/
var ValidateUsernameRegister = (function () {
    function ValidateUsernameRegister(el, zone, templateService) {
        this.el = el;
        this.zone = zone;
        this.templateService = templateService;
        this.x = require('jquery-validator');
        this.usernameValidationsEvent = new core_1.EventEmitter();
    }
    ValidateUsernameRegister.prototype.ngAfterViewInit = function () {
    };
    ValidateUsernameRegister.prototype.onKeyUp = function (event) {
        var _this = this;
        var e = event;
        var registrationUsernameSubmit;
        this.zone.runOutsideAngular(function () {
            jQuery.validator.addMethod("usernameLength", function (value, element, param) {
                var flag = false;
                if (value != null) {
                    var regx6to16 = new RegExp("^.{6,16}$"), flag = regx6to16.test(value);
                    if (flag) {
                        $('.validate li:eq(0)').addClass('success');
                        $('.validate li:eq(0)').removeClass('error');
                    }
                    else {
                        $('.validate li:eq(0)').addClass('error');
                        $('.validate li:eq(0)').removeClass('success');
                    }
                }
                return flag;
            });
            jQuery.validator.addMethod("atleast1Alphabetic", function (value, element, param) {
                var flag = false;
                if (value != null) {
                    var regx1alphabetic = new RegExp("(.*[a-zA-Z]){1}"), flag = regx1alphabetic.test(value);
                    if (flag) {
                        $('.validate li:eq(1)').addClass('success');
                        $('.validate li:eq(1)').removeClass('error');
                    }
                    else {
                        $('.validate li:eq(1)').addClass('error');
                        $('.validate li:eq(1)').removeClass('success');
                    }
                }
                return flag;
            });
            jQuery.validator.addMethod("validateSpecialCharacters", function (value, element, param) {
                var flag = false;
                if (value != null) {
                    var regxSpecialCharacters = new RegExp("^[^!#%^&\\<>\/]+$"), flag = regxSpecialCharacters.test(value);
                    if (flag) {
                        $('.validate li:eq(2)').addClass('success');
                        $('.validate li:eq(2)').removeClass('error');
                    }
                    else {
                        $('.validate li:eq(2)').addClass('error');
                        $('.validate li:eq(2)').removeClass('success');
                    }
                }
                return flag;
            });
            var registrationUsernameValidation = $("#usernameRegisterForm").validate({
                highlight: function (element) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function (element, errorClass) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function (error, element) {
                    if (element.is("input")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    username: {
                        required: function () {
                            $('.validate li:eq(0)').removeAttr('class');
                            $('.validate li:eq(1)').removeAttr('class');
                            $('.validate li:eq(2)').removeAttr('class');
                            return true;
                        },
                        usernameLength: true,
                        atleast1Alphabetic: true,
                        validateSpecialCharacters: true
                    }
                },
                messages: {
                    username: {
                        required: "Please fill",
                        usernameLength: "",
                        atleast1Alphabetic: "",
                        validateSpecialCharacters: ""
                    }
                }
            });
            registrationUsernameSubmit = registrationUsernameValidation.form();
            _this.usernameValidationsEvent.emit(registrationUsernameSubmit);
            _this.templateService.setFromValidatorFlag(registrationUsernameSubmit);
        });
    };
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], ValidateUsernameRegister.prototype, "usernameValidationsEvent", void 0);
    __decorate([
        core_1.HostListener('keyup', ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [KeyboardEvent]),
        __metadata("design:returntype", void 0)
    ], ValidateUsernameRegister.prototype, "onKeyUp", null);
    ValidateUsernameRegister = __decorate([
        core_1.Directive({
            selector: '[ValidateUsernameRegDirective]',
        }),
        __metadata("design:paramtypes", [core_1.ElementRef, core_1.NgZone, template_service_1.TemplateService])
    ], ValidateUsernameRegister);
    return ValidateUsernameRegister;
}());
exports.ValidateUsernameRegister = ValidateUsernameRegister;
/*
* Password validation for Registration
*/
var ValidatePasswordRegister = (function () {
    function ValidatePasswordRegister(el, zone, templateService) {
        this.el = el;
        this.zone = zone;
        this.templateService = templateService;
        this.x = require('jquery-validator');
        this.passwordValidationsEvent = new core_1.EventEmitter();
    }
    ValidatePasswordRegister.prototype.ngAfterViewInit = function () {
    };
    ValidatePasswordRegister.prototype.onKeyUp = function (event) {
        var _this = this;
        var e = event;
        var registrationPasswordSubmit;
        this.zone.runOutsideAngular(function () {
            jQuery.validator.addMethod("passwordLength", function (value, element, param) {
                var flag = false;
                if (value != null) {
                    var regx6to16 = new RegExp("^.{6,16}$"), flag = regx6to16.test(value);
                    if (flag) {
                        $('.validate li:eq(0)').addClass('success');
                        $('.validate li:eq(0)').removeClass('error');
                    }
                    else {
                        $('.validate li:eq(0)').addClass('error');
                        $('.validate li:eq(0)').removeClass('success');
                    }
                }
                return flag;
            });
            jQuery.validator.addMethod("atleast1Alphabetic", function (value, element, param) {
                var flag = false;
                if (value != null) {
                    var regx1alphabetic = new RegExp("(.*[a-zA-Z]){1}"), flag = regx1alphabetic.test(value);
                    if (flag) {
                        $('.validate li:eq(1)').addClass('success');
                        $('.validate li:eq(1)').removeClass('error');
                    }
                    else {
                        $('.validate li:eq(1)').addClass('error');
                        $('.validate li:eq(1)').removeClass('success');
                    }
                }
                return flag;
            });
            jQuery.validator.addMethod("validateSpecialCharacters", function (value, element, param) {
                var flag = false;
                if (value != null) {
                    var regxSpecialCharacters = new RegExp("^[^!#%^&\\<>\/]+$"), flag = regxSpecialCharacters.test(value);
                    if (flag) {
                        $('.validate li:eq(2)').addClass('success');
                        $('.validate li:eq(2)').removeClass('error');
                    }
                    else {
                        $('.validate li:eq(2)').addClass('error');
                        $('.validate li:eq(2)').removeClass('success');
                    }
                }
                return flag;
            });
            var registrationPasswordValidation = $("#passwordRegisterForm").validate({
                highlight: function (element) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function (element, errorClass) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function (error, element) {
                    if (element.is("input")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    password: {
                        required: function () {
                            $('.validate li:eq(0)').removeAttr('class');
                            $('.validate li:eq(1)').removeAttr('class');
                            $('.validate li:eq(2)').removeAttr('class');
                            return true;
                        },
                        passwordLength: true,
                        atleast1Alphabetic: true,
                        validateSpecialCharacters: true
                    }
                },
                messages: {
                    password: {
                        required: "Please fill",
                        passwordLength: "",
                        atleast1Alphabetic: "",
                        validateSpecialCharacters: ""
                    }
                }
            });
            registrationPasswordSubmit = registrationPasswordValidation.form();
            _this.passwordValidationsEvent.emit(registrationPasswordSubmit);
            _this.templateService.setFromValidatorFlag(registrationPasswordSubmit);
        });
    };
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], ValidatePasswordRegister.prototype, "passwordValidationsEvent", void 0);
    __decorate([
        core_1.HostListener('keyup', ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [KeyboardEvent]),
        __metadata("design:returntype", void 0)
    ], ValidatePasswordRegister.prototype, "onKeyUp", null);
    ValidatePasswordRegister = __decorate([
        core_1.Directive({
            selector: '[ValidatePasswordRegDirective]',
        }),
        __metadata("design:paramtypes", [core_1.ElementRef, core_1.NgZone, template_service_1.TemplateService])
    ], ValidatePasswordRegister);
    return ValidatePasswordRegister;
}());
exports.ValidatePasswordRegister = ValidatePasswordRegister;
/*
* ConfirmPassword validation for Registration
*/
var ValidateConfirmPasswordRegister = (function () {
    function ValidateConfirmPasswordRegister(el, zone, templateService) {
        this.el = el;
        this.zone = zone;
        this.templateService = templateService;
        this.x = require('jquery-validator');
    }
    ValidateConfirmPasswordRegister.prototype.onClick = function (event) {
        var _this = this;
        var el = $(this.el.nativeElement);
        var registrationConfirmPasswordValidationSubmit;
        this.zone.runOutsideAngular(function () {
            jQuery.validator.addMethod("comparePassword", function (value, element, param) {
                var flag = false;
                (param.password == param.confirmPassword) ? (flag = true) : (flag = false);
                return flag;
            });
            var registrationConfirmPasswordValidation = $("#confirmPasswordForm").validate({
                highlight: function (element) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function (element, errorClass) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function (error, element) {
                    if (element.is("input")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    confirmPassword: {
                        required: true,
                        comparePassword: _this.passwordData
                    }
                },
                messages: {
                    confirmPassword: {
                        required: "Please Confirm the Password once again",
                        comparePassword: "Please enter the same password"
                    }
                }
            });
            registrationConfirmPasswordValidation.settings.rules.confirmPassword.comparePassword = _this.passwordData;
            registrationConfirmPasswordValidationSubmit = registrationConfirmPasswordValidation.form();
            _this.templateService.setFromValidatorFlag(registrationConfirmPasswordValidationSubmit);
        });
    };
    __decorate([
        core_1.Input(),
        __metadata("design:type", Object)
    ], ValidateConfirmPasswordRegister.prototype, "passwordData", void 0);
    __decorate([
        core_1.HostListener('click', ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], ValidateConfirmPasswordRegister.prototype, "onClick", null);
    ValidateConfirmPasswordRegister = __decorate([
        core_1.Directive({
            selector: '[ValidateConfirmPasswordDirective]',
        }),
        __metadata("design:paramtypes", [core_1.ElementRef, core_1.NgZone, template_service_1.TemplateService])
    ], ValidateConfirmPasswordRegister);
    return ValidateConfirmPasswordRegister;
}());
exports.ValidateConfirmPasswordRegister = ValidateConfirmPasswordRegister;
//# sourceMappingURL=validateregister.directive.js.map