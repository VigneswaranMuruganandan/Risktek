import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { routing } from './register.routing';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '../shared/shared.module';
import {SharedService} from '../shared/services/shared.service';
import {TemplateService} from '../shared/services/template.service';
import {RegisterService} from './services/register.service';
import { FormsModule } from '@angular/forms';
import { RegisterComponent } from './Components/register.component';
import { RegistrationStep1Component }   from './Components/registrationStep1.Component';
import { RegistrationStep2Component }   from './Components/registrationStep2.Component';
import { RegistrationStep3Component }   from './Components/registrationStep3.Component';
import { RegistrationStep4Component }   from './Components/registrationStep4.Component';
import { RegistrationStep5Component }   from './Components/registrationStep5.Component';



const REGISTER_COMPONENTS = [
    RegisterComponent,
    RegistrationStep1Component,
    RegistrationStep2Component,
    RegistrationStep3Component,
    RegistrationStep4Component,
    RegistrationStep5Component
];

const REGISTER_PROVIDERS = [
   SharedService,
   TemplateService,
   RegisterService
];

@NgModule({
  	imports: [
	    routing,
	    TranslateModule.forChild(),
	    SharedModule,
	    FormsModule,
      CommonModule
	],
  	declarations: [
	    ...REGISTER_COMPONENTS
	],
  	providers: [
  		...REGISTER_PROVIDERS
  	]
})
export class RegisterModule {}
