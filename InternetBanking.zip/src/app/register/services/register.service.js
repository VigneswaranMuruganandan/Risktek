"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
require("rxjs/add/operator/toPromise");
var verifycustomerresponse_1 = require("../model/verifycustomerresponse");
var registerpwdresponse_1 = require("../model/registerpwdresponse");
var verifyotpresponse_1 = require("../../shared/model/verifyotpresponse");
var resendotpresponse_1 = require("../model/resendotpresponse");
var authkey_1 = require("../../shared/model/authkey");
var authdata_1 = require("../../shared/model/authdata");
var serviceinvoker_service_1 = require("../../shared/connector/serviceinvoker.service");
var encryption_service_1 = require("../../shared/services/encryption.service");
var sessioncontext_1 = require("../../shared/model/sessioncontext");
var globalURL_1 = require("../../shared/services/globalURL");
var RegisterService = (function () {
    function RegisterService(serviceInvoker, encryptionService) {
        this.serviceInvoker = serviceInvoker;
        this.encryptionService = encryptionService;
    }
    RegisterService.prototype.registerDevice = function (authRequest) {
        var _this = this;
        return this.serviceInvoker.invoke(globalURL_1.GlobalURL.SERVICE_URL.REGISTRATION.REGISTERDEVICE, authRequest)
            .map(function (resp) { return _this.populateAuthReq(resp); });
    };
    RegisterService.prototype.populateAuthReq = function (resp) {
        var authData = new authdata_1.AuthData();
        var respObj = JSON.parse(resp);
        console.log("result " + respObj.result.status);
        if (respObj.result.status == 'success') {
            authData.authKey = new authkey_1.AuthKey();
            authData.authKey.encIV = respObj.data.encIV;
            authData.authKey.encKey = respObj.data.encKey;
            authData.authKey.convID = respObj.data.convID;
            authData.authKey.macKey = respObj.data.macKey;
            authData.authKey.ec = respObj.data.eventCtr;
            console.log("convid " + authData.authKey.convID);
            var sessCtx = sessioncontext_1.SessionContext.getInstance();
            sessCtx.authKey = authData.authKey;
        }
        return authData;
    };
    RegisterService.prototype.verifyCustomer = function (authRequest) {
        var _this = this;
        return this.serviceInvoker.invoke(globalURL_1.GlobalURL.SERVICE_URL.REGISTRATION.VERIFYCUSTOMER, authRequest)
            .map(function (resp) { return _this.populateCustResp(resp); });
    };
    RegisterService.prototype.verifyOtp = function (authRequest) {
        var _this = this;
        return this.serviceInvoker.invoke(globalURL_1.GlobalURL.SERVICE_URL.REGISTRATION.VERIFYOTP, authRequest)
            .map(function (resp) { return _this.populateOtpResp(resp); });
    };
    RegisterService.prototype.resendOtp = function () {
        var _this = this;
        return this.serviceInvoker.invoke(globalURL_1.GlobalURL.SERVICE_URL.REGISTRATION.RESENDOTP, null)
            .map(function (resp) { return _this.populateResendOtpResp(resp); });
    };
    RegisterService.prototype.registerPwd = function (authRequest) {
        var _this = this;
        console.log(sessioncontext_1.SessionContext.getInstance());
        var pwdHash = this.encryptionService.generatePwdHash(sessioncontext_1.SessionContext.getInstance().userID, authRequest.pwd);
        authRequest.pwd = this.encryptionService.convertToBase64(pwdHash);
        return this.serviceInvoker.invoke(globalURL_1.GlobalURL.SERVICE_URL.REGISTRATION.REGISTERPASSWORD, authRequest)
            .map(function (resp) { return _this.populatePwdRegisterResp(resp); });
    };
    RegisterService.prototype.verifyLogin = function (authRequest) {
        var _this = this;
        var pwdHash = this.encryptionService.generatePwdHash(sessioncontext_1.SessionContext.getInstance().userID, authRequest.pwd);
        authRequest.pwd = this.encryptionService.convertToBase64(pwdHash);
        return this.serviceInvoker.invoke(globalURL_1.GlobalURL.SERVICE_URL.LOGIN.VERIFYLOGIN, authRequest)
            .map(function (resp) { return _this.populateLoginResp(resp); });
    };
    RegisterService.prototype.saveAuthenticationMethod = function (authRequest) {
        var _this = this;
        return this.serviceInvoker.invoke(globalURL_1.GlobalURL.SERVICE_URL.LOGIN.AUTHENTICATIONMETHOD, authRequest)
            .map(function (resp) { return _this.populateAuthenticationMethodResp(resp); });
    };
    RegisterService.prototype.populateCustResp = function (resp) {
        console.log("cust resp " + resp);
        var respObj = JSON.parse(resp);
        console.log("res " + respObj.result.status);
        var responseObj = new verifycustomerresponse_1.VerifyCustomerResponse();
        sessioncontext_1.SessionContext.getInstance().userID = respObj.cif;
        responseObj.otpDuration = respObj.otpDuration;
        responseObj.convID = respObj.convID;
        responseObj.cif = respObj.cif;
        responseObj.emailMasked = respObj.emailMasked;
        responseObj.mobileNumberMasked = respObj.mobileNumberMasked;
        responseObj.remainingOtpAttempts = respObj.remainingOtpAttempts;
        return responseObj;
    };
    RegisterService.prototype.populateOtpResp = function (resp) {
        var respObj = JSON.parse(resp);
        console.log("res " + respObj.result.status);
        var responseObj = new verifyotpresponse_1.VerifyOtpResponse();
        console.log("res " + respObj.result.success);
        responseObj.userName = respObj.userName;
        return responseObj;
    };
    RegisterService.prototype.populatePwdRegisterResp = function (resp) {
        var respObj = JSON.parse(resp);
        this.updateSessionContext(respObj);
        console.log("res " + respObj.result.status);
        var responseObj = new registerpwdresponse_1.RegisterPwdResponse();
        responseObj = respObj;
        console.log("res " + respObj.result.success);
        return responseObj;
    };
    RegisterService.prototype.populateLoginResp = function (resp) {
        var respObj = JSON.parse(resp);
        this.updateSessionContext(respObj);
        var responseObj = new registerpwdresponse_1.RegisterPwdResponse();
        responseObj = respObj;
        console.log("res " + responseObj);
        return responseObj;
    };
    RegisterService.prototype.populateAuthenticationMethodResp = function (resp) {
        var respObj = JSON.parse(resp);
        var responseObj = new registerpwdresponse_1.RegisterPwdResponse();
        responseObj = respObj;
        console.log("res " + responseObj);
        return responseObj;
    };
    RegisterService.prototype.updateSessionContext = function (respObj) {
        if (respObj.result.status == 'success') {
            var authData = new authdata_1.AuthData();
            authData.authKey = new authkey_1.AuthKey();
            authData.authKey.encIV = respObj.data.encIV;
            authData.authKey.encKey = respObj.data.encKey;
            authData.authKey.convID = respObj.data.convID;
            authData.authKey.macKey = respObj.data.macKey;
            authData.authKey.ec = respObj.data.eventCtr;
            var sessCtx = sessioncontext_1.SessionContext.getInstance();
            sessCtx.authKey = authData.authKey;
        }
    };
    RegisterService.prototype.populateResendOtpResp = function (resp) {
        var respObj = JSON.parse(resp);
        console.log("res " + respObj.result.status);
        var responseObj = new resendotpresponse_1.ResendOtpResponse();
        console.log("res " + respObj.result.success);
        responseObj.result.status = respObj.result.status;
        return responseObj;
    };
    RegisterService = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [serviceinvoker_service_1.ServiceInvoker,
            encryption_service_1.EncryptionService])
    ], RegisterService);
    return RegisterService;
}());
exports.RegisterService = RegisterService;
//# sourceMappingURL=register.service.js.map