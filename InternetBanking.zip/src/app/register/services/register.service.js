"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var http_1 = require("@angular/http");
require("rxjs/add/operator/toPromise");
var verifycustomerresponse_1 = require("../model/verifycustomerresponse");
var registerpwdresponse_1 = require("../model/registerpwdresponse");
var verifyotpresponse_1 = require("../model/verifyotpresponse");
var resendotpresponse_1 = require("../model/resendotpresponse");
var authkey_1 = require("../../shared/model/authkey");
var serviceinvoker_service_1 = require("../../shared/connector/serviceinvoker.service");
var encryption_service_1 = require("../../shared/services/encryption.service");
var sessioncontext_1 = require("../../shared/model/sessioncontext");
var RegisterService = (function () {
    function RegisterService(http, serviceInvoker, encryptionService) {
        this.http = http;
        this.serviceInvoker = serviceInvoker;
        this.encryptionService = encryptionService;
    }
    RegisterService.prototype.registerDevice = function (authRequest) {
        var _this = this;
        return this.serviceInvoker.invoke('/registration/device/register', authRequest).map(function (resp) { return _this.populateAuthReq(resp); });
    };
    RegisterService.prototype.populateAuthReq = function (resp) {
        var authKey = new authkey_1.AuthKey();
        var respObj = JSON.parse(resp);
        authKey.encIV = respObj.data.encIV;
        authKey.encKey = respObj.data.encKey;
        authKey.convID = respObj.data.convID;
        authKey.macKey = respObj.data.macKey;
        authKey.ec = respObj.data.eventCtr;
        return authKey;
    };
    RegisterService.prototype.verifyCustomer = function (authRequest) {
        var _this = this;
        return this.serviceInvoker.invoke('/registration/customer/verify', authRequest).map(function (resp) { return _this.populateCustResp(resp); });
    };
    RegisterService.prototype.verifyOtp = function (authRequest) {
        var _this = this;
        return this.serviceInvoker.invoke('/registration/otp/verify', authRequest).map(function (resp) { return _this.populateOtpResp(resp); });
    };
    RegisterService.prototype.resendOtp = function (authRequest) {
        var _this = this;
        return this.serviceInvoker.invoke('/registration/otp/resend', authRequest).map(function (resp) { return _this.populateResendOtpResp(resp); });
    };
    RegisterService.prototype.registerPwd = function (authRequest) {
        var _this = this;
        var pwdHash = this.encryptionService.generatePwdHash(sessioncontext_1.SessionContext.getInstance().userID, authRequest.pwd);
        authRequest.pwd = pwdHash;
        return this.serviceInvoker.invoke('/registration/pwd/register', authRequest).map(function (resp) { return _this.populatePwdRegisterResp(resp); });
    };
    RegisterService.prototype.populateCustResp = function (resp) {
        console.log("cust resp " + resp);
        var respObj = JSON.parse(resp);
        console.log("res " + respObj.result.status);
        var responseObj = new verifycustomerresponse_1.VerifyCustomerResponse();
        sessioncontext_1.SessionContext.getInstance().userID = respObj.cif;
        responseObj.otpDuration = respObj.otpDuration;
        responseObj.convID = respObj.convID;
        responseObj.cif = respObj.cif;
        responseObj.emailMasked = respObj.emailMasked;
        responseObj.mobileNumberMasked = respObj.mobileNumberMasked;
        responseObj.remainingOtpAttempts = respObj.remainingOtpAttempts;
        return responseObj;
    };
    RegisterService.prototype.populateOtpResp = function (resp) {
        var respObj = JSON.parse(resp);
        console.log("res " + respObj.result.status);
        var responseObj = new verifyotpresponse_1.VerifyOtpResponse();
        console.log("res " + respObj.result.success);
        return responseObj;
    };
    RegisterService.prototype.populatePwdRegisterResp = function (resp) {
        var respObj = JSON.parse(resp);
        console.log("res " + respObj.result.status);
        var responseObj = new registerpwdresponse_1.RegisterPwdResponse();
        console.log("res " + respObj.result.success);
        return responseObj;
    };
    RegisterService.prototype.populateResendOtpResp = function (resp) {
        var respObj = JSON.parse(resp);
        console.log("res " + respObj.result.status);
        var responseObj = new resendotpresponse_1.ResendOtpResponse();
        console.log("res " + respObj.result.success);
        responseObj.result.status = respObj.result.status;
        return responseObj;
    };
    RegisterService = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [http_1.Http, serviceinvoker_service_1.ServiceInvoker, encryption_service_1.EncryptionService])
    ], RegisterService);
    return RegisterService;
}());
exports.RegisterService = RegisterService;
//# sourceMappingURL=register.service.js.map