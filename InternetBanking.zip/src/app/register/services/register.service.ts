import { Injectable } from '@angular/core';
import { Http, Response, Headers , URLSearchParams, RequestOptions} from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';

import {AppSession} from '../../shared/model/appsession';
import {AuthRequest} from '../model/authrequest';
import {VerifyCustomerResponse} from '../model/verifycustomerresponse';
import {RegisterPwdResponse} from '../model/registerpwdresponse';
import {VerifyOtpResponse} from '../model/verifyotpresponse';
import {ResendOtpResponse} from '../model/resendotpresponse';
import {AuthKey} from '../../shared/model/authkey';
import {ServiceInvoker} from '../../shared/connector/serviceinvoker.service';
import {EncryptionService} from '../../shared/services/encryption.service';
import {SessionContext} from '../../shared/model/sessioncontext';




@Injectable()
export class RegisterService {


    constructor(private http: Http, private serviceInvoker: ServiceInvoker,private encryptionService: EncryptionService) { }

    

    registerDevice(authRequest:AuthRequest): Observable<AuthKey>{
        
       return this.serviceInvoker.invoke('/registration/device/register',authRequest).map(resp=>this.populateAuthReq(resp));
    }

    private populateAuthReq(resp:string){
        var authKey = new AuthKey();
        var respObj = JSON.parse(resp)
        authKey.encIV = respObj.data.encIV;
        authKey.encKey = respObj.data.encKey; 
        authKey.convID = respObj.data.convID; 
        authKey.macKey = respObj.data.macKey; 
        authKey.ec = respObj.data.eventCtr; 
        return authKey;
    }

    verifyCustomer(authRequest:AuthRequest): Observable<VerifyCustomerResponse>{
       return this.serviceInvoker.invoke('/registration/customer/verify',authRequest).map(resp=>this.populateCustResp(resp));
    }

    verifyOtp(authRequest:AuthRequest): Observable<VerifyOtpResponse>{
    
       return this.serviceInvoker.invoke('/registration/otp/verify',authRequest).map(resp=>this.populateOtpResp(resp));
    }

    resendOtp(authRequest:AuthRequest): Observable<ResendOtpResponse>{
       return this.serviceInvoker.invoke('/registration/otp/resend',authRequest).map(resp=>this.populateResendOtpResp(resp));
    }

    registerPwd(authRequest:AuthRequest): Observable<RegisterPwdResponse>{
       let pwdHash = this.encryptionService.generatePwdHash(SessionContext.getInstance().userID,authRequest.pwd);
       authRequest.pwd = pwdHash;
       return this.serviceInvoker.invoke('/registration/pwd/register',authRequest).map(resp=>this.populatePwdRegisterResp(resp));
    }



    private populateCustResp(resp:string){
        console.log("cust resp "+resp);
        let respObj = JSON.parse(resp);
        console.log("res "+respObj.result.status);

        let responseObj = new VerifyCustomerResponse();

        SessionContext.getInstance().userID = respObj.cif;
        responseObj.otpDuration = respObj.otpDuration;
        responseObj.convID = respObj.convID;
        responseObj.cif = respObj.cif;
        responseObj.emailMasked = respObj.emailMasked;
        responseObj.mobileNumberMasked = respObj.mobileNumberMasked;
        responseObj.remainingOtpAttempts = respObj.remainingOtpAttempts;
        return responseObj;
    }

    private populateOtpResp(resp:string){
        let respObj = JSON.parse(resp);
        console.log("res "+respObj.result.status);

        var responseObj = new VerifyOtpResponse();
        console.log("res "+respObj.result.success);
        
        return responseObj;
    }
    

    private populatePwdRegisterResp(resp:string){
        var respObj = JSON.parse(resp);
        console.log("res "+respObj.result.status);

        var responseObj = new RegisterPwdResponse();
        console.log("res "+respObj.result.success);
        
        return responseObj;
    }

    private populateResendOtpResp(resp:string){
        var respObj = JSON.parse(resp);
        console.log("res "+respObj.result.status);

        var responseObj = new ResendOtpResponse();
        console.log("res "+respObj.result.success);
        responseObj.result.status = respObj.result.status;
        
        return responseObj;
    }
    

}