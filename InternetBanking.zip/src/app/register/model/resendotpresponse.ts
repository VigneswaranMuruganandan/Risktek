import {APIResponse} from '../../shared/model/apiresponse';
export class ResendOtpResponse extends APIResponse{
	
	remainingOtpAttempts:number;
}