import {APIResponse} from '../../shared/model/apiresponse';
export class VerifyOtpResponse extends APIResponse{
	
	remainingOtpAttempts:number;
}