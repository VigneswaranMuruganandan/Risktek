import {APIResponse} from '../../shared/model/apiresponse';
export class RegisterPwdResponse extends APIResponse{
	
	
}