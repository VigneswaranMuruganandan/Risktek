
import {APIResponse} from '../../shared/model/apiresponse';

export class VerifyCustomerResponse extends APIResponse{
	otpDuration:number;
	convID:string;
	cif:string;
	emailMasked:string;
	mobileNumberMasked:string;
	remainingOtpAttempts:number;
}

