"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var router_1 = require("@angular/router");
var baseView_component_1 = require("../shared/Components/baseView.component");
var dashboard_component_1 = require("./Components/dashboard.component");
var routes = [{
        path: '',
        component: baseView_component_1.BaseViewComponent,
        children: [
            {
                path: 'dashboard',
                component: dashboard_component_1.DashboardComponent
            },
            {
                path: 'accounts',
                loadChildren: 'app/accounts/accounts.module#AccountsModule'
            },
            {
                path: 'offers',
                loadChildren: 'app/offers/offers.module#OffersModule'
            },
            {
                path: 'payments',
                loadChildren: 'app/payments/payments.module#PaymentsModule'
            },
            {
                path: 'accountsettings',
                loadChildren: 'app/accountSettings/accountSettings.module#AccountSettingsModule'
            },
            {
                path: '',
                redirectTo: 'dashboard',
                pathMatch: 'full'
            },
            {
                path: 'contactUs',
                loadChildren: 'app/others/others.module#OthersModule'
            },
            {
                path: 'investments',
                loadChildren: 'app/investments/investments.module#InvestmentsModule'
            },
            {
                path: 'cards',
                loadChildren: 'app/cards/cards.module#CardsModule'
            }
        ]
    }
];
exports.DashboardRouting = router_1.RouterModule.forChild(routes);
//# sourceMappingURL=dashboard.routing.js.map