import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BaseViewComponent }   from '../shared/Components/baseView.component';
import { DashboardComponent} from './Components/dashboard.component';



const routes: Routes = [{
        path: '',
        component: BaseViewComponent,
        children: [
        	{
			    path: 'dashboard',
			    component: DashboardComponent			    
			},
			{
		        path: 'accounts',
		        loadChildren: 'app/accounts/accounts.module#AccountsModule'
		    },
			{
		        path: 'offers',
		        loadChildren: 'app/offers/offers.module#OffersModule'
		    },
		    {
		        path: 'payments',
		        loadChildren: 'app/payments/payments.module#PaymentsModule'
		    },
		    {
		        path: 'accountsettings',
		        loadChildren: 'app/accountSettings/accountSettings.module#AccountSettingsModule'
		    },
			{
			    path: '',
			    redirectTo: 'dashboard',
			    pathMatch: 'full'
			},
			{
		        path: '',
		        loadChildren: 'app/others/others.module#OthersModule'
		    }
        ]
    }
];

export const DashboardRouting: ModuleWithProviders = RouterModule.forChild(routes);