import { Component, Input, OnInit} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {TemplateService} from '../../shared/services/template.service';
import {SharedService} from '../../shared/services/shared.service';
import * as $ from 'jquery';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Component({
  templateUrl: 'app/dashboard/templates/dashboard.html'
})
export class DashboardComponent {
	/*slides = [
	    {caption: "The Piper at the Gates of Dawn"},
	    {caption: "A Saucerful of Secrets"},
	    {caption: "Music from the Film More"},
	    {caption: "Ummagumma"},
	    {caption: "Atom Heart Mother"},
	    {caption: "Meddle"}
	  ];*/

	ngAfterViewInit() {
	   var conf = {
			dots:true,
			appendDots: $('.slick-carousel-dots'),
			dotsClass: 'carousel-dots',
			slidesToShow: 4,
  			slidesToScroll: 4,
			arrows: false,
			responsive: [
				{
					breakpoint: 1500,
					settings: {
						slidesToShow: 3,
						slidesToScroll: 3,
						infinite: true,
						dots: true
					}
				},
				{
					breakpoint: 1100,
					settings: {
						slidesToShow: 2,
						slidesToScroll: 2,
						infinite: true,
						dots: true
					}
				},
				{
					breakpoint: 600,
					settings: {
						slidesToShow: 2,
						slidesToScroll: 2
					}
				},
				{
					breakpoint: 520,
					settings: {
						slidesToShow: 1,
						slidesToScroll: 1
					}
				}
			]
		};
		//$('.slick-carousel').slick(conf);
	}
}