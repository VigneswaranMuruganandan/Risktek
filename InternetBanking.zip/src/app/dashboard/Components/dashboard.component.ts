import { Component, Input, OnInit} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {TemplateService} from '../../shared/services/template.service';
import {SharedService} from '../../shared/services/shared.service';
import * as $ from 'jquery';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Component({
  templateUrl: 'app/dashboard/templates/dashboard.html'
})
export class DashboardComponent implements OnInit {

	constructor(private templateService: TemplateService) {}

	ngOnInit() {
		this.templateService.showHideMenu();
		this.templateService.checkMenuState();
	}
}