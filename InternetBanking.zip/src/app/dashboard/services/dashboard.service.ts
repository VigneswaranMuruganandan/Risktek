import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { GlobalVariable} from '../../shared/services/global';
import { ServiceInvoker} from '../../shared/connector/serviceinvoker.service';
import { EncryptionService} from '../../shared/services/encryption.service';
import { GlobalURL} from '../../shared/services/globalURL';
import { DashBoardDetails } from '../model/DashBoardDetails';



@Injectable()
export class DashBoardService{


  constructor(private serviceInvoker: ServiceInvoker, 
                private encryptionService: EncryptionService){
  }

  fetchDashBoardResults(): Observable < DashBoardDetails > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.REGISTRATION.REGISTERDEVICE,null)
                                  .map(resp => this.populateDashBoardResults(resp));
  }

 

 private populateDashBoardResults(resp: string) {
        var dashBoardDetails = new DashBoardDetails();
        let respObj = JSON.parse(resp);
        console.log("result " + respObj.result.status);
        if (respObj.result.status == 'success') {
             dashBoardDetails.customerProducts = respObj.customerProducts;
             dashBoardDetails.favouriteProducts = respObj.favouriteProducts;
             dashBoardDetails.bulletin= respObj.bulletin;
             dashBoardDetails.user= respObj.user;                   
        }
        return dashBoardDetails;
  }

}

  

