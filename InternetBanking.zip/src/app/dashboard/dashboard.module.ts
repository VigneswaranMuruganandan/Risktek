import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { FormsModule } from '@angular/forms';
import { DashboardRouting } from './dashboard.routing';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '../shared/shared.module';
import { SharedService} from '../shared/services/shared.service';
import { TemplateService} from '../shared/services/template.service';
import { DashboardComponent} from './Components/dashboard.component';

const DASHBOARD_COMPONENTS = [
	DashboardComponent
];

const DASHBOARD_PROVIDERS = [
   SharedService,
   TemplateService
];

@NgModule({
  	imports: [
	    DashboardRouting,
	    TranslateModule.forChild(),
	    SharedModule,
	    FormsModule,
		CommonModule
	],
  	declarations: [
	    ...DASHBOARD_COMPONENTS
	],
  	providers: [
  		...DASHBOARD_PROVIDERS
  	]
})
export class DashboardModule {}
