export class Card{
   	private cardNumber:string;
	private cardHolderName:string;
	private cardType:string;
	private status:string;
	private ownerType:string;
	private cardLimit:string;
	private availableCashWithdrawalLimit:string;
	private availableBalance:string;
	private currentTotalOutstanding:string;
	private outstandingBalance:string;
	private minimumPaymentDue:string;
	private paymentDueDate:string;
	private nextStatementDate:string;
	private firstPoints:string;
	private firstMiles:string;
	private greenPoints:string;
	private greenContributionAmount:string;
	private currency:string;
	private nickName:string;
	private displaySequence:string;
	private isFavorite:string;
}