import {Loan} from './Loan';
import {Account} from './Account';
import {Card} from './Card';

export class CustomerProducts{
    accounts: Account[];
	loans : Loan[];
	cards : Card[];
	deposits:Account[];
}