export class Account{
	productName :string ;
	nickName:string;
	number:string;
	balance:string;
	accountCurrency:string;
	swiftCode:string;
	iban:string;
	holderName:string;
	currentBalance:string;
	blockedAmount:string;
	unclearedAmount:string;
	limitAmount:string;
	overDraftLimit:string;
	accountType:string;
	productType:string;
	branch:string;
	openingDate:string;
	displaySequence:string;
	isFavorite:string;
}