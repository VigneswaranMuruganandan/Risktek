"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var UserDetails = (function () {
    function UserDetails() {
    }
    return UserDetails;
}());
exports.UserDetails = UserDetails;
//# sourceMappingURL=UserDetails.js.map