import { APIResponse } from '../../shared/model/apiresponse';
import { CustomerProducts } from './CustomerProducts';
import { UserDetails } from './UserDetails';

export class DashBoardDetails  extends APIResponse{
    favouriteProducts:CustomerProducts;
	customerProducts:CustomerProducts;
	bulletin:String[];
	user:UserDetails;	
}