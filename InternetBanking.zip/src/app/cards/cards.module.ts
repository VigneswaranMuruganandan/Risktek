import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { FormsModule } from '@angular/forms';
import { routing } from './cards.routing';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '../shared/shared.module';
import {SharedService} from '../shared/services/shared.service';
import {TemplateService} from '../shared/services/template.service';
import { CardsComponent }   from './Components/cards.component';

import { CreditCardPinResetComponent }   from './Components/creditCardPinReset.component';
import { DebitCardPinResetComponent }   from './Components/debitCardPinReset.component';
import { ActivateDebitCardComponent }   from './Components/activateDebitCard.component';
import { ActivateDebitCardStep1Component }   from './Components/activateDebitCardStep1.component';
import { ActivateDebitCardStep2Component }   from './Components/activateDebitCardStep2.component';
import { ActivateDebitCardStep3Component }   from './Components/activateDebitCardStep3.component';
import { ActivateDebitCardStep4Component }   from './Components/activateDebitCardStep4.component';
import { ActivateDebitCardStep5Component }   from './Components/activateDebitCardStep5.component';


const CARDS_COMPONENTS = [
    CardsComponent,
    CreditCardPinResetComponent,
    DebitCardPinResetComponent,
    ActivateDebitCardComponent,
    ActivateDebitCardStep1Component,
    ActivateDebitCardStep2Component,
    ActivateDebitCardStep3Component,
    ActivateDebitCardStep4Component,
    ActivateDebitCardStep5Component,
];

const CARDS_DIRECTIVES = [
];

const CARDS_PROVIDERS = [
   SharedService,
   TemplateService
];

@NgModule({
  	imports: [
	    routing,
	    TranslateModule.forChild(),
	    SharedModule,
	    FormsModule,
      	CommonModule
	],
  	declarations: [
	  	...CARDS_COMPONENTS/*,
      	...CARDS_DIRECTIVES*/
	],
	providers: [
		...CARDS_PROVIDERS
	]
})
export class CardsModule {}
