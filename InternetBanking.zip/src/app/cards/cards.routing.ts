import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CardsComponent } from './Components/cards.component';
import { CreditCardPinResetComponent }   from './Components/creditCardPinReset.component';
import { DebitCardPinResetComponent }   from './Components/debitCardPinReset.component';
import { ActivateDebitCardComponent }   from './Components/activateDebitCard.component';
import { DebitCardsMainComponent }   from './Components/debitCardsMain.component';



const routes: Routes = [
    {
        path: '',
        component: DebitCardsMainComponent
    },
    {
        path: 'creditCardPinReset',
        component: CreditCardPinResetComponent
    },
    {
        path: 'debitCardPinReset',
        component: DebitCardPinResetComponent
    },
    {
        path: 'activateDebitCard',
        component: ActivateDebitCardComponent
    },
    {
        path: '',
        redirectTo: '',
        pathMatch: 'full'
    }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
