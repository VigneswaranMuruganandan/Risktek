import { Component, OnInit, Input} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Component({
  templateUrl: '../../templates/activateDebitCard.html'
})
export class ActivateDebitCardComponent implements OnInit{
	public stepNumber: number;
	
	
	ngOnInit() { 
    	this.stepNumber = 2;
    }

    validateDebitCardActivation(){
    	this.stepNumber = 2;
    	console.log("begin debit card activitation process");
    }

    validateOTPDebitCardActivation(){
        
    }
	
}