"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var template_service_1 = require("../../shared/services/template.service");
require("rxjs/add/operator/catch");
require("rxjs/add/operator/map");
var ActivateDebitCardStep2Component = (function () {
    function ActivateDebitCardStep2Component(templateService) {
        this.templateService = templateService;
        this.validateOTPDebitCardActivationEvent = new core_1.EventEmitter();
    }
    ActivateDebitCardStep2Component.prototype.validateOTP = function () {
        this.validateOTPDebitCardActivationEvent.emit();
    };
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], ActivateDebitCardStep2Component.prototype, "validateOTPDebitCardActivationEvent", void 0);
    ActivateDebitCardStep2Component = __decorate([
        core_1.Component({
            selector: 'activateDebitCardStep2-component',
            templateUrl: '../../templates/activateDebitCardStep2.html'
        }),
        __metadata("design:paramtypes", [template_service_1.TemplateService])
    ], ActivateDebitCardStep2Component);
    return ActivateDebitCardStep2Component;
}());
exports.ActivateDebitCardStep2Component = ActivateDebitCardStep2Component;
//# sourceMappingURL=activateDebitCardStep2.component.js.map