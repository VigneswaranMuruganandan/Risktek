import { Component, OnInit, Input} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {TemplateService} from '../../shared/services/template.service';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Component({
  selector: 'activateDebitCardStep4-component',
  templateUrl: '../../templates/activateDebitCardStep4.html'
})
export class ActivateDebitCardStep4Component{
	
	constructor(private templateService: TemplateService) {}	
}