import { Component, OnInit, Input,EventEmitter,Output} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {TemplateService} from '../../shared/services/template.service';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Component({
  selector: 'activateDebitCardStep4-component',
  templateUrl: 'app/cards/templates/activateDebitCardStep4.html'
})
export class ActivateDebitCardStep4Component{
	@Output() validateConfirmPinDebitCardEvent = new EventEmitter();
	constructor(private templateService: TemplateService) {}	

	validateConfirmPin(event:any){
		this.validateConfirmPinDebitCardEvent.emit();
	}
	
}