import { Component, OnInit, Input} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  templateUrl: 'app/cards/templates/debitCardsMain.html'
})
export class DebitCardsMainComponent{
	
	
	
}