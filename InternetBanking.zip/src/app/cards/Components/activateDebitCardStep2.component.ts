import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {TemplateService} from '../../shared/services/template.service';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Component({
  selector: 'activateDebitCardStep2-component',
  templateUrl: 'app/cards/templates/activateDebitCardStep2.html'
})
export class ActivateDebitCardStep2Component{
	@Output() validateOTPDebitCardActivationEvent = new EventEmitter();
	constructor(private templateService: TemplateService) {}

	validateOTP(event:any){
		this.validateOTPDebitCardActivationEvent.emit();
	}
	
}