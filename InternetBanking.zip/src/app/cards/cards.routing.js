"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var router_1 = require("@angular/router");
var cards_component_1 = require("./Components/cards.component");
var creditCardPinReset_component_1 = require("./Components/creditCardPinReset.component");
var debitCardPinReset_component_1 = require("./Components/debitCardPinReset.component");
var activateDebitCard_component_1 = require("./Components/activateDebitCard.component");
var routes = [
    {
        path: 'cards',
        component: cards_component_1.CardsComponent
    },
    {
        path: 'creditCardPinReset',
        component: creditCardPinReset_component_1.CreditCardPinResetComponent
    },
    {
        path: 'debitCardPinReset',
        component: debitCardPinReset_component_1.DebitCardPinResetComponent
    },
    {
        path: 'activateDebitCard',
        component: activateDebitCard_component_1.ActivateDebitCardComponent
    },
    {
        path: 'cards',
        redirectTo: '',
        pathMatch: 'full'
    }
];
exports.routing = router_1.RouterModule.forChild(routes);
//# sourceMappingURL=cards.routing.js.map