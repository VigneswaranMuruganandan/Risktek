"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var router_1 = require("@angular/router");
var creditCardPinReset_component_1 = require("./Components/creditCardPinReset.component");
var debitCardPinReset_component_1 = require("./Components/debitCardPinReset.component");
var activateDebitCard_component_1 = require("./Components/activateDebitCard.component");
var debitCardsMain_component_1 = require("./Components/debitCardsMain.component");
var routes = [
    {
        path: '',
        component: debitCardsMain_component_1.DebitCardsMainComponent
    },
    {
        path: 'creditCardPinReset',
        component: creditCardPinReset_component_1.CreditCardPinResetComponent
    },
    {
        path: 'debitCardPinReset',
        component: debitCardPinReset_component_1.DebitCardPinResetComponent
    },
    {
        path: 'activateDebitCard',
        component: activateDebitCard_component_1.ActivateDebitCardComponent
    },
    {
        path: '',
        redirectTo: '',
        pathMatch: 'full'
    }
];
exports.routing = router_1.RouterModule.forChild(routes);
//# sourceMappingURL=cards.routing.js.map