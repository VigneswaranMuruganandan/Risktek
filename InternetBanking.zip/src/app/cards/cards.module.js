"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var common_1 = require("@angular/common");
var forms_1 = require("@angular/forms");
var cards_routing_1 = require("./cards.routing");
var core_2 = require("@ngx-translate/core");
var shared_module_1 = require("../shared/shared.module");
var shared_service_1 = require("../shared/services/shared.service");
var template_service_1 = require("../shared/services/template.service");
var cards_component_1 = require("./Components/cards.component");
var creditCardPinReset_component_1 = require("./Components/creditCardPinReset.component");
var debitCardPinReset_component_1 = require("./Components/debitCardPinReset.component");
var activateDebitCard_component_1 = require("./Components/activateDebitCard.component");
var activateDebitCardStep1_component_1 = require("./Components/activateDebitCardStep1.component");
var activateDebitCardStep2_component_1 = require("./Components/activateDebitCardStep2.component");
var activateDebitCardStep3_component_1 = require("./Components/activateDebitCardStep3.component");
var activateDebitCardStep4_component_1 = require("./Components/activateDebitCardStep4.component");
var activateDebitCardStep5_component_1 = require("./Components/activateDebitCardStep5.component");
var CARDS_COMPONENTS = [
    cards_component_1.CardsComponent,
    creditCardPinReset_component_1.CreditCardPinResetComponent,
    debitCardPinReset_component_1.DebitCardPinResetComponent,
    activateDebitCard_component_1.ActivateDebitCardComponent,
    activateDebitCardStep1_component_1.ActivateDebitCardStep1Component,
    activateDebitCardStep2_component_1.ActivateDebitCardStep2Component,
    activateDebitCardStep3_component_1.ActivateDebitCardStep3Component,
    activateDebitCardStep4_component_1.ActivateDebitCardStep4Component,
    activateDebitCardStep5_component_1.ActivateDebitCardStep5Component,
];
var CARDS_DIRECTIVES = [];
var CARDS_PROVIDERS = [
    shared_service_1.SharedService,
    template_service_1.TemplateService
];
var CardsModule = (function () {
    function CardsModule() {
    }
    CardsModule = __decorate([
        core_1.NgModule({
            imports: [
                cards_routing_1.routing,
                core_2.TranslateModule.forChild(),
                shared_module_1.SharedModule,
                forms_1.FormsModule,
                common_1.CommonModule
            ],
            declarations: CARDS_COMPONENTS /*,
            ...CARDS_DIRECTIVES*/.slice(),
            providers: CARDS_PROVIDERS.slice()
        })
    ], CardsModule);
    return CardsModule;
}());
exports.CardsModule = CardsModule;
//# sourceMappingURL=cards.module.js.map