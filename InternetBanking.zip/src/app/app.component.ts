import { Component, OnInit, ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule }  from '@angular/router';
import {TranslateService} from '@ngx-translate/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';



@Component({
  selector: 'my-app',
  template: `
    <router-outlet></router-outlet>
  `,
  providers: []
})
export class AppComponent implements OnInit {
    public persons: any;
    constructor(private translate: TranslateService) {
        translate.addLangs(["en", "ar"]);
        translate.setDefaultLang('ar');
        let browserLang = translate.getBrowserLang();
        translate.use(browserLang.match(/en|ar/) ? browserLang : 'en');
    }
    userlanguageChange(){
        let currentLang = this.translate.currentLang;        
    }
    onChange(file: string) {
        //document.getElementById("globalTheme").setAttribute("href", 'app/assets/css/source/main-' + file + '.css');
    }
    ngOnInit() {
        //document.getElementById("globalTheme").setAttribute("href", 'app/assets/css/source/main-en.css');
    }
}