import { NgModule }      from '@angular/core';
import { CommonModule, DecimalPipe } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { Routes, RouterModule }  from '@angular/router';
import { ReactiveFormsModule, FormsModule,FormGroup, FormControl, Validators, FormBuilder} from '@angular/forms';
import { routing } from './app.routes';
import { AppComponent }  from './app.component';
import {SharedService} from './shared/services/shared.service';
import { CustomHttp } from './shared/services/customhttp';
import { AppRequestOptions } from './app.request.options';
import { AuthGuard } from './auth-guard.service';


import {TranslateModule, TranslateLoader} from "@ngx-translate/core";
import {TranslateHttpLoader} from "@ngx-translate/http-loader";
import { HttpModule, Http, RequestOptions, XHRBackend } from '@angular/http';
import * as $ from 'jquery';



export function HttpLoaderFactory(http: Http) {
    return new TranslateHttpLoader(http, "/i18n/", ".json");
}

@NgModule({
    imports: [
		BrowserModule, 
		HttpModule, 
		routing, 
		TranslateModule.forRoot({
			loader: {
				provide: TranslateLoader,
				useFactory: HttpLoaderFactory,
				deps: [Http]
			}
		}), 
		FormsModule
	],
    declarations: [AppComponent],
    providers: [SharedService, DecimalPipe, AuthGuard,
	    {
	      provide: Http,
	      useFactory: (backend: XHRBackend, defaultOptions: RequestOptions) => {
	        return new CustomHttp(backend, defaultOptions);
	      },
	      deps: [ XHRBackend, RequestOptions ]
	    },
	    {
	      provide: RequestOptions, useClass: AppRequestOptions
	    }
    ],
    bootstrap: [AppComponent]
})
export class AppModule {}
