import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import {GlobalVariable} from '../../shared/services/global';

@Injectable()
export class LoginService{
  private baseUrl: string = 'stubs/';

  constructor(private http : Http){
  }

  verifyAccessToken(): Observable<any>{
    return this.http
      .get(`${this.baseUrl}`+GlobalVariable.URL_MAPPING.ACCOUNT.VERIFY_ACCESS_TOKEN, {headers: this.getHeaders()})
     .map((response: Response) => <any>response.json())
            .catch(this.handleError);      
  }
  
 

  private getHeaders(){
    let headers = new Headers();
    headers.append('Accept', 'application/json');
    return headers;
  }
  private handleError(error: Response) {
        console.error(error);
        return Observable.throw(error.json().error || 'Server error');
  }
}


