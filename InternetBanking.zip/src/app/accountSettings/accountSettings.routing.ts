import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AccountSettingsComponent } from './Components/accountSettings.component';



const routes: Routes = [
    {
        path: '',
        component: AccountSettingsComponent
    },
    {
        path: '',
        redirectTo: '',
        pathMatch: 'full'
    }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
