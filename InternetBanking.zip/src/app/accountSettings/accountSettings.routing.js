"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var router_1 = require("@angular/router");
var accountSettings_component_1 = require("./Components/accountSettings.component");
var routes = [
    {
        path: '',
        component: accountSettings_component_1.AccountSettingsComponent
    },
    {
        path: '',
        redirectTo: '',
        pathMatch: 'full'
    }
];
exports.routing = router_1.RouterModule.forChild(routes);
//# sourceMappingURL=accountSettings.routing.js.map