import { Component, OnInit, Input} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Component({
  selector: 'personalinformation-component',
  templateUrl: 'app/accountSettings/templates/personalInformation.html'
})
export class PersonalInformationComponent {

}