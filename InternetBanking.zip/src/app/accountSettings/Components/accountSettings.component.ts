import { Component, OnInit, Input} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Component({
  templateUrl: 'app/accountSettings/templates/accountSettings.html'
})
export class AccountSettingsComponent {
	
}