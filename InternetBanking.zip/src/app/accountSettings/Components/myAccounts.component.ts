import { Component, OnInit, Input} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Component({
  selector: 'myaccounts-component',
  templateUrl: 'app/accountSettings/templates/myAccounts.html'
})
export class MyAccountsComponent {

}