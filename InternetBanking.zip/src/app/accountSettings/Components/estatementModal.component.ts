import { Component, OnInit, Input} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Component({
  selector: 'estatementmodal-component',
  templateUrl: 'app/accountSettings/templates/estatementModal.html'
})
export class EStatementModalComponent {

}