import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { WealthComponent } from './Components/wealth.component';



const routes: Routes = [
    {
        path: 'wealth',
        component: WealthComponent
    },
    {
        path: 'wealth',
        redirectTo: '',
        pathMatch: 'full'
    }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
