export class User{
	userId: any;
    password: any;
}