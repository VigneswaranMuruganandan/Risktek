"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var common_1 = require("@angular/common");
var investments_routing_1 = require("./investments.routing");
var core_2 = require("@ngx-translate/core");
var shared_module_1 = require("../shared/shared.module");
var shared_service_1 = require("../shared/services/shared.service");
var template_service_1 = require("../shared/services/template.service");
var forms_1 = require("@angular/forms");
var wealth_component_1 = require("./Components/wealth.component");
var wealthform_component_1 = require("./Components/wealthform.component");
var applyProduct_component_1 = require("./Components/applyProduct.component");
var applyProductStep1_component_1 = require("./Components/applyProductStep1.component");
var applyProductStep2_component_1 = require("./Components/applyProductStep2.component");
var applyProductStep3_component_1 = require("./Components/applyProductStep3.component");
var validateInvestments_directive_1 = require("./directives/validateInvestments.directive");
var INVESTMENT_COMPONENTS = [
    wealth_component_1.WealthComponent,
    wealthform_component_1.WealthFormComponent,
    applyProduct_component_1.ApplyProductComponent,
    applyProductStep1_component_1.ApplyProductStep1Component,
    applyProductStep2_component_1.ApplyProductStep2Component,
    applyProductStep3_component_1.ApplyProductStep3Component,
    validateInvestments_directive_1.ValidateApplyProductsSelection
];
var INVESTMENT_PROVIDERS = [
    shared_service_1.SharedService,
    template_service_1.TemplateService
];
var InvestmentsModule = (function () {
    function InvestmentsModule() {
    }
    InvestmentsModule = __decorate([
        core_1.NgModule({
            imports: [
                investments_routing_1.routing,
                core_2.TranslateModule.forChild(),
                shared_module_1.SharedModule,
                forms_1.FormsModule,
                common_1.CommonModule
            ],
            declarations: INVESTMENT_COMPONENTS.slice(),
            providers: INVESTMENT_PROVIDERS.slice()
        })
    ], InvestmentsModule);
    return InvestmentsModule;
}());
exports.InvestmentsModule = InvestmentsModule;
//# sourceMappingURL=investments.module.js.map