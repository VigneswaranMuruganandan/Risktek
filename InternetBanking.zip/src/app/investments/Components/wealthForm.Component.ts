import { Component, ViewChild  } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { FormsModule} from '@angular/forms';

@Component({
  selector: 'wealthform-component',
  templateUrl: 'app/investments/templates/wealthform.html'
})
export class WealthFormComponent {
	
    

}