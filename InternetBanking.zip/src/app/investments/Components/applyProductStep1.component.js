"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var template_service_1 = require("../../shared/services/template.service");
var ApplyProductStep1Component = (function () {
    function ApplyProductStep1Component(templateService) {
        this.templateService = templateService;
        this.applyProductNextEvent = new core_1.EventEmitter();
        this.productsSelected = [];
    }
    ApplyProductStep1Component.prototype.onChange = function (value, checked) {
        if (checked) {
            this.productsSelected.push(value);
        }
        else {
            var index = this.productsSelected.findIndex(function (x) { return x.value == value; });
            this.productsSelected.splice(index);
        }
    };
    ApplyProductStep1Component.prototype.applyProductNext = function (valid) {
        console.log(this.products);
        if (valid) {
            console.log(this.productsSelected);
            this.applyProductNextEvent.emit();
            this.templateService.resetFromValidatorFlag();
        }
    };
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], ApplyProductStep1Component.prototype, "applyProductNextEvent", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", Array)
    ], ApplyProductStep1Component.prototype, "productsSelected", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", Array)
    ], ApplyProductStep1Component.prototype, "products", void 0);
    ApplyProductStep1Component = __decorate([
        core_1.Component({
            selector: 'applyproductstep1-component',
            templateUrl: 'app/investments/templates/applyProductStep1.html'
        }),
        __metadata("design:paramtypes", [template_service_1.TemplateService])
    ], ApplyProductStep1Component);
    return ApplyProductStep1Component;
}());
exports.ApplyProductStep1Component = ApplyProductStep1Component;
//# sourceMappingURL=applyProductStep1.component.js.map