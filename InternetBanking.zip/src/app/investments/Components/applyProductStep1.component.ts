import { Component, OnInit, Input,EventEmitter,Output} from '@angular/core';
import {TemplateService} from '../../shared/services/template.service';
import * as $ from 'jquery';

@Component({
  selector: 'applyproductstep1-component',
  templateUrl: 'app/investments/templates/applyProductStep1.html'
})
export class ApplyProductStep1Component {

	constructor(private templateService: TemplateService) {}
	@Output() applyProductNextEvent = new EventEmitter();
	@Input() productsSelected:Array<any>=[];
	@Input() products:Array<any>;

	onChange(value:string,checked:boolean){
	    if(checked){
	      this.productsSelected.push(value);
	      
	    }else{
	      let index = this.productsSelected.findIndex(x => x.value == value);
	      this.productsSelected.splice(index);
	    }
  	}

	applyProductNext(valid:boolean){
		console.log(this.products)
		if(valid){
			console.log(this.productsSelected);
			this.applyProductNextEvent.emit();
			this.templateService.resetFromValidatorFlag();
		}
	}
}