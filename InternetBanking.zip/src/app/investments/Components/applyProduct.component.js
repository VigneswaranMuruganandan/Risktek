"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var ApplyProductComponent = (function () {
    function ApplyProductComponent() {
        this.productsSelected = [];
        this.products = [{ caption: "Mutual Fund", value: "Mutual Fund" },
            { caption: "Exchange Traded Funds", value: "Exchange Traded Funds" },
            { caption: "Systematic Investment Plan", value: "Systematic Investment Plan" },
            { caption: "Fixed Income", value: "Fixed Income" },
            { caption: "Structured Notes", value: "Structured Notes" },
            { caption: "Dual Currency Investments", value: "Dual Currency Investments" },
            { caption: "Others", value: "Others" }];
    }
    ApplyProductComponent.prototype.ngOnInit = function () {
        this.stepFlag = 1;
    };
    ApplyProductComponent.prototype.applyProductSelectionSubmit = function () {
        this.stepFlag = 2;
    };
    ApplyProductComponent.prototype.applyProductsNowSubmit = function () {
        this.stepFlag = 3;
    };
    ApplyProductComponent = __decorate([
        core_1.Component({
            templateUrl: 'app/investments/templates/applyProduct.html'
        })
    ], ApplyProductComponent);
    return ApplyProductComponent;
}());
exports.ApplyProductComponent = ApplyProductComponent;
//# sourceMappingURL=applyProduct.component.js.map