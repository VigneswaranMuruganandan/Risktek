"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var router_1 = require("@angular/router");
var applyProduct_component_1 = require("./Components/applyProduct.component");
var routes = [
    {
        path: '',
        component: applyProduct_component_1.ApplyProductComponent
    },
    {
        path: '',
        redirectTo: '',
        pathMatch: 'full'
    }
];
exports.routing = router_1.RouterModule.forChild(routes);
//# sourceMappingURL=investments.routing.js.map