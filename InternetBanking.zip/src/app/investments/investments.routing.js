"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var router_1 = require("@angular/router");
var wealth_component_1 = require("./Components/wealth.component");
var routes = [
    {
        path: 'wealth',
        component: wealth_component_1.WealthComponent
    },
    {
        path: 'wealth',
        redirectTo: '',
        pathMatch: 'full'
    }
];
exports.routing = router_1.RouterModule.forChild(routes);
//# sourceMappingURL=investments.routing.js.map