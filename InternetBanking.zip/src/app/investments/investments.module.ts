import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { routing } from './investments.routing';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '../shared/shared.module';
import {SharedService} from '../shared/services/shared.service';
import {TemplateService} from '../shared/services/template.service';
import { FormsModule } from '@angular/forms';
import { WealthComponent }   from './Components/wealth.component';
import { WealthFormComponent }   from './Components/wealthform.component';


const INVESTMENT_COMPONENTS = [
    WealthComponent,
    WealthFormComponent
];

const INVESTMENT_PROVIDERS = [
   SharedService,
   TemplateService
];

@NgModule({
  	imports: [
	    routing,
	    TranslateModule.forChild(),
	    SharedModule,
	    FormsModule,
      CommonModule
	],
  	declarations: [
	    ...INVESTMENT_COMPONENTS
	],
  	providers: [
  		...INVESTMENT_PROVIDERS
  	]
})
export class InvestmentsModule {}
