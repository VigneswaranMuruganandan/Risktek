"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var common_1 = require("@angular/common");
var platform_browser_1 = require("@angular/platform-browser");
var forms_1 = require("@angular/forms");
var app_routes_1 = require("./app.routes");
var app_component_1 = require("./app.component");
var shared_service_1 = require("./shared/services/shared.service");
var customhttp_1 = require("./shared/services/customhttp");
var app_request_options_1 = require("./app.request.options");
var auth_guard_service_1 = require("./auth-guard.service");
var core_2 = require("@ngx-translate/core");
var http_loader_1 = require("@ngx-translate/http-loader");
var http_1 = require("@angular/http");
function HttpLoaderFactory(http) {
    return new http_loader_1.TranslateHttpLoader(http, "/i18n/", ".json");
}
exports.HttpLoaderFactory = HttpLoaderFactory;
var AppModule = (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        core_1.NgModule({
            imports: [
                platform_browser_1.BrowserModule,
                http_1.HttpModule,
                app_routes_1.routing,
                core_2.TranslateModule.forRoot({
                    loader: {
                        provide: core_2.TranslateLoader,
                        useFactory: HttpLoaderFactory,
                        deps: [http_1.Http]
                    }
                }),
                forms_1.FormsModule
            ],
            declarations: [app_component_1.AppComponent],
            providers: [shared_service_1.SharedService, common_1.DecimalPipe, auth_guard_service_1.AuthGuard,
                {
                    provide: http_1.Http,
                    useFactory: function (backend, defaultOptions) {
                        return new customhttp_1.CustomHttp(backend, defaultOptions);
                    },
                    deps: [http_1.XHRBackend, http_1.RequestOptions]
                },
                {
                    provide: http_1.RequestOptions, useClass: app_request_options_1.AppRequestOptions
                }
            ],
            bootstrap: [app_component_1.AppComponent]
        })
    ], AppModule);
    return AppModule;
}());
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map