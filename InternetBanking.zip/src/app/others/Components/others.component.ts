import { Component, OnInit, Input} from '@angular/core';

@Component({
  templateUrl: 'app/others/templates/others.html'
})
export class OthersComponent {
	

}