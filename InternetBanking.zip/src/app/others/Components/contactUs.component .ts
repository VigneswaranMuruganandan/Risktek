import { Component, OnInit, Input} from '@angular/core';

@Component({
  templateUrl: 'app/others/templates/contactUs.html'
})
export class ContactUsComponent {
	
}