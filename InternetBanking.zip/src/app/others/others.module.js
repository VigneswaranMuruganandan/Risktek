"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var common_1 = require("@angular/common");
var others_routing_1 = require("./others.routing");
var core_2 = require("@ngx-translate/core");
var shared_module_1 = require("../shared/shared.module");
var shared_service_1 = require("../shared/services/shared.service");
var template_service_1 = require("../shared/services/template.service");
var others_service_1 = require("./services/others.service");
var forms_1 = require("@angular/forms");
var others_component_1 = require("./Components/others.component");
var contactUs_component_1 = require("./Components/contactUs.component");
var OTHERS_COMPONENTS = [
    others_component_1.OthersComponent,
    contactUs_component_1.ContactUsComponent
];
var OTHERS_PROVIDERS = [
    shared_service_1.SharedService,
    template_service_1.TemplateService,
    others_service_1.OthersService
];
var OthersModule = (function () {
    function OthersModule() {
    }
    OthersModule = __decorate([
        core_1.NgModule({
            imports: [
                others_routing_1.routing,
                core_2.TranslateModule.forChild(),
                shared_module_1.SharedModule,
                forms_1.FormsModule,
                common_1.CommonModule
            ],
            declarations: OTHERS_COMPONENTS.slice(),
            providers: OTHERS_PROVIDERS.slice()
        })
    ], OthersModule);
    return OthersModule;
}());
exports.OthersModule = OthersModule;
//# sourceMappingURL=others.module.js.map