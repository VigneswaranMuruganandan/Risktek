import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OthersComponent } from './Components/others.component';
import { ContactUsComponent } from './Components/contactUs.component';

const routes: Routes = [
	{
        path: 'others',
        component: OthersComponent
    },
    {
    	path: 'contactUs',
        component: ContactUsComponent
    },
    {
	    path: 'others',
	    redirectTo: '',
	    pathMatch: 'full'
	}
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);