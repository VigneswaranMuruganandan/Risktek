"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var router_1 = require("@angular/router");
var others_component_1 = require("./Components/others.component");
var contactUs_component_1 = require("./Components/contactUs.component");
var routes = [
    {
        path: 'others',
        component: others_component_1.OthersComponent
    },
    {
        path: 'contactUs',
        component: contactUs_component_1.ContactUsComponent
    },
    {
        path: 'others',
        redirectTo: '',
        pathMatch: 'full'
    }
];
exports.routing = router_1.RouterModule.forChild(routes);
//# sourceMappingURL=others.routing.js.map