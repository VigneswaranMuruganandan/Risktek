import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'forgotpasswordstep4-component',
  templateUrl: 'app/forgotPassword/templates/forgotPasswordStep4.html'
})
export class ForgotPasswordStep4Component implements OnInit{
	public showConfirmPassword: boolean;
	@Input() validPasswordFlag: boolean;
	@Output() validateForgotNewPasswordEvent = new EventEmitter();


	passwordValidations(){
		this.validPasswordFlag = true;
	}

	ngOnInit() {
		this.showConfirmPassword = false;
	}

	validatePassword(){
		this.showConfirmPassword=true;
	}
	validateConfirmPassword(){
		this.validateForgotNewPasswordEvent.emit();
	}
}