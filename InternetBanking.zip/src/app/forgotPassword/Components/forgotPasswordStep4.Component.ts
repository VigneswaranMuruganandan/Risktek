import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { CustomerData } from '../../register/model/customerData';
import {TemplateService} from '../../shared/services/template.service';

@Component({
  selector: 'forgotpasswordstep4-component',
  templateUrl: 'app/forgotPassword/templates/forgotPasswordStep4.html'
})
export class ForgotPasswordStep4Component implements OnInit{
	public showConfirmPassword: boolean;
	@Input() validPasswordFlag: boolean;
	@Output() validateForgotNewPasswordEvent = new EventEmitter();
	@Input() customerData: CustomerData;
	public passwordData : any;

	constructor(private templateService: TemplateService) {}

	ngOnInit() {
		this.passwordData = {"password":"","confirmPassword":""};
		this.showConfirmPassword = false;
	}

	passwordValidations(){
		this.validPasswordFlag = true;
	}

	validatePassword(){
		this.showConfirmPassword=true;
	}

	validateConfirmPassword(valid: boolean){
		if(valid){
			this.templateService.resetFromValidatorFlag();
			this.validateForgotNewPasswordEvent.emit(this.passwordData.password);
		}
	}
}