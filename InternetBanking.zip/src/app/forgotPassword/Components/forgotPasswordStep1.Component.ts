import { Component, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {TemplateService} from '../../shared/services/template.service';

@Component({
  selector: 'forgotpasswordstep1-component',
  templateUrl: 'app/forgotPassword/templates/forgotPasswordStep1.html'
})
export class ForgotPasswordStep1Component {
	@Output() validateCustomerIdentificationForgotPwdEvent = new EventEmitter();

	private customerID:string;

	constructor(private templateService: TemplateService) {}

	validateCustomer(valid: boolean){
		console.log(" customerID:" + this.customerID);
		if(valid){
			this.templateService.resetFromValidatorFlag();
			this.validateCustomerIdentificationForgotPwdEvent.emit(this.customerID);	
		}
	}
}