import { Component, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'forgotpasswordstep1-component',
  templateUrl: 'app/forgotPassword/templates/forgotPasswordStep1.html'
})
export class ForgotPasswordStep1Component {
	@Output() validateCustomerIdentificationEvent = new EventEmitter();

	validateCustomer(){
		this.validateCustomerIdentificationEvent.emit();
	}
}