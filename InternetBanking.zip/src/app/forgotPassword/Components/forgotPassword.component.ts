import { Component, OnInit, Input} from '@angular/core';

@Component({
  templateUrl: 'app/forgotPassword/templates/forgotPassword.html'
})
export class ForgotPasswordComponent implements OnInit{
	
	public stepFlag: number;
	public validUsername:boolean;
	public validPassword:boolean;

	ngOnInit() { 
    	this.stepFlag = 1;
    	this.validUsername = false;
    }


    validateCustomerIdentification(){
    	this.stepFlag = 2;
    	console.log("validated customer identification");
    }

    validateForgotPwdOTP(){
    	this.stepFlag = 3;
    	console.log("validated OTP");
    }

    validateForgotPwdUsername(){
    	this.stepFlag = 4;
    	console.log("validated Username");
    }

    validateForgotNewPassword(){
    	this.stepFlag = 5;
    }

    /*validateForgotConfirmPassword(){
    	
    }*/

    SaveForgotPassword(){
        console.log("redirect to dashboard");
    }

}