import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerData } from '../../register/model/customerData';
import { SharedService } from '../../shared/services/shared.service';
import { ForgotPasswordService } from '../services/forgotPassword.service';
import {AuthKey} from '../../shared/model/authkey';
import {AuthData} from '../../shared/model/authdata';
import { ForgotPassword} from '../model/forgotPassword';
import {VerifyCustomerResponse} from '../../register/model/verifycustomerresponse';
import {VerifyOtpResponse} from '../../shared/model/verifyotpresponse';

@Component({
  templateUrl: 'app/forgotPassword/templates/forgotPassword.html'
})
export class ForgotPasswordComponent implements OnInit{
	
	public stepValue: number;
	public validUsername:boolean;
	public validPassword:boolean;
    public customerData: CustomerData;

    constructor( private forgotPasswordService: ForgotPasswordService, 
                 private sharedService: SharedService,
                 private router: Router) {}

	ngOnInit() { 
    	this.stepValue = 1;
    	this.validUsername = false;
        this.customerData = new CustomerData();
    }

    /*
    * step 1:
    */
    validateCustomerIdentificationForgotPwd(customerID: string){
        this.customerData.customerID = customerID;
        let registerDeviceData = this.sharedService.setupAuthKeys();
        console.log("Register Device Data ::"+registerDeviceData);
        if(registerDeviceData && registerDeviceData.deviceID !=''){
            this.sharedService.registerDevice(registerDeviceData)
                .subscribe(
                    resp => this.handleRegisterDeviceDataResp(resp),
                    error => this.sharedService.handleError(error)
                );
        }
    }

    /*
    * Step 2: Verify the customer ID to get the CIF number
    */
    private handleRegisterDeviceDataResp(resp: AuthData){
        if(resp.authKey.convID != ''){
            console.log("validating customer identification " + this.customerData.customerID);
            let data = new ForgotPassword();
            data.customerID = this.customerData.customerID;
            this.forgotPasswordService.verifyCustomer(data)
                .subscribe(
                    resp => this.handleVerifyCustIDResp(resp),
                    error => this.sharedService.handleError(error)
                );
        }
    }

    /*
    * Handle the Response of Verify Customer ID
    * to get Mobile number and email and move to OTP Page
    */
    private handleVerifyCustIDResp(resp: VerifyCustomerResponse) {
        console.log('handleVerifyCustIDResp ' + resp);
        this.stepValue = 2;
        this.customerData.mobileNumber = resp.mobileNumberMasked;
        this.customerData.emailID = resp.emailMasked;
    }

    validateForgotPwdOTP(otp: string){
    	console.log("validating OTP " + otp);
        let data = new ForgotPassword();
        data.otp = otp;
        this.forgotPasswordService.verifyOtp(data)
            .subscribe(
                resp => this.handleVerifyOtpResp(resp),
                error => this.sharedService.handleError(error)
            );
    }

    /*
    * Handle the Verify OTP Response
    */
    private handleVerifyOtpResp(resp: any) {
        console.log('handleVerifyOtpResp ' + resp);
        this.customerData.name = resp.userName;
        this.stepValue = 3;
    }

    /*
    * Handle the Username
    */
    validateForgotPwdUsername(userName: string){
        this.customerData.userName = userName;
    	this.stepValue = 4;
    }

    /*
    * Step 4: Change the New Username and Hashed Password 
    */
    validateForgotNewPassword(pwd: string){
    	console.log("validating Password " + pwd);
        this.customerData.pwd = pwd;
        let data = new ForgotPassword();
        data.pwd = pwd;
        data.userName = this.customerData.userName;
        this.forgotPasswordService.resetPwd(data)
            .subscribe(
                resp => this.handleVerifyPwdResp(resp),
                error => this.sharedService.handleError(error)
            );
    }

    /*
    * Step 5: Verify the Username and Hashed Password 
    */
    private handleVerifyPwdResp(resp: any) {
        console.log('handleVerifyPwdResp ' + resp);
        if (resp.result.status == "success") {
            this.stepValue = 5;
            
        }
    }
    
    verifyForgotPasswordLogin(){
        
        let data = new ForgotPassword();
        data.userName = this.customerData.userName;
        data.pwd = this.customerData.pwd;
        this.forgotPasswordService.verifyLogin(data)
            .subscribe(
                resp => this.handleLoginResp(resp),
                error => this.sharedService.handleError(error)
            );
    }

    /*
    * Handle the verify Login based on actions
    */
    private handleLoginResp(resp: any) {
        if (resp.result.status == 'success') {
            this.router.navigate(['/dashboard']);
        }
    }

}