"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var ForgotPasswordComponent = (function () {
    function ForgotPasswordComponent() {
    }
    ForgotPasswordComponent.prototype.ngOnInit = function () {
        this.stepFlag = 1;
        this.validUsername = false;
    };
    ForgotPasswordComponent.prototype.validateCustomerIdentification = function () {
        this.stepFlag = 2;
        console.log("validated customer identification");
    };
    ForgotPasswordComponent.prototype.validateForgotPwdOTP = function () {
        this.stepFlag = 3;
        console.log("validated OTP");
    };
    ForgotPasswordComponent.prototype.validateForgotPwdUsername = function () {
        this.stepFlag = 4;
        console.log("validated Username");
    };
    ForgotPasswordComponent.prototype.validateForgotNewPassword = function () {
        this.stepFlag = 5;
    };
    /*validateForgotConfirmPassword(){
        
    }*/
    ForgotPasswordComponent.prototype.SaveForgotPassword = function () {
        console.log("redirect to dashboard");
    };
    ForgotPasswordComponent = __decorate([
        core_1.Component({
            templateUrl: 'app/forgotPassword/templates/forgotPassword.html'
        })
    ], ForgotPasswordComponent);
    return ForgotPasswordComponent;
}());
exports.ForgotPasswordComponent = ForgotPasswordComponent;
//# sourceMappingURL=forgotPassword.component.js.map