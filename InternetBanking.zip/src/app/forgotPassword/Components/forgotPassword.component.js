"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var customerData_1 = require("../../register/model/customerData");
var shared_service_1 = require("../../shared/services/shared.service");
var forgotPassword_service_1 = require("../services/forgotPassword.service");
var forgotPassword_1 = require("../model/forgotPassword");
var ForgotPasswordComponent = (function () {
    function ForgotPasswordComponent(forgotPasswordService, sharedService, router) {
        this.forgotPasswordService = forgotPasswordService;
        this.sharedService = sharedService;
        this.router = router;
    }
    ForgotPasswordComponent.prototype.ngOnInit = function () {
        this.stepValue = 1;
        this.validUsername = false;
        this.customerData = new customerData_1.CustomerData();
    };
    /*
    * step 1:
    */
    ForgotPasswordComponent.prototype.validateCustomerIdentificationForgotPwd = function (customerID) {
        var _this = this;
        this.customerData.customerID = customerID;
        var registerDeviceData = this.sharedService.setupAuthKeys();
        console.log("Register Device Data ::" + registerDeviceData);
        if (registerDeviceData && registerDeviceData.deviceID != '') {
            this.sharedService.registerDevice(registerDeviceData)
                .subscribe(function (resp) { return _this.handleRegisterDeviceDataResp(resp); }, function (error) { return _this.sharedService.handleError(error); });
        }
    };
    /*
    * Step 2: Verify the customer ID to get the CIF number
    */
    ForgotPasswordComponent.prototype.handleRegisterDeviceDataResp = function (resp) {
        var _this = this;
        if (resp.authKey.convID != '') {
            console.log("validating customer identification " + this.customerData.customerID);
            var data = new forgotPassword_1.ForgotPassword();
            data.customerID = this.customerData.customerID;
            this.forgotPasswordService.verifyCustomer(data)
                .subscribe(function (resp) { return _this.handleVerifyCustIDResp(resp); }, function (error) { return _this.sharedService.handleError(error); });
        }
    };
    /*
    * Handle the Response of Verify Customer ID
    * to get Mobile number and email and move to OTP Page
    */
    ForgotPasswordComponent.prototype.handleVerifyCustIDResp = function (resp) {
        console.log('handleVerifyCustIDResp ' + resp);
        this.stepValue = 2;
        this.customerData.mobileNumber = resp.mobileNumberMasked;
        this.customerData.emailID = resp.emailMasked;
    };
    ForgotPasswordComponent.prototype.validateForgotPwdOTP = function (otp) {
        var _this = this;
        console.log("validating OTP " + otp);
        var data = new forgotPassword_1.ForgotPassword();
        data.otp = otp;
        this.forgotPasswordService.verifyOtp(data)
            .subscribe(function (resp) { return _this.handleVerifyOtpResp(resp); }, function (error) { return _this.sharedService.handleError(error); });
    };
    /*
    * Handle the Verify OTP Response
    */
    ForgotPasswordComponent.prototype.handleVerifyOtpResp = function (resp) {
        console.log('handleVerifyOtpResp ' + resp);
        this.customerData.name = resp.userName;
        this.stepValue = 3;
    };
    /*
    * Handle the Username
    */
    ForgotPasswordComponent.prototype.validateForgotPwdUsername = function (userName) {
        this.customerData.userName = userName;
        this.stepValue = 4;
    };
    /*
    * Step 4: Change the New Username and Hashed Password
    */
    ForgotPasswordComponent.prototype.validateForgotNewPassword = function (pwd) {
        var _this = this;
        console.log("validating Password " + pwd);
        this.customerData.pwd = pwd;
        var data = new forgotPassword_1.ForgotPassword();
        data.pwd = pwd;
        data.userName = this.customerData.userName;
        this.forgotPasswordService.resetPwd(data)
            .subscribe(function (resp) { return _this.handleVerifyPwdResp(resp); }, function (error) { return _this.sharedService.handleError(error); });
    };
    /*
    * Step 5: Verify the Username and Hashed Password
    */
    ForgotPasswordComponent.prototype.handleVerifyPwdResp = function (resp) {
        console.log('handleVerifyPwdResp ' + resp);
        if (resp.result.status == "success") {
            this.stepValue = 5;
        }
    };
    ForgotPasswordComponent.prototype.verifyForgotPasswordLogin = function () {
        var _this = this;
        var data = new forgotPassword_1.ForgotPassword();
        data.userName = this.customerData.userName;
        data.pwd = this.customerData.pwd;
        this.forgotPasswordService.verifyLogin(data)
            .subscribe(function (resp) { return _this.handleLoginResp(resp); }, function (error) { return _this.sharedService.handleError(error); });
    };
    /*
    * Handle the verify Login based on actions
    */
    ForgotPasswordComponent.prototype.handleLoginResp = function (resp) {
        if (resp.result.status == 'success') {
            this.router.navigate(['/dashboard']);
        }
    };
    ForgotPasswordComponent = __decorate([
        core_1.Component({
            templateUrl: 'app/forgotPassword/templates/forgotPassword.html'
        }),
        __metadata("design:paramtypes", [forgotPassword_service_1.ForgotPasswordService,
            shared_service_1.SharedService,
            router_1.Router])
    ], ForgotPasswordComponent);
    return ForgotPasswordComponent;
}());
exports.ForgotPasswordComponent = ForgotPasswordComponent;
//# sourceMappingURL=forgotPassword.component.js.map