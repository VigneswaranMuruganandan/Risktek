import { Component, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'forgotpasswordstep3-component',
  templateUrl: 'app/forgotPassword/templates/forgotPasswordStep3.html'
})
export class ForgotPasswordStep3Component {
	@Input() validUsernameFlag: boolean;
	@Output() validateForgotPwdUsernameEvent = new EventEmitter();


    usernameValidations(){
    	this.validUsernameFlag = true;
    }

	validateUsername(){
		this.validateForgotPwdUsernameEvent.emit();
	}
}