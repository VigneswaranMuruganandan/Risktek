import { Component, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { CustomerData } from '../../register/model/customerData';

@Component({
  selector: 'forgotpasswordstep3-component',
  templateUrl: 'app/forgotPassword/templates/forgotPasswordStep3.html'
})
export class ForgotPasswordStep3Component {
	@Input() validUsernameFlag: boolean;
	@Output() validateForgotPwdUsernameEvent = new EventEmitter();
	@Input() customerData: CustomerData;
	private userName:string;
	
    usernameValidations(flag :boolean){
    	this.validUsernameFlag = flag;
    }

	validateUsername(){
		this.validateForgotPwdUsernameEvent.emit(this.userName);
	}
}