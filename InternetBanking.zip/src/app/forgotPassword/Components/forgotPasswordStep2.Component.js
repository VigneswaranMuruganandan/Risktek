"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var ForgotPasswordStep2Component = (function () {
    function ForgotPasswordStep2Component() {
        this.validateForgotPwdOTPEvent = new core_1.EventEmitter();
    }
    ForgotPasswordStep2Component.prototype.validateOTP = function () {
        this.validateForgotPwdOTPEvent.emit();
    };
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], ForgotPasswordStep2Component.prototype, "validateForgotPwdOTPEvent", void 0);
    ForgotPasswordStep2Component = __decorate([
        core_1.Component({
            selector: 'forgotpasswordstep2-component',
            templateUrl: 'app/forgotPassword/templates/forgotPasswordStep2.html'
        })
    ], ForgotPasswordStep2Component);
    return ForgotPasswordStep2Component;
}());
exports.ForgotPasswordStep2Component = ForgotPasswordStep2Component;
//# sourceMappingURL=forgotPasswordStep2.Component.js.map