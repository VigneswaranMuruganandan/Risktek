import { Component, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'forgotpasswordstep5-component',
  templateUrl: 'app/forgotPassword/templates/forgotPasswordStep5.html'
})
export class ForgotPasswordStep5Component {
	@Output() verifyForgotPasswordLoginEvent = new EventEmitter();

	launchDashboard(){
		this.verifyForgotPasswordLoginEvent.emit();
	}
}