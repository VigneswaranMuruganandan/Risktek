"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var template_service_1 = require("../../shared/services/template.service");
var ForgotPasswordStep1Component = (function () {
    function ForgotPasswordStep1Component(templateService) {
        this.templateService = templateService;
        this.validateCustomerIdentificationForgotPwdEvent = new core_1.EventEmitter();
    }
    ForgotPasswordStep1Component.prototype.validateCustomer = function (valid) {
        console.log(" customerID:" + this.customerID);
        if (valid) {
            this.templateService.resetFromValidatorFlag();
            this.validateCustomerIdentificationForgotPwdEvent.emit(this.customerID);
        }
    };
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], ForgotPasswordStep1Component.prototype, "validateCustomerIdentificationForgotPwdEvent", void 0);
    ForgotPasswordStep1Component = __decorate([
        core_1.Component({
            selector: 'forgotpasswordstep1-component',
            templateUrl: 'app/forgotPassword/templates/forgotPasswordStep1.html'
        }),
        __metadata("design:paramtypes", [template_service_1.TemplateService])
    ], ForgotPasswordStep1Component);
    return ForgotPasswordStep1Component;
}());
exports.ForgotPasswordStep1Component = ForgotPasswordStep1Component;
//# sourceMappingURL=forgotPasswordStep1.Component.js.map