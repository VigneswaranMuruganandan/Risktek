import { Component, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'forgotpasswordstep2-component',
  templateUrl: 'app/forgotPassword/templates/forgotPasswordStep2.html'
})
export class ForgotPasswordStep2Component {
	@Output() validateForgotPwdOTPEvent = new EventEmitter();

	validateOTP(){
		this.validateForgotPwdOTPEvent.emit();
	}
}