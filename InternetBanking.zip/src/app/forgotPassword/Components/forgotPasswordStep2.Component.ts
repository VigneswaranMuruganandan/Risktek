import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { CustomerData } from '../../register/model/customerData';

@Component({
  selector: 'forgotpasswordstep2-component',
  templateUrl: 'app/forgotPassword/templates/forgotPasswordStep2.html'
})
export class ForgotPasswordStep2Component implements OnInit{
	@Output() validateForgotPwdOTPEvent = new EventEmitter();
	@Input() customerData: CustomerData;
	public otp:string;
	public otpList :Array<string>;

	ngOnInit() { 
    	this.otpList = ['','','','','','']
    }

	validateOTP(){
		this.otp = this.otpList.join('');
		this.validateForgotPwdOTPEvent.emit(this.otp);
	}
}