"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var serviceinvoker_service_1 = require("../../shared/connector/serviceinvoker.service");
var encryption_service_1 = require("../../shared/services/encryption.service");
var globalURL_1 = require("../../shared/services/globalURL");
var sessioncontext_1 = require("../../shared/model/sessioncontext");
var authkey_1 = require("../../shared/model/authkey");
var authdata_1 = require("../../shared/model/authdata");
var verifyotpresponse_1 = require("../../shared/model/verifyotpresponse");
var verifycustomerresponse_1 = require("../../register/model/verifycustomerresponse");
var registerpwdresponse_1 = require("../../register/model/registerpwdresponse");
var ForgotPasswordService = (function () {
    function ForgotPasswordService(serviceInvoker, encryptionService) {
        this.serviceInvoker = serviceInvoker;
        this.encryptionService = encryptionService;
    }
    ForgotPasswordService.prototype.verifyCustomer = function (ForgotPassword) {
        var _this = this;
        return this.serviceInvoker.invoke(globalURL_1.GlobalURL.SERVICE_URL.LOGIN.VERIFYCUSTOMERID, ForgotPassword)
            .map(function (resp) { return _this.populateCustResp(resp); });
    };
    ForgotPasswordService.prototype.populateCustResp = function (resp) {
        console.log("cust resp " + resp);
        var respObj = JSON.parse(resp);
        console.log("res " + respObj.result.status);
        var responseObj = new verifycustomerresponse_1.VerifyCustomerResponse();
        sessioncontext_1.SessionContext.getInstance().userID = respObj.cif;
        responseObj.otpDuration = respObj.otpDuration;
        responseObj.convID = respObj.convID;
        responseObj.cif = respObj.cif;
        responseObj.emailMasked = respObj.emailMasked;
        responseObj.mobileNumberMasked = respObj.mobileNumberMasked;
        responseObj.remainingOtpAttempts = respObj.remainingOtpAttempts;
        return responseObj;
    };
    ForgotPasswordService.prototype.verifyOtp = function (ForgotPassword) {
        var _this = this;
        return this.serviceInvoker.invoke(globalURL_1.GlobalURL.SERVICE_URL.REGISTRATION.VERIFYOTP, ForgotPassword)
            .map(function (resp) { return _this.populateOtpResp(resp); });
    };
    ForgotPasswordService.prototype.populateOtpResp = function (resp) {
        var respObj = JSON.parse(resp);
        console.log("res " + respObj.result.status);
        var responseObj = new verifyotpresponse_1.VerifyOtpResponse();
        console.log("res " + respObj.result.success);
        responseObj.userName = respObj.userName;
        return responseObj;
    };
    ForgotPasswordService.prototype.resetPwd = function (ForgotPassword) {
        var _this = this;
        console.log(sessioncontext_1.SessionContext.getInstance());
        var pwdHash = this.encryptionService.generatePwdHash(sessioncontext_1.SessionContext.getInstance().userID, ForgotPassword.pwd);
        ForgotPassword.pwd = this.encryptionService.convertToBase64(pwdHash);
        return this.serviceInvoker.invoke(globalURL_1.GlobalURL.SERVICE_URL.FORGOT_PASSWORD.RESETPASSWORD, ForgotPassword)
            .map(function (resp) { return _this.populatePwdRegisterResp(resp); });
    };
    ForgotPasswordService.prototype.populatePwdRegisterResp = function (resp) {
        var respObj = JSON.parse(resp);
        console.log("res " + respObj.result.status);
        var responseObj = new registerpwdresponse_1.RegisterPwdResponse();
        responseObj = respObj;
        console.log("res " + respObj.result.success);
        return responseObj;
    };
    ForgotPasswordService.prototype.verifyLogin = function (ForgotPassword) {
        var _this = this;
        var pwdHash = this.encryptionService.generatePwdHash(sessioncontext_1.SessionContext.getInstance().userID, ForgotPassword.pwd);
        ForgotPassword.pwd = this.encryptionService.convertToBase64(pwdHash);
        return this.serviceInvoker.invoke(globalURL_1.GlobalURL.SERVICE_URL.LOGIN.VERIFYLOGIN, ForgotPassword)
            .map(function (resp) { return _this.populateLoginResp(resp); });
    };
    ForgotPasswordService.prototype.populateLoginResp = function (resp) {
        var respObj = JSON.parse(resp);
        this.updateSessionContext(respObj);
        var responseObj = new registerpwdresponse_1.RegisterPwdResponse();
        responseObj = respObj;
        console.log("res " + responseObj);
        return responseObj;
    };
    ForgotPasswordService.prototype.updateSessionContext = function (respObj) {
        if (respObj.result.status == 'success') {
            var authData = new authdata_1.AuthData();
            authData.authKey = new authkey_1.AuthKey();
            authData.authKey.encIV = respObj.data.encIV;
            authData.authKey.encKey = respObj.data.encKey;
            authData.authKey.convID = respObj.data.convID;
            authData.authKey.macKey = respObj.data.macKey;
            authData.authKey.ec = respObj.data.eventCtr;
            var sessCtx = sessioncontext_1.SessionContext.getInstance();
            sessCtx.authKey = authData.authKey;
        }
    };
    ForgotPasswordService = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [serviceinvoker_service_1.ServiceInvoker,
            encryption_service_1.EncryptionService])
    ], ForgotPasswordService);
    return ForgotPasswordService;
}());
exports.ForgotPasswordService = ForgotPasswordService;
//# sourceMappingURL=forgotPassword.service.js.map