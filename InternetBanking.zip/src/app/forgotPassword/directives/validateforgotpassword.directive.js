"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var $ = require("jquery");
var template_service_1 = require("../../shared/services/template.service");
/*
* Login Form validation for Registration
*/
var ValidateLogin = (function () {
    function ValidateLogin(el, zone, templateService) {
        this.el = el;
        this.zone = zone;
        this.templateService = templateService;
        this.x = require('jquery-validator');
    }
    ValidateLogin.prototype.onClick = function (event) {
        var _this = this;
        var el = $(this.el.nativeElement);
        var loginValidationSubmit;
        this.zone.runOutsideAngular(function () {
            var loginValidation = $("#loginForm").validate({
                highlight: function (element) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function (element, errorClass) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function (error, element) {
                    if (element.is("input")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    userName: {
                        required: true
                    },
                    password: {
                        required: true
                    }
                },
                messages: {
                    userName: {
                        required: "Please enter Customer Identification Number"
                    },
                    password: {
                        required: "Please enter Password"
                    }
                }
            });
            loginValidationSubmit = loginValidation.form();
            _this.templateService.setFromValidatorFlag(loginValidationSubmit);
        });
    };
    __decorate([
        core_1.HostListener('click', ['$event']),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", void 0)
    ], ValidateLogin.prototype, "onClick", null);
    ValidateLogin = __decorate([
        core_1.Directive({
            selector: '[ValidateForgotPasswordDirective]',
        }),
        __metadata("design:paramtypes", [core_1.ElementRef, core_1.NgZone, template_service_1.TemplateService])
    ], ValidateLogin);
    return ValidateLogin;
}());
exports.ValidateLogin = ValidateLogin;
//# sourceMappingURL=validateforgotpassword.directive.js.map