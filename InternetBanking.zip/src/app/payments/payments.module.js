"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var common_1 = require("@angular/common");
var payments_routing_1 = require("./payments.routing");
var core_2 = require("@ngx-translate/core");
var shared_module_1 = require("../shared/shared.module");
var shared_service_1 = require("../shared/services/shared.service");
var template_service_1 = require("../shared/services/template.service");
var forms_1 = require("@angular/forms");
var charity_component_1 = require("./Components/charity.component");
var charityStep1_Component_1 = require("./Components/charityStep1.Component");
var charityStep2_Component_1 = require("./Components/charityStep2.Component");
var charityStep3_Component_1 = require("./Components/charityStep3.Component");
var charityStep4_Component_1 = require("./Components/charityStep4.Component");
var charityStep5_Component_1 = require("./Components/charityStep5.Component");
var PAYMENTS_COMPONENTS = [
    charity_component_1.CharityComponent,
    charityStep1_Component_1.CharityStep1Component,
    charityStep2_Component_1.CharityStep2Component,
    charityStep3_Component_1.CharityStep3Component,
    charityStep4_Component_1.CharityStep4Component,
    charityStep5_Component_1.CharityStep5Component
];
var PAYMENTS_PROVIDERS = [
    shared_service_1.SharedService,
    template_service_1.TemplateService
];
var PaymentsModule = (function () {
    function PaymentsModule() {
    }
    PaymentsModule = __decorate([
        core_1.NgModule({
            imports: [
                payments_routing_1.routing,
                core_2.TranslateModule.forChild(),
                shared_module_1.SharedModule,
                forms_1.FormsModule,
                common_1.CommonModule
            ],
            declarations: PAYMENTS_COMPONENTS.slice(),
            providers: PAYMENTS_PROVIDERS.slice()
        })
    ], PaymentsModule);
    return PaymentsModule;
}());
exports.PaymentsModule = PaymentsModule;
//# sourceMappingURL=payments.module.js.map