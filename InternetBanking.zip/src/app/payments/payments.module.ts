import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { routing } from './payments.routing';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '../shared/shared.module';
import {SharedService} from '../shared/services/shared.service';
import {TemplateService} from '../shared/services/template.service';
import { FormsModule } from '@angular/forms';
import { CharityComponent } from './Components/charity.component';
import { CharityStep1Component }   from './Components/charityStep1.Component';
import { CharityStep2Component }   from './Components/charityStep2.Component';
import { CharityStep3Component }   from './Components/charityStep3.Component';
import { CharityStep4Component }   from './Components/charityStep4.Component';
import { CharityStep5Component }   from './Components/charityStep5.Component';



const PAYMENTS_COMPONENTS = [
    CharityComponent,
    CharityStep1Component,
    CharityStep2Component,
    CharityStep3Component,
    CharityStep4Component,
    CharityStep5Component
];

const PAYMENTS_PROVIDERS = [
   SharedService,
   TemplateService
];

@NgModule({
  	imports: [
	    routing,
	    TranslateModule.forChild(),
	    SharedModule,
	    FormsModule,
		CommonModule
	],
  	declarations: [
	    ...PAYMENTS_COMPONENTS
	],
  	providers: [
  		...PAYMENTS_PROVIDERS
  	]
})
export class PaymentsModule {}
