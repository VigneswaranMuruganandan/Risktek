import { Component, OnInit, Input} from '@angular/core';

@Component({
  templateUrl: 'app/payments/templates/charity.html'
})
export class CharityComponent implements OnInit{
	public stepFlag: number;
	public charityItems:Array<any>=[{'imageName':'prcf.png'},{'imageName':'prcf.png'},{'imageName':'prcf.png'},{'imageName':'prcf.png'},{'imageName':'prcf.png'},{'imageName':'prcf.png'},{'imageName':'prcf.png'},{'imageName':'prcf.png'},{'imageName':'prcf.png'},{'imageName':'prcf.png'}];

	ngOnInit() { 
    	this.stepFlag = 1;
    }
    validateCharitySelectionNext(){
    	this.stepFlag = 2;
    }

    validateCharityReviewPayment(){
    	this.stepFlag = 3;
    }

    validateCharityMakePayment(){
    	this.stepFlag = 4;
    }

    validateCharityOtpConfirm(){
    	this.stepFlag = 5;
    }
}