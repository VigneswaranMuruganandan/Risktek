import { Component, OnInit, Input} from '@angular/core';

@Component({
  templateUrl: 'app/payments/templates/charity.html'
})
export class CharityComponent{
	
}