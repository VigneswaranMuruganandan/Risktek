import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'charitystep4-component',
  templateUrl: 'app/payments/templates/charityStep4.html'
})
export class CharityStep4Component{
	
}