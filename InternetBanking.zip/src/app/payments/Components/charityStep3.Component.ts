import { Component, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'charitystep3-component',
  templateUrl: 'app/payments/templates/charityStep3.html'
})
export class CharityStep3Component {
	
}