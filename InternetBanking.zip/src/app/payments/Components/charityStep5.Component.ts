import { Component, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'charitystep5-component',
  templateUrl: 'app/payments/templates/charityStep5.html'
})
export class CharityStep5Component {
	
}