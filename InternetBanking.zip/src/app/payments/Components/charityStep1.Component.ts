import { Component, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'charitystep1-component',
  templateUrl: 'app/payments/templates/charityStep1.html'
})
export class CharityStep1Component {
	
}