"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var router_1 = require("@angular/router");
var charity_component_1 = require("./Components/charity.component");
var routes = [
    {
        path: 'charity',
        component: charity_component_1.CharityComponent
    },
    {
        path: '',
        redirectTo: 'charity',
        pathMatch: 'full'
    }
];
exports.routing = router_1.RouterModule.forChild(routes);
//# sourceMappingURL=payments.routing.js.map