<?php
include_once('db_connect.php');
if(isset($_POST)){
	if($_POST['type']=="REGISTER"){
		$username = $_POST['username'];
		$password = $_POST['password'];
		$firstName = $_POST['firstName'];
		$lastName = $_POST['lastName'];
		if( empty($username) || empty($password) )
		{
			echo "Username and Password are mandatory - from PHP!";
			exit();
		}
		$con = db_connect();
	    $sql = "SELECT * FROM users WHERE username='".$username."'";
		$result = $con->query($sql);
		if ($result->num_rows > 0) {
		    echo "Username $username has already been taken";
		}
		else
		{
		$insert_sql = "INSERT INTO users(username,password,fname,lname) VALUES ('".$username.
		"','".$password."','".$firstName."','".$lastName."')";
			if ($con->query($insert_sql) === TRUE) {
			    echo "New record created successfully";
			} else {
			    echo "Error: " . $sql . "<br>" . $con->error;
			}
		}
	}

	if($_POST['type']=="LOGIN"){
		$username = $_POST['username'];
        $password = $_POST ['password'];
 
		if( empty($username) || empty($password) )
			echo "Username and Password Mandatory - from PHP";
		else
		{
			$con = db_connect();
			$sql = "SELECT count(*) FROM users WHERE username='".$username."' AND password='".$password."'";
	   		$result = $con->query($sql);
			if ($result->num_rows > 0) 
		 		echo "Login Successful";
			else
		 	echo "Failed To Login";
   		}	
	}
}

?>