$("#register").click( function() {
	var data = {
		"type": "REGISTER",
		"username": $('#registerForm').find('input[name="username"]').val(),
		"password":$('#registerForm').find('input[name="password"]').val(), 
		"firstName":$('#registerForm').find('input[name="firstName"]').val(),  
		"lastName": $('#registerForm').find('input[name="lastName"]').val()
	};
	var request = $.ajax({
	  url: "process.php",
	  dataType: "json",
	  type: "POST",
	  data: data,
	  success: function(data) {
        console.log(data);
      }
	});

});

$("#login").click( function() {
	var data = {
		"type": "LOGIN",
		"username": $('#loginForm').find('input[name="username"]').val(),
		"password":$('#loginForm').find('input[name="password"]').val(), 
	};
	var request = $.ajax({
	  url: "process.php",
	  dataType: "json",
	  type: "POST",
	  data: data,
	  success: function(data) {
        console.log(data);
      }
	});

});


