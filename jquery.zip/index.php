<html>
<head><title>REGISTER</title></head>
<body>
 
<form name="register" id="registerForm">
  Username:<br>
  <input type="text" name="username">
  <br><br>
  Password:<br>
  <input type="password" name="password">
  <br><br>
  FirstName:<br>
  <input type="text" name="firstName">
  <br><br>
  LastName:<br>
  <input type="text" name="lastName">
  <br><br>
  <input type="button" id="register" value="Register">
</form> 
 
<div id="ack"></div>
 
<script
  src="https://code.jquery.com/jquery-3.4.1.min.js"
  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
  crossorigin="anonymous"></script>
<script type="text/javascript" src="./assets/script.js"></script>
</body>
</html>