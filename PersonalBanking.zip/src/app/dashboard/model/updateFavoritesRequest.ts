export class UpdateFavoritesRequest {
    productRef : string[];	
}