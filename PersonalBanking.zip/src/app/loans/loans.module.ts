import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { FormsModule } from '@angular/forms';
import { routing } from './loans.routing';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '../shared/shared.module';
import { SharedService} from '../shared/services/shared.service';
import { TemplateService} from '../shared/services/template.service';
import { LoansComponent }   from './Components/loans.component';
import { LoansService }   from './services/loans.service';
import { BaseLoanDeferralComponent } from './Components/baseLoanDeferral.component';
import { LoanDeferralStep1Component } from './Components/loanDeferralStep1.component';
import { LoanDeferralStep2Component } from './Components/loanDeferralStep2.component';
import {
  ValidateLoanDeferral
} from './directives/validateloans.directive';


const LOANS_COMPONENTS = [
    LoansComponent,
    BaseLoanDeferralComponent,
    LoanDeferralStep1Component,
    LoanDeferralStep2Component
];

const LOANS_DIRECTIVES = [
    ValidateLoanDeferral
];

const LOANS_PROVIDERS = [
   SharedService,
   TemplateService,
   LoansService
];

@NgModule({
  	imports: [
	    routing,
	    TranslateModule.forChild(),
	    SharedModule,
	    FormsModule,
        CommonModule
	],
  	declarations: [
	  ...LOANS_COMPONENTS,
      ...LOANS_DIRECTIVES
	],
	providers: [
		...LOANS_PROVIDERS
	]
})
export class LoansModule {}
