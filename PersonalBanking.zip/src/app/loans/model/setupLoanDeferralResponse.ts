import {APIResponse} from '../../shared/model/apiResponse';
import { Product } from '../../shared/model/product';
import { Amount } from '../../shared/model/amount';
import { Loan } from './loan';

export class SetupLoanDeferralResponse extends APIResponse{
	notes :string;
	loanDetails :Loan[];
	account :Product;
	charge :Amount;
}