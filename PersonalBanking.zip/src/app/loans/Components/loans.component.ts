import { Component, OnInit, Input, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { LoansService } from '../services/loans.service';
import { Router } from '@angular/router';
import { SessionContext} from '../../shared/model/sessionContext';
import { TemplateService } from '../../shared/services/template.service';
import { SharedService } from '../../shared/services/shared.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { ErrorService } from '../../shared/services/error.service';
import { AppSession} from '../../shared/model/appSession';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import Chart from 'chart.js';
import { GlobalVariable} from '../../shared/services/global';
import { LoansResponse } from '../model/loansResponse';
import { Loan } from '../model/loan';

@Component({
    templateUrl: './../templates/loans.html'
})
export class LoansComponent implements OnInit {
    @ViewChild("myCanvas") myCanvas: ElementRef;
    context:CanvasRenderingContext2D;
    public loansColor :string[] = GlobalVariable.LOANS_COLOR;
    public data :number[] = new Array();
    public labels :string[] = new Array();
    public loansList :Loan[];

    constructor( private loansService: LoansService, 
                 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private templateService: TemplateService,
                 private errorService: ErrorService,
                 private router: Router) {}

    ngOnInit() {
      this.errorService.resetErrorResp();
      this.fetchLoansList();
    }
    /*
    * Fetch the Loan List from service
    */
    fetchLoansList(){
        this.spinnerService.startSpinner('loanDetails');
        this.loansService.fetchLoanList()
            .subscribe(
                resp => {
                    this.spinnerService.stopSpinner('loanDetails');
                    if(resp.result.status == 'success'){
                        this.loansList = resp.loanDetailList;
                        this.mapCalculation();
                    }else if(resp.result.status == 'error'){
                        this.errorService.setErrorResp(resp.result);
                    }                    
                },
                error => {
                    this.spinnerService.stopSpinner('loanDetails');
                    this.sharedService.handleError(error);
                }
            );
    }
    /*
    * Calculate the Data and labels for charts
    */
    mapCalculation(){
        let loanTotal = 0;
        this.loansList.map(obj => { 
            if(obj){
                loanTotal = loanTotal + obj.outstandingBalance.value;
            }
        });
        this.loansList.map(obj => { 
            if(obj){
                this.labels.push(obj.loanAccountNumber);
                let data = Math.round((obj.outstandingBalance.value/loanTotal)*100);
                this.data.push(data);
            }
        });
        this.generateLoanChart();
    }

    /*
    * Generate the charts for the Loans
    */
    generateLoanChart(){
        let ctx = this.myCanvas.nativeElement.getContext('2d');
        let chart : CanvasRenderingContext2D = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: this.labels,
                datasets: [{
                    backgroundColor: this.loansColor,
                    borderColor: 'white',
                    data: this.data,
                }]
            },
            options: {
                maintainAspectRatio: false,
                legend: {
                    display: false,
                    position: 'bottom',
                    labels: {
                        fontColor: 'rgb(255, 99, 132)'
                    }
                },
                title: {
                    display: false,
                    text: 'Your Total Outstanding Balance',
                }
            }
        });
    }
}