import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { SharedService } from '../../shared/services/shared.service';
import { TemplateService } from '../../shared/services/template.service';
import { ErrorService } from '../../shared/services/error.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { LoansService } from '../services/loans.service';
import { Router } from '@angular/router';
import { SetupLoanDeferralResponse } from '../model/setupLoanDeferralResponse';
import { LoanDeferralRequest } from '../model/loanDeferralRequest';

@Component({
  selector: 'loanDeferralStep2-component',
  templateUrl: './../templates/loanDeferralStep2.html'
})
export class LoanDeferralStep2Component {
	@Input() loanDeferralRequest :LoanDeferralRequest;
	@Input() charges :number;
	@Input() setupLoanDeferralResponse :SetupLoanDeferralResponse;

}