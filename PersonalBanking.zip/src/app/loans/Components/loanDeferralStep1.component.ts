import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { SharedService } from '../../shared/services/shared.service';
import { TemplateService } from '../../shared/services/template.service';
import { ErrorService } from '../../shared/services/error.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { LoansService } from '../services/loans.service';
import { Router } from '@angular/router';
import { SetupLoanDeferralResponse } from '../model/setupLoanDeferralResponse';
import { LoanDeferralRequest } from '../model/loanDeferralRequest';

@Component({
  selector: 'loanDeferralStep1-component',
  templateUrl: './../templates/loanDeferralStep1.html'
})
export class LoanDeferralStep1Component {
	@Output() submitLoanDeferralEvent = new EventEmitter();
	@Input() loanDeferralRequest :LoanDeferralRequest;
	@Input() loanSelected :any;
	@Input() charges :number;
	@Input() setupLoanDeferralResponse :SetupLoanDeferralResponse;

	submit(){
		this.submitLoanDeferralEvent.emit();
	}

	onChange(value:string,checked:boolean){
		this.loanDeferralRequest.loanDetails = [];
	    this.loanSelected.filter((product,index) => {
	    	if(product.loanAccountNumber == value){
	    		this.loanSelected[index].status = checked;
	    	}
	    	if(product.status){
	    		this.loanDeferralRequest.loanDetails.push(product);
	    	}
	    });
	    this.charges = this.setupLoanDeferralResponse.charge.value * this.loanDeferralRequest.loanDetails.length;
  	}

}