import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { routing } from './applyForProducts.routing';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '../shared/shared.module';
import {SharedService} from '../shared/services/shared.service';
import {TemplateService} from '../shared/services/template.service';
import { ApplyForProductsService } from './services/applyForProducts.service';
import { FormsModule } from '@angular/forms';
import { ApplyForProductsComponent } from './Components/applyForProducts.component';
import { BaseApplyForNewAccountComponent } from './Components/baseApplyForNewAccount.component';
import { ApplyForNewAccountStep1Component } from './Components/applyForNewAccountStep1.component';
import { ApplyForNewAccountStep2Component } from './Components/applyForNewAccountStep2.component';
import { ApplyForNewAccountStep3Component } from './Components/applyForNewAccountStep3.component';
import { BaseApplyForNewCardComponent } from './Components/baseApplyForNewCard.component';
import { ApplyForNewCardStep1Component } from './Components/applyForNewCardStep1.component';
import { ApplyForNewCardStep2Component } from './Components/applyForNewCardStep2.component';
import { ApplyForNewCardStep3Component } from './Components/applyForNewCardStep3.component';
import { BaseApplyForNewLoanComponent } from './Components/baseApplyForNewLoan.component';
import { ApplyForNewLoanStep1Component } from './Components/applyForNewLoanStep1.component';
import { ApplyForNewLoanStep2Component } from './Components/applyForNewLoanStep2.component';
import { ApplyForNewLoanStep3Component } from './Components/applyForNewLoanStep3.component';
import { BaseApplyForNewDepositComponent } from './Components/baseApplyForNewDeposit.component';
import { ApplyForNewDepositStep1Component } from './Components/applyForNewDepositStep1.component';
import { ApplyForNewDepositStep2Component } from './Components/applyForNewDepositStep2.component';
import { ApplyForNewDepositStep3Component } from './Components/applyForNewDepositStep3.component';

import { 
  ValidateApplyForAccountDirective,
  ValidateApplyForCardDirective,
  ValidateApplyForLoanDirective,
  ValidateApplyForDepositDirective 
} from './directives/validateApplyforProducts.directive';

const APPLYFORPRODUCTS_COMPONENTS = [
    ApplyForProductsComponent,
    BaseApplyForNewAccountComponent,
    ApplyForNewAccountStep1Component,
    ApplyForNewAccountStep2Component,
    ApplyForNewAccountStep3Component,
    BaseApplyForNewCardComponent,
    ApplyForNewCardStep1Component,
    ApplyForNewCardStep2Component,
    ApplyForNewCardStep3Component,
    BaseApplyForNewLoanComponent,
    ApplyForNewLoanStep1Component,
    ApplyForNewLoanStep2Component,
    ApplyForNewLoanStep3Component,
    BaseApplyForNewDepositComponent,
    ApplyForNewDepositStep1Component,
    ApplyForNewDepositStep2Component,
    ApplyForNewDepositStep3Component
];

const APPLYFORPRODUCTS_DIRECTIVES = [
  ValidateApplyForAccountDirective,
  ValidateApplyForCardDirective,
  ValidateApplyForLoanDirective,
  ValidateApplyForDepositDirective
];

const APPLYFORPRODUCTS_PROVIDERS = [
   SharedService,
   TemplateService,
   ApplyForProductsService
];

@NgModule({
  	imports: [
	    routing,
	    TranslateModule.forChild(),
	    SharedModule,
	    FormsModule,
      CommonModule
	],
  	declarations: [
	    ...APPLYFORPRODUCTS_COMPONENTS,
      ...APPLYFORPRODUCTS_DIRECTIVES
	],
  	providers: [
  		...APPLYFORPRODUCTS_PROVIDERS
  	]
})
export class ApplyForProductsModule {}
