export class LeadsBaseRequest  {
	firstName :string;
	lastName :string;
	phoneNumber :string;
	nationality :string;
	email :string;
	salary :string;
	companyName :string;
	emirates :string;
	comments :string;
	leadSource :string; // How did you hear about us
	productType :string; // Credit cards , Accounts, Wealth Products
	productSubType :string; // Abu Dhabi Platinum Card, Savings Account
	productGroupName :string; // Conventional, Islamic
	dateOfBirth :string; //not there in service end
	salaryCurrency: string; //not there in service end

	constructor() { 
 		this.productSubType = '';
 		this.emirates = '';
 		this.leadSource = '';
	}
}

