import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { LeadsBaseRequest } from '../model/leadsBaseRequest';

@Component({
  selector: 'applyForNewCardStep2-component',
  templateUrl: './../templates/applyForNewCardStep2.html'
})
export class ApplyForNewCardStep2Component {
	@Input() applyforProduct: LeadsBaseRequest;
	@Output() reviewApplyForProductEvent = new EventEmitter();
	@Output() backApplyForProductEvent = new EventEmitter();

	review(){
		this.reviewApplyForProductEvent.emit();
	}

	back(){
		this.backApplyForProductEvent.emit(1);
	}
}