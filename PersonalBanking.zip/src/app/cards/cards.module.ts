import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { FormsModule } from '@angular/forms';
import { routing } from './cards.routing';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '../shared/shared.module';
import { CardsService} from './services/cards.service';
import { SharedService} from '../shared/services/shared.service';
import { TemplateService} from '../shared/services/template.service';
import { ValidateBlockReasonSelection, ValidateEmbossingName }   from './directives/validateCards.directive';
import { DebitCardsMainComponent }   from './Components/debitCardsMain.component';
import { DebitCardsDetailsComponent }   from './Components/debitCardsDetails.component';
import { DebitCardsRightContentComponent }   from './Components/debitCardsRightContent.component';
import { ActivateDebitCardComponent }   from './Components/activateDebitCard.component';
import { ActivateDebitCardStep1Component }   from './Components/activateDebitCardStep1.component';
import { ActivateDebitCardStep2Component }   from './Components/activateDebitCardStep2.component';
import { ActivateDebitCardStep3Component }   from './Components/activateDebitCardStep3.component';
import { ActivateDebitCardStep4Component }   from './Components/activateDebitCardStep4.component';
import { ActivateDebitCardStep5Component }   from './Components/activateDebitCardStep5.component';
import { ResetPinDebitCardComponent }   from './Components/resetPinDebitCard.component';
import { ResetPinDebitCardStep1Component }   from './Components/resetPinDebitCardStep1.component';
import { ResetPinDebitCardStep2Component }   from './Components/resetPinDebitCardStep2.component';
import { ResetPinDebitCardStep3Component }   from './Components/resetPinDebitCardStep3.component';
import { ResetPinDebitCardStep4Component }   from './Components/resetPinDebitCardStep4.component';
import { ResetPinDebitCardStep5Component }   from './Components/resetPinDebitCardStep5.component';
import { BlockDebitCardComponent }   from './Components/blockDebitCard.component';
import { BlockDebitCardStep1Component }   from './Components/blockDebitCardStep1.component';
import { ReplaceDebitCardComponent }   from './Components/replaceDebitCard.component';
import { ReplaceDebitCardStep1Component }   from './Components/replaceDebitCardStep1.component';
import { ReplaceDebitCardStep2Component }   from './Components/replaceDebitCardStep2.component';
import { ReplaceDebitCardStep3Component }   from './Components/replaceDebitCardStep3.component';

import { CreditCardsMainComponent }   from './Components/creditCardsMain.component';
import { CreditCardsDetailsComponent }   from './Components/creditCardsDetails.component';
import { CreditCardsRightContentComponent }   from './Components/creditCardsRightContent.component';


const CARDS_COMPONENTS = [
    DebitCardsMainComponent,
    DebitCardsDetailsComponent,
    DebitCardsRightContentComponent,
    ActivateDebitCardComponent,
    ActivateDebitCardStep1Component,
    ActivateDebitCardStep2Component,
    ActivateDebitCardStep3Component,
    ActivateDebitCardStep4Component,
    ActivateDebitCardStep5Component,
    ResetPinDebitCardComponent,
    ResetPinDebitCardStep1Component,
    ResetPinDebitCardStep2Component,
    ResetPinDebitCardStep3Component,
    ResetPinDebitCardStep4Component,
    ResetPinDebitCardStep5Component,
    BlockDebitCardComponent,
    BlockDebitCardStep1Component,
    ReplaceDebitCardComponent,
    ReplaceDebitCardStep1Component,
    ReplaceDebitCardStep2Component,
    ReplaceDebitCardStep3Component,
    CreditCardsMainComponent,
    CreditCardsDetailsComponent,
    CreditCardsRightContentComponent,
];

const CARDS_DIRECTIVES = [
    ValidateBlockReasonSelection,
    ValidateEmbossingName
];

const CARDS_PROVIDERS = [
   CardsService,
   SharedService,
   TemplateService
];

@NgModule({
  	imports: [
	    routing,
	    TranslateModule.forChild(),
	    SharedModule,
	    FormsModule,
      	CommonModule
	],
  	declarations: [
	  	...CARDS_COMPONENTS,
      ...CARDS_DIRECTIVES
	],
	providers: [
		...CARDS_PROVIDERS
	]
})
export class CardsModule {}
