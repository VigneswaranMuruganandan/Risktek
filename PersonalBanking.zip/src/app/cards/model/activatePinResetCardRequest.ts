
export class ActivatePinResetCardRequest {

    cardNumber:string;
    pin:string;
    cardType:string;
    authKey:string;
}

