
import {APIResponse} from '../../shared/model/apiResponse';
import { CreditCardDetail } from './creditCardDetail';

export class FetchCreditCardDetailsResponse  extends APIResponse{

  	cardDetails:CreditCardDetail[];
}

