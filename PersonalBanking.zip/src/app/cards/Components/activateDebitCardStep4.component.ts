import { Component, OnInit, Input,EventEmitter,Output} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { SendOtpRequest} from '../../shared/model/sendOtpRequest';
import { SendOtpResponse} from '../../shared/model/sendOtpResponse';

@Component({
  selector: 'activateDebitCardStep4-component',
  templateUrl: './../templates/activateDebitCardStep4.html'
})
export class ActivateDebitCardStep4Component {

	@Output() validateOTPDebitCardActivationEvent = new EventEmitter();
	@Output() backOTPButtonEvent = new EventEmitter();
	@Input() sendOtpRequest:SendOtpRequest;
	@Input() sendOtpResponse:SendOtpResponse;

	validateOTP(otp : string){
		this.validateOTPDebitCardActivationEvent.emit(otp);
	}

	backOTP(){
		this.backOTPButtonEvent.emit();
	}
}