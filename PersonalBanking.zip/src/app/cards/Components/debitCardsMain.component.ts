import { Component, OnInit, Input, ViewChild} from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { CardsService} from '../services/cards.service';
import { SharedService} from '../../shared/services/shared.service';
import { FetchDebitCardDetailsResponse} from '../model/fetchDebitCardDetailsResponse';
import { DebitCardDetail} from '../model/debitCardDetail';
import { ErrorService } from '../../shared/services/error.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { DebitCardsDetailsComponent} from './debitCardsDetails.component';

@Component({
  templateUrl: './../templates/debitCardsMain.html'
})
export class DebitCardsMainComponent implements OnInit {
	
	public fetchDebitCardDetailsResponse:FetchDebitCardDetailsResponse;
  public debitCardDetail:DebitCardDetail;
  public debitCard:DebitCardDetail;
  public carouselDebitCardList:DebitCardDetail[];
  @ViewChild(DebitCardsDetailsComponent) debitCardsDetailsComponent: DebitCardsDetailsComponent;

  constructor( private cardsService: CardsService,
               private sharedService: SharedService,
               private errorService: ErrorService,
               private spinnerService: SpinnerService) {}

  ngOnInit() {
      this.spinnerService.startSpinner('loader');
      this.fetchDebitCards();
      this.errorService.resetErrorResp();
  }
	
 /*
 * Fetch all Debit Cards list
 */
	fetchDebitCards(){
		this.cardsService.fetchDebitCardList()
			.subscribe(
              resp => this.handleDebitCardsResp(resp),
              error => this.sharedService.handleError(error)
          	);
	}

	/*
   * Handle Debit Card Details Response
   */
	private handleDebitCardsResp(resp:FetchDebitCardDetailsResponse){
		  this.spinnerService.stopSpinner('loader');
      if (resp.result.status == "success") {
          this.fetchDebitCardDetailsResponse = new FetchDebitCardDetailsResponse();
          this.fetchDebitCardDetailsResponse = resp;
          if(this.fetchDebitCardDetailsResponse.cardDetails && 
                        this.fetchDebitCardDetailsResponse.cardDetails.length>0 ){
            let debitCard = this.fetchDebitCardDetailsResponse.cardDetails[0];
            this.debitCardToBeDisplayed(debitCard);
          }
      } else {
          this.errorService.setErrorResp(resp.result);
          console.log(resp.result.status);
      }
	}

  /*
   * Initialise the DebitCard To be displayed 
   * and update rest Debit Cards in right Carousel
   */
  debitCardToBeDisplayed(debitCard:DebitCardDetail){
    this.debitCard = debitCard;
    this.updateCarouselDebitCards(debitCard);
    if(this.debitCardsDetailsComponent){
      this.debitCardsDetailsComponent.enableOrDisableButton();
    }
    
  }

  /*
   * Update Right Carousel
   */
  updateCarouselDebitCards(debitCard:DebitCardDetail) {
    let debitCardList = this.fetchDebitCardDetailsResponse.cardDetails;
    this.carouselDebitCardList = debitCardList.filter(debitCardItem => debitCardItem.cardNumber !== debitCard.cardNumber);
  }

 /*
  * On click of any Carousel Debit Card
  */ 
  carouselDebitCardSelection(debitCard:DebitCardDetail){
    this.debitCardToBeDisplayed(debitCard);
  }
}