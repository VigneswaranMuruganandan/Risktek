import { Component, OnInit, Input, ViewChild} from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { CardsService} from '../services/cards.service';
import { SharedService} from '../../shared/services/shared.service';
import { FetchCreditCardDetailsResponse} from '../model/fetchCreditCardDetailsResponse';
import { CreditCardDetail} from '../model/creditCardDetail';
import { ErrorService } from '../../shared/services/error.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { CreditCardsDetailsComponent} from './creditCardsDetails.component';

@Component({
  templateUrl: './../templates/creditCardsMain.html'
})
export class CreditCardsMainComponent implements OnInit {
	
	public fetchCreditCardDetailsResponse:FetchCreditCardDetailsResponse;
  public creditCardDetail:CreditCardDetail;
  public creditCard:CreditCardDetail;
  public carouselCreditCardList:CreditCardDetail[];
  @ViewChild(CreditCardsDetailsComponent) creditCardsDetailsComponent: CreditCardsDetailsComponent;

  constructor( private cardsService: CardsService,
               private sharedService: SharedService,
               private errorService: ErrorService,
               private spinnerService: SpinnerService) {}

  ngOnInit() {
      this.spinnerService.startSpinner('loader');
      this.fetchCreditCards();
      this.errorService.resetErrorResp();
  }
	
 /*
 * Fetch all Credit Cards list
 */
	fetchCreditCards(){
		this.cardsService.fetchCreditCardList()
			.subscribe(
              resp => this.handleCreditCardsResp(resp),
              error => this.sharedService.handleError(error)
          	);
	}

	/*
   * Handle Credit Card Details Response
   */
	private handleCreditCardsResp(resp:FetchCreditCardDetailsResponse){
		  this.spinnerService.stopSpinner('loader');
      if (resp.result.status == "success") {
          this.fetchCreditCardDetailsResponse = new FetchCreditCardDetailsResponse();
          this.fetchCreditCardDetailsResponse = resp;
          if(this.fetchCreditCardDetailsResponse.cardDetails && 
                        this.fetchCreditCardDetailsResponse.cardDetails.length>0 ){
            let creditCard = this.fetchCreditCardDetailsResponse.cardDetails[0];
            this.creditCardToBeDisplayed(creditCard);
          }
      } else {
          this.errorService.setErrorResp(resp.result);
          console.log(resp.result.status);
      }
	}

  /*
   * Initialise the CreditCard To be displayed 
   * and update rest Credit Cards in right Carousel
   */
  creditCardToBeDisplayed(creditCard:CreditCardDetail){
    this.creditCard = creditCard;
    this.updateCarouselCreditCards(creditCard);
    if(this.creditCardsDetailsComponent){
      this.creditCardsDetailsComponent.enableOrDisableButton();
    }
    
  }

  /*
   * Update Right Carousel
   */
  updateCarouselCreditCards(creditCard:CreditCardDetail) {
    let creditCardList = this.fetchCreditCardDetailsResponse.cardDetails;
    this.carouselCreditCardList = creditCardList.filter(creditCardItem => creditCardItem.cardNumber !== creditCard.cardNumber);
  }

 /*
  * On click of any Carousel Credit Card
  */ 
  carouselCreditCardSelection(creditCard:CreditCardDetail){
    this.creditCardToBeDisplayed(creditCard);
  }
}