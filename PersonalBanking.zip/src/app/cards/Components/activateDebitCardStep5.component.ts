import { Component, OnInit, Input} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {TemplateService} from '../../shared/services/template.service';
import { APIResponse } from '../../shared/model/apiResponse';
import { GlobalVariable} from '../../shared/services/global';
import { Router } from '@angular/router';

@Component({
  selector: 'activateDebitCardStep5-component',
  templateUrl: './../templates/activateDebitCardStep5.html'
})
export class ActivateDebitCardStep5Component{
	
	@Input() activateCardResponse:APIResponse;

	  constructor( private router: Router) {}	

	redirectToContactUs(){
		this.router.navigate([GlobalVariable.ROUTE_MAPPING.CONTACT_US]);
	}
}