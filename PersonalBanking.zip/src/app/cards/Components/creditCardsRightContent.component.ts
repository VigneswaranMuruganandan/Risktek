import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {CreditCardDetail} from '../model/creditCardDetail';

@Component({
  selector: '[creditcardrightcontent-component]',
  templateUrl: './../templates/creditCardsRightContent.html'
})
export class CreditCardsRightContentComponent{
	
	@Input() carouselCreditCardList:CreditCardDetail[];
	@Output() carouselCreditCardEvent = new EventEmitter();

	carouselCreditCard(card:CreditCardDetail){
	  	this.carouselCreditCardEvent.emit(card);
	  }
	
	
}