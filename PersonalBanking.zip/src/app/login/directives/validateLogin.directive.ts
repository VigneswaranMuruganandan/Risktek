import { Component, ElementRef, Directive, HostListener, NgZone, Input, Output, EventEmitter } from '@angular/core';
import * as $ from 'jquery';
import {TemplateService} from '../../shared/services/template.service';

import 'app/assets/js/jquery.validate.js';

/*
* Login Form validation for Registration
*/
@Directive({
    selector: '[ValidateLoginDirective]',
})
export class ValidateLogin {
    //private x = require('jquery-validator');
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}

    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let loginValidationSubmit;
        this.zone.runOutsideAngular(() => {
            var loginValidation = (<any>$("#loginForm")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    userName: {
                        required: true
                    },
                    password: {
                        required: true
                    }
                },
                messages: {
                    userName: {
                        required: "Please enter Customer Identification Number"
                    },
                    password: {
                        required: "Please enter Password"
                    }
                }
            });
            loginValidationSubmit = loginValidation.form();
            this.templateService.setFormValidatorFlag(loginValidationSubmit);
        });
    }
}



@Directive({
    selector: '[ValidateOpenAccountDirective]',
})
export class ValidateOpenAccount {
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}

    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let openAccountValidationSubmit;
        this.zone.runOutsideAngular(() => {
            var openAccountValidation = (<any>$("#openAccountform")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input,select,textarea")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    accountType: {
                        required: true
                    },
                    firstName: {
                        required: true
                    },
                    lastName: {
                        required: true
                    },
                    email: {
                        required: true
                    },
                    dateOfBirth: {
                        required: true
                    },
                    emirates: {
                        required: true
                    },
                    nationality: {
                        required: true
                    },
                    company: {
                        required: true
                    },
                    salaryCurrency: {
                        required: true
                    },
                    monthlySalary: {
                        required: true
                    },
                    PhoneNumber: {
                        required: true
                    },
                    mobileNumber: {
                        required: true
                    },
                    hearAboutUs: {
                        required: true
                    },
                    comments: {
                        required: true
                    }
                },
                messages: {
                    accountType: {
                        required: "Please make a selection"
                    },
                    firstName: {
                        required: "Please fill"
                    },
                    lastName: {
                        required: "Please fill"
                    },
                    email: {
                        required: "Please fill"
                    },
                    dateOfBirth: {
                        required: "Please make a selection"
                    },
                    emirates: {
                        required: "Please make a selection"
                    },
                    nationality: {
                        required: "Please fill"
                    },
                    company: {
                        required: "Please fill"
                    },
                    salaryCurrency: {
                        required: "Please make a selection"
                    },
                    monthlySalary: {
                        required: "Please fill"
                    },
                    PhoneNumber: {
                        required: "Please fill"
                    },
                    mobileNumber: {
                        required: "Please fill"
                    },
                    hearAboutUs: {
                        required: "Please make a selection"
                    },
                    comments: {
                        required: "Please fill"
                    }
                }
            });
            openAccountValidationSubmit = openAccountValidation.form();
            this.templateService.setFormValidatorFlag(openAccountValidationSubmit);
        });
    }
}