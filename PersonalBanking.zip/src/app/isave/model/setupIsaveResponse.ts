import { APIResponse } from '../../shared/model/apiResponse';
import { Amount } from '../../shared/model/amount';
import { Product } from '../../shared/model/product';

export class SetupIsaveResponse  extends APIResponse {
   fundingSources : Product[];
   purposeChoices : string[];
   frequencies : string[];
   dailyTransferLimit :Amount;
   currencies : string[];
   instructionNotes :string;
   receivingPoints :Product[];
}