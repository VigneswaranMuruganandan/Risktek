import { Amount } from '../../shared/model/amount';

export class ModifyRegularSaving {
   siRefNumber :string;
   isaveAccountIdentifier :string;
   frequency :string;
   transactionAmount :Amount;
   startDate :string;
   endDate :string;
}