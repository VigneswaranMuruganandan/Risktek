export class updateIsaveRequest {
	cin :string;
	isaveAccountIdentifier :string;
	accountDescription :string;
	accountPurpose :string;
	interestCondition :string;
	currency :string;
	balance :string;
}