import { Amount } from '../../shared/model/amount';

export class ISave {
	cin :string;
	isaveAccountIdentifier :string;
	accountDescription :string;
	accountPurpose :string;
	interestCondition :string;
	currency :string;
	balance :Amount;
	$$index: number;
	isRegularSavingSetup :boolean;
	isaveRegularSavingIdentifier :string;
}

