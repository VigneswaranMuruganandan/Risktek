import { Amount } from '../../shared/model/amount';

export class RegularSaving {
   siRefNumber :string;
   debitAccountNo :string;//source
   debitAccountNickname :string;
   debitAccountPurpose :string;
   isaveAccountIdentifier :string;//destination
   isaveAccountNickname :string;
   frequency :string;
   transactionAmount :Amount;
   startDate :string;
   endDate :string;
   isaveAccountPurpose :string;
   $$index :number
}