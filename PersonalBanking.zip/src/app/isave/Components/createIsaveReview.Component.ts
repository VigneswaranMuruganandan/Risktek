import { Component, OnInit, Input, Output, EventEmitter, ViewChild, OnDestroy } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ErrorService } from '../../shared/services/error.service';
import { SharedService } from '../../shared/services/shared.service';
import { SetupIsaveResponse } from '../model/setupIsaveResponse';
import { CreateIsaveRequest } from '../model/createIsaveRequest';
import { TemplateService } from '../../shared/services/template.service';
import { Product } from '../../shared/model/product';

@Component({
  selector: 'createIsaveReview-component',
  templateUrl: './../templates/createIsaveReview.html'
})
export class CreateIsaveReviewComponent implements OnInit{
	@Output() backIsaveAccountEvent = new EventEmitter();
	@Output() submitIsaveAccountEvent = new EventEmitter();
	@Input() setupIsaveResponse :SetupIsaveResponse;
	@Input() createIsaveRequest :CreateIsaveRequest;
	product :Product;
	
	constructor( private errorService: ErrorService,
				 public templateService: TemplateService,
				 private sharedService: SharedService){}

	ngOnInit() {
		this.product = this.setupIsaveResponse.fundingSources[this.templateService.getSelectIndex(this.setupIsaveResponse.fundingSources,'prodRef',this.createIsaveRequest.sourceAccount)];
	}

	confirmIsave() {
		this.submitIsaveAccountEvent.emit();
	}

	back(){
		this.backIsaveAccountEvent.emit(1);
	}
}