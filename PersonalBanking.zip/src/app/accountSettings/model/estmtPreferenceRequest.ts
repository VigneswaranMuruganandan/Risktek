import { AuthRequest } from '../../shared/model/authRequest';

export class EstmtPreferenceRequest extends AuthRequest {
	eStatementPref :boolean;
	email :string;
}