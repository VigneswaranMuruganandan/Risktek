export class NickNameReq{
	productID :string ;
	nickName:string;
	isFavorite:boolean;
	isHide:boolean;
}