import { AuthRequest } from '../../shared/model/authRequest';

export class UpdateUsername extends AuthRequest{
	userName: string;
}