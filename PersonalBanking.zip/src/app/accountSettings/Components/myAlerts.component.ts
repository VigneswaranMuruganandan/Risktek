import { Component, OnInit, Input,Output, EventEmitter } from '@angular/core';
import { ProfileAlertRes } from '../model/profileAlertRes';
import { ProfileAlertReq } from '../model/profileAlertReq';
import {AccountSettingsService} from '../services/accountSettings.service';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    TranslateService,
    GlobalVariable
} from '../../shared';

@Component({
    selector: 'myalerts-component',
    templateUrl: './../templates/myAlerts.html'
})
export class MyAlertsComponent implements OnInit {
	profileAlertReq: ProfileAlertReq;
    profileAlertRes: ProfileAlertRes;    
    saveButtonShow = true;
    @Output() getTabCountEvent = new EventEmitter();

    constructor( private accountSettingsService: AccountSettingsService,
		         private sharedService: SharedService,
                 private templateService: TemplateService,
		         private errorService: ErrorService,
		         private spinnerService: SpinnerService) {}

    ngOnInit() {
        this.initAlertsPrefFetch();
        this.getAlertsHistory();
    }

    /*
    * Fetch Alerts Preference
    */
    initAlertsPrefFetch() {
        this.errorService.resetErrorResp();
        this.spinnerService.startSpinner("accountSettings")
        this.accountSettingsService.fetchAlertPref()
            .subscribe(
                resp => this.handleAlertPrefFetchResp(resp),
                error => this.sharedService.handleError(error)
            );
    }
    handleAlertPrefFetchResp(resp: ProfileAlertRes) {
        this.spinnerService.stopSpinner("accountSettings");
        if (resp && resp.result.status == 'success') {
            console.log(resp);
            this.profileAlertRes = new ProfileAlertRes();
            this.profileAlertRes = resp;
            this.setAlertProfileReq();
        } else if (resp.result.status == 'error') {
            this.errorService.setErrorResp(resp.result);
        }
    }

    setAlertProfileReq() {
        this.profileAlertReq = new ProfileAlertReq();
        let data = JSON.stringify(this.profileAlertRes);
        this.profileAlertReq = JSON.parse(data);
    }

    onAlertChange(checked: boolean, channel: string, type: string) {
        if (checked) {
            this.profileAlertReq[type][channel] = true;
        } else {
            this.profileAlertReq[type][channel] = false;
        }
        this.saveButtonShow = this.templateService.dataComparsion(this.profileAlertRes,this.profileAlertReq);
    }
    /*
    * Save Alert Preference
    */
    saveAlertPref() {
        console.log(this.profileAlertReq);
        this.errorService.resetErrorResp();
        this.spinnerService.startSpinner("accountSettings");
        this.accountSettingsService.updateAlertPref(this.profileAlertReq)
            .subscribe(
                resp => this.handleAlertPrefUpdateResp(resp),
                error => this.sharedService.handleError(error)
            );
    }
    
    handleAlertPrefUpdateResp(resp: ProfileAlertRes) {
        this.spinnerService.stopSpinner("accountSettings");
        if (resp && resp.result.status == 'success') {
            this.profileAlertRes = resp;
            this.saveButtonShow = false;
        } else if (resp.result.status == 'error') {
            this.errorService.setErrorResp(resp.result);
            this.saveButtonShow = true;
        }
    }

    /*
    * Fetch the total length of the Alerts from service
    */
    getAlertsHistory(){
        this.spinnerService.startSpinner('alertCenter');
        this.accountSettingsService.fetchAlertsHistory()
            .subscribe(
                resp => {
                    this.getTabCountEvent.emit({ count: resp.alertHistory.length, type: 'alertCount'});
                },
                error => this.sharedService.handleError(error)
            );
    }
}
