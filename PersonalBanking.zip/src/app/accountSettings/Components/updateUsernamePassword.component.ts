import { Component, OnInit, Input,Output, EventEmitter} from '@angular/core';
import { UpdateUsername } from '../model/updateUsername';
import { UpdatePassword } from '../model/updatePassword';
import { AccountSettingsService } from '../services/accountSettings.service';
import { VerifyOtpResponse } from '../../shared/model/verifyOtpResponse';
import { CustomerData } from '../../register/model/customerData';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    AppSession,
    TranslateService,
    UserDetails,
    UserContext,
    NameValuePair,
    APIResponse
} from '../../shared';

@Component({
  selector: 'updateUsernamePassword-component',
  templateUrl: './../templates/updateUsernamePassword.html'
})
export class UpdateUsernamePasswordComponent implements OnInit{
	public stepValue: number;
	public currentTabUserPwd :string;
	public oldUsername :string;
	public updateUsername: UpdateUsername;
	public updatePassword: UpdatePassword;
	public customerData: CustomerData;

	constructor(private accountSettingsService: AccountSettingsService,
                private sharedService: SharedService,
                private errorService: ErrorService,
                private spinnerService: SpinnerService,
                private router: Router) {}
	
	ngOnInit(){
		this.init();
	}
	/*
	* Init method for updating the username and password
	*/
	init(){
		this.stepValue = 1;
		this.currentTabUserPwd = "UPDATE_USERNAME";
		this.updateUsername = new UpdateUsername();
		this.updatePassword = new UpdatePassword();
		this.customerData = new CustomerData();
		this.customerData.userName = UserContext.getInstance().userDetails.userName;
	}
	/*
	* setting the current tab and maintaining
	*/
	setCurrentTab(tab :string){
		this.currentTabUserPwd = tab;
	}
	/*
	* verifying the Username and password through service
	*/
	verifyUpdateUsernamePassword(){	
		this.spinnerService.startSpinner('updateUsernamePassword');	
		if(this.currentTabUserPwd == "UPDATE_USERNAME"){
			this.accountSettingsService.verifyUserName(this.updateUsername)
            .subscribe(
                resp => this.handleVerifyUsername(resp),
                error => this.sharedService.handleError(error)
            );
		}
		if(this.currentTabUserPwd == "UPDATE_PASSSWORD"){
			this.accountSettingsService.verifyPassword(this.updatePassword)
            .subscribe(
                resp => this.handleVerifyUsername(resp),
                error => this.sharedService.handleError(error)
            );
		}
	}
	/*
	* Handle the verify Username response
	*/
	handleVerifyUsername(resp :VerifyOtpResponse){
		this.spinnerService.stopSpinner('updateUsernamePassword');	
		if(resp.result.status == 'success'){
            this.customerData.mobileNumber = resp.mobileNumberMasked;
            this.customerData.emailID = resp.emailMasked;
            this.customerData.otpDuration = resp.otpDuration;
            this.updateUsername.txnRef = resp.txnRef;
            this.stepValue = 2;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
			
        }
	}
	/*
	* Handle the verify Password response
	*/
	handleVerifyPassword(resp :VerifyOtpResponse){
		this.spinnerService.stopSpinner('updateUsernamePassword');	
		if(resp.result.status == 'success'){
            this.customerData.mobileNumber = resp.mobileNumberMasked;
            this.customerData.emailID = resp.emailMasked;
            this.customerData.otpDuration = resp.otpDuration;
            this.updatePassword.txnRef = resp.txnRef;
            this.stepValue = 2;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
			
        }
	}
	/*
	* Update the Username and Password through service call
	*/
	validateUpdateUsernamePassword(otp :string){
		this.spinnerService.startSpinner('updateUsernamePassword');
		if(otp){
			if(this.currentTabUserPwd == "UPDATE_USERNAME"){
				this.updateUsername.authKey = otp;
				this.accountSettingsService.updateUserName(this.updateUsername)
	            .subscribe(
	                resp => this.handleUpdateUsername(resp),
	                error => this.sharedService.handleError(error)
	            );
			}
			if(this.currentTabUserPwd == "UPDATE_PASSSWORD"){
				this.updatePassword.authKey = otp;
				let updatePassword = new UpdatePassword();
				updatePassword.txnRef = this.updatePassword.txnRef;
				updatePassword.authKey = this.updatePassword.authKey;
				updatePassword.pwd = this.updatePassword.newPwd;
				updatePassword.authKey = this.updatePassword.authKey;
				this.accountSettingsService.updatePassword(updatePassword)
	            .subscribe(
	                resp => this.handleUpdatePassword(resp),
	                error => this.sharedService.handleError(error)
	            );
			}
		}
	}
	/*
	* Handle the update response for Username
	*/
	handleUpdateUsername(resp :APIResponse){
		this.spinnerService.stopSpinner('updateUsernamePassword');
		if(resp.result.status == 'success'){
            this.stepValue = 3;
            UserContext.getInstance().userDetails.userName = this.updateUsername.userName;
        }else if (resp.result.status == 'error') {
            let nextStep = this.errorService.handleOTPError(resp.result);
            if(nextStep) {
                this.stepValue = 3;
            }
        }
	}
	/*
	* Handle the update response for Password
	*/
	handleUpdatePassword(resp :APIResponse){
		this.spinnerService.stopSpinner('updateUsernamePassword');
		if(resp.result.status == 'success'){
            this.stepValue = 3;
        }else if (resp.result.status == 'error') {
            let nextStep = this.errorService.handleOTPError(resp.result);
            /*if(nextStep) {
                this.stepValue = 3;
            }*/
        }
	}
	/*
	* Back functionality for Update Username and Password
	*/	
	backUpdateUsernamePassword(step :number){
		this.stepValue = step;
	}

}