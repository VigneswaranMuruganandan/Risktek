import { Component, OnInit, Input,Output, EventEmitter} from '@angular/core';
import {
    SharedService, SpinnerService, ErrorService, TemplateService, Router, TranslateService
} from '../../shared';

@Component({
  selector: 'updateEmailStep2-component',
  templateUrl: './../templates/updateEmailStep2.html'
})
export class UpdateEmailStep2Component implements OnInit{
	@Output() validateUpdateEmailEvent = new EventEmitter();
	@Output() backUpdateEmailEvent = new EventEmitter();

	constructor( private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService) {}
	
	ngOnInit(){}

	validateOTP(otp : string){
		if(otp){
			this.errorService.resetErrorResp();
			this.validateUpdateEmailEvent.emit(otp);
		}
	}

	back(){
		this.backUpdateEmailEvent.emit(1);
	}

}