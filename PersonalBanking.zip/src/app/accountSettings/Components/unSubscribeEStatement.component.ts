import { Component, OnInit, Input, Output, EventEmitter, ViewChild} from '@angular/core';
import { AccountSettingsService } from '../services/accountSettings.service';
import { PreferenceRequest } from '../model/preferenceRequest';
import { EstmtPreferenceRequest } from '../model/estmtPreferenceRequest';
import { VerifyOtpResponse } from '../../shared/model/verifyOtpResponse';
import { UpdateEmailComponent } from './updateEmail.component';
import {
    SharedService, SpinnerService, ErrorService, TemplateService, Router, TranslateService, ServerError, Product, GlobalVariable, AppSession, UserDetails, UserContext, APIResponse
} from '../../shared';
import { CustomerData } from '../../register/model/customerData';

@Component({
  selector: 'unSubscribeEStatement-component',
  templateUrl: './../templates/unSubscribeEStatement.html'
})
export class UnSubscribeEStatementComponent {
	public userDetails: UserDetails;
  public customerData: CustomerData;
  public estmtPreferenceRequest :EstmtPreferenceRequest;
  @ViewChild(UpdateEmailComponent) updateEmail: UpdateEmailComponent;
  @Output() updateParentDataEvent = new EventEmitter();

	constructor( private sharedService: SharedService,
                 private router: Router,
                 private templateService: TemplateService,
                 private spinnerService: SpinnerService,
                 private accountSettingsService: AccountSettingsService,
                 private errorService: ErrorService) {}
	
	init(){
		this.userDetails = UserContext.getInstance().userDetails;
    this.customerData = new CustomerData();
	}

  saveUnSubscribeEStatement(valid :boolean){
      if(valid){
          this.accountSettingsService.deactivateEstatement()
          .subscribe(
              resp => this.handleDeactivateEstatement(resp),
              error => this.sharedService.handleError(error)
          );
      }
  }

  handleDeactivateEstatement(resp :APIResponse){
      if(resp.result.status == 'success'){
          (<any>$('#unSubscribeEmail')).modal('hide');
          this.userDetails.estatementPreference = false;
          this.updateParentDataEvent.emit();
      }else if(resp.result.status == 'error'){
          this.errorService.setErrorResp(resp.result);            
      }
  }

  editEmailAddress(){
      (<any>$('#unSubscribeEmail')).modal('hide');
      this.router.navigate(['/accountsettings/personalInformation']);
      this.spinnerService.startSpinner('accountSettings'); 
      setTimeout(()=> {
        this.spinnerService.stopSpinner('accountSettings');
        (<any>$('#updateEmail')).click();
      }, 2000);
  }
}