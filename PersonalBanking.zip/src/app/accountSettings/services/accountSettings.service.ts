import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import {ServiceInvoker} from '../../shared/connector/serviceInvoker.service';
import {EncryptionService} from '../../shared/services/encryption.service';
import { NickNameReq } from '../model/nickNameReq';
import { APIResponse } from '../../shared/model/apiResponse';
import { VerifyOtpResponse } from '../../shared/model/verifyOtpResponse';
import { ProfileAlertRes } from '../model/profileAlertRes';
import { ProfileAlertReq } from '../model/profileAlertReq';
import { AlertCentreResp } from '../model/alertCentreResp';
import { UpdateUsername } from '../model/updateUsername';
import { UpdatePassword } from '../model/updatePassword';
import { PreferenceRequest } from '../model/preferenceRequest';
import { EstmtPreferenceRequest } from '../model/estmtPreferenceRequest';
import { UserDetails } from '../../shared/model/userDetails';
import {
    SessionContext,
    AppSession,
    GlobalVariable,
    GlobalURL
} from '../../shared';

@Injectable()
export class AccountSettingsService {

  	constructor(private serviceInvoker: ServiceInvoker, 
                private encryptionService: EncryptionService) {}

    updateNickName(req:NickNameReq): Observable <APIResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ACCOUNTSETTINGS.UPDATENICKNAME,req)
                                .map(resp => JSON.parse(resp));
    }
    
    fetchAlertPref():Observable <ProfileAlertRes>{
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ACCOUNTSETTINGS.ALERTS_PREFERENCE_FETCH,null)
                                .map(resp => JSON.parse(resp));
    }

    updateAlertPref(req:ProfileAlertReq):Observable <ProfileAlertRes>{
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ACCOUNTSETTINGS.ALERTS_PREFERENCE_UPDATE,req)
                                .map(resp => JSON.parse(resp));
    }

    fetchAlertsHistory():Observable <AlertCentreResp>{
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ACCOUNTSETTINGS.GET_ALERTS_HISTORY,null)
                                .map(resp => JSON.parse(resp));
    }

    verifyUserName(updateUsername: UpdateUsername):Observable <VerifyOtpResponse>{
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ACCOUNTSETTINGS.VERIFY_USERNAME, updateUsername)
                                .map(resp => JSON.parse(resp));
    }

    updateUserName(updateUsername: UpdateUsername):Observable <APIResponse>{
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ACCOUNTSETTINGS.UPDATE_USERNAME, updateUsername)
                                .map(resp => JSON.parse(resp));
    }

    verifyPassword(updatePassword: UpdatePassword):Observable <VerifyOtpResponse>{
      let data = new UpdatePassword();
      data = Object.assign({}, updatePassword);
      console.log(SessionContext.getInstance().userID);
      let oldPwdHash = this.encryptionService.generatePwdHash(SessionContext.getInstance().userID, data.oldPwd);
      let newPwdHash = this.encryptionService.generatePwdHash(SessionContext.getInstance().userID, data.newPwd);
      let confirmPwdHash = this.encryptionService.generatePwdHash(SessionContext.getInstance().userID, data.confirmPwd);
      data.oldPwd = this.encryptionService.convertToBase64(oldPwdHash);
      data.newPwd = this.encryptionService.convertToBase64(newPwdHash);
      data.confirmPwd = this.encryptionService.convertToBase64(confirmPwdHash);
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ACCOUNTSETTINGS.VERIFY_PASSWORD, data)
                                .map(resp => JSON.parse(resp));
    }

    updatePassword(updatePassword: UpdatePassword):Observable <APIResponse>{
      let pwdHash = this.encryptionService.generatePwdHash(SessionContext.getInstance().userID, updatePassword.pwd);
      updatePassword.pwd = this.encryptionService.convertToBase64(pwdHash);
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ACCOUNTSETTINGS.UPDATE_PASSWORD, updatePassword)
                                .map(resp => JSON.parse(resp));
    }

    otpForEmailEstatement(preferenceRequest: PreferenceRequest):Observable <VerifyOtpResponse>{
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ACCOUNTSETTINGS.OTP_EMAIL_ESTATEMENT, preferenceRequest)
                                .map(resp => JSON.parse(resp));
    }

    updateEmailEstatement(estmtPreferenceRequest: EstmtPreferenceRequest):Observable <UserDetails>{
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ACCOUNTSETTINGS.UPDATE_EMAIL_ESTATEMENT, estmtPreferenceRequest)
                                .map(resp => JSON.parse(resp));
    }

    deactivateEstatement():Observable <APIResponse>{
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ACCOUNTSETTINGS.DEACTIVATE_ESTATEMENT, null)
                                .map(resp => JSON.parse(resp));
    }

}


