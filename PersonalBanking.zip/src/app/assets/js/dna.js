var client;
var dnaGlobal;
init();
setDeviceCookie();
collectingSystemInfo();

function init() {
    try {
        //checkCookie();
        client = new ca.rm.Client();
        console.log(client);
        var contextPath = "http://localhost:6798";
        client.setProperty("baseurl", contextPath);
        client.loadFlash(readyCallback);

    } catch (e) {
        alert(e.message);
    }
}

function collectingSystemInfo() {
    client.processDNA();
    var json = client.getDNA();
    var did = client.getDID();
    //alert("Device DNA : "+json);
    //alert("Device ID : "+did);
    document.getElementById("dna").value=json;
    dnaGlobal=json;
    //document.CollectMFPToEvaluate.DDNA = json;
    //document.CollectMFPToEvaluate.DeviceID = did ;
}

function readyCallback(flag) {
    configureClient();
    client.processDNA();
}

function configureClient(flag) {
    client.setProperty("format", "json");
    client.setProperty("didname", "RISKFORT_COOKIE");
}
function setDeviceCookie() {
    var did = getCookiesValue("RISKFORT_COOKIE");

    if (did && did != null && did.trim() != "") {
        var client = new ca.rm.Client();
        client.processDNA();

        client.setProperty("didname", "RISKFORT_COOKIE");
        client.setDID(did);
    }

};
function getCookiesValue(value) {
    var name = value + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') c = c.substring(1);
        if (c.indexOf(name) == 0)
            return c.substring(name.length, c.length);
    }
    return "";
}; 