import { Offer } from './offer';
import { APIResponse } from '../../shared/model/apiResponse';

export class OffersResponse extends APIResponse{
    offers: Offer[];
}