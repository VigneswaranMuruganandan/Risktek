import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'outsideUAEAddBeneStep2-component',
  templateUrl: './../templates/outsideUAEAddBeneStep2.html'
})
export class OutsideUAEAddBeneStep2Component {

	@Output() validateTransferFormNextButtonEvent = new EventEmitter();
	@Output() backToBeneFormButtonEvent = new EventEmitter();


	validateTransferForm(){
		this.validateTransferFormNextButtonEvent.emit();
	}

	backToBeneForm(){
		this.backToBeneFormButtonEvent.emit();
	}
    
    
}
