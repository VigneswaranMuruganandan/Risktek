import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    TranslateService,
    ServerError,
    Product,
    GlobalVariable,
    UserContext
} from '../../shared';
import {CreateBeneficiaryRequest} from '../model/createBeneficiaryRequest';
import {CreateBeneficiaryResponse} from '../model/createBeneficiaryResponse';
import { BeneficiariesService} from '../services/beneficiaries.service';

@Component({
  selector: 'withinUAEAddBeneStep4-component',
  templateUrl: './../templates/withinUAEAddBeneStep4.html'
})
export class WithinUAEAddBeneStep4Component implements OnInit{ 	
 	@Input() createBeneficiaryRequest:CreateBeneficiaryRequest;
	@Input() createBeneficiaryResponse:CreateBeneficiaryResponse;
  @Output() reloadStepOneEvent = new EventEmitter();
  public serverError :ServerError;
  public editBeneficiary:boolean

    ngOnInit() {
    	this.generateError();
      if(UserContext.getInstance().addOrEditBeneficiary == GlobalVariable.OPERATION_TYPE.ADD){
      this.editBeneficiary = false;
      }else{
        this.editBeneficiary = true;
      }
    }

    constructor( private beneficiariesService:BeneficiariesService,
    			       public translate: TranslateService,
	               private sharedService: SharedService,
	               private errorService: ErrorService,
	               private spinnerService: SpinnerService,
	               private router: Router){}

    addAnotherBene(){
      UserContext.getInstance().addOrEditBeneficiary = GlobalVariable.OPERATION_TYPE.ADD;
      this.reloadStepOneEvent.emit();
    }

    transferBeneficiary(){
    	this.spinnerService.startSpinner('loader');
    	this.beneficiariesService.fetchBeneTransferList()
	     .subscribe(
	         resp => {
	         	this.spinnerService.stopSpinner('loader');
	         	if (resp.result.status == "success") {
			        let data = resp.beneficiaryList;
			        data = data.filter(beneItem => {
                      if((beneItem.type == GlobalVariable.TRANSFER_TYPES.WITHIN_UAE_FUNDS_TRANSFER) && (beneItem.nickName == this.createBeneficiaryRequest.nickName)){
                        return beneItem;
                      }
                    });
			        UserContext.getInstance().transferData = data[0];
      					this.router.navigate([GlobalVariable.ROUTE_MAPPING.TRANSFER_WITHINUAE]);
  			    }else if (resp.result.status == 'error') {
  			        this.errorService.setErrorResp(resp.result);
  			    }
	         },
	         error => this.sharedService.handleError(error)
	     );
	}

    generateError(){
      this.serverError = new ServerError();
      this.serverError.backButton = {"text":"Back to Add Beneficiary","router":GlobalVariable.ROUTE_MAPPING.BENEFICIARIES};
      this.translate.get('SERVERERROR.ADDBENEFICIARYTRANSFERWITHINUAE',{param1: this.createBeneficiaryRequest.receiverName})
      .subscribe((value: string) => {
          this.serverError.errorDescription = value;
      });
    }
}
