import {LeadsBaseRequest} from '../../applyForProducts/model/leadsBaseRequest';

export class LeadRequest extends LeadsBaseRequest{
	products: string [];
	name: string;
}