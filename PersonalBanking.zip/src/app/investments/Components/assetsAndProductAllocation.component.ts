import { Component, OnInit, Input} from '@angular/core';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    AppSession,
    TranslateService,
    UserDetails,
    UserContext
} from '../../shared';
import { InvestmentsService } from '../services/investments.service';
import { AssetProductAllocationResponse } from '../model/assetProductAllocationResponse';
import { WealthEnquiryRequest } from '../model/wealthEnquiryRequest';
import {RelationshipManager} from '../model/relationshipManager';

@Component({
	templateUrl: './../templates/assetsAndProductAllocation.html'
})
export class AssetsAndProductAllocationComponent implements OnInit {
	public relationshipManager: RelationshipManager;
	public assetAllocation :any;
	public productAllocation :any;
	public wealthEnquiryRequest :WealthEnquiryRequest;
	public userDetails: UserDetails;

	constructor( private templateService: TemplateService,
				 private investmentsService: InvestmentsService, 
    			 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService) {}

	ngOnInit(){
		this.errorService.resetErrorResp();
		this.initRMDetails();
		this.initProductAllocation();
		this.initAssetAllocation();
		this.userDetails = new UserDetails();
		this.userDetails = UserContext.getInstance().userDetails;
	}

	initRMDetails(){
        if(AppSession.getInstance().isRelationshipManager){
        	this.relationshipManager = new RelationshipManager();
        	this.relationshipManager = AppSession.getInstance().relationshipManager
        }
	}
	/*
	* Product Allocation service call
	*/
	initProductAllocation(){
		this.spinnerService.startSpinner('productAllocation');
		this.wealthEnquiryRequest = new WealthEnquiryRequest();
		this.wealthEnquiryRequest.asOnDate = this.templateService.getTodaydate('YYYYMMDD');
		this.investmentsService.fetchProductAllocation(this.wealthEnquiryRequest)
            .subscribe(
                resp => this.handleProductAllocation(resp),
                error => this.sharedService.handleError(error)
            );
	}
	/*
	* Handle the Product Allocation
	*/
	handleProductAllocation(resp :any){
		this.spinnerService.stopSpinner('productAllocation');
		if(resp.result.status == 'success'){
            this.productAllocation = resp;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
	}
	/*
	* Asset Allocation Service call
	*/
	initAssetAllocation(){
		this.spinnerService.startSpinner('assetAllocation');
		this.wealthEnquiryRequest = new WealthEnquiryRequest();
		this.wealthEnquiryRequest.asOnDate = this.templateService.getTodaydate('YYYYMMDD');
		this.investmentsService.fetchAssetAllocation(this.wealthEnquiryRequest)
            .subscribe(
                resp => this.handlefetchAssetAllocation(resp),
                error => this.sharedService.handleError(error)
            );
	}
	/*
	* Handle the Asset allocation service call
	*/
	handlefetchAssetAllocation(resp :any){
		this.spinnerService.stopSpinner('assetAllocation');
		if(resp.result.status == 'success'){
            this.assetAllocation = resp;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
	}
}