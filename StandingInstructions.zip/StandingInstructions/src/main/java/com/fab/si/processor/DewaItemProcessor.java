/**
 * 
 */
package com.fab.si.processor;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

import com.fab.si.common.ApplicationConstants;
import com.fab.si.common.ServiceUrls;
import com.fab.si.common.TransactionStatus;
import com.fab.si.helper.HttpConnector;
import com.fab.si.helper.JsonUtils;
import com.fab.si.helper.SIUtility;
import com.fab.si.model.common.ConnectorResponse;
import com.fab.si.model.common.SIDetails;
import com.fab.si.model.payment.BalanceEnquiryResponse;
import com.fab.si.model.payment.BillerPaymentResponse;
import com.fab.si.model.payment.DewaBalanceEnquiryRequest;
import com.fab.si.model.payment.DewaBillPaymentRequest;
import com.fab.si.repository.SITransactionRepository;

/**
 * @author o4359
 *
 */
public class DewaItemProcessor implements ItemProcessor<SIDetails, SIDetails> {

	private Logger log = LoggerFactory.getLogger(getClass());

	@Autowired
	private HttpConnector httpConnect;

	@Autowired
	private SIUtility siUtility;

	@Autowired
	private SITransactionRepository siTxnRepo;

	@Override
	public SIDetails process(SIDetails siDetails) throws Exception {

		final String siId = siDetails.getSiID();
		log.info("{} - DEWA Object in Item Processor: {}", siId, siDetails);

		// UPDATE IN SI TRANSACTIONS
		siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.VALIDATE_RULES, null));
		// CALL DEWA BALANCE ENQUIRY
		BalanceEnquiryResponse balEnqRes = this.dewaBalanceEnquiry(siDetails);
		if (balEnqRes != null) {
			final String amountDue = balEnqRes.getAmountDue();

			log.info("{} - Dewa Amount Due: {}", siId, amountDue);

			if (StringUtils.isNotBlank(amountDue)) {
				BillerPaymentResponse paymentRes = null;
				if (ApplicationConstants.ACCOUNT.equalsIgnoreCase(siDetails.getSourceType())) {
					// UPDATE IN SI TRANSACTIONS
					siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.PAYMENT_PROCESSING, null));
					// PAYMENT
					paymentRes = this.dewaAccountPayment(balEnqRes, siDetails);
					// UPDATE IN SI TRANSACTIONS
					if (paymentRes != null) {
						siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(paymentRes, siDetails, TransactionStatus.PAYMENT_STATUS, null));
					} else {
						siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(paymentRes, siDetails, TransactionStatus.INTERNAL_ERROR, null));
					}
				} else if (ApplicationConstants.CARD.equalsIgnoreCase(siDetails.getSourceType())) {
					// UPDATE IN SI TRANSACTIONS
					siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.PAYMENT_PROCESSING, null));
					paymentRes = this.dewaCardPayment(balEnqRes, siDetails);
					// UPDATE IN SI TRANSACTIONS
					if (paymentRes != null) {
						siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(paymentRes, siDetails, TransactionStatus.PAYMENT_STATUS, null));
					} else {
						siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(paymentRes, siDetails, TransactionStatus.INTERNAL_ERROR, null));
					}
				}
			} else {
				log.info("{} - Invalid Dewa Balance Enquiry Response", siId);
				siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.VALIDATE_RULES_FAILED, siUtility.prepareFailureResponseStatus()));
			}
		}
		return siDetails;
	}

	/**
	 * This method is to prepare DewaBalanceEnquiryRequest Object
	 * 
	 * @param siDetails
	 * @return DewaBalanceEnquiryRequest Object
	 */
	private DewaBalanceEnquiryRequest prepareDewaBalEnqReq(final SIDetails siDetails) {
		DewaBalanceEnquiryRequest dewaBalanceReq = new DewaBalanceEnquiryRequest();
		final String dewaConsumerNo = siDetails.getCreditAcctNo();
		if (StringUtils.isNotBlank(dewaConsumerNo)) {
			dewaBalanceReq.setDewaConsumer(siUtility.prepareBalEnqReq(siDetails, ApplicationConstants.DEWA));
		}
		dewaBalanceReq.setCustomerIdentifier(siDetails.getCustomerIdentifier());
		return dewaBalanceReq;
	}

	/**
	 * This method is to execute Balance Inquiry Service
	 * 
	 * @param siDetails
	 * @return BalanceEnquiryResponse Object
	 */
	private BalanceEnquiryResponse dewaBalanceEnquiry(final SIDetails siDetails) {
		BalanceEnquiryResponse response = null;
		final String siId = siDetails.getSiID();
		final String requestJson = JsonUtils.convertToJson(this.prepareDewaBalEnqReq(siDetails));
		log.info("{} - Dewa Balance Enquiry Request: {}", siId, requestJson);
		// CREATE HTTP HEADERS
		Map<String, String> headers = siUtility.populateHeaders(siDetails.getChannelId());
		ConnectorResponse connResponse = httpConnect.post(ServiceUrls.DEWA_BALANCE_ENQ, requestJson, headers);
		if (connResponse.getResponseStatus() == 200) {
			log.info("{} - Dewa Balance Enquiry Response: {}", siId, connResponse.getJsonResponse());
			response = JsonUtils.convertToObject(BalanceEnquiryResponse.class, connResponse.getJsonResponse());
		}
		log.info("{} - Dewa BalanceEnquiryResponse: {}", siId, response);
		return response;
	}

	/**
	 * This method is to execute Account Payment Service
	 * 
	 * @param balEnqRes
	 * @param siDetails
	 * @return BillerPaymentResponse Object
	 */
	private BillerPaymentResponse dewaAccountPayment(final BalanceEnquiryResponse balEnqRes, final SIDetails siDetails) {
		BillerPaymentResponse response = null;
		final String siId = siDetails.getSiID();
		DewaBillPaymentRequest dewaPayment = new DewaBillPaymentRequest();
		dewaPayment.setDewaConsumer(siUtility.prepareBalEnqReq(siDetails, ApplicationConstants.DEWA));
		dewaPayment.setAccountPayment(siUtility.preparePaymentReq(siDetails, balEnqRes));
		dewaPayment.setCustomerIdentifier(siDetails.getCustomerIdentifier());
		final String requestJson = JsonUtils.convertToJson(dewaPayment);
		log.info("{} - Dewa Account Payment Request: {}", siId, requestJson);
		// CREATE HTTP HEADERS
		Map<String, String> headers = siUtility.populateHeaders(siDetails.getChannelId());
		ConnectorResponse connResponse = httpConnect.post(ServiceUrls.DEWA_PAYMENT_BYACCOUNT, requestJson, headers);
		if (connResponse.getResponseStatus() == 200) {
			log.info("{} - Dewa Account Payment JSON Response: {}", siId, connResponse.getJsonResponse());
			response = JsonUtils.convertToObject(BillerPaymentResponse.class, connResponse.getJsonResponse());
		}
		log.info("{} - Dewa Account BillerPaymentResponse: {}", siId, response);
		return response;
	}

	/**
	 * This method is to execute Card Payment Service
	 * 
	 * @param balEnqRes
	 * @param siDetails
	 * @return BillerPaymentResponse Object
	 */
	private BillerPaymentResponse dewaCardPayment(final BalanceEnquiryResponse balEnqRes, final SIDetails siDetails) {
		BillerPaymentResponse response = null;
		final String siId = siDetails.getSiID();
		DewaBillPaymentRequest dewaPayment = new DewaBillPaymentRequest();
		dewaPayment.setDewaConsumer(siUtility.prepareBalEnqReq(siDetails, ApplicationConstants.DEWA));
		dewaPayment.setCardPayment(siUtility.preparePaymentReq(siDetails, balEnqRes));
		dewaPayment.setCustomerIdentifier(siDetails.getCustomerIdentifier());
		final String requestJson = JsonUtils.convertToJson(dewaPayment);
		log.info("{} - Dewa Card Payment Request: {}", siId, requestJson);
		// CREATE HTTP HEADERS
		Map<String, String> headers = siUtility.populateHeaders(siDetails.getChannelId());
		ConnectorResponse connResponse = httpConnect.post(ServiceUrls.DEWA_PAYMENT_BYCARD, requestJson, headers);
		if (connResponse.getResponseStatus() == 200) {
			log.info("{} - Dewa Card Payment Response: {}", siId, connResponse.getJsonResponse());
			response = JsonUtils.convertToObject(BillerPaymentResponse.class, connResponse.getJsonResponse());
		}
		log.info("{} - Dewa Card BillerPaymentResponse: {}", siId, response);
		return response;
	}
}
