/**
 * 
 */
package com.fab.si.common;

/**
 * @author Pratik Das
 *
 */
public enum ErrorCodes {
	
	VRFY_CUST("Customer Verification Failed"),
	VRFY_OTP("Verification Failed"),
	USERNAME_PASSWORD_WRONG("Invalid credentials . Please Enter correct Username and password"),

	VRFY_CUST_FLD("Customer Verification Failed"),
	VRFY_CUST_INVALID(""),
	VRFY_OTP_MTCH_FLD("Verification Failed"),
	VRFY_OTP_MAX_ATTEMPTS_EXCEEDED("Otp max number of attempts exceeded"),
	VRFY_OTP_RESEND_TIMES_EXCEEDED("Otp max number of generations exceeded"),
	VRFY_PIN_EXISTS(""),	
	VRFY_CHNNL_ACCSS_FLD("Channel Access is blocked"), 
	
	KEY_GEN_FLD("Key Generation Failed"), 

	ACCESS_CTRL_DEVICE_MISMATCH("Invalid credentials"), 
	ACCESS_CTRL_CIF_MISMATCH("Invalid credentials"), 
	REG_UNAME_EXISTS("Username Already Exists , Kindly Enter a differenet username"),
	
	FRGT_PWD_IB("Password cannot be same as last password"),
	FRGT_PWD_INVALID_USER("You are not a registered customer , kindly register or call customer care"),
	FRGT_5PWD_IB("Password cannot be same as last 5 password"),
	
    LEAD_CREATION_FAILED(""),
	
	REG_EXISTS_CIF_DEVICE_ID(""), 
	REG_EXISTS_MB(""), 
	REG_EXISTS_MORE_DEVICES_MB(""), 
	REG_EXISTS_MORE_DEVICES_IB(""),
	REG_UNAME_SPL_CHAR(""),
	REG_UNAME_MIN_CHAR(""),
	REG_UNAME_MAX_CHAR(""),
	REG_UNAME_NA_CHAR(""),
	REG_INVALID_USER("Invalid User"),
	REG_INVALID_DEVICE("Registration Failed. Invalid Device."),
	REG_CHNNL_ACCSS_BLOCKED("Registration Failed. Access Blocked."), 
	REG_CHNNL_ACCSS_LOCKED("Registration Failed. Access Locked."), 
	REG_CHNNL_INACTIVE("Registration Failed. Channel Inactive."), // 6 months of inactivity	
	
	SYS_INVALID_OTP_STATE(""), 
	
	SYS_ACCESS_DENIED("Token Mismatch"), 
	SYS_HTTP_CON_FLD("Http Connection failed"), 
	SYS_HTTPS_CON_FLD("Https certificate load failed."), 
	SYS_MISSING_MAND_CONFIG("Missing mandatory service configuration."), 
	SYS_CONVRT("Exception in conversion"), 
	SYS_INVALID_CONDITION("Invalid condition"), 
	ACCT_NO_RECORDS_FOUND("No Record found"),

	SYS_DB_CONN_FLD("DB Connection failed"),
	SYS_DB_QRY_EX_FLD("Query execution failed"), 
	SYS_DB_UPD_EX_FLD("Update execution failed"), 
	SYS_DB_QRY_REC_NOT_FOUND("Record not found"),
	
	SYS_ERROR("Exception while processing request."),
	SYS_DEFAULT_ERROR("System is under maintenance and we will be back soon!"),
	MOBILENO_NOT_REGISTERED("Mobile No for the Customer is Not Registered"),
	
	INVALID_ACCOUNT("Dear Customer, the account number you have entered is incorrect. Please call SMART CALL for more info."),
	INSUFFICIENT_ACCOUNT_BALANCE("Dear Customer, you do not have sufficient balance in your account. Please call SMART CALL for more info."),
	POSTING_RESTRICTION("Dear Customer, the account number you have entered is not active. Please call SMART CALL for more info."),
	SALIK_MAX_MIN_AMT("Dear Customer, your salik Balance is more than the minimum amount."),
	BALANCE_ENQ_FAILED("Dear Customer, your consumer no set up for Standing Instructions is not valid. Please call SMART CALL for more info.");
	
	private String code;
	private String desc;
	
	private ErrorCodes(String desc) {
		this.code = name();
		this.desc = desc;
	}
	public String getCode() {
		return code;
	}
	public String getDesc() {
		return desc;
	}
}
