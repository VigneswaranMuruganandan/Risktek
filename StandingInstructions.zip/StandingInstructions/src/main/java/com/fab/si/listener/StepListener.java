/**
 * 
 */
package com.fab.si.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.stereotype.Component;

/**
 * @author o4359
 *
 */
@Component
public class StepListener implements StepExecutionListener {

	private Logger log = LoggerFactory.getLogger(getClass());

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		log.info("STEP {} COMPLETED FOR JOB {}", stepExecution.getStepName(), stepExecution.getJobExecution().getJobInstance().getJobName());
		return null;
	}

	@Override
	public void beforeStep(StepExecution stepExecution) {
		log.info("STEP {} STARTED FOR JOB {}", stepExecution.getStepName(), stepExecution.getJobExecution().getJobInstance().getJobName());
	}

}
