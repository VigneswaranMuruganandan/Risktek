/**
 * 
 */
package com.fab.si.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ItemReadListener;
import org.springframework.stereotype.Component;

/**
 * @author o4359
 *
 */
@Component
public class ReaderListener<T> implements ItemReadListener<T> {

	private Logger log = LoggerFactory.getLogger(getClass());

	@Override
	public void afterRead(T readListener) {
		log.info("SUCCESSFULLY READ DETAILS FROM DATABASE: {}", readListener.toString());
	}

	@Override
	public void beforeRead() {
		log.info("STARTING READ FOR DETAILS FROM DATABASE");
	}

	@Override
	public void onReadError(Exception exe) {
		log.error("ERROR WHILE READING DETAILS FROM DATABASE: {}", exe);
	}
}
