/**
 * 
 */
package com.fab.si.repository;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fab.si.common.ApplicationConstants;
import com.fab.si.common.ErrorCodes;
import com.fab.si.common.QueryConstants;
import com.fab.si.common.T24CompanyCodes;
import com.fab.si.model.common.SIDetails;
import com.fab.si.model.transfer.BeneficiaryDetails;
import com.fab.si.model.transfer.ErrorDetails;
import com.fab.si.model.transfer.TransferResponseStatus;

/**
 * @author o4359
 *
 */
@Component
public class CustomerRepository {

	private Logger log = LoggerFactory.getLogger(getClass());

	@Autowired
	private DataSource pbDataSource;

	@Resource(name = "ciDs")
	private DataSource ciDs;

	public TransferResponseStatus validateCustomerAccount(final SIDetails siDetails) {
		TransferResponseStatus status = new TransferResponseStatus();
		ResultSet rs = null;
		try (Connection con = ciDs.getConnection(); 
				PreparedStatement ps = con.prepareStatement(QueryConstants.SELECT_ACCT_VALIDATE_QUERY);) {

			ps.setString(1, siDetails.getDebitAccountNo());
			ps.setString(2, siDetails.getCustomerIdentifier());
			rs = ps.executeQuery();

			status.setStatus(ApplicationConstants.SUCCESS);
			int count = 0;
			ErrorDetails errorDetails = null;
			while (rs.next()) {
				errorDetails = new ErrorDetails();
				status.setStatus(ApplicationConstants.ERROR);
				count++;
				if (!ApplicationConstants.E.equals(rs.getString(ApplicationConstants.TXTACCTSTATUS)) && !ApplicationConstants.TWO.equals(rs.getString(ApplicationConstants.TXTACCTSTATUS))) {
					errorDetails.setErrorCode(ErrorCodes.POSTING_RESTRICTION.getCode());
					errorDetails.setErrorDesc(ErrorCodes.POSTING_RESTRICTION.getDesc());
				} else if (new BigDecimal(rs.getString(ApplicationConstants.NUMAVAILBAL)).compareTo(new BigDecimal(siDetails.getMaxAmount())) == -1) {
					errorDetails.setErrorCode(ErrorCodes.INSUFFICIENT_ACCOUNT_BALANCE.getCode());
					errorDetails.setErrorDesc(ErrorCodes.INSUFFICIENT_ACCOUNT_BALANCE.getDesc());
				}
				status.getErrorDetails().add(errorDetails);
			}
			if (count < 1) {
				if (errorDetails != null) {
					errorDetails.setErrorCode(ErrorCodes.INVALID_ACCOUNT.getCode());
					errorDetails.setErrorDesc(ErrorCodes.INVALID_ACCOUNT.getDesc());
				}
			}
		} catch (SQLException exe) {
			log.error("Exception Occured in validateCustomerAccount: {} ", exe);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					log.error("Exception Occured in validateCustomerAccount while closing the resultset: {} ", e);
				}
			}
		}
		return status;
	}

	public BeneficiaryDetails getCustomerBeneDetails(final SIDetails siDetails) {
		BeneficiaryDetails beneDetails = null;

		ResultSet rs = null;
		try (Connection con = pbDataSource.getConnection(); 
				PreparedStatement ps = con.prepareStatement(QueryConstants.SELECT_BENE_CUSTOMER_QUERY);) {

			ps.setString(1, siDetails.getCustomerIdentifier());
			ps.setString(2, siDetails.getBeneId());
			ps.setString(3, siDetails.getTemplateId());
			rs = ps.executeQuery();
			while (rs.next()) {
				int i = 0;
				beneDetails = new BeneficiaryDetails();
				beneDetails.setCifId(rs.getString(++i));
				beneDetails.setBeneNickName(rs.getString(++i));
				beneDetails.setTemplateId(rs.getString(++i));
				beneDetails.setBeneficiaryName(rs.getString(++i));
				beneDetails.setBeneAccount(rs.getString(++i));
				beneDetails.setBeneType(rs.getString(++i));
				beneDetails.setBeneAddr1(rs.getString(++i));
				beneDetails.setBeneAddr2(rs.getString(++i));
				beneDetails.setBeneAddr3(rs.getString(++i));
				beneDetails.setRoutingCode(rs.getString(++i));
				beneDetails.setTransferCurrency(rs.getString(++i));
				beneDetails.setBeneBankCountry(rs.getString(++i));
				beneDetails.setReceiverBankName(rs.getString(++i));
				beneDetails.setBeneBranchName(rs.getString(++i));
				beneDetails.setBeneBankAddr1(rs.getString(++i));
				beneDetails.setBeneBankAddr2(rs.getString(++i));
				beneDetails.setBeneDescription(rs.getString(++i));
				beneDetails.setReceiverBankSWIFTCode(rs.getString(++i));
				beneDetails.setChargeType(rs.getString(++i));
				beneDetails.setCorrespondantBank(rs.getString(++i));
			}

		} catch (SQLException exe) {
			log.error("Exception Occured in getCustomerBeneDetails: {} ", exe);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					log.error("Exception Occured in getCustomerBeneDetails while closing the resultset: {} ", e);
				}
			}
		}
		return beneDetails;
	}

	public String getCompanyForCardAccount(final String accountOrCardNo, final String type) {
		String companyCode = null;
		ResultSet rs = null;
		try (Connection con = ciDs.getConnection();
				PreparedStatement ps = con.prepareStatement(QueryConstants.SELECT_COMPANY_FROM_ACCTS_QUERY);
				PreparedStatement ps1 = con.prepareStatement(QueryConstants.SELECT_COMPANY_FROM_CARDS_QUERY);) {
			if (ApplicationConstants.ACCOUNT.equalsIgnoreCase(type)) {
				ps.setString(1, accountOrCardNo);
				rs = ps.executeQuery();
				while (rs.next()) {
					companyCode = T24CompanyCodes.valueOf(rs.getString(1)).getCompanyCode();
				}
			} else if (ApplicationConstants.CARD.equalsIgnoreCase(type)) {
				ps1.setString(1, accountOrCardNo);
				rs = ps1.executeQuery();
				while (rs.next()) {
					companyCode = T24CompanyCodes.valueOf(rs.getString(1)).getCompanyCode();
				}
			}
		} catch (SQLException exe) {
			log.error("Exception Occured in getCompanyForCardAccount: {} ", exe);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					log.error("Exception Occured in getCompanyForCardAccount while closing the resultset: {} ", e);
				}
			}
		}
		return companyCode;
	}

	public String getCurrencyFromAccount(final String accountNo) {
		String currency = null;
		ResultSet rs = null;
		try (Connection con = ciDs.getConnection(); 
				PreparedStatement ps = con.prepareStatement(QueryConstants.SELECT_CURR_FROM_ACCTS_QUERY);) {
			ps.setString(1, accountNo);
			rs = ps.executeQuery();
			while (rs.next()) {
				currency = rs.getString(1);
			}
		} catch (SQLException exe) {
			log.error("Exception Occured in getCurrencyFromAccount: {} ", exe);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					log.error("Exception Occured in getCompanyForCardAccount while closing the resultset: {} ", e);
				}
			}
		}
		return currency;
	}
}
