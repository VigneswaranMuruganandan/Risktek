package com.fab.si.config;

//import java.util.Arrays;
//import org.springframework.boot.CommandLineRunner;
//import org.springframework.boot.SpringApplication;
//import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
//import org.springframework.boot.autoconfigure.SpringBootApplication;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.context.ApplicationContext;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.ImportResource;
import org.springframework.context.support.ClassPathXmlApplicationContext;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
//import de.codecentric.boot.admin.config.EnableAdminServer;
//import org.springframework.scheduling.annotation.EnableScheduling;

//@Configuration
//@EnableAdminServer
//@SpringBootApplication
//@EnableAutoConfiguration
//@EnableScheduling
//@EnableBatchProcessing
//@ImportResource({ "classpath:applicationContext.xml" })
public class App {

	private static final String START = "start";
	//private static final String STOP = "stop";
	private static final String SPRING_CONTEXT_XML = "applicationContext.xml";

	public static void main(String[] args) {
		
		if (args.length > 0) {
			final String action = args[0];
			if (action.equalsIgnoreCase(START)) {
				// CHECK IF SI START BATCH APPLICATION
				//SpringApplication.run(App.class, args);
				new ClassPathXmlApplicationContext(SPRING_CONTEXT_XML);
			} /*else if (action.equalsIgnoreCase(STOP)) {
				// CHECK IF STOP THE BATCH APPLICATION
				System.exit(0);
			}*/
		}
	}

	//@Configuration
	//public static class SecurityConfig extends WebSecurityConfigurerAdapter {

		//@Override
		//protected void configure(HttpSecurity http) throws Exception {

			// Page with login form is served as /login.html and does a POST on
			// /login
			//http.formLogin().loginPage("/login.html").loginProcessingUrl("/login").permitAll();
			// The UI does a POST on /logout on logout
			//http.logout().logoutUrl("/logout");
			// The ui currently doesn't support csrf
			//http.csrf().disable();
			// Requests for the login page and the static assets are allowed
			//http.authorizeRequests().antMatchers("/login.html", "/**/*.css", "/img/**", "/third-party/**").permitAll();
			// ... and any other request needs to be authorized
			//http.authorizeRequests().antMatchers("/**").authenticated();
			// Enable so that the clients can authenticate via HTTP basic for
			// registering
			//http.httpBasic();
		//}
	//}

	// end::configuration-spring-security[]

	/*
	 * @Bean public CommandLineRunner commandLineRunner(ApplicationContext ctx)
	 * { return args -> { log.info(
	 * "Let's inspect the beans provided by Spring Boot:"); String[] beanNames =
	 * ctx.getBeanDefinitionNames(); Arrays.sort(beanNames); for (String
	 * beanName : beanNames) { log.info(beanName); } }; }
	 */
}
