/**
 * 
 */
package com.fab.si.model.transfer;

/**
 * @author o4359
 *
 */
public class ExchangeRate {

	private String rateQuoteReference;
	private String treasuryRate;
	private String customerSpread;
	private String customerRate;
	private String etReferenceNumber;

	/**
	 * @return the rateQuoteReference
	 */
	public String getRateQuoteReference() {
		return rateQuoteReference;
	}

	/**
	 * @param rateQuoteReference
	 *            the rateQuoteReference to set
	 */
	public void setRateQuoteReference(String rateQuoteReference) {
		this.rateQuoteReference = rateQuoteReference;
	}

	/**
	 * @return the treasuryRate
	 */
	public String getTreasuryRate() {
		return treasuryRate;
	}

	/**
	 * @param treasuryRate
	 *            the treasuryRate to set
	 */
	public void setTreasuryRate(String treasuryRate) {
		this.treasuryRate = treasuryRate;
	}

	/**
	 * @return the customerSpread
	 */
	public String getCustomerSpread() {
		return customerSpread;
	}

	/**
	 * @param customerSpread
	 *            the customerSpread to set
	 */
	public void setCustomerSpread(String customerSpread) {
		this.customerSpread = customerSpread;
	}

	/**
	 * @return the customerRate
	 */
	public String getCustomerRate() {
		return customerRate;
	}

	/**
	 * @param customerRate
	 *            the customerRate to set
	 */
	public void setCustomerRate(String customerRate) {
		this.customerRate = customerRate;
	}

	/**
	 * @return the etReferenceNumber
	 */
	public String getEtReferenceNumber() {
		return etReferenceNumber;
	}

	/**
	 * @param etReferenceNumber
	 *            the etReferenceNumber to set
	 */
	public void setEtReferenceNumber(String etReferenceNumber) {
		this.etReferenceNumber = etReferenceNumber;
	}
}
