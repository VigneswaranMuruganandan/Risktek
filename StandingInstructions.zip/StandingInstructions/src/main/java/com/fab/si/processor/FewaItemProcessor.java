/**
 * 
 */
package com.fab.si.processor;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

import com.fab.si.common.ApplicationConstants;
import com.fab.si.common.ServiceUrls;
import com.fab.si.common.TransactionStatus;
import com.fab.si.helper.HttpConnector;
import com.fab.si.helper.JsonUtils;
import com.fab.si.helper.SIUtility;
import com.fab.si.model.common.ConnectorResponse;
import com.fab.si.model.common.SIDetails;
import com.fab.si.model.payment.BalanceEnquiryResponse;
import com.fab.si.model.payment.BillerPaymentResponse;
import com.fab.si.model.payment.FewaBalanceEnquiryRequest;
import com.fab.si.model.payment.FewaBillPaymentRequest;
import com.fab.si.repository.SITransactionRepository;

/**
 * @author o4359
 *
 */
public class FewaItemProcessor implements ItemProcessor<SIDetails, SIDetails> {

	private Logger log = LoggerFactory.getLogger(getClass());

	@Autowired
	private HttpConnector httpConnect;

	@Autowired
	private SIUtility siUtility;

	@Autowired
	private SITransactionRepository siTxnRepo;

	@Override
	public SIDetails process(SIDetails siDetails) throws Exception {

		final String siId = siDetails.getSiID();
		log.info("{} - FEWA Object in Item Processor: {}", siId, siDetails);

		// UPDATE IN SI TRANSACTIONS
		siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.VALIDATE_RULES, null));
		// CALL FEWA BALANCE ENQUIRY
		BalanceEnquiryResponse balEnqRes = this.fewaBalanceEnquiry(siDetails);
		if (balEnqRes != null) {
			final String amountDue = balEnqRes.getAmountDue();

			log.info("{} - Fewa Amount Due: {}", siId, amountDue);

			if (StringUtils.isNotBlank(amountDue)) {
				BillerPaymentResponse paymentRes = null;
				if (ApplicationConstants.ACCOUNT.equalsIgnoreCase(siDetails.getSourceType())) {
					// UPDATE IN SI TRANSACTIONS
					siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.PAYMENT_PROCESSING, null));
					// PAYMENT
					paymentRes = this.fewaAccountPayment(balEnqRes, siDetails);
					// UPDATE IN SI TRANSACTIONS
					if (paymentRes != null) {
						siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(paymentRes, siDetails, TransactionStatus.PAYMENT_STATUS, null));
					} else {
						siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(paymentRes, siDetails, TransactionStatus.INTERNAL_ERROR, null));
					}
				} else if (ApplicationConstants.CARD.equalsIgnoreCase(siDetails.getSourceType())) {
					// UPDATE IN SI TRANSACTIONS
					siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.PAYMENT_PROCESSING, null));
					paymentRes = this.fewaCardPayment(balEnqRes, siDetails);
					// UPDATE IN SI TRANSACTIONS
					if (paymentRes != null) {
						siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(paymentRes, siDetails, TransactionStatus.PAYMENT_STATUS, null));
					} else {
						siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(paymentRes, siDetails, TransactionStatus.INTERNAL_ERROR, null));
					}
				}
			} else {
				log.info("{} - Invalid Fewa Balance Enquiry Response", siId);
				siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.VALIDATE_RULES_FAILED, siUtility.prepareFailureResponseStatus()));
			}
		}
		return siDetails;
	}

	/**
	 * This method is to prepare FewaBalanceEnquiryRequest Object
	 * 
	 * @param siDetails
	 * @return FewaBalanceEnquiryRequest Object
	 */
	private FewaBalanceEnquiryRequest prepareFewaBalEnqReq(final SIDetails siDetails) {
		FewaBalanceEnquiryRequest fewaBalanceReq = new FewaBalanceEnquiryRequest();
		final String fewaConsumerNo = siDetails.getCreditAcctNo();
		if (StringUtils.isNotBlank(fewaConsumerNo)) {
			fewaBalanceReq.setFewaConsumer(siUtility.prepareBalEnqReq(siDetails, ApplicationConstants.FEWA));
		}
		fewaBalanceReq.setCustomerIdentifier(siDetails.getCustomerIdentifier());
		return fewaBalanceReq;
	}

	/**
	 * This method is to execute Balance Inquiry Service
	 * 
	 * @param siDetails
	 * @return BalanceEnquiryResponse Object
	 */
	private BalanceEnquiryResponse fewaBalanceEnquiry(final SIDetails siDetails) {
		BalanceEnquiryResponse response = null;
		final String siId = siDetails.getSiID();
		final String requestJson = JsonUtils.convertToJson(this.prepareFewaBalEnqReq(siDetails));
		log.info("{} - Fewa Balance Enquiry Request: {}", siId, requestJson);
		// CREATE HTTP HEADERS
		Map<String, String> headers = siUtility.populateHeaders(siDetails.getChannelId());
		ConnectorResponse connResponse = httpConnect.post(ServiceUrls.FEWA_BALANCE_ENQ, requestJson, headers);
		if (connResponse.getResponseStatus() == 200) {
			log.info("{} - Fewa Balance Enquiry Response: {}", siId, connResponse.getJsonResponse());
			response = JsonUtils.convertToObject(BalanceEnquiryResponse.class, connResponse.getJsonResponse());
		}
		log.info("{} - Fewa BalanceEnquiryResponse: {}", siId, response);
		return response;
	}

	/**
	 * This method is to execute Account Payment Service
	 * 
	 * @param balEnqRes
	 * @param siDetails
	 * @return BillerPaymentResponse Object
	 */
	private BillerPaymentResponse fewaAccountPayment(final BalanceEnquiryResponse balEnqRes, final SIDetails siDetails) {
		BillerPaymentResponse response = null;
		final String siId = siDetails.getSiID();
		FewaBillPaymentRequest fewaPayment = new FewaBillPaymentRequest();
		fewaPayment.setFewaConsumer(siUtility.prepareBalEnqReq(siDetails, ApplicationConstants.FEWA));
		fewaPayment.setAccountPayment(siUtility.preparePaymentReq(siDetails, balEnqRes));
		fewaPayment.setCustomerIdentifier(siDetails.getCustomerIdentifier());
		final String requestJson = JsonUtils.convertToJson(fewaPayment);
		log.info("{} - Fewa Account Payment Request: {}", siId, requestJson);
		// CREATE HTTP HEADERS
		Map<String, String> headers = siUtility.populateHeaders(siDetails.getChannelId());
		ConnectorResponse connResponse = httpConnect.post(ServiceUrls.FEWA_PAYMENT_BYACCOUNT, requestJson, headers);
		if (connResponse.getResponseStatus() == 200) {
			log.info("{} - Fewa Account Payment JSON Response: {}", siId, connResponse.getJsonResponse());
			response = JsonUtils.convertToObject(BillerPaymentResponse.class, connResponse.getJsonResponse());
		}
		log.info("{} - Fewa Account BillerPaymentResponse: {}", siId, response);
		return response;
	}

	/**
	 * This method is to execute Card Payment Service
	 * 
	 * @param balEnqRes
	 * @param siDetails
	 * @return BillerPaymentResponse Object
	 */
	private BillerPaymentResponse fewaCardPayment(final BalanceEnquiryResponse balEnqRes, final SIDetails siDetails) {
		BillerPaymentResponse response = null;
		final String siId = siDetails.getSiID();
		FewaBillPaymentRequest fewaPayment = new FewaBillPaymentRequest();
		fewaPayment.setFewaConsumer(siUtility.prepareBalEnqReq(siDetails, ApplicationConstants.FEWA));
		fewaPayment.setCardPayment(siUtility.preparePaymentReq(siDetails, balEnqRes));
		fewaPayment.setCustomerIdentifier(siDetails.getCustomerIdentifier());
		final String requestJson = JsonUtils.convertToJson(fewaPayment);
		log.info("{} - Fewa Card Payment Request: {}", siId, requestJson);
		// CREATE HTTP HEADERS
		Map<String, String> headers = siUtility.populateHeaders(siDetails.getChannelId());
		ConnectorResponse connResponse = httpConnect.post(ServiceUrls.FEWA_PAYMENT_BYCARD, requestJson, headers);
		if (connResponse.getResponseStatus() == 200) {
			log.info("{} - Fewa Card Payment Response: {}", siId, connResponse.getJsonResponse());
			response = JsonUtils.convertToObject(BillerPaymentResponse.class, connResponse.getJsonResponse());
		}
		log.info("{} - Fewa Card BillerPaymentResponse: {}", siId, response);
		return response;
	}
}
