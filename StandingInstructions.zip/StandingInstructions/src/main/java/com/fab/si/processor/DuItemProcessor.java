/**
 * 
 */
package com.fab.si.processor;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fab.si.common.ApplicationConstants;
import com.fab.si.common.ServiceUrls;
import com.fab.si.common.TransactionStatus;
import com.fab.si.helper.HttpConnector;
import com.fab.si.helper.JsonUtils;
import com.fab.si.helper.SIUtility;
import com.fab.si.model.common.ConnectorResponse;
import com.fab.si.model.common.SIDetails;
import com.fab.si.model.payment.BalanceEnquiryResponse;
import com.fab.si.model.payment.BillerPaymentResponse;
import com.fab.si.model.payment.DuBalanceEnquiryRequest;
import com.fab.si.model.payment.DuBillPaymentRequest;
import com.fab.si.repository.SITransactionRepository;

/**
 * @author o4359
 *
 */
@Component
public class DuItemProcessor implements ItemProcessor<SIDetails, SIDetails> {

	private Logger log = LoggerFactory.getLogger(getClass());

	@Autowired
	private HttpConnector httpConnect;

	@Autowired
	private SIUtility siUtility;

	@Autowired
	private SITransactionRepository siTxnRepo;

	@Override
	public SIDetails process(SIDetails siDetails) throws Exception {

		final String siId = siDetails.getSiID();
		log.info("{} - DU Object in Item Processor: {}", siId, siDetails);

		// UPDATE IN SI TRANSACTIONS
		siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.VALIDATE_RULES, null));
		// CALL DU BALANCE ENQUIRY
		BalanceEnquiryResponse balEnqRes = this.duBalanceEnquiry(siDetails);
		if (balEnqRes != null) {
			final String amountDue = balEnqRes.getAmountDue();
			log.info("{} - Du Amount Due: {} ", siId, amountDue);

			if (StringUtils.isNotBlank(amountDue)) {
				BillerPaymentResponse paymentRes = null;
				if (ApplicationConstants.ACCOUNT.equalsIgnoreCase(siDetails.getSourceType())) {
					// UPDATE IN SI TRANSACTIONS
					siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.PAYMENT_PROCESSING, null));
					// PAYMENT
					paymentRes = this.duAccountPayment(balEnqRes, siDetails);
					// UPDATE IN SI TRANSACTIONS
					if (paymentRes != null) {
						siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(paymentRes, siDetails, TransactionStatus.PAYMENT_STATUS, null));
					} else {
						siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(paymentRes, siDetails, TransactionStatus.INTERNAL_ERROR, null));
					}
				} else if (ApplicationConstants.CARD.equalsIgnoreCase(siDetails.getSourceType())) {
					// UPDATE IN SI TRANSACTIONS
					siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.PAYMENT_PROCESSING, null));
					paymentRes = this.duCardPayment(balEnqRes, siDetails);
					// UPDATE IN SI TRANSACTIONS
					if (paymentRes != null) {
						siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(paymentRes, siDetails, TransactionStatus.PAYMENT_STATUS, null));
					} else {
						siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(paymentRes, siDetails, TransactionStatus.INTERNAL_ERROR, null));
					}
				}
			} else {
				log.info("{} - Invalid Du Balance Enquiry Response", siId);
				siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.VALIDATE_RULES_FAILED, siUtility.prepareFailureResponseStatus()));
			}
		}
		return siDetails;
	}

	/**
	 * This method is to prepare DuBalanceEnquiryRequest Object
	 * 
	 * @param siDetails
	 * @return DuBalanceEnquiryRequest Object
	 */
	private DuBalanceEnquiryRequest prepareDuBalEnqReq(final SIDetails siDetails) {
		DuBalanceEnquiryRequest duBalanceReq = new DuBalanceEnquiryRequest();
		final String duConsumerNo = siDetails.getCreditAcctNo();
		if (StringUtils.isNotBlank(duConsumerNo)) {
			duBalanceReq.setDuConsumer(siUtility.prepareBalEnqReq(siDetails, ApplicationConstants.DU));
		}
		duBalanceReq.setCustomerIdentifier(siDetails.getCustomerIdentifier());
		return duBalanceReq;
	}

	/**
	 * This method is to execute Balance Inquiry Service
	 * 
	 * @param siDetails
	 * @return BalanceEnquiryResponse Object
	 */
	private BalanceEnquiryResponse duBalanceEnquiry(final SIDetails siDetails) {
		BalanceEnquiryResponse response = null;
		final String siId = siDetails.getSiID();
		final String requestJson = JsonUtils.convertToJson(this.prepareDuBalEnqReq(siDetails));
		log.info("{} - Du Balance Enquiry Request: {}", siId, requestJson);
		// CREATE HTTP HEADERS
		Map<String, String> headers = siUtility.populateHeaders(siDetails.getChannelId());
		ConnectorResponse connResponse = httpConnect.post(ServiceUrls.DU_BALANCE_ENQ, requestJson, headers);
		if (connResponse.getResponseStatus() == 200) {
			log.info("{} - Du Balance Enquiry Response: {}", siId, connResponse.getJsonResponse());
			response = JsonUtils.convertToObject(BalanceEnquiryResponse.class, connResponse.getJsonResponse());
		}
		log.info("{} - Du BalanceEnquiryResponse: {}", siId, response);
		return response;
	}

	/**
	 * This method is to execute Account Payment Service
	 * 
	 * @param balEnqRes
	 * @param siDetails
	 * @return BillerPaymentResponse Object
	 */
	private BillerPaymentResponse duAccountPayment(final BalanceEnquiryResponse balEnqRes, final SIDetails siDetails) {
		BillerPaymentResponse response = null;
		final String siId = siDetails.getSiID();
		DuBillPaymentRequest duPayment = new DuBillPaymentRequest();
		duPayment.setDuConsumer(siUtility.prepareBalEnqReq(siDetails, ApplicationConstants.DU));
		duPayment.setAccountPayment(siUtility.preparePaymentReq(siDetails, balEnqRes));
		duPayment.setCustomerIdentifier(siDetails.getCustomerIdentifier());
		final String requestJson = JsonUtils.convertToJson(duPayment);
		log.info("{} - Du Account Payment Request: {}", siId, requestJson);
		// CREATE HTTP HEADERS
		Map<String, String> headers = siUtility.populateHeaders(siDetails.getChannelId());
		ConnectorResponse connResponse = httpConnect.post(ServiceUrls.DU_PAYMENT_BYACCOUNT, requestJson, headers);
		if (connResponse.getResponseStatus() == 200) {
			log.info("{} - Du Account Payment JSON Response: {}", siId, connResponse.getJsonResponse());
			response = JsonUtils.convertToObject(BillerPaymentResponse.class, connResponse.getJsonResponse());
		}
		log.info("{} - Du Account BillerPaymentResponse: {}", siId, response);
		return response;
	}

	/**
	 * This method is to execute Card Payment Service
	 * 
	 * @param balEnqRes
	 * @param siDetails
	 * @return BillerPaymentResponse Object
	 */
	private BillerPaymentResponse duCardPayment(final BalanceEnquiryResponse balEnqRes, final SIDetails siDetails) {
		BillerPaymentResponse response = null;
		final String siId = siDetails.getSiID();
		DuBillPaymentRequest duPayment = new DuBillPaymentRequest();
		duPayment.setDuConsumer(siUtility.prepareBalEnqReq(siDetails, ApplicationConstants.DU));
		duPayment.setCardPayment(siUtility.preparePaymentReq(siDetails, balEnqRes));
		duPayment.setCustomerIdentifier(siDetails.getCustomerIdentifier());
		final String requestJson = JsonUtils.convertToJson(duPayment);
		log.info("{} - Du Card Payment Request: {}", siId, requestJson);
		// CREATE HTTP HEADERS
		Map<String, String> headers = siUtility.populateHeaders(siDetails.getChannelId());
		ConnectorResponse connResponse = httpConnect.post(ServiceUrls.DU_PAYMENT_BYCARD, requestJson, headers);
		if (connResponse.getResponseStatus() == 200) {
			log.info("{} - Du Card Payment Response: {}", siId, connResponse.getJsonResponse());
			response = JsonUtils.convertToObject(BillerPaymentResponse.class, connResponse.getJsonResponse());
		}
		log.info("{} - Du Card BillerPaymentResponse: {}", siId, response);
		return response;
	}
}
