/**
 * 
 */
package com.fab.si.common;

/**
 * @author O4359
 * 
 */
public enum T24CompanyCodes {

	BNK("AE0010001", "FGB - LIVE"), 
	HNI("AE0010003", "HNI Banking"), 
	FGF("AE0010002", "FGFS"), 
	ISL("AE0010007", "ISLAMIC BANKING WBG"), 
	ISB("AE0010004", "Islamic Banking - FGB"), 
	B60("AE0010600","Islamic Branch - HO"), 
	LYB("LY0010001", "Gulf Libyan Bank"), 
	QAB("QA0010001", "Qatar Bank"), 
	SNG("SG0010001", "Singapore"), 
	SGI("SG0010007", "Singapore Islamic Bank");

	private String companyCode;
	private String description;

	private T24CompanyCodes(String companyCode, String description) {
		this.companyCode = companyCode;
		this.description = description;
	}

	/**
	 * @return the companyShortCode
	 */
	public String getCompanyShortCode() {
		return this.name();
	}

	/**
	 * @return the companyCode
	 */
	public String getCompanyCode() {
		return companyCode;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	public static T24CompanyCodes findByCompanyCode(String companyCode) {
		T24CompanyCodes[] T24CompanyCodeList = T24CompanyCodes.values();

		if (companyCode != null) {
			for (T24CompanyCodes t24CompanyCode : T24CompanyCodeList) {
				if (t24CompanyCode.getCompanyCode().equals(companyCode.trim())) {
					return t24CompanyCode;
				}
			}
		}
		return null;
	}

	public static T24CompanyCodes findByCompanyShortCode(String companyShortCode) {
		T24CompanyCodes[] T24CompanyCodeList = T24CompanyCodes.values();

		if (companyShortCode != null) {
			for (T24CompanyCodes t24CompanyCode : T24CompanyCodeList) {
				if (t24CompanyCode.name().equalsIgnoreCase(companyShortCode.trim())) {
					return t24CompanyCode;
				}
			}
		}
		return null;
	}
}
