/**
 * 
 */
package com.fab.si.model.transfer;

import java.util.List;

/**
 * @author o4359
 *
 */
public class Address {

	private List<AddressDetails> addressComponents;

	/**
	 * @return the addressComponents
	 */
	public List<AddressDetails> getAddressComponents() {
		return addressComponents;
	}

	/**
	 * @param addressComponents
	 *            the addressComponents to set
	 */
	public void setAddressComponents(List<AddressDetails> addressComponents) {
		this.addressComponents = addressComponents;
	}

}
