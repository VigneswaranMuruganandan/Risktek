package com.fab.si.common;

public enum ContentGroup {

	MSGTEMPLATE, 
	BULLETIN, 
	TERM_CONDITION,
	CARD_IMG; 
}
