/**
 * 
 */
package com.fab.si.model.transfer;

/**
 * @author o4359
 *
 */
public class Charge {

	private String type;
	private String amount;
	private String borneBy;

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type
	 *            the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the amount
	 */
	public String getAmount() {
		return amount;
	}

	/**
	 * @param amount
	 *            the amount to set
	 */
	public void setAmount(String amount) {
		this.amount = amount;
	}

	/**
	 * @return the borneBy
	 */
	public String getBorneBy() {
		return borneBy;
	}

	/**
	 * @param borneBy
	 *            the borneBy to set
	 */
	public void setBorneBy(String borneBy) {
		this.borneBy = borneBy;
	}
}
