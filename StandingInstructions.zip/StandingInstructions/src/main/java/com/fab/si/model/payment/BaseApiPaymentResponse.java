/**
 * 
 */
package com.fab.si.model.payment;

import java.util.List;

/**
 * @author o4359
 *
 */
public class BaseApiPaymentResponse {

	private List<PaymentResponseStatus> responseStatus;

	/**
	 * @return the responseStatus
	 */
	public List<PaymentResponseStatus> getResponseStatus() {
		return responseStatus;
	}

	/**
	 * @param responseStatus
	 *            the responseStatus to set
	 */
	public void setResponseStatus(List<PaymentResponseStatus> responseStatus) {
		this.responseStatus = responseStatus;
	}
}
