
package com.fab.si.model.notify;

import java.io.Serializable;

public class BaseRequest implements Serializable {

	private static final long serialVersionUID = 743348371324693115L;
	protected String sourceSystem;
	protected String requestID;
	protected String responseID;		// Transient variable

	public String getRequestID() {
		return requestID;
	}

	public void setRequestID(String requestID) {
		this.requestID = requestID;
	}

	public String getResponseID() {
		return responseID;
	}

	public void setResponseID(String responseID) {
		this.responseID = responseID;
	}

	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Request [requestID=");
		builder.append(requestID);
		builder.append(", requestID=");
		builder.append(responseID);
		builder.append(", sourceSystem=");
		builder.append(sourceSystem);
		builder.append("]");
		return builder.toString();
	}
}
