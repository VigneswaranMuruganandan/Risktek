/**
 * 
 */
package com.fab.si.model.notify;

import java.io.Serializable;

//@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class ResponseData<T> implements Serializable {

	private static final long serialVersionUID = -7919004718624363710L;

	protected T responseEntity;
	protected ResponseStatus response;

	/**
	 * @return the responseEntity
	 */
	public T getResponseEntity() {
		return responseEntity;
	}

	/**
	 * @return the response
	 */
	public ResponseStatus getResponse() {
		return response;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ResponseData [entity=");
		builder.append(responseEntity);
		builder.append(", status=");
		builder.append(response);
		builder.append("]");
		return builder.toString();
	}
}
