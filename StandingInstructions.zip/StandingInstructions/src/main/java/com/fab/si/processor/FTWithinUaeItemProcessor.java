/**
 * 
 */
package com.fab.si.processor;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fab.si.common.ApplicationConstants;
import com.fab.si.common.ServiceUrls;
import com.fab.si.common.TemplateId;
import com.fab.si.common.TransactionStatus;
import com.fab.si.helper.HttpConnector;
import com.fab.si.helper.JsonUtils;
import com.fab.si.helper.SIUtility;
import com.fab.si.model.common.ConnectorResponse;
import com.fab.si.model.common.SIDetails;
import com.fab.si.model.transfer.FundsTransferRequest;
import com.fab.si.model.transfer.FundsTransferResponse;
import com.fab.si.model.transfer.TransferResponseStatus;
import com.fab.si.repository.CustomerRepository;
import com.fab.si.repository.SITransactionRepository;

/**
 * @author o4359
 *
 */
@Component
public class FTWithinUaeItemProcessor implements ItemProcessor<SIDetails, SIDetails> {

	private Logger log = LoggerFactory.getLogger(getClass());

	@Autowired
	private HttpConnector httpConnect;

	@Autowired
	private SIUtility siUtility;

	@Autowired
	private SITransactionRepository siTxnRepo;

	@Autowired
	private CustomerRepository custRepo;

	@Override
	public SIDetails process(SIDetails siDetails) throws Exception {

		final String siId = siDetails.getSiID();
		log.info("{} - Funds Transfer Within Uae Object in Item Processor: {}", siId, siDetails);

		// UPDATE IN SI TRANSACTIONS
		siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateFtRequest(null, siDetails, TransactionStatus.VALIDATE_RULES, null));
		TransferResponseStatus status = custRepo.validateCustomerAccount(siDetails);
		log.info("{} - ResponseStatus Object in Item Processor: {}", siId, status);
		if (ApplicationConstants.SUCCESS.equalsIgnoreCase(status.getStatus())) {
			// UPDATE IN SI TRANSACTIONS
			siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateFtRequest(null, siDetails, TransactionStatus.PAYMENT_PROCESSING, null));
			final FundsTransferResponse ftResponse = this.withinUaeTransfer(siDetails);
			if (ftResponse != null) {
				siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateFtRequest(ftResponse, siDetails, TransactionStatus.PAYMENT_STATUS, null));
			} else {
				siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateFtRequest(ftResponse, siDetails, TransactionStatus.INTERNAL_ERROR, null));
			}
		} else {
			siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateFtRequest(null, siDetails, TransactionStatus.VALIDATE_RULES_FAILED, status));
		}
		return siDetails;
	}

	/**
	 * This method is to execute Funds Transfer Within Bank Service
	 * 
	 * @param balEnqRes
	 * @param siDetails
	 * @return FundsTransferResponse Object
	 */
	private FundsTransferResponse withinUaeTransfer(final SIDetails siDetails) {
		FundsTransferResponse response = null;
		final String siId = siDetails.getSiID();
		final FundsTransferRequest withinUaeFt = siUtility.prepareFundsTransferReq(siDetails, custRepo.getCustomerBeneDetails(siDetails), TemplateId.WITHIN_UAE_FT);
		final String requestJson = JsonUtils.convertToJson(withinUaeFt);
		log.info("{} - Funds Transfer Within Uae Request: {}", siId, requestJson);
		// CREATE HTTP HEADERS
		Map<String, String> headers = siUtility.populateHeaders(siDetails.getChannelId(), siDetails.getCustomerIdentifier());
		ConnectorResponse connResponse = httpConnect.post(ServiceUrls.FT_WITHIN_UAE, requestJson, headers);
		if (connResponse.getResponseStatus() == 200) {
			log.info("{} - Funds Transfer Within Uae Response: {}", siId, connResponse.getJsonResponse());
			response = JsonUtils.convertToObject(FundsTransferResponse.class, connResponse.getJsonResponse());
		}
		log.info("{} - Funds Transfer Within Uae FundsTransferResponse: {}", siId, response);
		return response;
	}
}
