/**
 * 
 */
package com.fab.si.model.transfer;

import java.util.List;

/**
 * @author o4359
 *
 */
public class FundsTransferRequest {

	private String cif;
	private String accountingUnitIdentifier;
	private String debitAccountNo;
	private String creditAccountNo;
	private String transactionAmount;
	private String transactionCurrency;
	private String debitReference;
	private String debitEffectiveDate;
	private String creditAccountCurrency;
	private String creditEffectiveDate;
	private String paymentDetails;
	private String chargeAccount;
	private String chargePaymentType;
	private String creditReference;
	private String chargeBearerIndicationType;
	private String commissionPaymentType;
	private String transferType;
	private List<Charge> charge;
	private List<Charge> commission;
	private BeneficiaryDetails containsBeneficiary;
	private ExchangeRate exchangeRate;

	/**
	 * @return the cif
	 */
	public String getCif() {
		return cif;
	}

	/**
	 * @param cif
	 *            the cif to set
	 */
	public void setCif(String cif) {
		this.cif = cif;
	}

	/**
	 * @return the debitAccountNo
	 */
	public String getDebitAccountNo() {
		return debitAccountNo;
	}

	/**
	 * @param debitAccountNo
	 *            the debitAccountNo to set
	 */
	public void setDebitAccountNo(String debitAccountNo) {
		this.debitAccountNo = debitAccountNo;
	}

	/**
	 * @return the creditAccountNo
	 */
	public String getCreditAccountNo() {
		return creditAccountNo;
	}

	/**
	 * @param creditAccountNo
	 *            the creditAccountNo to set
	 */
	public void setCreditAccountNo(String creditAccountNo) {
		this.creditAccountNo = creditAccountNo;
	}

	/**
	 * @return the transactionAmount
	 */
	public String getTransactionAmount() {
		return transactionAmount;
	}

	/**
	 * @param transactionAmount
	 *            the transactionAmount to set
	 */
	public void setTransactionAmount(String transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	/**
	 * @return the transactionCurrency
	 */
	public String getTransactionCurrency() {
		return transactionCurrency;
	}

	/**
	 * @param transactionCurrency
	 *            the transactionCurrency to set
	 */
	public void setTransactionCurrency(String transactionCurrency) {
		this.transactionCurrency = transactionCurrency;
	}

	/**
	 * @return the debitReference
	 */
	public String getDebitReference() {
		return debitReference;
	}

	/**
	 * @param debitReference
	 *            the debitReference to set
	 */
	public void setDebitReference(String debitReference) {
		this.debitReference = debitReference;
	}

	/**
	 * @return the debitEffectiveDate
	 */
	public String getDebitEffectiveDate() {
		return debitEffectiveDate;
	}

	/**
	 * @return the accountingUnitIdentifier
	 */
	public String getAccountingUnitIdentifier() {
		return accountingUnitIdentifier;
	}

	/**
	 * @param accountingUnitIdentifier
	 *            the accountingUnitIdentifier to set
	 */
	public void setAccountingUnitIdentifier(String accountingUnitIdentifier) {
		this.accountingUnitIdentifier = accountingUnitIdentifier;
	}

	/**
	 * @param debitEffectiveDate
	 *            the debitEffectiveDate to set
	 */
	public void setDebitEffectiveDate(String debitEffectiveDate) {
		this.debitEffectiveDate = debitEffectiveDate;
	}

	/**
	 * @return the creditAccountCurrency
	 */
	public String getCreditAccountCurrency() {
		return creditAccountCurrency;
	}

	/**
	 * @param creditAccountCurrency
	 *            the creditAccountCurrency to set
	 */
	public void setCreditAccountCurrency(String creditAccountCurrency) {
		this.creditAccountCurrency = creditAccountCurrency;
	}

	/**
	 * @return the creditEffectiveDate
	 */
	public String getCreditEffectiveDate() {
		return creditEffectiveDate;
	}

	/**
	 * @param creditEffectiveDate
	 *            the creditEffectiveDate to set
	 */
	public void setCreditEffectiveDate(String creditEffectiveDate) {
		this.creditEffectiveDate = creditEffectiveDate;
	}

	/**
	 * @return the paymentDetails
	 */
	public String getPaymentDetails() {
		return paymentDetails;
	}

	/**
	 * @param paymentDetails
	 *            the paymentDetails to set
	 */
	public void setPaymentDetails(String paymentDetails) {
		this.paymentDetails = paymentDetails;
	}

	/**
	 * @return the chargeAccount
	 */
	public String getChargeAccount() {
		return chargeAccount;
	}

	/**
	 * @param chargeAccount
	 *            the chargeAccount to set
	 */
	public void setChargeAccount(String chargeAccount) {
		this.chargeAccount = chargeAccount;
	}

	/**
	 * @return the chargePaymentType
	 */
	public String getChargePaymentType() {
		return chargePaymentType;
	}

	/**
	 * @param chargePaymentType
	 *            the chargePaymentType to set
	 */
	public void setChargePaymentType(String chargePaymentType) {
		this.chargePaymentType = chargePaymentType;
	}

	/**
	 * @return the creditReference
	 */
	public String getCreditReference() {
		return creditReference;
	}

	/**
	 * @param creditReference
	 *            the creditReference to set
	 */
	public void setCreditReference(String creditReference) {
		this.creditReference = creditReference;
	}

	/**
	 * @return the chargeBearerIndicationType
	 */
	public String getChargeBearerIndicationType() {
		return chargeBearerIndicationType;
	}

	/**
	 * @param chargeBearerIndicationType
	 *            the chargeBearerIndicationType to set
	 */
	public void setChargeBearerIndicationType(String chargeBearerIndicationType) {
		this.chargeBearerIndicationType = chargeBearerIndicationType;
	}

	/**
	 * @return the commissionPaymentType
	 */
	public String getCommissionPaymentType() {
		return commissionPaymentType;
	}

	/**
	 * @param commissionPaymentType
	 *            the commissionPaymentType to set
	 */
	public void setCommissionPaymentType(String commissionPaymentType) {
		this.commissionPaymentType = commissionPaymentType;
	}

	/**
	 * @return the transferType
	 */
	public String getTransferType() {
		return transferType;
	}

	/**
	 * @param transferType
	 *            the transferType to set
	 */
	public void setTransferType(String transferType) {
		this.transferType = transferType;
	}

	/**
	 * @return the charge
	 */
	public List<Charge> getCharge() {
		return charge;
	}

	/**
	 * @param charge
	 *            the charge to set
	 */
	public void setCharge(List<Charge> charge) {
		this.charge = charge;
	}

	/**
	 * @return the commission
	 */
	public List<Charge> getCommission() {
		return commission;
	}

	/**
	 * @param commission
	 *            the commission to set
	 */
	public void setCommission(List<Charge> commission) {
		this.commission = commission;
	}

	/**
	 * @return the containsBeneficiary
	 */
	public BeneficiaryDetails getContainsBeneficiary() {
		return containsBeneficiary;
	}

	/**
	 * @param containsBeneficiary
	 *            the containsBeneficiary to set
	 */
	public void setContainsBeneficiary(BeneficiaryDetails containsBeneficiary) {
		this.containsBeneficiary = containsBeneficiary;
	}

	/**
	 * @return the exchangeRate
	 */
	public ExchangeRate getExchangeRate() {
		return exchangeRate;
	}

	/**
	 * @param exchangeRate
	 *            the exchangeRate to set
	 */
	public void setExchangeRate(ExchangeRate exchangeRate) {
		this.exchangeRate = exchangeRate;
	}
}
