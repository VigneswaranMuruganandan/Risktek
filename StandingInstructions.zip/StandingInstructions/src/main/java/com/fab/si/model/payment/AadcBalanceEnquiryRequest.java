/**
 * 
 */
package com.fab.si.model.payment;

/**
 * @author o4359
 *
 */
public class AadcBalanceEnquiryRequest {

	private BalanceEnquiryRequest aadcConsumer;
	private String customerIdentifier;

	/**
	 * @return the aadcConsumer
	 */
	public BalanceEnquiryRequest getAadcConsumer() {
		return aadcConsumer;
	}

	/**
	 * @param aadcConsumer
	 *            the aadcConsumer to set
	 */
	public void setAadcConsumer(BalanceEnquiryRequest aadcConsumer) {
		this.aadcConsumer = aadcConsumer;
	}

	/**
	 * @return the customerIdentifier
	 */
	public String getCustomerIdentifier() {
		return customerIdentifier;
	}

	/**
	 * @param customerIdentifier
	 *            the customerIdentifier to set
	 */
	public void setCustomerIdentifier(String customerIdentifier) {
		this.customerIdentifier = customerIdentifier;
	}

}
