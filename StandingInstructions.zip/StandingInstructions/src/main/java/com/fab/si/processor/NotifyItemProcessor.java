/**
 * 
 */
package com.fab.si.processor;

import java.util.Date;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

import com.fab.si.common.ApplicationConstants;
import com.fab.si.common.ContentGroup;
import com.fab.si.common.ContentID;
import com.fab.si.common.ServiceUrls;
import com.fab.si.common.TransactionStatus;
import com.fab.si.helper.HttpConnector;
import com.fab.si.helper.JsonUtils;
import com.fab.si.helper.PropertyConfig;
import com.fab.si.helper.TextUtils;
import com.fab.si.helper.SIUtility;
import com.fab.si.model.common.ConnectorResponse;
import com.fab.si.model.common.SIDetails;
import com.fab.si.model.common.SITransaction;
import com.fab.si.model.notify.EmailRequest;
import com.fab.si.model.payment.ContentItem;
import com.fab.si.repository.NotificationRepository;
import com.fab.si.repository.SITransactionRepository;

/**
 * @author o4359
 *
 */
public class NotifyItemProcessor implements ItemProcessor<SIDetails, SIDetails> {

	private Logger log = LoggerFactory.getLogger(getClass());

	@Autowired
	private HttpConnector httpConnect;

	@Autowired
	private PropertyConfig propConfig;

	@Autowired
	private NotificationRepository notifyRepo;

	@Autowired
	private SITransactionRepository siTxnRepo;

	@Autowired
	private SIUtility siUtility;

	@Override
	public SIDetails process(SIDetails siDetails) throws Exception {
		log.info("Notify Object in Item Processor: {}", siDetails);
		this.notifyBySms(siDetails);
		this.notifyByEmail(siDetails);
		return siDetails;
	}

	private void notifyBySms(final SIDetails siDetails) {
		log.info("Send Notification SMS");
	}

	private void notifyByEmail(SIDetails siDetails) {

		log.info("Send Notification EMAIL for SI: {}", siDetails);
		final String contentId = ContentID.getContentIdBySmsStatus(siDetails.getSmsStatus());
		if (StringUtils.isBlank(contentId)) {
			log.info("Email Template Not set for SMS Status: {}", siDetails.getSmsStatus());
			return;
		}
		final ContentItem contentItem = notifyRepo.getSmsEmailMsgByContentId(ContentID.valueOf(contentId), ContentGroup.MSGTEMPLATE, siDetails.getChannelId(), ApplicationConstants.EMAIL);
		final String[] parameters = {siDetails.getCreditAcctNo(),TextUtils.formatDate(new Date())};
		if (contentItem != null) {
			final String msg = TextUtils.createTextFromTemplate(contentItem.getContentText(), parameters);
			log.info("Email Formatted Message: {}", msg);
			EmailRequest request = new EmailRequest();
			request.setFromAddress(propConfig.getFromAddress());
			request.setEntityName(propConfig.getEntityName());
			request.setSourceSystem(propConfig.getEntityName());
			request.setRequestID(UUID.randomUUID().toString());
			request.addToAddress(notifyRepo.getCustomerEmailId(siDetails));
			request.setEmailBodyContentType(ApplicationConstants.MEDIATYPE_TXTPLAIN);
			request.setEmailSubject(contentItem.getMetadata());
			request.setEmailBodyContent(msg);

			// CREATE HTTP HEADERS
			final Map<String, String> headers = siUtility.populateHeaders(siDetails.getChannelId(), siDetails.getCustomerIdentifier());
			final String requestJson = JsonUtils.convertToJson(request);
			log.info("Notify Email Request: {}", requestJson);
			final ConnectorResponse connResponse = httpConnect.post(ServiceUrls.NOTIFY_EMAIL, requestJson, headers);
			if (connResponse.getResponseStatus() == 200) {
				log.info("Email Notification Response: {}", connResponse.getJsonResponse());
				siTxnRepo.updateSiSmsTransaction(this.prepareSITransactionUpdateRequest(TransactionStatus.PAYMENT_SMS_SENT_SUCCESS, siDetails));
			} else {
				siTxnRepo.updateSiSmsTransaction(this.prepareSITransactionUpdateRequest(TransactionStatus.PAYMENT_SMS_SENT_FAILED, siDetails));
			}
		} else {
			log.info("Message Not set for the Channel");
		}
	}

	private SITransaction prepareSITransactionUpdateRequest(TransactionStatus status, final SIDetails siDetails) {
		SITransaction siTxn = new SITransaction();
		siTxn.setSiId(siDetails.getSiID());
		siTxn.setSmsStatus(status.name());
		siTxn.setTxnStatus(siDetails.getTxnStatus());
		siTxn.setStatusCode(siDetails.getStatusCode());
		siTxn.setStatusDesc(siDetails.getStatusDesc());
		siTxn.setTxnId(siDetails.getTxnId());
		siTxn.setNxtRunOn(siDetails.getNextRunOnDate());
		siTxn.setPerDayRetryCount(siDetails.getRetryCount());
		siTxn.setCompletedCount(siDetails.getCompletedCount());
		siTxn.setCreatedBy(siDetails.getCustomerIdentifier());
		siTxn.setModifiedBy(ApplicationConstants.NOTIFY_JOB);
		return siTxn;
	}
}
