/**
 * 
 */
package com.fab.si.listener;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ItemWriteListener;
import org.springframework.stereotype.Component;

/**
 * @author o4359
 *
 */
@Component
public class WriterListener<T> implements ItemWriteListener<T> {

	private Logger log = LoggerFactory.getLogger(getClass());

	@Override
	public void afterWrite(List<? extends T> arg0) {
		log.info("SUCCESSFULLY WRITE {} DETAILS FROM DATABASE", arg0.toString());
	}

	@Override
	public void beforeWrite(List<? extends T> arg0) {
		log.info("STARTING WRITE FOR {} DETAILS FROM DATABASE", arg0.toString());
	}

	@Override
	public void onWriteError(Exception exe, List<? extends T> arg1) {
		log.error("ERROR WHILE WRITING {} DETAILS FROM DATABASE", arg1.toString(), exe);
	}

}
