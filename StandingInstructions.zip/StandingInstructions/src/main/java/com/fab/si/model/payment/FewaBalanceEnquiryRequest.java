/**
 * 
 */
package com.fab.si.model.payment;

/**
 * @author o4359
 *
 */
public class FewaBalanceEnquiryRequest {

	private BalanceEnquiryRequest fewaConsumer;
	private String customerIdentifier;

	/**
	 * @return the fewaConsumer
	 */
	public BalanceEnquiryRequest getFewaConsumer() {
		return fewaConsumer;
	}

	/**
	 * @param fewaConsumer
	 *            the fewaConsumer to set
	 */
	public void setFewaConsumer(BalanceEnquiryRequest fewaConsumer) {
		this.fewaConsumer = fewaConsumer;
	}

	/**
	 * @return the customerIdentifier
	 */
	public String getCustomerIdentifier() {
		return customerIdentifier;
	}

	/**
	 * @param customerIdentifier
	 *            the customerIdentifier to set
	 */
	public void setCustomerIdentifier(String customerIdentifier) {
		this.customerIdentifier = customerIdentifier;
	}

}
