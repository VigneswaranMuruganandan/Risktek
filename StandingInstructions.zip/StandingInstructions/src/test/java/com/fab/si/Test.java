/**
 * 
 */
package com.fab.si;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import com.fab.si.helper.JsonUtils;
import com.fab.si.model.payment.BillerPaymentRequest;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author o4359
 *
 */
public class Test {

	/**
	 * @param args
	 */
	
	public static String GetMajorAmount(String amount) throws Exception
	{
		try
		{
			if (amount == null) return "0";
			int idx = amount.indexOf(".");
			if (idx >= 0) return amount.substring(0, idx);
			return amount;
		}
		catch (Exception ex)
		{
			throw ex;
		}
	}
	
	public static String GetMinorAmount(String amount) throws Exception
	{
		try
		{
			if (amount == null) return "0";
			int idx = amount.indexOf(".");
			if (idx >= 0) //12.345, 12.034, 12.30, 12.0, 12.1
			{
				String sigDigits = amount.substring(idx+1, amount.length());
				if (sigDigits.length() == 1 &&   (Integer.valueOf(sigDigits)> 0) )
					return amount.substring(idx+1, amount.length()) + "0";
				else
					return amount.substring(idx+1, amount.length());
			}
			return "0";
		}
		catch (Exception ex)
		{
			throw ex;
		}
	}
	
	public static String createJsonString() {
		BillerPaymentRequest paymentRequest = new BillerPaymentRequest();
		paymentRequest.setAccountNo("1234");
		paymentRequest.setCurrencyCode("AED");
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(Include.NON_NULL);
		Map<String, Object> reqMap = new HashMap<>();
		reqMap.put("accountPayment", mapper.convertValue(paymentRequest, Map.class));
		
		Map<String, String> balanceMap = new HashMap<>();
		balanceMap.put("agency", "AADC");
		balanceMap.put("consumerNo", "123654788");
		reqMap.put("aadcConsumer", balanceMap);
		final String jsonRequest = JsonUtils.convertToJson(reqMap);
		return jsonRequest;
	}
	
	public static void main(String[] args) throws Exception {
		
		System.out.println(Double.valueOf(Test.GetMajorAmount("153.13")));
		System.out.println(Test.GetMinorAmount("153.13"));
		System.out.println(BigDecimal.valueOf(Double.valueOf(Test.GetMajorAmount("153.13"))));
		System.out.println(BigDecimal.valueOf(Double.valueOf("153.13")));
		int i = 0;
		System.out.println(" ++i " + ++i);
		System.out.println(" i++ " + i++);
		System.out.println("JSON Request: " + createJsonString());
	}

}
