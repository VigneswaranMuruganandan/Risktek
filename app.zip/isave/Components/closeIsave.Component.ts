import { Component, OnInit, Input, Output, EventEmitter, ViewChild, OnDestroy } from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { ErrorService} from '../../shared/services/error.service';
import { SharedService } from '../../shared/services/shared.service';

@Component({
  selector: 'closeIsave-component',
  templateUrl: './../templates/closeIsave.html'
})
export class CloseIsaveComponent{
	@Output() closeIsaveconfirmationEvent = new EventEmitter();

	constructor( private errorService: ErrorService,
				 private sharedService: SharedService){}

	cancelCloseIsave(){
		(<any>$('#close-isave')).modal('hide');
	}

	closeIsaveSubmit(){
		this.closeIsaveconfirmationEvent.emit();
	}
	
}