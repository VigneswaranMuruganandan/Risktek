import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'createSavingsPlanReview-component',
  templateUrl: './../templates/createSavingsPlanReview.html'
})
export class CreateSavingsPlanReviewComponent {
	@Output() backSavingsPlanEvent = new EventEmitter();
	@Output() submitSavingsPlanEvent = new EventEmitter();
	
    confirmSavingsPlan() {
		this.submitSavingsPlanEvent.emit();
	}

	back(){
		this.backSavingsPlanEvent.emit(1);
	}
}