import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { Router } from '@angular/router';

@Component({
  selector: 'editSavingsPlan-component',
  templateUrl: './../templates/editSavingsPlan.html'
})
export class EditSavingsPlanComponent implements OnInit {

	constructor( private router: Router) {}

	ngOnInit() { 
    	//test
    }

    ConfirmEditSavingsPlan(){
    	this.router.navigate(['/iSaveAccount']);
    }
   
}