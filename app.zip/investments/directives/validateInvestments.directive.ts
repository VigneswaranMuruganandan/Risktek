import { Component, ElementRef, Directive, HostListener, NgZone, Input, Output, EventEmitter } from '@angular/core';
import * as $ from 'jquery';
import {TemplateService} from '../../shared/services/template.service';

/*
* Apply Products Selection 
*/
@Directive({
    selector: '[ValidateProductsSelection]',
})
export class ValidateApplyProductsSelection {
    //private x = require('jquery-validator');
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let applyProductStep1Submit:boolean;
        this.zone.runOutsideAngular(() => {
            var applyProductSelectionValidation = (<any>$("#applyProductStep1Form")).validate({
                ignore: [],
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input")) {
                        $('#errorDiv').append(error);
                    }
                },
                rules: {
                    products: {
                        required: true
                    },
                },
                messages: {
                    products: {
                        required: "Please make a selection"
                    }
                }
            });
            applyProductStep1Submit = applyProductSelectionValidation.form();
            this.templateService.setFormValidatorFlag(applyProductStep1Submit);
        });
    }
}
/*
* Emirates location Selection 
*/
@Directive({
    selector: '[ValidateEmiratesSelection]',
})
export class ValidateEmiratesSelection {
    //private x = require('jquery-validator');
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let emiratesStep2Submit:boolean;
        this.zone.runOutsideAngular(() => {
            var emiratesSelectionValidation = (<any>$("#selectEmirateForm")).validate({
                ignore: [],
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("select")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    emirates: {
                        required: true
                    },
                },
                messages: {
                    emirates: {
                        required: "Please make a selection"
                    }
                }
            });
            emiratesStep2Submit = emiratesSelectionValidation.form();
            this.templateService.setFormValidatorFlag(emiratesStep2Submit);
        });
    }
}


