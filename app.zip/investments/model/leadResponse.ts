import {APIResponse} from '../../shared/model/apiResponse';
export class LeadResponse extends APIResponse{
	
	leadId:string;
}