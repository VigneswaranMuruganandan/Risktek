import { Component, OnInit, Input} from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { AccountsService} from '../../accounts/services/accounts.service';
import { ErrorService } from '../../shared/services/error.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { SharedService} from '../../shared/services/shared.service';
import { CustomerAccountsResponse} from '../../accounts/model/customerAccountsResponse';
import { UserDetails } from '../../shared/model/userDetails';
import { UserContext} from '../../shared/model/userContext';
import {AccountSettingsService} from '../services/accountSettings.service';
import { AlertCentreResp } from '../model/alertCentreResp';
import * as $ from 'jquery';

@Component({
    templateUrl: './../templates/accountSettings.html'
})
export class AccountSettingsComponent implements OnInit {
    customerAccountsResponse: CustomerAccountsResponse;
    alertCentreResp:AlertCentreResp;
    accounts: Array < object > ;
    userDetails: UserDetails;
    alertCentreShow = false;
    
    constructor(private accountsService: AccountsService,
                private accountSettingsService: AccountSettingsService,
                private sharedService: SharedService,
                private errorService: ErrorService,
                private spinnerService: SpinnerService) {}
    
    ngOnInit() {
        this.spinnerService.startSpinner('loader');
        this.userDetails = UserContext.getInstance().userDetails;
        this.alertCentreResp = new AlertCentreResp();
        this.fetchAccounts();
        this.getAlertsHistory();
    }

    /*
    * Fetch Customer Accounts 
    */
    fetchAccounts() {
        this.accountsService.fetchCustomerAccounts()
            .subscribe(
                resp => this.handleCustAcctsResp(resp),
                error => this.sharedService.handleError(error)
            );
    }
    
    /*
    * Handle Customer Accounts Response
    */
    handleCustAcctsResp(resp: any) {
        this.spinnerService.stopSpinner('loader');
        if (resp.result.status == "success") {
            this.customerAccountsResponse = new CustomerAccountsResponse();
            this.customerAccountsResponse = resp;
            if(this.customerAccountsResponse.customerProducts && this.customerAccountsResponse.customerProducts.accounts){
                this.accounts = this.customerAccountsResponse.customerProducts.accounts.length >0 ? this.customerAccountsResponse.customerProducts.accounts : [];
            }else{
                this.accounts = [];
            }
        } else if (resp.result.status == 'error') {
            this.errorService.setErrorResp(resp.result);
        }
    }
    /*
    * Fetch Alert Centre History 
    */
    getAlertsHistory(){
        this.accountSettingsService.fetchAlertsHistory()
            .subscribe(
                resp => this.handleAlertsHistoryResp(resp),
                error => this.sharedService.handleError(error)
            );
    }

    /*
    * Handle Alert Centre History Response
    */
    handleAlertsHistoryResp(resp: AlertCentreResp) {
        //this.spinnerService.stopSpinner('loader');
        if (resp.result.status == "success") {
            this.alertCentreResp.alertHistory = resp.alertHistory;
        } else if (resp.result.status == 'error') {
            this.errorService.setErrorResp(resp.result);
        }
    }

    /*
    * Display Alert Centre Page
    */
    displayAlertCentre(event:any){
        this.alertCentreShow = true;
    }

    /*
    * Hide Alert Centre Page
    */
    alertCentreBackButton(event:any){
        this.alertCentreShow = false;
    }

    showTab(id: string, event: any) {
        let tab = $('ul.profileHeaders li a');
        for (let i = 0; i <= tab.length; i++) {
            $(tab[i]).removeClass('active');
        }
        $(event.currentTarget).addClass('active');
        let tabList = $('.profileTabs');
        for (let j = 0; j <= tabList.length; j++) {
            $(tabList[j]).removeClass('in');
            $(tabList[j]).removeClass('active');
        }
        $('#' + id).addClass('in');
        $('#' + id).addClass('active');
    }
}