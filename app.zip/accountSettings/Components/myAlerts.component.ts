import { Component, OnInit, Input,Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { ProfileAlertRes } from '../model/profileAlertRes';
import { ProfileAlertReq } from '../model/profileAlertReq';
import {AccountSettingsService} from '../services/accountSettings.service';
import {ErrorService } from '../../shared/services/error.service';
import {SpinnerService } from '../../shared/services/spinner.service';
import {SharedService} from '../../shared/services/shared.service';

@Component({
    selector: 'myalerts-component',
    templateUrl: './../templates/myAlerts.html'
})
export class MyAlertsComponent implements OnInit {
	profileAlertReq: ProfileAlertReq;
    profileAlertRes: ProfileAlertRes;
    @Output() showAlertCentreEvent = new EventEmitter();
    saveButtonShow = true;
    tempProfileSMS: boolean;
    tempProfileEmail: boolean;
    tempMarketSMS: boolean;
    tempMarketEmail: boolean;
    tempLoginSMS: boolean;
    tempLoginEmail: boolean;

    constructor(private accountSettingsService: AccountSettingsService,
        private sharedService: SharedService,
        private errorService: ErrorService,
        private spinnerService: SpinnerService) {}

    ngOnInit() {
        this.initAlertsPrefFetch();
    }
    /*
    * Fetch Alerts Preference
    */
    initAlertsPrefFetch() {
        this.errorService.resetErrorResp();
        this.spinnerService.startSpinner("loader")
        this.accountSettingsService.fetchAlertPref()
            .subscribe(
                resp => this.handleAlertPrefFetchResp(resp),
                error => this.sharedService.handleError(error)
            );
    }
    handleAlertPrefFetchResp(resp: ProfileAlertRes) {
        this.spinnerService.stopSpinner("loader");
        if (resp && resp.result.status == 'success') {
            console.log(resp);
            this.profileAlertRes = new ProfileAlertRes();
            this.profileAlertRes = resp;
            this.setAlertProfileReq();
        } else if (resp.result.status == 'error') {
            this.errorService.setErrorResp(resp.result);
        }
    }
    /*
    * Setting Init values Alerts Preference
    */
    setAlertProfileReq() {
        this.profileAlertReq = new ProfileAlertReq();
        Object.getOwnPropertyNames(this.profileAlertRes)
    				.map((key: string) => {    					
    					this.profileAlertReq[key] = this.profileAlertRes[key];
    				});
        //Storing default vaules
        this.tempProfileSMS = this.profileAlertRes.profileAlert.sms;
        this.tempProfileEmail = this.profileAlertRes.profileAlert.email;
        this.tempMarketSMS = this.profileAlertRes.maketingAlert.sms;
        this.tempMarketEmail = this.profileAlertRes.maketingAlert.email;
        this.tempLoginSMS = this.profileAlertRes.loginAlert.sms;
        this.tempLoginEmail = this.profileAlertRes.loginAlert.email;
    }

    /*
    * On click of AlertCentre
    */
    showAlertCentre() {
        this.showAlertCentreEvent.emit();
    }

    /*
    * On Change of CheckBox
    */
    onAlertChange(checked: boolean, channel: string, type: string) {
        if (checked) {
            this.profileAlertReq[type][channel] = true;
        } else {
            this.profileAlertReq[type][channel] = false;
        }
        this.toggleSaveButton();
    }
    /*
    * Should Enable/Disable Save chnages button only if user modifies
    */
    toggleSaveButton() {
        if ((this.tempMarketSMS != this.profileAlertReq.maketingAlert.sms) ||
            (this.tempMarketEmail != this.profileAlertReq.maketingAlert.email) ||
            (this.tempProfileSMS != this.profileAlertReq.profileAlert.sms) ||
            (this.tempProfileEmail != this.profileAlertReq.profileAlert.email) ||
            (this.tempLoginSMS != this.profileAlertReq.loginAlert.sms) ||
            (this.tempLoginEmail != this.profileAlertReq.loginAlert.email)) {
            this.saveButtonShow = false;
        } else {
            this.saveButtonShow = true;
        }
    }
    /*
    * Save Alert Preference
    */
    saveAlertPref() {
        this.errorService.resetErrorResp();
        this.spinnerService.startSpinner("loader");
        this.accountSettingsService.updateAlertPref(this.profileAlertReq)
            .subscribe(
                resp => this.handleAlertPrefUpdateResp(resp),
                error => this.sharedService.handleError(error)
            );
    }
    handleAlertPrefUpdateResp(resp: ProfileAlertRes) {
        this.spinnerService.stopSpinner("loader");
        if (resp && resp.result.status == 'success') {
            console.log(resp);
            this.profileAlertRes = resp;
            this.saveButtonShow = true;
            this.tempProfileSMS = this.profileAlertRes.profileAlert.sms;
            this.tempProfileEmail = this.profileAlertRes.profileAlert.email;
            this.tempMarketSMS = this.profileAlertRes.maketingAlert.sms;
            this.tempMarketEmail = this.profileAlertRes.maketingAlert.email;
            this.tempLoginSMS = this.profileAlertRes.loginAlert.sms;
            this.tempLoginEmail = this.profileAlertRes.loginAlert.email;
        } else if (resp.result.status == 'error') {
            this.errorService.setErrorResp(resp.result);
            this.saveButtonShow = false;
        }
    }

}
