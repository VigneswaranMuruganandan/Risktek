import { APIResponse } from '../../shared/model/apiResponse';
import { Amount } from '../../shared/model/amount';

export class ChequeBookChargeResponse extends APIResponse {
	accountIdentifier :string;
	numberOfCheckbooks :string;
	charge :Amount;
}