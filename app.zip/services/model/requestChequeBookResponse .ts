export class RequestChequeBookResponse{
	accountIdentifier :string;
	chequeStatus :string;
	currency :string;
	additionalInformation :string;
	waiveChargesFlag :string;
	name :string;
	numberOfCheckbooksRequested :string;
	checkbookType :string;
	printFlag :string;
	branchIdentifier :string;
	eventTime :string;
	numberOfLeavesRequested :string;
	startNumberOfCheque :string;
	orderDate :string;
	requestId :string;
	modRecordCount :string;
	manufactureDate :string;
	issuedBy :string;
	authoriser :string;
	accountingUnitIdentifier :string;
	departmentId :string;
	overrideCode :string;

}