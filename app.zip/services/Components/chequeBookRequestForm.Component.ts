import { Component, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {TemplateService} from '../../shared/services/template.service';
import { ErrorService} from '../../shared/services/error.service';

@Component({
  selector: 'chequeBookRequestForm-component',
  templateUrl: './../templates/chequeBookRequestForm.html'
})
export class chequeBookRequestFormComponent {
	@Output() validateChequeBookReqEvent = new EventEmitter();

	constructor( public templateService: TemplateService,
				 private errorService: ErrorService) {}

	validateForm(valid: boolean){
		if(valid){
			this.templateService.resetFormValidatorFlag();
			this.validateChequeBookReqEvent.emit();
		}
	}

}



