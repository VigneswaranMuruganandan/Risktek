import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { ErrorService} from '../../shared/services/error.service';

@Component({
  selector: 'chequeBookRequestSucess-component',
  templateUrl: './../templates/chequeBookRequestSuccess.html'
})
export class chequeBookRequestSuccessComponent {
	
	constructor( private errorService: ErrorService ){}
}