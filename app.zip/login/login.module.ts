import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { FormsModule } from '@angular/forms';
import { routing } from './login.routing';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '../shared/shared.module';
import {SharedService} from '../shared/services/shared.service';
import {TemplateService} from '../shared/services/template.service';
import { LoginComponent }   from './Components/login.component';
import { LoginForm1Component }   from './Components/loginform1.component';
import { RegisterSoftTokenComponent }   from './Components/registerSoftToken.component';
import {LoginService} from './services/login.service';
import { ValidateLogin } from './directives/validateLogin.directive';

const LOGIN_COMPONENTS = [
    LoginComponent,
    LoginForm1Component,
    RegisterSoftTokenComponent
];

const LOGIN_DIRECTIVES = [
    ValidateLogin
];

const LOGIN_PROVIDERS = [
   SharedService,
   TemplateService,
   LoginService
];

@NgModule({
  	imports: [
	    routing,
	    TranslateModule.forChild(),
	    SharedModule,
	    FormsModule,
      CommonModule
	],
  	declarations: [
	    ...LOGIN_COMPONENTS,
      ...LOGIN_DIRECTIVES
	],
	providers: [
		...LOGIN_PROVIDERS
	]
})
export class LoginModule {}
