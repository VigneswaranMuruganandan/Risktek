import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CharityComponent } from './Components/charity.component';


const routes: Routes = [
	{
        path: 'charity',
        component: CharityComponent
    },
    {
	    path: '',
	    redirectTo: 'charity',
	    pathMatch: 'full'
	}
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);