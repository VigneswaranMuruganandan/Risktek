import { Component, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: '[charitystep2-component]',
  templateUrl: './../templates/charityStep2.html'
})
export class CharityStep2Component {
@Output() charityReviewPaymentEvent = new EventEmitter();

	charityReviewPayment(){
		this.charityReviewPaymentEvent.emit();
	}
}