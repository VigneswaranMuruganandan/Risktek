import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '../auth-guard.service';
import { TransfersComponent } from './Components/transfers.component';
import { WithinFABTransferComponent } from './Components/withinFABTransfer.component';
import { WithinUAETransferComponent } from './Components/withinUAETransfer.component';
import { OutsideUAETransferComponent } from './Components/outsideUAETransfer.component';
import { AddBeneWithinFABTransferComponent }      from './Components/addBeneWithinFABTransfer.component';
import { AddBeneWithinUAETransferComponent }      from './Components/addBeneWithinUAETransfer.component';
import { AddBeneOutsideUAETransferComponent }     from './Components/addBeneOutsideUAETransfer.component';


const routes: Routes = [
	{
        path: '',
        component: TransfersComponent
    },
    {
	    path: '',
	    redirectTo: '',
	    pathMatch: 'full'
	},
	{
	    path: 'withinFAB',
     	component: WithinFABTransferComponent,
	},
	{
	    path: 'withinUAE',
     	component: WithinUAETransferComponent,
	},
	{
	    path: 'outsideUAE',
     	component: OutsideUAETransferComponent,
	},
	{
	    path: 'addTWithinFAB',
     	component: AddBeneWithinFABTransferComponent,
	},
	{
	    path: 'addTWithinUAE',
     	component: AddBeneWithinUAETransferComponent,
	},
	{
	    path: 'addTOutsideUAE',
     	component: AddBeneOutsideUAETransferComponent,
	},
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);