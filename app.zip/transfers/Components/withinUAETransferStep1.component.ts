import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'withinUAETransferStep1-component',
  templateUrl: './../templates/withinUAETransferStep1.html'
})
export class WithinUAETransferStep1Component {

	@Output() validateFormNextButtonEvent = new EventEmitter();

	validateForm(){
		this.validateFormNextButtonEvent.emit();
	}
    
    
}
