import { Component, OnInit, Input} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'addBeneOutsideUAETransferStep5-component',
  templateUrl: './../templates/addBeneOutsideUAETransferStep5.html'
})
export class AddBeneOutsideUAETransferStep5Component {
 
    
}
