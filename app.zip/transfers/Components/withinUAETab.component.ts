import { Component, OnInit, Input} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'withinUAE-tab',
  templateUrl: './../templates/withinUAETab.html'
})
export class WithinUAETabComponent {

   
}
