import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'addBeneWithinFABTransferStep1-component',
  templateUrl: './../templates/addBeneWithinFABTransferStep1.html'
})
export class AddBeneWithinFABTransferStep1Component {

	@Output() validateFormNextButtonEvent = new EventEmitter();

	validateForm(){
		this.validateFormNextButtonEvent.emit();
	}
    
    
}
