import { Component, OnInit, Input} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'addBeneWithinUAETransferStep4-component',
  templateUrl: './../templates/addBeneWithinUAETransferStep4.html'
})
export class AddBeneWithinUAETransferStep4Component {
 
    
}
