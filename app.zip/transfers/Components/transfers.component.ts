import { Component, OnInit, Input} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  templateUrl: './../templates/transfers.html'
})
export class TransfersComponent implements OnInit{


    constructor() {}

	ngOnInit() { 
    
    }  
    
}
