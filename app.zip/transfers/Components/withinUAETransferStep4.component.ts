import { Component, OnInit, Input} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'withinUAETransferStep4-component',
  templateUrl: './../templates/withinUAETransferStep4.html'
})
export class WithinUAETransferStep4Component {
 
    
}
