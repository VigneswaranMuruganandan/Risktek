import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'addBeneOutsideUAETransferStep3-component',
  templateUrl: './../templates/addBeneOutsideUAETransferStep3.html'
})
export class AddBeneOutsideUAETransferStep3Component {

	@Output() confirmReviewButtonEvent = new EventEmitter();
	@Output() backReviewButtonEvent = new EventEmitter();

	confirmReview(){
		this.confirmReviewButtonEvent.emit();
	}

	backReview(){
		this.backReviewButtonEvent.emit();
	}
    

    
}
