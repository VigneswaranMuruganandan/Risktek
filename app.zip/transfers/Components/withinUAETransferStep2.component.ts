import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'withinUAETransferStep2-component',
  templateUrl: './../templates/withinUAETransferStep2.html'
})
export class WithinUAETransferStep2Component {

	@Output() confirmReviewButtonEvent = new EventEmitter();
	@Output() backReviewButtonEvent = new EventEmitter();

	confirmReview(){
		this.confirmReviewButtonEvent.emit();
	}

	backReview(){
		this.backReviewButtonEvent.emit();
	}
    

    
}
