import { Component, OnInit, Input} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'withinFABTransferStep4-component',
  templateUrl: './../templates/withinFABTransferStep4.html'
})
export class WithinFABTransferStep4Component {
 
    
}
