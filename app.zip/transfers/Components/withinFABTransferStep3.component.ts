import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'withinFABTransferStep3-component',
  templateUrl: './../templates/withinFABTransferStep3.html'
})
export class WithinFABTransferStep3Component {

	@Output() validateOTPEvent = new EventEmitter();
	@Output() backOTPButtonEvent = new EventEmitter();

	validateOTP(){
		this.validateOTPEvent.emit();
	}

	backOTP(){
		this.backOTPButtonEvent.emit();
	}
    
}
