import {APIResponse} from '../../shared/model/apiResponse';
export class VerifyPasswordResponse extends APIResponse{
	
}