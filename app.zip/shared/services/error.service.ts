import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import * as $ from 'jquery';
import { GlobalVariable } from './global';
import { InvocationResult } from '../model/invocationResult';
import { ErrorInfo } from '../model/errorInfo';


@Injectable()
export class ErrorService{
  errorResp : InvocationResult;
  
  constructor(private http : Http){
    this.resetErrorResp(); 
  }
  /*
  * Set the Error Message and code
  */
  setErrorResp(resp : InvocationResult){
    this.errorResp.status = resp.status == 'error' ? 'true': 'false'; 
    this.errorResp.errorInfo = new ErrorInfo();
    this.errorResp.errorInfo.code = resp.errorInfo.code;
    this.errorResp.errorInfo.desc = resp.errorInfo.desc;
    this.verifyErrorCode(resp);
  }
  /*
  * Get the Error status
  */
  getErrorStatus(){
    return this.errorResp.status;
  }
  /*
  * Get the Error Message
  */
  getErrorMessage(field: string){
    return this.errorResp.errorInfo[field];
  }
  /*
  * Reset the Error Response
  */
  resetErrorResp(){
    this.errorResp = new InvocationResult();
    this.errorResp.status = 'false';
  }
  /*
  * Verify the Code
  */
  verifyErrorCode(resp : InvocationResult){
    let desc = GlobalVariable.ERROR_CODES[resp.errorInfo.code];
    if(desc){      
      this.errorResp.errorInfo.desc = desc.replace(/MESSAGE_DISPLAY/g, resp.msgArgs[0]);
    }    
  }    
}