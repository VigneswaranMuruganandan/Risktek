import { Component, OnInit, Input} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  templateUrl: './../templates/outsideUAEAddBene.html'
})
export class OutsideUAEAddBeneComponent implements OnInit{

	public stepValue: number;
    constructor() {}

	ngOnInit() { 
    	this.stepValue = 1;
    }

    validateBeneFormNextButton(){
    	this.stepValue = 2;
    }
    
    validateTransferFormNextButton(){
        this.stepValue = 3;
    }

    backToBeneFormButton(){
        this.stepValue = 1;
    }

    confirmReviewButton(){
    	this.stepValue = 4;
    }

    backReviewButton(){
        this.stepValue = 2;
    }

    validateOTP(){
    	this.stepValue = 5;
    }

    backOTPButton(){
        this.stepValue = 3;
    }


   
    
}
