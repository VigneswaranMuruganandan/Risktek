import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { Router } from '@angular/router';
import {CreateBeneficiaryRequest} from '../model/createBeneficiaryRequest';
import {TemplateService} from '../../shared/services/template.service';

@Component({
  selector: 'withinUAEAddBeneStep1-component',
  templateUrl: './../templates/withinUAEAddBeneStep1.html'
})
export class WithinUAEAddBeneStep1Component {

	@Output() validateFormNextButtonEvent = new EventEmitter();
	@Input() createBeneficiaryRequest:CreateBeneficiaryRequest;

	constructor( public templateService: TemplateService) {}

	validateForm(valid:boolean){
		if(valid){
            this.templateService.resetFormValidatorFlag();
            this.validateFormNextButtonEvent.emit();
        }   
	}
    
}
