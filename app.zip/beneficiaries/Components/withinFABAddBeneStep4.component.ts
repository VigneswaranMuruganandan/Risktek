import { Component, OnInit, Input} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'withinFABAddBeneStep4-component',
  templateUrl: './../templates/withinFABAddBeneStep4.html'
})
export class WithinFABAddBeneStep4Component {


    
    
}
