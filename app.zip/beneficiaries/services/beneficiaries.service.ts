import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import {GlobalURL} from '../../shared/services/globalURL';
import {ServiceInvoker} from '../../shared/connector/serviceInvoker.service';
import {EncryptionService} from '../../shared/services/encryption.service';
import {BeneListResp} from '../model/beneListResp';
import {BillerListResp} from '../model/billerListResp';
import {CreateBeneficiaryRequest} from '../model/createBeneficiaryRequest';
import {CreateBeneficiaryResponse} from '../model/createBeneficiaryResponse';


@Injectable()
export class BeneficiariesService {

  	constructor(private serviceInvoker: ServiceInvoker, 
                private encryptionService: EncryptionService) {}

    fetchBeneTransferList(): Observable <BeneListResp> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.BENEFICIARIES.BENE_TRANSFER_FETCH,null)
                                .map(resp => JSON.parse(resp));
    }

    fetchBenePaymentList(): Observable <BillerListResp> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.BENEFICIARIES.BENE_PAYMENT_FETCH,null)
                                .map(resp => JSON.parse(resp));
    }

    createBeneficiary(data:CreateBeneficiaryRequest): Observable <CreateBeneficiaryResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.BENEFICIARIES.CREATE_BENEF,data)
                                .map(resp => JSON.parse(resp));
    }

}


