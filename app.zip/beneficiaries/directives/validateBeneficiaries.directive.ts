import { Component, ElementRef, Directive, HostListener, NgZone, Input, Output, EventEmitter } from '@angular/core';
import * as $ from 'jquery';
import {TemplateService} from '../../shared/services/template.service';

/*
* Add FAB beneficiary
*/
@Directive({
    selector: '[ValidateFABBeneDirective]',
})
export class ValidateFABBeneficiary {
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let fabBeneStep1Submit:boolean;
        this.zone.runOutsideAngular(() => {
            (<any>$).validator.addMethod("customBenefName", function (value, element, param) {
                    if(value){
                        var isValid = false;
                        var splitted = value.split(' ');
                        if(splitted.length > 1){
                            if(splitted[0].length >=1 && splitted[1].length >= 1){
                                isValid = true;
                            }
                        }
                    }
                    return this.optional(element) || (isValid);
                });
            var fabBeneDetailsValidation = (<any>$("#fabBeneStep1Form")).validate({
                ignore: [],
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input")) {
                        element.parent().append(error);
                    }
                },
                 rules: {
                    beneName: {
                        required: true,
                        customBenefName:true

                    },
                    beneNickName: {
                        required: true
                    },
                    accountNumber: {
                        required: true,
                        minlength:16
                    }
                },
                messages: {
                    beneName: {
                        required: "Please fill in",
                        customBenefName:"Please enter the complete beneficiary name"
                    },
                    beneNickName: {
                        required: "Please fill in"
                    },
                    accountNumber: {
                        required: "Please fill in",
                        minlength:"Please enter a valid Account number"
                    }
                }
            });
            fabBeneStep1Submit = fabBeneDetailsValidation.form();
            this.templateService.setFormValidatorFlag(fabBeneStep1Submit);
        });
    }
}


/*
* Add Within UAE beneficiary
*/
@Directive({
    selector: '[ValidateWithinUAEBeneDirective]',
})
export class ValidateWithinUAEBeneficiary {
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let withinUAEBeneStep1Submit:boolean;
        this.zone.runOutsideAngular(() => {
            (<any>$).validator.addMethod("customBenefName", function (value, element, param) {
                    if(value){
                        var isValid = false;
                        var splitted = value.split(' ');
                        if(splitted.length > 1){
                            if(splitted[0].length >=1 && splitted[1].length >= 1){
                                isValid = true;
                            }
                        }
                    }
                    return this.optional(element) || (isValid);
                });
            /*(<any>$).validator.addMethod("creditCardValid", function (value, element, param) {
                    var isValid = true;
                    if(value && $scope.data.transferUAE.transferTo == 'Credit Card'){
                        isValid = false;
                        if((value.charAt(0) == '4' || value.charAt(0) == '5' || value.charAt(0) == '2') && value.length == 16){
                            isValid = true;
                        }
                        
                    }
                    return this.optional(element) || (isValid);
                });
             (<any>$).validator.addMethod("ibanValid", function (value, element, param) {
                    var isValid = true;
                    if(value && $scope.data.transferUAE.transferTo == 'Bank Account'){
                        isValid = false;
                        if(value.length == 23){
                            isValid = true;
                        }
                        
                    }
                    return this.optional(element) || (isValid);
                });*/
            var withinUAEBeneDetailsValidation = (<any>$("#withinUAEBeneStep1Form")).validate({
                ignore: [],
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input")) {
                        element.parent().append(error);
                    }
                },
                 rules: {
                    beneName: {
                        required: true,
                        customBenefName:true

                    },
                    beneNickName: {
                        required: true
                    },
                    accountOrCard: {
                        required: true
                    },
                    bankName: {
                        required: true
                    }
                },
                messages: {
                    beneName: {
                        required: "Please fill in",
                        customBenefName:"Please enter the complete beneficiary name"
                    },
                    beneNickName: {
                        required: "Please fill in"
                    },
                    accountOrCard: {
                        required: "Please fill in",
                    },
                    bankName: {
                        required: "Please fill in"
                    }
                }
            });
            withinUAEBeneStep1Submit = withinUAEBeneDetailsValidation.form();
            this.templateService.setFormValidatorFlag(withinUAEBeneStep1Submit);
        });
    }
}