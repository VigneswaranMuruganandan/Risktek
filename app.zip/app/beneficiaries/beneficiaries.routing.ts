import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '../auth-guard.service';
import { BeneficiariesComponent } from './Components/beneficiaries.component';
import { BeneficiariesTransfersComponent } from './Components/beneficiariesTransfers.component';
import { BeneficiariesPaymentsComponent } from './Components/beneficiariesPayments.component';
import { WithinFABAddBeneComponent } from './Components/withinFABAddBene.component';
import { WithinUAEAddBeneComponent } from './Components/withinUAEAddBene.component';
import { OutsideUAEAddBeneComponent }     from './Components/outsideUAEAddBene.component';
import { AddBillerComponent }      from './Components/addBiller.component';


const routes: Routes = [
	
    {
	    path: '',
     	component: BeneficiariesComponent,
	},
    {
	    path: '',
	    redirectTo: '',
	    pathMatch: 'full'
	},
	{
	    path: 'withinFAB',
     	component: WithinFABAddBeneComponent,
	},
	{
	    path: 'withinUAE',
     	component: WithinUAEAddBeneComponent,
	},
	{
	    path: 'outsideUAE',
     	component: OutsideUAEAddBeneComponent,
	},
	{
	    path: 'addBiller',
     	component: AddBillerComponent,
	}
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);