import { Component, ElementRef, Directive, HostListener, NgZone, Input, Output, EventEmitter } from '@angular/core';
import * as $ from 'jquery';
import {TemplateService} from '../../shared/services/template.service';

/*
* Add FAB beneficiary
*/
@Directive({
    selector: '[ValidateFABBeneDirective]',
})
export class ValidateFABBeneficiary {
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let fabBeneStep1Submit:boolean;
        this.zone.runOutsideAngular(() => {
            (<any>$).validator.addMethod("customBenefName", function (value, element, param) {
                    if(value){
                        var isValid = false;
                        var splitted = value.split(' ');
                        if(splitted.length > 1){
                            if(splitted[0].length >=1 && splitted[1].length >= 1){
                                isValid = true;
                            }
                        }
                    }
                    return this.optional(element) || (isValid);
                });
            var fabBeneDetailsValidation = (<any>$("#fabBeneStep1Form")).validate({
                ignore: [],
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input")) {
                        element.parent().append(error);
                    }
                },
                 rules: {
                    beneName: {
                        required: true,
                        customBenefName:true

                    },
                    beneNickName: {
                        required: true
                    },
                    accountNumber: {
                        required: true,
                        minlength:16
                    }
                },
                messages: {
                    beneName: {
                        required: "Please fill in",
                        customBenefName:"Please enter the complete beneficiary name"
                    },
                    beneNickName: {
                        required: "Please fill in"
                    },
                    accountNumber: {
                        required: "Please fill in",
                        minlength:"Please enter a valid Account number"
                    }
                }
            });
            fabBeneStep1Submit = fabBeneDetailsValidation.form();
            this.templateService.setFormValidatorFlag(fabBeneStep1Submit);
        });
    }
}


/*
* Add Within UAE beneficiary
*/
@Directive({
    selector: '[ValidateWithinUAEBeneDirective]',
})
export class ValidateWithinUAEBeneficiary {
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let withinUAEBeneStep1Submit:boolean;
        var temp;
        this.zone.runOutsideAngular(() => {
            (<any>$).validator.addMethod("customBenefName", function (value, element, param) {
                    if(value){
                        var isValid = false;
                        var splitted = value.split(' ');
                        if(splitted.length > 1){
                            if(splitted[0].length >=1 && splitted[1].length >= 1){
                                isValid = true;
                            }
                        }
                    }
                    return this.optional(element) || (isValid);
                });
           /* (<any>$).validator.addMethod("creditCardValid", function (value, element, param) {
                    temp = parseInt(value.charAt(0))? 'credit': 'account';
                    if(value){
                        var isValid = false;
                        if(value.length == 16 && temp == 'credit'){
                            isValid = true;
                        }
                        if(value.length == 23 && temp == 'account'){
                            isValid = true;
                        }
                        
                    }
                    return this.optional(element) || (isValid);
                });
             (<any>$).validator.addMethod("ibanValid", function (value, element, param) {
                    var isValid = true;
                    temp = parseInt(value.charAt(0))? 'credit': 'account';
                    if(value ){
                        isValid = false;
                        if(value.length == 23 && temp == 'account'){
                            isValid = true;
                        }
                        
                    }
                    return this.optional(element) || (isValid);
                });*/
            var withinUAEBeneDetailsValidation = (<any>$("#withinUAEBeneStep1Form")).validate({
                ignore: [],
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input")) {
                        element.parent().append(error);
                    }
                    if (element.is("select")) {
                        element.parent().append(error);
                    }
                },
                 rules: {
                    beneName: {
                        required: true,
                        customBenefName:true

                    },
                    beneNickName: {
                        required: true
                    },
                    accountOrCard: {
                        required: true
                        //creditCardValid:true
                    },
                    bankName: {
                        required: true
                    }
                },
                messages: {
                    beneName: {
                        required: "Please fill in",
                        customBenefName:"Please enter the complete beneficiary name"
                    },
                    beneNickName: {
                        required: "Please fill in"
                    },
                    accountOrCard: {
                        required: "Please fill in"
                        /*creditCardValid:function(input) {
                             return customMessage(input);
                        }*/
                    },
                    bankName: {
                        required: "Please fill in"
                    }
                }
            });
            
            /*function customMessage(){
                if(temp=='credit'){
                   return input.data("message");
                 }else{
                    return input.data("message");
             }

            }*/
            

            withinUAEBeneStep1Submit = withinUAEBeneDetailsValidation.form();
            this.templateService.setFormValidatorFlag(withinUAEBeneStep1Submit);
        });
    }
}


/*
* Add Outside UAE beneficiary
*/
@Directive({
    selector: '[ValidateOutsideUAEBeneDirective]',
})
export class ValidateOutsideUAEBeneficiary {
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let outsideUAEBeneStep1Submit:boolean;
        this.zone.runOutsideAngular(() => {
            (<any>$).validator.addMethod("customBenefName", function (value, element, param) {
                    if(value){
                        var isValid = false;
                        var splitted = value.split(' ');
                        if(splitted.length > 1){
                            if(splitted[0].length >=1 && splitted[1].length >= 1){
                                isValid = true;
                            }
                        }
                    }
                    return this.optional(element) || (isValid);
                });
            var outsideUAEBeneDetailsValidation = (<any>$("#outsideUAEBeneStep1Form")).validate({
                ignore: [],
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input")) {
                        element.parent().append(error);
                    }
                    if (element.is("select")) {
                        element.parent().append(error);
                    }
                },
                 rules: {
                    beneName: {
                        required: true,
                        customBenefName:true

                    },
                    beneNickName: {
                        required: true
                    },
                    beneAddress: {
                        required: true
                    },
                    accountNumber: {
                        required: true
                    },
                    bankName: {
                        required: true
                    },
                    bankCountry: {
                        required: true
                    },
                    bankAddress: {
                        required: true
                    },
                    bankSwiftCode: {
                        required: true
                    },
                    bankSortCode: {
                        required: true
                    }
                },
                messages: {
                    beneName: {
                        required: "Please fill in",
                        customBenefName:"Please enter the complete beneficiary name"
                    },
                    beneNickName: {
                        required: "Please fill in"
                    },
                    beneAddress: {
                        required: "Please fill in"
                    },
                    accountNumber: {
                        required: "Please fill in"
                    },
                    bankName: {
                         required: "Please fill in"
                    },
                    bankCountry: {
                        required: "Please fill in"
                    },
                    bankAddress: {
                        required: "Please fill in"
                    },
                    bankSwiftCode: {
                        required: "Please fill in"
                    },
                    bankSortCode: {
                        required: "Please fill in"
                    }
                }
            });

            console.log(outsideUAEBeneDetailsValidation)
            outsideUAEBeneStep1Submit = outsideUAEBeneDetailsValidation.form();
            this.templateService.setFormValidatorFlag(outsideUAEBeneStep1Submit);
        });
    }
}


/*
* Validation for addition Beneficiary of Biller and Automatic Biller
*/
@Directive({
    selector: '[ValidateBillerBeneDirective]',
})
export class ValidateBillerBeneficiary {

    @Input() createBillerBeneRequest: any;

    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {

        console.log(this.createBillerBeneRequest);
        
        var el = $(this.el.nativeElement);
        let billerBeneForm:boolean;
        this.zone.runOutsideAngular(() => {
            (<any>$).validator.addMethod("autoConsumereLengthValidation", function (value, element, param) {
                  if((param.createBillerBeneRequest && param.createBillerBeneRequest.agency =="ETISALAT") || 
                      (param.createBillerBeneRequest && param.createBillerBeneRequest.agency =="DU")){
                     return true;
                  }else{
                     return this.optional(element) || (value.length == 10 );
                  }
            
             });
            var billerBeneDetailsValidation = (<any>$("#billerBeneAddForm")).validate({
                ignore: [],
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input")) {
                        element.parent().append(error);
                    }
                     if (element.is("select")) {
                        element.parent().append(error);
                    }
                },
                 rules: {
                    billerAgency: {
                        required: true
                    },
                    consumerNo: {
                        required: true
                        //autoConsumereLengthValidation: this.createBillerBeneRequest
                    },
                    nickName: {
                        required: true
                    },
                    salikPinNo: {
                        required: true
                    },
                    billerDate: {
                        required: true
                    },
                    minAmount:{
                        required: true
                    },
                    amount: {
                        required: true,
                        min: () => { 
                                if(this.createBillerBeneRequest && this.createBillerBeneRequest.agency){
                                    if(this.createBillerBeneRequest.agency =="ETISALAT"){
                                        return 10;
                                    }else if( this.createBillerBeneRequest.agency =="DU"){
                                        return 20;
                                    }else{
                                        return 1;
                                    }
                                }
                            }
                    },
                    sourceAccount: {
                        required: true
                    }
                },
                messages: {
                    billerAgency: {
                        required: "Please select"
                    },
                    consumerNo: {
                        required: "Please fill in"
                        //autoConsumereLengthValidation: "Length of consumer number should be 10"
                    },
                    nickName: {
                        required: "Please fill in"
                    },
                    salikPinNo: {
                        required: "Please fill in"
                    },
                    billerDate: {
                        required: "Please fill in"
                    },
                    minAmount:{
                        required: "Please fill in"
                    },
                    amount: {
                        required: "Please fill in",
                        min: () => { 
                                if(this.createBillerBeneRequest && this.createBillerBeneRequest.agency =="ETISALAT"){
                                    return "Minimum payment accepted is AED 10";
                                }else if( this.createBillerBeneRequest.agency =="DU"){
                                    return "Minimum payment accepted is AED 20";
                                }else{
                                    return "Minimum payment accepted is AED 1";
                                }
                                    
                            }
                    },
                    sourceAccount: {
                        required: "Please fill in"
                    }
                }
            });
            billerBeneForm = billerBeneDetailsValidation.form();
            this.templateService.setFormValidatorFlag(billerBeneForm);
            
            });
    }
}