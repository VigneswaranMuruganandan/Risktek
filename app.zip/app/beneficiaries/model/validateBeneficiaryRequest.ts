
export class ValidateBeneficiaryRequest{
  	fundTransferType:string;
    nickName:string;
    accountOrCardNo:string;
    operation:string;
    beneName:string;
}

