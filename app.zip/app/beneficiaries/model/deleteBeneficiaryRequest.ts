
export class DeleteBeneficiaryRequest {

  	fundTransferType:string;
    authKey:string;
    nickName:string;
    beneId:string;
}

