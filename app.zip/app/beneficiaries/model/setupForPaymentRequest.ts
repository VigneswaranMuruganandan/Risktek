export class SetupForPaymentRequest {

	paymentType:string;

}

