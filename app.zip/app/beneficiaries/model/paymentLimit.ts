import {Amount} from '../../shared/model/amount';

export class PaymentLimit {
    dailyTransferLimit:Amount;
    txnTransferLimit:Amount;
    availableLimit:Amount;
    paymentType:string;

}

