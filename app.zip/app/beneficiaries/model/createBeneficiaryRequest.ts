
export class CreateBeneficiaryRequest{

  	transferType:string;
    authKey:string;
    txnRef:string;
    nickName:string;
    receiverName:string;
    receiverBankName:string;
    routingCode:string;
    accountOrCardNo:string;
    receiverBankAddress:string;
    receiverBankSwiftCode:string;
    receiverBankCountry:string;
    receiverBankSortCode:string;

}

