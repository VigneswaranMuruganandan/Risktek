import { Autopay } from '../../transfers/model/autopay';

export class CreateBillerBeneRequest{
	authKey:string;
	txnRef:string;
    agency:string;
    consumerNo:string;
    salikPinNo:string
    nickName:string;
    autopayEnabled:boolean;
    accountOrCardNo:string;
    autoPayAmount:string;
    minAmount:number;
    productType:string;
    autopay :Autopay;
}

