
export class DeleteBillerBeneRequest{
	agency:string;
	consumerNo:string;
}

