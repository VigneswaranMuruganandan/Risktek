import {APIResponse} from '../../shared/model/apiResponse';
import {Product} from '../../shared/model/product';
import {PaymentLimit} from './paymentLimit';

export class SetupForPaymentResponse  extends APIResponse{
	
	paymentType:string;
	fundingSources:Product[];
	txnRef:string;
	numberOfPayments :number[];
	frequencies: string[];
	paymentLimits:PaymentLimit[];
}

