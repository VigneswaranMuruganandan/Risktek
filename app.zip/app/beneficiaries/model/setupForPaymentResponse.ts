import {APIResponse} from '../../shared/model/apiResponse';
import {Product} from '../../shared/model/product';

export class SetupForPaymentResponse  extends APIResponse{

	paymentType:string;
	fundingSources:Product[];
	txnRef:string;
	numberOfPayments :number[];
	frequencies: string[];
}

