import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'outsideUAEAddBeneStep4-component',
  templateUrl: './../templates/outsideUAEAddBeneStep4.html'
})
export class OutsideUAEAddBeneStep4Component {

	@Output() validateOTPEvent = new EventEmitter();
	@Output() backOTPButtonEvent = new EventEmitter();

	validateOTP(){
		this.validateOTPEvent.emit();
	}

	backOTP(){
		this.backOTPButtonEvent.emit();
	}
    
}
