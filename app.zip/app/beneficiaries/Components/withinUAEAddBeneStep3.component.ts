import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { Router } from '@angular/router';
import { SendOtpRequest} from '../../shared/model/sendOtpRequest';
import { SendOtpResponse} from '../../shared/model/sendOtpResponse';

@Component({
  selector: 'withinUAEAddBeneStep3-component',
  templateUrl: './../templates/withinUAEAddBeneStep3.html'
})
export class WithinUAEAddBeneStep3Component {

	@Output() validateOTPEvent = new EventEmitter();
	@Output() backOTPButtonEvent = new EventEmitter();
	@Input() sendOtpRequest:SendOtpRequest;
	@Input() sendOtpResponse:SendOtpResponse;

	validateOTP(otp : string){
		this.validateOTPEvent.emit(otp);
	}

	backOTP(){
		this.backOTPButtonEvent.emit();
	}
    
}
