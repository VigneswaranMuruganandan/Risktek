import { Component, OnInit, Input} from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'outsideUAEAddBeneStep5-component',
  templateUrl: './../templates/outsideUAEAddBeneStep5.html'
})
export class OutsideUAEAddBeneStep5Component {
 
    
}
