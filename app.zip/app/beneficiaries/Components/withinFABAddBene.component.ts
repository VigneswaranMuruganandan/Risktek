import { Component, OnInit, Input} from '@angular/core';
import { SharedService} from '../../shared/services/shared.service';
import { TranslateService} from '@ngx-translate/core';
import { ErrorService } from '../../shared/services/error.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { GlobalVariable} from '../../shared/services/global';
import { BeneficiariesService} from '../services/beneficiaries.service';
import { CreateBeneficiaryRequest} from '../model/createBeneficiaryRequest';
import { CreateBeneficiaryResponse} from '../model/createBeneficiaryResponse';
import { SendOtpRequest} from '../../shared/model/sendOtpRequest';
import { SendOtpResponse} from '../../shared/model/sendOtpResponse';
import { AppSession} from '../../shared/model/appSession';
import { SetupForBeneficiaryResponse} from '../model/setupForBeneficiaryResponse';
import { SetupForBeneficiaryRequest} from '../model/setupForBeneficiaryRequest';
import { ValidateBeneficiaryRequest} from '../model/validateBeneficiaryRequest';
import { APIResponse } from '../../shared/model/apiResponse';

@Component({
  templateUrl: './../templates/withinFABAddBene.html'
})
export class WithinFABAddBeneComponent implements OnInit{
  	public stepValue: number;
    public sendOtpRequest:SendOtpRequest;
    public sendOtpResponse:SendOtpResponse;
    public setupForBeneficiaryRequest:SetupForBeneficiaryRequest;
    public setupForBeneficiaryResponse:SetupForBeneficiaryResponse;
    public validateBeneficiaryRequest:ValidateBeneficiaryRequest;
  
    createBeneficiaryRequest:CreateBeneficiaryRequest;
    createBeneficiaryResponse:CreateBeneficiaryResponse;
    constructor(private beneficiariesService:BeneficiariesService,
                private sharedService: SharedService,
                private errorService: ErrorService,
                private spinnerService: SpinnerService){}

	  ngOnInit() { 
      this.initWithinFAB();
    }

    initWithinFAB(){
      this.stepValue = 1;
      this.createBeneficiaryRequest = new CreateBeneficiaryRequest();
      this.setupForBeneficiaryRequest = new SetupForBeneficiaryRequest();
      this.validateBeneficiaryRequest = new ValidateBeneficiaryRequest();
      this.errorService.resetErrorResp();
      this.fetchBeneficiarySetup();
    }

    fetchBeneficiarySetup(){
      this.setupForBeneficiaryRequest.transferType = GlobalVariable.TRANSFER_TYPES.WITHIN_BANK_FUNDS_TRANSFER;
      this.beneficiariesService.beneficiarySetup(this.setupForBeneficiaryRequest)
            .subscribe(
                resp => this.handleTransferSetupResp(resp),
                error => this.sharedService.handleError(error)
            );

    }

    handleTransferSetupResp(resp:any){
        this.spinnerService.stopSpinner('loader');
        if (resp.result.status == "success") {
            this.setupForBeneficiaryResponse = new SetupForBeneficiaryResponse();
            this.setupForBeneficiaryResponse = resp;
        }else if (resp.result.status == 'error') {
            this.errorService.setErrorResp(resp.result);
        }
    }

    validateFormNextButton(){
      this.errorService.resetErrorResp();
      this.spinnerService.startSpinner('loader');
      this.validateBeneficiaryRequest.nickName = this.createBeneficiaryRequest.nickName;
      this.validateBeneficiaryRequest.accountOrCardNo = this.createBeneficiaryRequest.accountOrCardNo;
      this.validateBeneficiaryRequest.beneName = this.createBeneficiaryRequest.receiverName;
      this.validateBeneficiaryRequest.operation = GlobalVariable.OPERATION_TYPE.ADD;
      this.validateBeneficiaryRequest.fundTransferType = GlobalVariable.TRANSFER_TYPES.WITHIN_BANK_FUNDS_TRANSFER;
      this.beneficiariesService.validateBeneficary(this.validateBeneficiaryRequest)
            .subscribe(
                resp => this.handleValidateBeneResp(resp),
                error => this.sharedService.handleError(error)
            );
    }

    handleValidateBeneResp(resp:APIResponse){
      this.spinnerService.stopSpinner('loader');
      if (resp.result.status == "success") {
          this.stepValue = 2;
      }else if (resp.result.status == 'error') {
          this.errorService.setErrorResp(resp.result);
      }
    }


    confirmReviewButton(){
      this.errorService.resetErrorResp();
      this.spinnerService.startSpinner('loader');
      this.sendOtpRequest = new SendOtpRequest();
      this.sendOtpRequest.txnCode = GlobalVariable.TRANSACTION_CODES.BENEF_ADD_WITHIN_BANK_FUNDS_TRANSFER;
      this.sendOtpRequest.txnRef = this.setupForBeneficiaryResponse.txnRef;
      this.sharedService.sendOTP(this.sendOtpRequest)
        .subscribe(
            resp => this.handleSendOTPResp(resp),
            error => this.sharedService.handleError(error)
        );     
    }

    handleSendOTPResp(resp:SendOtpResponse){
      this.spinnerService.stopSpinner('loader');
      if (resp.result.status == "success") {
          this.sendOtpResponse = new SendOtpResponse();
          this.sendOtpResponse = resp;
          this.stepValue = 3;
      }else if (resp.result.status == 'error') {
          this.errorService.setErrorResp(resp.result);
      }
    }

    backReviewButton(){
        this.stepValue = 1;
    }

    validateOTP(otp: string){
      if(otp){
          this.errorService.resetErrorResp();
          this.createBeneficiaryRequest.authKey = otp;
          this.createBeneficiaryRequest.transferType = GlobalVariable.TRANSFER_TYPES.WITHIN_BANK_FUNDS_TRANSFER;
          this.createBeneficiaryRequest.txnRef = this.setupForBeneficiaryResponse.txnRef;
          this.errorService.resetErrorResp();
          this.spinnerService.startSpinner('loader');
          this.beneficiariesService.createBeneficiary(this.createBeneficiaryRequest)
            .subscribe(
                resp => this.handleAddBeneResp(resp),
                error => this.sharedService.handleError(error)
            );
        }   
    }

    handleAddBeneResp(resp:CreateBeneficiaryResponse){
      this.spinnerService.stopSpinner('loader');
      this.createBeneficiaryResponse = new CreateBeneficiaryResponse();
      this.createBeneficiaryResponse = resp;
      if (resp.result.status == "success") {
          this.stepValue = 4;
      }else if (resp.result.status == 'error') {
          let nextStep = this.errorService.handleOTPError(resp.result);
            if(nextStep) {
                this.stepValue = 4;
            }
      }
    }


    backOTPButton(){
        this.stepValue = 2;
    }
    
    reloadStepOne(){
      this.initWithinFAB();
    }
}
