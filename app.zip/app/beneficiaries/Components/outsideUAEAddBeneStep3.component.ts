import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'outsideUAEAddBeneStep3-component',
  templateUrl: './../templates/outsideUAEAddBeneStep3.html'
})
export class OutsideUAEAddBeneStep3Component {

	@Output() confirmReviewButtonEvent = new EventEmitter();
	@Output() backReviewButtonEvent = new EventEmitter();

	confirmReview(){
		this.confirmReviewButtonEvent.emit();
	}

	backReview(){
		this.backReviewButtonEvent.emit();
	}
    

    
}
