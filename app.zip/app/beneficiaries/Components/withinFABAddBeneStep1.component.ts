import { Component, OnInit, Input, Output, EventEmitter,AfterViewInit} from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService} from '@ngx-translate/core';
import {CreateBeneficiaryRequest} from '../model/createBeneficiaryRequest';
import {TemplateService} from '../../shared/services/template.service';
import { UserContext} from '../../shared/model/userContext';
import { GlobalVariable} from '../../shared/services/global';

@Component({
  selector: 'withinFABAddBeneStep1-component',
  templateUrl: './../templates/withinFABAddBeneStep1.html'
})
export class WithinFABAddBeneStep1Component implements AfterViewInit {

	@Output() validateFormNextButtonEvent = new EventEmitter();
	@Input() createBeneficiaryRequest:CreateBeneficiaryRequest;

	constructor( public templateService: TemplateService) {}

	ngAfterViewInit(){
      if(UserContext.getInstance().addOrEditBeneficiary == GlobalVariable.OPERATION_TYPE.UPDATE)
        (<any>$('#nickName')).prop("readonly",true);
    }

	validateForm(valid:boolean){
		if(valid){
            this.templateService.resetFormValidatorFlag();
            this.validateFormNextButtonEvent.emit();
        }   
	}
    
    
}
