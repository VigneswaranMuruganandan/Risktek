import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService} from '@ngx-translate/core';
import { SendOtpRequest} from '../../shared/model/sendOtpRequest';
import { SendOtpResponse} from '../../shared/model/sendOtpResponse';

@Component({
  selector: 'withinFABAddBeneStep3-component',
  templateUrl: './../templates/withinFABAddBeneStep3.html'
})
export class WithinFABAddBeneStep3Component {

	@Output() validateOTPEvent = new EventEmitter();
	@Output() backOTPButtonEvent = new EventEmitter();
	@Input() sendOtpRequest:SendOtpRequest;
	@Input() sendOtpResponse:SendOtpResponse;

	validateOTP(otp : string){
		this.validateOTPEvent.emit(otp);
	}

	backOTP(){
		this.backOTPButtonEvent.emit();
	}
    
}
