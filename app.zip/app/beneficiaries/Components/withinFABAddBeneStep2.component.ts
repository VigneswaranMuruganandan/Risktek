import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService} from '@ngx-translate/core';
import {CreateBeneficiaryRequest} from '../model/createBeneficiaryRequest';

@Component({
	selector: 'withinFABAddBeneStep2-component',
  templateUrl: './../templates/withinFABAddBeneStep2.html'
})
export class WithinFABAddBeneStep2Component {

	@Output() confirmReviewButtonEvent = new EventEmitter();
	@Output() backReviewButtonEvent = new EventEmitter();
	@Input() createBeneficiaryRequest:CreateBeneficiaryRequest;

	confirmReview(){
		this.confirmReviewButtonEvent.emit();
	}

	backReview(){
		this.backReviewButtonEvent.emit();
	}
    

    
}
