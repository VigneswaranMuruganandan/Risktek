import { Component, OnInit, Input} from '@angular/core';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    TranslateService,
    ServerError,
    Product,
    GlobalVariable,
    UserContext
} from '../../shared';
import {CreateBeneficiaryRequest} from '../model/createBeneficiaryRequest';
import {CreateBeneficiaryResponse} from '../model/createBeneficiaryResponse';
import { BeneficiariesService} from '../services/beneficiaries.service';

@Component({
  selector: 'withinUAEAddBeneStep4-component',
  templateUrl: './../templates/withinUAEAddBeneStep4.html'
})
export class WithinUAEAddBeneStep4Component implements OnInit{ 	
 	@Input() createBeneficiaryRequest:CreateBeneficiaryRequest;
	@Input() createBeneficiaryResponse:CreateBeneficiaryResponse;
    public serverError :ServerError;

    ngOnInit() {
    	this.generateError();
    }

    constructor( private beneficiariesService:BeneficiariesService,
    			 public translate: TranslateService,
	             private sharedService: SharedService,
	             private errorService: ErrorService,
	             private spinnerService: SpinnerService,
	             private router: Router){}

    transferBeneficiary(){
    	this.spinnerService.startSpinner('loader');
    	this.beneficiariesService.fetchBeneTransferList()
	     .subscribe(
	         resp => {
         	this.spinnerService.stopSpinner('loader');
	         	if (resp.result.status == "success") {
			        let data = resp.beneficiaryList;
			        data.filter(beneItem => beneItem.nickName == this.createBeneficiaryRequest.nickName );
			        UserContext.getInstance().transferData = data[0];
					this.router.navigate([GlobalVariable.ROUTE_MAPPING.TRANSFER_WITHINUAE]);
			    }else if (resp.result.status == 'error') {
			        this.errorService.setErrorResp(resp.result);
			    }
	         },
	         error => this.sharedService.handleError(error)
	     );
	}

    generateError(){
      this.serverError = new ServerError();
      this.serverError.backButton = {"text":"Back to Add Beneficiary","router":GlobalVariable.ROUTE_MAPPING.TRANSFER_MONEY};
      this.translate.get('SERVERERROR.ADDBENEFICIARYTRANSFERWITHINUAE',{param1: this.createBeneficiaryRequest.receiverName})
      .subscribe((value: string) => {
          this.serverError.errorDescription = value;
      });
    }
}
