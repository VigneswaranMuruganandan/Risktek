import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService} from '@ngx-translate/core';
import { CreateBillerBeneRequest} from '../model/createBillerBeneRequest';
import { CreateBillerBeneResponse} from '../model/createBillerBeneResponse';
import { GlobalVariable} from '../../shared/services/global';
import { BeneficiariesService} from '../services/beneficiaries.service';

@Component({
  selector: 'addBillerStep4-component',
  templateUrl: './../templates/addBillerStep4.html'
})
export class AddBillerStep4Component implements OnInit {
 	
 	public imageUrl:any;
 	@Input() salikAutoBy:string;
 	@Input() createBillerBeneRequest:CreateBillerBeneRequest;
 	@Input() createBillerBeneResponse:CreateBillerBeneResponse;
 	@Output() backToAddPaymentEvent = new EventEmitter();

 	constructor( private router: Router,
 				 private beneficiariesService:BeneficiariesService) {}

 	ngOnInit() { 
	  this.imageUrl = GlobalVariable.IMAGE_URL;
	}

	backToAddPayment(addPaymentType:string){
		this.backToAddPaymentEvent.emit(addPaymentType);
	}
}
