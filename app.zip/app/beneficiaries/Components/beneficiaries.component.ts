import { Component, OnInit, Input} from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService} from '@ngx-translate/core';

@Component({
  templateUrl: './../templates/beneficiaries.html'
})
export class BeneficiariesComponent implements OnInit{

    constructor(private router: Router) {}

	ngOnInit() { 
       
    }

}
