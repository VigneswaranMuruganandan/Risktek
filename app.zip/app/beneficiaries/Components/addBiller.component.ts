import { Component, OnInit, Input} from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService} from '@ngx-translate/core';
import { AppSession} from '../../shared/model/appSession';
import { CreateBillerBeneRequest} from '../model/createBillerBeneRequest';
import { SetupForPaymentResponse} from '../model/setupForPaymentResponse';
import { SetupForPaymentRequest} from '../model/setupForPaymentRequest';
import { BeneficiariesService} from '../services/beneficiaries.service';
import { SharedService} from '../../shared/services/shared.service';
import { ErrorService } from '../../shared/services/error.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { SendOtpRequest} from '../../shared/model/sendOtpRequest';
import { SendOtpResponse} from '../../shared/model/sendOtpResponse';
import { GlobalVariable} from '../../shared/services/global';
import { CreateBillerBeneResponse} from '../model/createBillerBeneResponse';
import { FetchBalanceForPaymentRequest } from '../model/fetchBalanceForPaymentRequest';
import { FetchBalanceForPaymentResponse } from '../model/fetchBalanceForPaymentResponse';
import { Autopay } from '../../transfers/model/autopay';
import { ValidateBeneficiaryRequest} from '../model/validateBeneficiaryRequest';
import { APIResponse } from '../../shared/model/apiResponse';
import { UserContext} from '../../shared/model/userContext';

@Component({
  templateUrl: './../templates/addBiller.html'
})
export class AddBillerComponent implements OnInit{

	  public stepValue: number;
    public appSession: AppSession;
    public billerTypes:any=[];
    public createBillerBeneRequest:CreateBillerBeneRequest;
    public createBillerBeneResponse:CreateBillerBeneResponse
    public setupForPaymentResponse:SetupForPaymentResponse;
    public setupForPaymentRequest:SetupForPaymentRequest;
    public fetchBalanceForPaymentRequest:FetchBalanceForPaymentRequest;
    public fetchBalanceForPaymentResponse:FetchBalanceForPaymentResponse;
    public addBillerType:string;
    public sendOtpRequest:SendOtpRequest;
    public sendOtpResponse:SendOtpResponse;
    public salikAutoBy:string;
    public validatebillerBeneReq:ValidateBeneficiaryRequest;

    constructor(  private beneficiariesService:BeneficiariesService,
                  private sharedService: SharedService,
                  private errorService: ErrorService,
                  private spinnerService: SpinnerService) {}

  	ngOnInit() { 
        this.initAddBiller();
    }

    initAddBiller(){
      this.stepValue = 1;
      this.appSession = AppSession.getInstance();
      this.billerTypes=this.appSession.paymentTypes.filter(biller => GlobalVariable.BILLER_DESCRIPTION[biller.paymentTransferName]!=undefined);
      this.createBillerBeneRequest = new CreateBillerBeneRequest();
      this.createBillerBeneRequest.autopay = new Autopay();
      //this.addBillerType=this.beneficiariesService.getAddBillerType();
      if(UserContext.getInstance().addPaymentType=="ADD_SI_P"){
          this.createBillerBeneRequest.autopayEnabled=true;
      }else{
          this.createBillerBeneRequest.autopayEnabled=false;
      }
      this.fetchPaymentSetup();
      this.errorService.resetErrorResp();
    }

    fetchPaymentSetup(){
        this.spinnerService.startSpinner('loader');
        this.setupForPaymentRequest = new SetupForPaymentRequest();
        this.setupForPaymentRequest.paymentType = "ETISALAT";
        this.beneficiariesService.paymentSetup(this.setupForPaymentRequest)
            .subscribe(
                resp => this.handlePaymentSetupResp(resp),
                error => this.sharedService.handleError(error)
            );
    }

    handlePaymentSetupResp(resp:any){
        this.spinnerService.stopSpinner('loader');
        if (resp.result.status == "success") {
            this.setupForPaymentResponse = new SetupForPaymentResponse();
            this.setupForPaymentResponse = resp;
            this.createBillerBeneRequest.accountOrCardNo= this.setupForPaymentResponse.fundingSources[0].prodRef;
        }else if (resp.result.status == 'error') {
            this.errorService.setErrorResp(resp.result);
        }
    }

    validateAddBillerForm(salikAutoBy:string){
      this.salikAutoBy = salikAutoBy;
      this.verifyConsumerNumber(); 
    }

    
    verifyConsumerNumber(){
      this.spinnerService.startSpinner('loader');
      this.errorService.resetErrorResp();
      this.fetchBalanceForPaymentRequest = new FetchBalanceForPaymentRequest();
      this.fetchBalanceForPaymentRequest.agency = this.createBillerBeneRequest.agency;
      this.fetchBalanceForPaymentRequest.consumerNo = this.createBillerBeneRequest.consumerNo;
      this.fetchBalanceForPaymentRequest.telephoneNo = this.createBillerBeneRequest.consumerNo;
      if(this.createBillerBeneRequest.agency=='SALIK'){
          this.fetchBalanceForPaymentRequest.salikPinNo = this.createBillerBeneRequest.salikPinNo;
      }
      this.beneficiariesService.balanceEnquiryForPayment(this.fetchBalanceForPaymentRequest)
                .subscribe(
                    resp => this.handleBalanceEnqResp(resp),
                    error => this.sharedService.handleError(error)
            );
    }

    handleBalanceEnqResp(resp:FetchBalanceForPaymentResponse){
      this.spinnerService.stopSpinner('loader');
        if (resp.result.status == "success") {
            this.fetchBalanceForPaymentResponse = new FetchBalanceForPaymentResponse();
            this.fetchBalanceForPaymentResponse = resp;
            //this.stepValue = 2;
            this.verifyBillerBeneficiary();
        }else if (resp.result.status == 'error') {
            this.errorService.setErrorResp(resp.result);
        }
    }

    verifyBillerBeneficiary(){
      this.errorService.resetErrorResp();
      this.spinnerService.startSpinner('loader');
      this.validatebillerBeneReq  =  new ValidateBeneficiaryRequest();
      this.validatebillerBeneReq.paymentTypes = this.createBillerBeneRequest.agency;
      this.validatebillerBeneReq.consumerNo = this.createBillerBeneRequest.consumerNo;
      this.validatebillerBeneReq.operation  = GlobalVariable.OPERATION_TYPE.ADD;
      this.validatebillerBeneReq.nickName = this.createBillerBeneRequest.nickName;
      if(this.createBillerBeneRequest.autopayEnabled){
        this.validatebillerBeneReq.accountOrCardNo  = this.createBillerBeneRequest.accountOrCardNo;
      }
      this.beneficiariesService.validateBeneficary(this.validatebillerBeneReq)
            .subscribe(
                resp => this.handleValidateBeneResp(resp),
                error => this.sharedService.handleError(error)
            );
    }

    handleValidateBeneResp(resp:APIResponse){
      this.spinnerService.stopSpinner('loader');
      if (resp.result.status == "success") {
          this.stepValue = 2;
      }else if (resp.result.status == 'error') {
          this.errorService.setErrorResp(resp.result);
      }
    }

    confirmBillerReviewButton(){
      this.errorService.resetErrorResp();
      this.spinnerService.startSpinner('loader');
      this.triggerOTP();
    }

    triggerOTP(){
       this.sendOtpRequest = new SendOtpRequest();
        this.sendOtpRequest.txnRef = this.setupForPaymentResponse.txnRef;
        this.sendOtpRequest.txnCode = GlobalVariable.TRANSACTION_CODES['BENEF_ADD_'+this.createBillerBeneRequest.agency+'_BILLPAYMENT'];
        this.sharedService.sendOTP(this.sendOtpRequest)
          .subscribe(
              resp => this.handleSendOTPResp(resp),
              error => this.sharedService.handleError(error)
          );
    }

    handleSendOTPResp(resp:SendOtpResponse){
      this.spinnerService.stopSpinner('loader');
      if (resp.result.status == "success") {
          this.sendOtpResponse = new SendOtpResponse();
          this.sendOtpResponse = resp;
          this.stepValue = 3;
      }else if (resp.result.status == 'error') {
          this.errorService.setErrorResp(resp.result);
      }
    }

    backBillerReviewButton(){
        this.stepValue = 1;
    }

    validateOTP(otp: string){
        if(otp){
            this.createBillerBeneRequest.authKey = otp;
            this.errorService.resetErrorResp();
            this.spinnerService.startSpinner('loader');
            if(this.salikAutoBy =="date" && this.createBillerBeneRequest.agency=="SALIK"
                     && this.createBillerBeneRequest.minAmount){
              delete this.createBillerBeneRequest.minAmount;
            }
            if(this.salikAutoBy =="amount" && this.createBillerBeneRequest.agency=="SALIK"
                     && this.createBillerBeneRequest.autopay.startDate){
              delete this.createBillerBeneRequest.autopay.startDate;
            }
            this.createBillerBeneRequest.txnRef = this.setupForPaymentResponse.txnRef;
            this.beneficiariesService.createBillPayBeneficiary(this.createBillerBeneRequest)
                .subscribe(
                    resp => this.handleAddBeneResp(resp),
                    error => this.sharedService.handleError(error)
            );
        }  
        
    }

    handleAddBeneResp(resp:CreateBillerBeneResponse){
      this.spinnerService.stopSpinner('loader');
      this.createBillerBeneResponse = new CreateBillerBeneResponse();
      this.createBillerBeneResponse = resp;
      if (resp.result.status == "success") {
          this.stepValue = 4;
      }else if (resp.result.status == 'error') {
         let nextStep = this.errorService.handleOTPError(resp.result);
            if(nextStep) {
                this.stepValue = 4;
            }
      }
    }

    backOTPButton(){
        this.stepValue = 2;
    }

    backToAddBillerBeneficicary(addPaymentType:string){
      this.beneficiariesService.setAddBillerType(addPaymentType);
      this.initAddBiller();
    }
}
