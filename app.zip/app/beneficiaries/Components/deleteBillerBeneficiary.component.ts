import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    TranslateService,
    ServerError,
    Product, 
    APIResponse
} from '../../shared';
import { BeneficiariesService} from '../services/beneficiaries.service';
import { Biller} from '../model/biller';
import { DeleteBillerBeneRequest} from '../model/deleteBillerBeneRequest';

@Component({
	selector: 'deleteBillerBeneficiary-modal',
  	templateUrl: './../templates/deleteBillerBeneficiary.html'
})
export class DeleteBillerBeneficiaryComponent implements OnInit  {
    public stepValue: number;
    public recurringPayments :boolean;
    @Input() biller:Biller;
    @Output() reloadPaymentBeneficiaries = new EventEmitter();
    deleteBillerBeneRequest :DeleteBillerBeneRequest;

    constructor( private templateService: TemplateService,
                 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService,
                 public beneficiariesService: BeneficiariesService,
                 private router: Router) {}

    ngOnInit() {
        this.initDeleteBeneficiary();
    }

    initDeleteBeneficiary(){
      this.errorService.resetErrorResp();
      this.stepValue = 1;
      this.recurringPayments = false;
      this.deleteBillerBeneRequest = new DeleteBillerBeneRequest();
     
    }

    deleteBeneficiaryConfirm(){
      this.errorService.resetErrorResp();
      this.spinnerService.startSpinner('deleteBillerBeneficiary'); 
      this.deleteBillerBeneRequest.agency = this.biller.billerName;
      this.deleteBillerBeneRequest.consumerNo = this.biller.consumerNo;    
      this.deleteBillerBeneRequest.nickName = this.biller.nickName;  
      this.deleteBillerBeneRequest.templateId = this.biller.templateId; 
      this.deleteBillerBeneRequest.beneId = this.biller.beneId;
      if(this.biller.autoPayment){
        this.deleteBillerBeneRequest.siId = this.biller.siId;
        this.deleteBillerBeneRequest.autopayEnabled = this.biller.autoPayment;
      }
      this.beneficiariesService.deleteBillPayBeneficiary(this.deleteBillerBeneRequest)
        .subscribe(
          resp => this.handleDeleteBeneficiary(resp),
          error => this.sharedService.handleError(error)
        );
    }

    handleDeleteBeneficiary(resp :APIResponse){
      this.spinnerService.stopSpinner('deleteBillerBeneficiary');
      if(resp.result.status == 'success'){
          this.stepValue = 2;
          this.reloadPaymentBeneficiaries.emit();
      }else if(resp.result.status == 'error'){
          this.errorService.setErrorResp(resp.result);

      }
    }

    closeModal(){
      this.errorService.resetErrorResp();
      (<any>$('#delete-payment')).modal('hide');
    }
}
