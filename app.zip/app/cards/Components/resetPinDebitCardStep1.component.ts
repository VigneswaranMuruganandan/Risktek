import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {TemplateService} from '../../shared/services/template.service';

@Component({
  selector: 'resetPinDebitCardStep1-component',
  templateUrl: './../templates/resetPinDebitCardStep1.html'
})
export class ResetPinDebitCardStep1Component{
	
	@Output() validateDebitCardResetPinEvent = new EventEmitter();
	
	beginDebitCardResetPin(event:any){
		this.validateDebitCardResetPinEvent.emit();
	}
}