import { Component, OnInit, Input} from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { ErrorService } from '../../shared/services/error.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { CardsService} from '../services/cards.service';
import { SharedService} from '../../shared/services/shared.service';
import { DebitCardDetail} from '../model/debitCardDetail';
import { SendOtpRequest} from '../../shared/model/sendOtpRequest';
import { SendOtpResponse} from '../../shared/model/sendOtpResponse';
import { AppSession} from '../../shared/model/appSession';
import { APIResponse } from '../../shared/model/apiResponse';
import { GlobalVariable} from '../../shared/services/global';
import { ActivatePinResetCardRequest} from '../model/activatePinResetCardRequest';
import { SessionContext} from '../../shared/model/sessionContext';
import { AuthRequest} from '../../register/model/authRequest';
import { AuthData} from '../../shared/model/authData';
import { Router } from '@angular/router';

@Component({
  templateUrl:'./../templates/resetPinDebitCard.html'
})
export class ResetPinDebitCardComponent implements OnInit{

    public stepValue: number;
    public debitCard:DebitCardDetail;
    public sendOtpRequest:SendOtpRequest;
    public sendOtpResponse:SendOtpResponse;
    public resetPinDebitCardRequest:ActivatePinResetCardRequest;
    public resetPinDebitCardResponse:APIResponse;
    public pin:string;
    public confirmPin:string;
    
    constructor( private cardsService: CardsService,
                 private sharedService: SharedService,
                 private errorService: ErrorService,
                 private spinnerService: SpinnerService,
                 private router: Router) {}
    
    ngOnInit() { 
        this.initResetPinDebitCard();
    }

    initResetPinDebitCard(){
        this.debitCard = this.cardsService.getDebitCard();
        this.resetPinDebitCardRequest = new ActivatePinResetCardRequest();
        this.resetPinDebitCardRequest.cardNumber = this.debitCard.cardNumber;
        this.resetPinDebitCardRequest.cardType = "DEBIT";
        this.stepValue = 1;
    }

    validateDebitCardResetPin(){
        this.stepValue = 2;
    }

    validatePinDebitCard(pin:string){
        console.log("pin:"+ pin);
        this.pin = pin;
        this.stepValue = 3;
    }

    backToDebitCardStepOne(){
        this.stepValue = 1;
    }

    validateConfirmPinDebitCard(confirmPin:string){
        this.confirmPin = confirmPin;
        if(this.pin==this.confirmPin){
            this.errorService.resetErrorResp();
            this.spinnerService.startSpinner('loader');
            this.sendOtpRequest = new SendOtpRequest();
            this.sendOtpRequest.txnCode = GlobalVariable.TRANSACTION_CODES.DEBIT_CARD_ACTIVATE;
            this.sharedService.sendOTP(this.sendOtpRequest)
                .subscribe(
                    resp => this.handleSendOTPResp(resp),
                    error => this.sharedService.handleError(error)
                );   
        }else{
            let data ={"status":"error","errorInfo":{"code":"PIN_INVALID","desc":"Comfirm Pin doesn't match"},"msgArgs":[]};
            this.errorService.setErrorResp(data);
            $('#pinFormReset').click();
        }
    }

    handleSendOTPResp(resp:SendOtpResponse){
        this.spinnerService.stopSpinner('loader');
        if (resp.result.status == "success") {
            this.sendOtpResponse = new SendOtpResponse();
            this.sendOtpResponse = resp;
            this.stepValue = 4;
        }else if (resp.result.status == 'error') {
            this.errorService.setErrorResp(resp.result);
        }
    }

    backToDebitCardStepTwo(){
        this.errorService.resetErrorResp();
        this.stepValue = 2;
        $('#pinFormReset').click();
    }

    validateOTPDebitCardResetPin(otp: string){
        if(otp){
            this.resetPinDebitCardRequest.authKey = otp;
            this.errorService.resetErrorResp();
            this.spinnerService.startSpinner('loader');
            this.cardsService.cardPinReset(this.resetPinDebitCardRequest)
                .subscribe(
                    resp => this.handleActivateDebitResp(resp),
                    error => this.sharedService.handleError(error)
            );
        }  
    }

    handleActivateDebitResp(resp:APIResponse){
      this.spinnerService.stopSpinner('loader');
      this.resetPinDebitCardResponse = new APIResponse();
      this.resetPinDebitCardResponse = resp;
      if (resp.result.status == "success") {
          this.stepValue = 5;
          (<any>$('#logoutPinResetModal')).modal('show');
          setTimeout(()=> {
                   this.logoutAfterSuccess();
              }, 5000);
      }else if (resp.result.status == 'error') {
          let nextStep = this.errorService.handleOTPError(resp.result);
            if(nextStep) {
                this.stepValue = 4;
            }
      }
    }

    backOTPButton(){
       this.stepValue = 3;
    }

    logoutAfterSuccess(){
        let data = new AuthRequest();
        data.deviceID = SessionContext.getInstance().deviceID
        this.sharedService.logout(data)
          .subscribe(
              resp => this.handleLogout(resp),
              error => this.sharedService.handleError(error)
          );
    }

    handleLogout(resp : AuthData){
        this.errorService.resetErrorResp();
        if(resp && resp.result.status == 'success'){
            SessionContext.destroyInstance(resp);
            this.router.navigate(['/login']);
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
    }
}