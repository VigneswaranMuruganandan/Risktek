import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'resetPinDebitCardStep2-component',
  templateUrl: './../templates/resetPinDebitCardStep2.html'
})
export class ResetPinDebitCardStep2Component {

	@Output() validatePinDebitCardEvent = new EventEmitter();
	@Output() backToStepOneEvent = new EventEmitter();

	validatePin(pin:string){
		this.validatePinDebitCardEvent.emit(pin);
	}

	backToStepOne(){
		this.backToStepOneEvent.emit();
	}
	
}