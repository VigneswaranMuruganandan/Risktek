import { Component, OnInit, Input, ViewChild, AfterViewInit} from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { CreditCardDetail} from '../model/creditCardDetail';
import { BlockDebitCardComponent} from './blockDebitCard.component';
import { GlobalVariable} from '../../shared/services/global';
import { Router } from '@angular/router';
import { CardsService} from '../services/cards.service';


@Component({
  selector: '[creditcarddetails-component]',
  templateUrl: './../templates/creditCardsDetails.html'
})
export class CreditCardsDetailsComponent implements AfterViewInit{
	
	@ViewChild(BlockDebitCardComponent) blockDebitCardComponent: BlockDebitCardComponent;
	@Input() creditCard:CreditCardDetail;
	
    constructor( private router: Router,
    			 private cardsService: CardsService) {}

	ngAfterViewInit() {
    	this.enableOrDisableButton();
  	}

  	enableOrDisableButton(){

	    $('ul.creditCardOptions li a').removeClass('disabled');
	    if(this.creditCard.status=="INACTIVE"){
	      $("#resetPinButton").addClass('disabled');
	      $("#blockButton").addClass('disabled');
	    }else{
	      $("#activeButton").addClass('disabled');
	    }
 	}
	blockCardPopup(){
		(<any>$('#block-card-modal')).modal('show');
		this.blockDebitCardComponent.initBlockCode();
	}

	activateCreditcard(){
		this.cardsService.setCreditCard(this.creditCard);
		this.router.navigate([GlobalVariable.ROUTE_MAPPING.CREDITCARDS_ACTIVATE]);
	}

	resetPinCreditcard(){
		this.cardsService.setCreditCard(this.creditCard);
		this.router.navigate([GlobalVariable.ROUTE_MAPPING.CREDITCARDS_RESETPIN]);
	}
}