import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'activateDebitCardStep2-component',
  templateUrl: './../templates/activateDebitCardStep2.html'
})
export class ActivateDebitCardStep2Component {

	@Output() validatePinDebitCardEvent = new EventEmitter();
	@Output() backToStepOneEvent = new EventEmitter();

	validatePin(pin:string){
		this.validatePinDebitCardEvent.emit(pin);
	}

	backToStepOne(){
		this.backToStepOneEvent.emit();
	}
	
}