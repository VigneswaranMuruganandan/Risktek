import { Component, OnInit, Input, ViewChild, AfterViewInit} from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { DebitCardDetail} from '../model/debitCardDetail';
import { BlockDebitCardComponent} from './blockDebitCard.component';
import { GlobalVariable} from '../../shared/services/global';
import { Router } from '@angular/router';
import { CardsService} from '../services/cards.service';


@Component({
  selector: '[debitcarddetails-component]',
  templateUrl: './../templates/debitCardsDetails.html'
})
export class DebitCardsDetailsComponent implements AfterViewInit{
	
	@ViewChild(BlockDebitCardComponent) blockDebitCardComponent: BlockDebitCardComponent;
	@Input() debitCard:DebitCardDetail;
	
    constructor( private router: Router,
    			 private cardsService: CardsService) {}

	ngAfterViewInit() {
    	this.enableOrDisableButton();
  	}

  	enableOrDisableButton(){

	    $('ul.debitCardOptions li a').removeClass('disabled');
	    if(this.debitCard.status=="NEW"){
	      $("#resetPinButton").addClass('disabled');
	      //$("#blockButton").addClass('disabled');
	    }else{
	      $("#activeButton").addClass('disabled');
	    }
 	}
	blockCardPopup(){
		(<any>$('#block-card-modal')).modal('show');
		this.blockDebitCardComponent.initBlockCode();
	}

	activateDebitcard(){
		this.cardsService.setDebitCard(this.debitCard);
		this.router.navigate([GlobalVariable.ROUTE_MAPPING.DEBITCARDS_ACTIVATE]);
	}

	resetPinDebitcard(){
		this.cardsService.setDebitCard(this.debitCard);
		this.router.navigate([GlobalVariable.ROUTE_MAPPING.DEBITCARDS_RESETPIN]);
	}
}