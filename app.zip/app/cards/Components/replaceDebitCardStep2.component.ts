import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { SharedService} from '../../shared/services/shared.service';
import { ErrorService } from '../../shared/services/error.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { CardsService } from '../services/cards.service';
import { SendOtpRequest} from '../../shared/model/sendOtpRequest';
import { SendOtpResponse} from '../../shared/model/sendOtpResponse';

@Component({
  templateUrl: './../templates/replaceDebitCardStep2.html',
  selector:'replaceDebitCardStep2-component'
})
export class ReplaceDebitCardStep2Component {

	@Output() validateOTPReplaceCardEvent = new EventEmitter();
	@Input() sendOtpRequest:SendOtpRequest;
	@Input() sendOtpResponse:SendOtpResponse;

	constructor( private errorService: ErrorService){}

	validateOTP(otp : string){
		this.errorService.resetErrorResp();
		this.validateOTPReplaceCardEvent.emit(otp);
	}

    	
    
}