import {APIResponse} from '../../shared/model/apiResponse';
import { CreditCardDetail } from './creditCardDetail';

export class FetchCardDetailsResponse  extends APIResponse{

  	cardDetails:CreditCardDetail[];
}

