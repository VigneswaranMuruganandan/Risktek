import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ActivateDebitCardComponent }   from './Components/activateDebitCard.component';
import { DebitCardsMainComponent }   from './Components/debitCardsMain.component';
import { ResetPinDebitCardComponent }   from './Components/resetPinDebitCard.component';
import { CreditCardsMainComponent }   from './Components/creditCardsMain.component';



const routes: Routes = [
    {
        path: 'debit',
        component: DebitCardsMainComponent
    },
    {
        path: 'credit',
        component: CreditCardsMainComponent
    },
    {
        path: 'resetPinDebitCard',
        component: ResetPinDebitCardComponent
    },
    {
        path: 'activateDebitCard',
        component: ActivateDebitCardComponent
    },
    {
        path: '',
        redirectTo: '',
        pathMatch: 'full'
    }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
