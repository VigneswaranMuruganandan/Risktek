import { APIResponse } from '../../shared/model/apiResponse';
import { ISave } from './isave';

export class ISaveResponse  extends APIResponse {
    isaveList: ISave[];
}