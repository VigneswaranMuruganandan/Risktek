import { APIResponse } from '../../shared/model/apiResponse';
import { RegularSaving } from './regularSaving';

export class RegularSavingResponse  extends APIResponse {
    iSaveSIList: RegularSaving[];
}