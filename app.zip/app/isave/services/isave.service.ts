import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';
import {AppSession} from '../../shared/model/appSession';
import {ServiceInvoker} from '../../shared/connector/serviceInvoker.service';
import { SharedService } from '../../shared/services/shared.service';
import {ErrorService} from '../../shared/services/error.service';
import {SessionContext} from '../../shared/model/sessionContext';
import {GlobalURL} from '../../shared/services/globalURL';
import { ISaveResponse } from '../model/isaveResponse';
import { ISave } from '../model/isave';
import { CreateIsaveRequest } from '../model/createIsaveRequest';
import { CreateIsaveResponse } from '../model/createIsaveResponse';
import { CloseIsaveRequest } from '../model/closeIsaveRequest';
import { SetupIsaveResponse } from '../model/setupIsaveResponse';
import { RegularSavingResponse } from '../model/regularSavingResponse';
import { CreateRegSavingRequest } from '../model/createRegSavingRequest';
import { CreateRegSavingResponse } from '../model/createRegSavingResponse';
import { RegularSaving } from '../model/regularSaving';
import { ModifyRegularSaving } from '../model/modifyRegularSaving';

@Injectable()
export class IsaveService {
  public isave :ISave;
  public regularSaving :RegularSaving;

  constructor( private serviceInvoker: ServiceInvoker, 
               private errorService: ErrorService,
               private sharedService: SharedService) {}

  setupIsave(): Observable < SetupIsaveResponse > {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ISAVE.SETUP_ISAVE, null)
                                .map(resp => JSON.parse(resp));
  }

  setupRegularSaving(): Observable < SetupIsaveResponse > {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ISAVE.SETUP_REGULAR_SAVINGS, null)
                                .map(resp => JSON.parse(resp));
  }

  fetchIsaveList(): Observable < ISaveResponse > {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ISAVE.ISAVE_LIST, null)
                                .map(resp => JSON.parse(resp));
  }

  createIsave(createIsaveRequest :CreateIsaveRequest): Observable < CreateIsaveResponse > {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ISAVE.ISAVE_CREATE, createIsaveRequest)
                                .map(resp => JSON.parse(resp));
  }

  createRegularSaving(createRegSavingRequest :CreateRegSavingRequest): Observable < CreateRegSavingResponse > {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ISAVE.REGULAR_SAVINGS_CREATE, createRegSavingRequest)
                                .map(resp => JSON.parse(resp));
  }

  updateIsave(isave :ISave): Observable < CreateIsaveResponse > {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ISAVE.ISAVE_UPDATE, isave)
                                .map(resp => JSON.parse(resp));
  }

  updateRegularSaving(modifyRegularSaving :ModifyRegularSaving): Observable < CreateIsaveResponse > {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ISAVE.REGULAR_SAVINGS_UPDATE, modifyRegularSaving)
                                .map(resp => JSON.parse(resp));
  }

  deleteIsave(closeIsaveRequest: CloseIsaveRequest): Observable < any > {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ISAVE.ISAVE_CLOSE, closeIsaveRequest)
                                .map(resp => JSON.parse(resp));
  }

  fetchRegularSavingList(): Observable < RegularSavingResponse > {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ISAVE.REGULAR_SAVINGS_LIST, null)
                                .map(resp => JSON.parse(resp));
  }

  setISaveData(data: any){
	    this.isave = data;
	}
	
	getISaveData(){
	  return this.isave;
	}
	resetISaveData(){
	  this.isave = new ISave();
	}

  setRegSavData(data: any){
      this.regularSaving = data;
  }
  
  getRegSavData(){
    return this.regularSaving;
  }
  resetRegSavData(){
    this.regularSaving = new RegularSaving();
  }
}