import { Component, ElementRef, Directive, HostListener, NgZone, Input, Output, EventEmitter } from '@angular/core';
import * as $ from 'jquery';
import {TemplateService} from '../../shared/services/template.service';
import 'app/assets/js/jquery.validate.js';
import { CreateRegSavingRequest } from '../model/createRegSavingRequest';


@Directive({
    selector: '[validateCreateIsaveDirective]',
})
export class ValidateCreateIsave {
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let validateCreateIsaveValidationSubmit;
        this.zone.runOutsideAngular(() => {
            var validateCreateIsaveValidation = (<any>$("#validateCreateIsaveForm")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input,select")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    accountNumber: {
                        required: true
                    },
                    accountPurpose: {
                        required: true
                    },
                    ifOthers: {
                        required: true
                    },
                    nickName: {
                        required: true
                    },
                    openingAmount: {
                        required: true
                    },
                    termsAndCond: {
                        required: true
                    }

                },
                messages: {
                    customerIdentificationNo: {
                        required: "Please enter Customer Identification Number"
                    },
                    accountNumber: {
                        required: "Please make a selection"
                    },
                    accountPurpose: {
                        required: "Please make a selection"
                    },
                    ifOthers: {
                        required: "Please fill"
                    },
                    nickName: {
                        required: "Please fill"
                    },
                    openingAmount: {
                        required: "Please fill"
                    },
                    termsAndCond: {
                        required: "Please accept the terms and conditions"
                    }
                }
            });
            validateCreateIsaveValidationSubmit = validateCreateIsaveValidation.form();
            this.templateService.setFormValidatorFlag(validateCreateIsaveValidationSubmit);
        });
    }
}

@Directive({
    selector: '[validateEditIsaveDirective]',
})
export class ValidateEditIsave {
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let validateEditIsaveValidationSubmit;
        this.zone.runOutsideAngular(() => {
            var validateEditIsaveValidation = (<any>$("#validateEditIsaveForm")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input,select")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    accountDescription: {
                        required: true
                    },
                    accountPurpose: {
                        required: true
                    },
                    ifOthers: {
                        required: true
                    }
                },
                messages: {
                    accountDescription: {
                        required: "Please fill in"
                    },
                    accountPurpose: {
                        required: "Please fill in"
                    },
                    ifOthers: {
                        required: "Please fill in"
                    }
                }
            });
            validateEditIsaveValidationSubmit = validateEditIsaveValidation.form();
            this.templateService.setFormValidatorFlag(validateEditIsaveValidationSubmit);
        });
    }
}


@Directive({
    selector: '[validateCreateRegularSavingsDirective]',
})
export class ValidateCreateRegularSavings {
    @Input() createRegSavingRequest: CreateRegSavingRequest;

    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let validateCreateRegularSavingsValidationSubmit;
        this.zone.runOutsideAngular(() => {
            (<any>$).validator.addMethod("notEqual", 
            function (value :any, element :any, param :any) {
                var flag = false;
                if(value != null){
                    flag = (value != param) ? true : false;
                }
                return flag;
            });

            (<any>$).validator.addMethod("validateFrequency", 
            (value :any, element :any, param :any) => {
                let flag = false;
                if(this.createRegSavingRequest){
                    if(this.createRegSavingRequest.frequency && this.createRegSavingRequest.startDate && this.createRegSavingRequest.endDate){
                        let days = 0;
                        let frequency = this.createRegSavingRequest.frequency.toLowerCase();
                        if(frequency == 'daily') days = 1;
                        if(frequency == 'half yearly') days = 183;
                        if(frequency == 'weekly') days = 7;
                        if(frequency == 'quarterly') days = 92;
                        if(frequency == 'monthly') days = 30;
                        let startDate :any = this.createRegSavingRequest.startDate.split('/');
                        startDate = new Date(startDate[2],parseInt(startDate[1])-1,startDate[0]);
                        let endDate :any = this.createRegSavingRequest.endDate.split('/');
                        endDate = new Date(endDate[2],parseInt(endDate[1])-1,endDate[0]);
                        let timeDiff :any = Math.abs(endDate.getTime() - startDate.getTime());
                        let diffDays :any = Math.ceil(timeDiff / (1000 * 3600 * 24));
                        if(diffDays == days){
                            flag = true;
                        }else {
                            flag = false;
                        }
                    }
                }else {
                    flag = true;
                }
                return flag;
            });            

            var validateCreateRegularSavingsValidation = (<any>$("#validateCreateRegularSavingsForm")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input,select")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    sourceAccount: {
                        required: true
                    },
                    destinationAccount: {
                        required: true,
                        notEqual: this.createRegSavingRequest.sourceAccount,
                    },
                    openingAmount: {
                        required: true,
                        min: 1
                    },
                    frequency: {
                        required: true
                        //validateFrequency : true
                    },
                    startDate: {
                        required: true
                    },
                    endDate: {
                        required: true
                    },
                    termsAndCond: {
                        required: true
                    }
                },
                messages: {
                    sourceAccount: {
                        required: "Please make a selection"
                    },
                    destinationAccount: {
                        required: "Please make a selection",
                        notEqual: "Source Account and Destination Account cannot be same",

                    },
                    openingAmount: {
                        required: "Please fill in",
                        min : "Minimum amount should be greater than 0"
                    },
                    frequency: {
                        required: "Please make a selection"
                        //validateFrequency: "Freqency type is not should for dates selected"
                    },
                    startDate: {
                        required: "Please make a selection"
                    },
                    endDate: {
                        required: "Please make a selection"
                    },
                    termsAndCond: {
                        required: "Please accept the terms and conditions"
                    }
                }
            });
            validateCreateRegularSavingsValidationSubmit = validateCreateRegularSavingsValidation.form();
            this.templateService.setFormValidatorFlag(validateCreateRegularSavingsValidationSubmit);
        });
    }
}

@Directive({
    selector: '[validateEditRegularSavingsDirective]',
})
export class ValidateEditRegularSavings {
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let validateEditRegularSavingsValidationSubmit;
        this.zone.runOutsideAngular(() => {
            var validateEditRegularSavingsValidation = (<any>$("#validateEditRegularSavingsForm")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input,select")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    customerIdentificationNo: {
                        required: true
                    }
                },
                messages: {
                    customerIdentificationNo: {
                        required: "Please enter Customer Identification Number"
                    }
                }
            });
            validateEditRegularSavingsValidationSubmit = validateEditRegularSavingsValidation.form();
            this.templateService.setFormValidatorFlag(validateEditRegularSavingsValidationSubmit);
        });
    }
}

@Directive({
    selector: '[validateCloseIsaveDirective]',
})
export class ValidateCloseIsave {
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let validateCloseIsaveValidationSubmit;
        this.zone.runOutsideAngular(() => {
            var validateCloseIsaveValidation = (<any>$("#closeIsaveForm")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input,select,textarea")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    endDate: {
                        required: true
                    },
                    transferTo: {
                        required: true
                    },
                    reasonOfClosure: {
                        required: true
                    }

                },
                messages: {
                    endDate: {
                        required: "Please select"
                    },
                    transferTo: {
                        required: "Please make a selection"
                    },
                    reasonOfClosure: {
                        required: "Please make a selection"
                    }
                }
            });
            validateCloseIsaveValidationSubmit = validateCloseIsaveValidation.form();
            this.templateService.setFormValidatorFlag(validateCloseIsaveValidationSubmit);
        });
    }
}