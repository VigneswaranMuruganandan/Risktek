import { Component, OnInit, Input, Output, EventEmitter, ViewChild, OnDestroy } from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { ErrorService} from '../../shared/services/error.service';
import { SharedService } from '../../shared/services/shared.service';
import { CloseIsaveRequest } from '../model/closeIsaveRequest';

@Component({
  selector: 'closeIsaveConfirmation-component',
  templateUrl: './../templates/closeIsaveConfirmation.html'
})
export class CloseIsaveConfirmationComponent{
	@Input() closeIsaveRequest :CloseIsaveRequest;

	constructor( private errorService: ErrorService,
				 private sharedService: SharedService){}

	
}