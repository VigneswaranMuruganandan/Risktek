import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { RegularSaving } from '../model/regularSaving';
import { CreateRegSavingRequest } from '../model/createRegSavingRequest';
import { CreateRegSavingResponse } from '../model/createRegSavingResponse';
import { SetupIsaveResponse } from '../model/setupIsaveResponse';
import { SharedService } from '../../shared/services/shared.service';
import { TemplateService } from '../../shared/services/template.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { ErrorService } from '../../shared/services/error.service';
import { IsaveService } from '../services/isave.service';
import { Router } from '@angular/router';
import { GlobalVariable} from '../../shared/services/global';
import { ModifyRegularSaving } from '../model/modifyRegularSaving';

@Component({
  selector: 'editSavingsPlan-component',
  templateUrl: './../templates/editSavingsPlan.html'
})
export class EditSavingsPlanComponent implements OnInit {
	regularSaving :RegularSaving;
	setupRegularSavingResponse: SetupIsaveResponse;
	public globalVariable :any;
	modifyRegularSaving :ModifyRegularSaving;

	constructor( private templateService: TemplateService,
             private errorService: ErrorService,
             public isaveService: IsaveService,
             private spinnerService: SpinnerService,
             private sharedService: SharedService,
             private router: Router) {}

	ngOnInit() { 
    	this.errorService.resetErrorResp();
        let data = JSON.stringify(this.isaveService.getRegSavData());
        this.regularSaving = JSON.parse(data);;
        this.globalVariable = GlobalVariable;
        this.modifyRegularSaving = new ModifyRegularSaving();
        this.initRegularSaving();
    }

    initRegularSaving(){
        this.errorService.resetErrorResp();
        this.spinnerService.startSpinner('editRegularSaving');
        this.isaveService.setupRegularSaving()
            .subscribe(
                resp => this.handleSetupRegularSaving(resp),
                error => this.sharedService.handleError(error)
            );
    }

    handleSetupRegularSaving(resp :SetupIsaveResponse){
        this.spinnerService.stopSpinner('editRegularSaving');
        if(resp.result.status == 'success'){
            this.setupRegularSavingResponse = resp;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
    }

    setModifyRegularSavingData(){
      let key = ["siRefNumber", "isaveAccountIdentifier", "frequency", "startDate","transactionAmount"];
      for(let k of key){
        this.modifyRegularSaving[k] = this.regularSaving[k];
      }
    }

    ConfirmEditSavingsPlan(){
    	this.setModifyRegularSavingData();
   		this.spinnerService.startSpinner('editRegularSaving');
        this.templateService.resetFormValidatorFlag();
        this.isaveService.updateRegularSaving(this.modifyRegularSaving)
            .subscribe(
                resp => this.handleUpdateRegularSaving(resp),
                error => this.sharedService.handleError(error)
            );
    }

    handleUpdateRegularSaving(resp :any){
    	this.spinnerService.stopSpinner('editRegularSaving');
        if(resp.result.status == 'success'){
        	this.isaveService.resetRegSavData();
            this.router.navigate(['/iSaveAccount']);
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
    }

    datePicker(date :string){
        this.modifyRegularSaving.endDate = date;
    }
   
}