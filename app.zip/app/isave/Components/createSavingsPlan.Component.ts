import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { SetupIsaveResponse } from '../model/setupIsaveResponse';
import { CreateRegSavingRequest } from '../model/createRegSavingRequest';
import { TemplateService } from '../../shared/services/template.service';
import { ErrorService } from '../../shared/services/error.service';
import { SharedService } from '../../shared/services/shared.service';
import { GlobalVariable} from '../../shared/services/global';

@Component({
  selector: 'createSavingsPlan-component',
  templateUrl: './../templates/createSavingsPlan.html'
})
export class CreateSavingsPlanComponent {
	@Output() createSavingsPlanAccountEvent = new EventEmitter();
	@Input() setupRegularSavingResponse :SetupIsaveResponse;
	@Input() createRegSavingRequest :CreateRegSavingRequest;
   	public temp :any;
   	public globalVariable :any;

   	constructor( private errorService: ErrorService,
				 public templateService: TemplateService,
				 private sharedService: SharedService){}

   	ngOnInit() {
		this.temp = { "termsAndCond": false };
		this.globalVariable = GlobalVariable;
	}

	datePickerGroup(data :any){
		if(data.type == 'startDate'){
			this.createRegSavingRequest.startDate = data.event;
		}
		if(data.type == 'endDate'){
			this.createRegSavingRequest.endDate = data.event;
		}
	}

    sourceAccountSelection(){
    	if(this.createRegSavingRequest.sourceAccount){
			this.createRegSavingRequest.sourceAccountNickName = this.setupRegularSavingResponse.fundingSources[this.templateService.getSelectIndex(this.setupRegularSavingResponse.fundingSources,'prodRef',this.createRegSavingRequest.sourceAccount)].nickName;
			this.temp.currency = this.setupRegularSavingResponse.fundingSources[this.templateService.getSelectIndex(this.setupRegularSavingResponse.fundingSources,'prodRef',this.createRegSavingRequest.sourceAccount)].balance.currency;;
		}
    }

    destAccountSelection(){
    	if(this.createRegSavingRequest.isaveAccountNo){
			this.createRegSavingRequest.iSaveAccountNickName = this.setupRegularSavingResponse.receivingPoints[this.templateService.getSelectIndex(this.setupRegularSavingResponse.receivingPoints,'prodRef',this.createRegSavingRequest.sourceAccount)].nickName;
		}
    }
    
    createSavingsPlan(valid: boolean){
   		if(valid){
			this.templateService.resetFormValidatorFlag();
			this.createSavingsPlanAccountEvent.emit();
		}
	}
}