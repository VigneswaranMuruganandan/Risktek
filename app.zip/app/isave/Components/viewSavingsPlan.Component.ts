import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { ErrorService } from '../../shared/services/error.service';
import { SharedService } from '../../shared/services/shared.service';
import { TemplateService } from '../../shared/services/template.service';
import { RegularSaving } from '../model/regularSaving';
import { SpinnerService } from '../../shared/services/spinner.service';
import { IsaveService } from '../services/isave.service';

@Component({
  templateUrl: './../templates/viewSavingsPlan.html'
})
export class ViewSavingsPlanComponent implements OnInit {
	regularSaving :RegularSaving;
	
	constructor( private templateService: TemplateService,
	             private errorService: ErrorService,
	             public isaveService: IsaveService,
	             private spinnerService: SpinnerService,
	             private sharedService: SharedService) {}

	ngOnInit() { 
    	this.errorService.resetErrorResp();
    	this.spinnerService.startSpinner('viewRegularSavings');
        this.regularSaving = this.isaveService.getRegSavData();
        setTimeout(()=> {
          this.spinnerService.stopSpinner('viewRegularSavings');
        }, 200);
    }
   
}