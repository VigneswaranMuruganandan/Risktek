import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { SetupIsaveResponse } from '../model/setupIsaveResponse';
import { IsaveService } from '../services/isave.service';
import { ErrorService} from '../../shared/services/error.service';
import { SharedService } from '../../shared/services/shared.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { CreateRegSavingRequest } from '../model/createRegSavingRequest';
import { CreateRegSavingResponse } from '../model/createRegSavingResponse';

@Component({
  templateUrl: './../templates/baseCreateSavingsPlan.html'
})
export class BaseCreateSavingsPlanComponent implements OnInit {
	public stepValue: number;
	setupRegularSavingResponse: SetupIsaveResponse;
    createRegSavingRequest :CreateRegSavingRequest;
    createRegSavingResponse :CreateRegSavingResponse;

    constructor( private errorService: ErrorService,
                 public isaveService: IsaveService,
                 private spinnerService: SpinnerService,
                 private sharedService: SharedService){}

	ngOnInit() {
        this.stepValue = 1;
        this.initRegularSaving();
        this.createRegSavingRequest = new CreateRegSavingRequest();
        this.createRegSavingResponse = new CreateRegSavingResponse();
    }

    initRegularSaving(){
        this.errorService.resetErrorResp();
        this.spinnerService.startSpinner('createRegularSaving');
        this.isaveService.setupRegularSaving()
            .subscribe(
                resp => this.handleSetupRegularSaving(resp),
                error => this.sharedService.handleError(error)
            );
    }

    handleSetupRegularSaving(resp :SetupIsaveResponse){
        this.spinnerService.stopSpinner('createRegularSaving');
        if(resp.result.status == 'success'){
            this.setupRegularSavingResponse = resp;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
    }

    createSavingsPlanAccount(){
    	this.stepValue = 2;
    }

    submitSavingsPlan(){
        this.spinnerService.startSpinner('createRegularSaving');
        this.isaveService.createRegularSaving(this.createRegSavingRequest)
            .subscribe(
                resp => this.handleCreateRegularSaving(resp),
                error => this.sharedService.handleError(error)
            );
    }

    handleCreateRegularSaving(resp :CreateRegSavingResponse){
        this.spinnerService.stopSpinner('createRegularSaving');
        if(resp.result.status == 'success'){
            this.createRegSavingResponse = resp;
            this.stepValue = 3;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
    }

    backSavingsPlan(value: number){
        this.stepValue = value;
    }
       
}