import { Component, OnInit, Input, Output, EventEmitter, ViewChild, OnDestroy } from '@angular/core';
import { IsaveService } from '../services/isave.service';
import { CloseIsaveRequest } from '../model/closeIsaveRequest';
import { SetupIsaveResponse } from '../model/setupIsaveResponse';
import { ISave } from '../model/isave';
import { Product } from '../../shared/model/product';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    TranslateService
} from '../../shared';


@Component({
  selector: 'closeIsave-component',
  templateUrl: './../templates/closeIsave.html'
})
export class CloseIsaveComponent implements OnInit{
	@Output() closeIsaveconfirmationEvent = new EventEmitter();
	@Input() setupIsaveResponse: SetupIsaveResponse;
	@Input() closeIsaveRequest :CloseIsaveRequest;
	public isave: ISave;
	public steps :any;
	public stepValue :number;
	fundingSources :Product[];

	constructor( private errorService: ErrorService,
				 private templateService: TemplateService,
				 public isaveService: IsaveService,
				 private spinnerService: SpinnerService,
				 private sharedService: SharedService){}

	ngOnInit() {
		this.init();
	}

	init(){
		this.errorService.resetErrorResp();
		this.stepValue = 1;
		this.steps = {'step1':true,'step2':false,'step3':false};
		this.isave = this.isaveService.getISaveData();
		this.spinnerService.startSpinner('closeIsave');
		setTimeout(()=> {
          this.spinnerService.stopSpinner('closeIsave');
        }, 200);       
	}

	filterTransferToAccount(){
		if(this.setupIsaveResponse){
			this.fundingSources = this.setupIsaveResponse.fundingSources.filter(obj => obj.prodRef !== this.closeIsaveRequest.iSaveAccountNumber);
		}
	}

	datePicker(date :string){
    	this.steps.step2 = true;
    	this.updateStep(2);
    	this.closeIsaveRequest.endDate = date;
    	this.filterTransferToAccount();
    }

    transferTo(){
    	this.steps.step3 = true;
    	this.updateStep(3);
    }

	cancelCloseIsave(){
		(<any>$('#close-isave')).modal('hide');
	}

	closeIsaveSubmit(valid :boolean){
		if(valid){
			this.isaveService.getISaveData();
			this.closeIsaveconfirmationEvent.emit();
		}
	}

	updateStep(step :number){
		this.stepValue = step;
	}
}