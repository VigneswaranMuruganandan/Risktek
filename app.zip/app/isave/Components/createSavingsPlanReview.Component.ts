import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { SetupIsaveResponse } from '../model/setupIsaveResponse';
import { CreateRegSavingRequest } from '../model/createRegSavingRequest';
import { TemplateService } from '../../shared/services/template.service';
import { ErrorService } from '../../shared/services/error.service';
import { SharedService } from '../../shared/services/shared.service';
import { Product } from '../../shared/model/product';
import { CreateRegSavingResponse } from '../model/createRegSavingResponse';

@Component({
  selector: 'createSavingsPlanReview-component',
  templateUrl: './../templates/createSavingsPlanReview.html'
})
export class CreateSavingsPlanReviewComponent {
	@Output() backSavingsPlanEvent = new EventEmitter();
	@Output() submitSavingsPlanEvent = new EventEmitter();
	@Input() setupRegularSavingResponse :SetupIsaveResponse;
	@Input() createRegSavingRequest :CreateRegSavingRequest;
	@Input() createRegSavingResponse :CreateRegSavingResponse;
	sourceProduct :Product;
	destinationProduct :Product;

	constructor( private errorService: ErrorService,
				 public templateService: TemplateService,
				 private sharedService: SharedService){}

	ngOnInit() {
		this.sourceProduct = this.setupRegularSavingResponse.fundingSources[this.templateService.getSelectIndex(this.setupRegularSavingResponse.fundingSources,'prodRef',this.createRegSavingRequest.sourceAccount)];
		this.destinationProduct = this.setupRegularSavingResponse.receivingPoints[this.templateService.getSelectIndex(this.setupRegularSavingResponse.receivingPoints,'prodRef',this.createRegSavingRequest.isaveAccountNo)];
	}

    confirmSavingsPlan() {
		this.submitSavingsPlanEvent.emit();
	}

	back(){
		this.backSavingsPlanEvent.emit(1);
	}
}