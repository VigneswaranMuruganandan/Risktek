import { Component, OnInit, Input, Output, EventEmitter, ViewChild, OnDestroy } from '@angular/core';
import { SetupIsaveResponse } from '../model/setupIsaveResponse';
import { CreateIsaveRequest } from '../model/createIsaveRequest';
import { CreateIsaveResponse } from '../model/createIsaveResponse';
import {
    SharedService,
    ErrorService,
    TemplateService,
    Router,
    TranslateService,
    Product,
	GlobalVariable
} from '../../shared';

@Component({
  selector: 'createIsaveSuccess-component',
  templateUrl: './../templates/createIsaveSuccess.html'
})
export class CreateIsaveSuccessComponent implements OnInit{
	@Output() initIsaveEvent = new EventEmitter();
	@Input() createIsaveResponse :CreateIsaveResponse;
	@Input() setupIsaveResponse :SetupIsaveResponse;
	@Input() createIsaveRequest :CreateIsaveRequest;
	product :Product;
	
	constructor( private templateService: TemplateService,
				 private errorService: ErrorService,
				 private router: Router) {}

	ngOnInit() {
		this.product = this.setupIsaveResponse.fundingSources[this.templateService.getSelectIndex(this.setupIsaveResponse.fundingSources,'prodRef',this.createIsaveRequest.sourceAccount)];
	}

	backtoIsave(){
		this.initIsaveEvent.emit();
	}
}