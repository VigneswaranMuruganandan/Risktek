import { Component, OnInit, Input, Output, EventEmitter, ViewChild, OnDestroy } from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { ErrorService} from '../../shared/services/error.service';
import { SharedService } from '../../shared/services/shared.service';
import { IsaveService } from '../services/isave.service';
import { ISaveResponse } from '../model/isaveResponse';
import { ISave } from '../model/isave';
import { SpinnerService } from '../../shared/services/spinner.service';
import { CreateIsaveRequest } from '../model/createIsaveRequest';
import { CreateIsaveResponse } from '../model/createIsaveResponse';
import { CloseIsaveRequest } from '../model/closeIsaveRequest';

@Component({
  templateUrl: './../templates/viewIsave.html'
})
export class ViewIsaveComponent implements OnInit{
	public isave: ISave;

	constructor( private errorService: ErrorService,
				 public isaveService: IsaveService,
				 private spinnerService: SpinnerService,
				 private sharedService: SharedService){}

	ngOnInit() {
		this.errorService.resetErrorResp();
		this.spinnerService.startSpinner('viewIsave');
        this.isave = this.isaveService.getISaveData();
        setTimeout(()=> {
          this.spinnerService.stopSpinner('viewIsave');
        }, 200);
    }
}