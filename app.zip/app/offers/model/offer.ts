import { NameValuePair } from '../../shared/model/nameValuePair';

export class Offer {
  title :string;
  description :string;
  smallImageUrl :string;
  largeImageUrl :string;
  startDate :string;
  endDate :string;
  tnc :string;
  locations :string[];
  category :NameValuePair;
  merchant :NameValuePair;
}