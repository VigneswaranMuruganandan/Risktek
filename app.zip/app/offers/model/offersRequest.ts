export class OffersRequest {
  requestChannel :number;
  keyword :string;
  category :string;
  merchant :string;
  locationLat :number;
  locationLon :number;
  active :boolean;
  startDate :string;
  endDate :string;
  maxResults :number;
  language :string;
}


