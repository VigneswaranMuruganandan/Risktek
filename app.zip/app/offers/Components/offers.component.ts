import { Component, OnInit, Input} from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { OffersService} from '../services/offers.service';
import { ErrorService } from '../../shared/services/error.service';
import { SharedService} from '../../shared/services/shared.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { OffersRequest } from '../model/offersRequest';
import { OffersResponse } from '../model/offersResponse';
import { CategorieItems } from '../model/categorieItems';
import { MerchantItems } from '../model/merchantItems';
import { Categories } from '../model/categories';
import { Merchants } from '../model/merchants';
import { NameValuePair } from '../../shared/model/nameValuePair';
import { AppSession} from '../../shared/model/appSession';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/filter';

@Component({
  templateUrl: './../templates/offers.html'
})
export class OffersComponent implements OnInit {
    public offersRequest = new OffersRequest();
	public offersResponse = new OffersResponse();
    public merchants : MerchantItems[];
    public categories: CategorieItems[]; 	
    public keyword :NameValuePair[];
    public appSession: AppSession;

	constructor( private offersService: OffersService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService, 
                 private sharedService: SharedService) {}

	ngOnInit() {
        this.offersRequest.category = '';
        this.offersRequest.merchant = '';
        this.merchants = new Array();
        this.categories = new Array();
        this.fetchMerchants();
        this.fetchCategories();
        this.appSession = AppSession.getInstance();
        if(this.appSession.accountOfferMerchant && this.appSession.accountOfferMerchant != ''){
            this.offersRequest.category = this.appSession.accountOfferMerchant;
            this.searchOffers();
            this.appSession.accountOfferMerchant = '';
        }
    }

    generateKeywords(offersRequest :OffersRequest){
        if(offersRequest){
            this.keyword = [];
            Object.getOwnPropertyNames(offersRequest)
            .map((key: string) => {                
                if(offersRequest[key] && offersRequest[key]!=''){
                    let data = new NameValuePair();
                    data.name = key;
                    data.value = offersRequest[key];
                    this.keyword.push(data);
                }                
            });
        }
    }
    /*
    * Search the Offers with Keyword, Merchant and Categories
    */
    searchOffers(){
        this.spinnerService.startSpinner('offerResponse');
        let data = new OffersRequest();
        Object.getOwnPropertyNames(this.offersRequest)
            .map((key: string) => {
                if(this.offersRequest[key] != '')
                data[key] = this.offersRequest[key];
            });
        this.generateKeywords(this.offersRequest);        
        this.offersService.fetchOffers(data)
        .subscribe(
            resp => this.handleOffersResp(resp),
            error => this.sharedService.handleError(error)
        );
    }
    /*
    * Handle the Search the Offers
    */
    handleOffersResp(resp :any){
        this.spinnerService.stopSpinner('offerResponse');
        if(resp.result.status == 'success'){
            this.offersResponse = resp;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
    }
    /*
    * Fetch the Categories Service calls
    */
    fetchCategories(){
        this.offersService.fetchCategories()
        .subscribe(
            resp => this.handleCategoriesResp(resp),
            error => this.sharedService.handleError(error)
        );
    }
    /*
    * Handle the Categories service calls
    */
    handleCategoriesResp(resp :Categories){
        if(resp.result.status == 'success'){
            this.categories = resp.items;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
    }
    /*
    * Fetch the Merchant Service calls
    */
    fetchMerchants(){
        this.offersService.fetchMerchants()
        .subscribe(
            resp => this.handleMerchantsResp(resp),
            error => this.sharedService.handleError(error)
        );
    }
    /*
    * Handle the Merchant service calls
    */
    handleMerchantsResp(resp :Merchants){
    	if(resp.result.status == 'success'){
    		this.merchants = resp.items;
            console.log(this.merchants);
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
    }

    /*CalculatePosition(locations :string[]){
        let km = '';
        if(locations.length > 0){
            //console.log(locations)
        }
        let data = {"show":true,"km":"0.58K"}
        return data
    }*/

    getDescription(tag :NameValuePair){
        let display;
        switch(tag.name) {
            case 'category':
                display = this.categories.filter(data => data.ItemID == parseInt(tag.value))[0].Title;;
                break;
            case 'merchant':
                display = this.merchants.filter(data => data.ItemID == parseInt(tag.value))[0].Title;;
                break;
            default:
                display = tag.value;
        }
        return display;
    }
}