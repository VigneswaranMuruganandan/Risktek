export class UpdateFavoritesProduct {
    productRef : string;	
    favoriteState : boolean;
}