import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { BeneficiariesService} from '../../beneficiaries/services/beneficiaries.service';
import {BeneListResp} from '../../beneficiaries/model/beneListResp';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    TranslateService,
    ServerError,
    Product,
    GlobalVariable
} from '../../shared';

@Component({
  selector: 'transferModal-component',
  templateUrl: './../templates/transferModal.html'
})
export class TransferModalComponent {
	@Input() selectedTransfer : any;  
  @Input() beneListResp :BeneListResp;
  icons :any;
  constructor( private templateService: TemplateService,
                 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService,
                 private router: Router) {}

	init() {
        this.errorService.resetErrorResp();
        this.icons = GlobalVariable.IMAGE_URL;
        this.spinnerService.startSpinner('dashboardTransferBeneficiary'); 
        setTimeout(()=> {
          this.spinnerService.stopSpinner('dashboardTransferBeneficiary'); 
        }, 1000);
    }
}