import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { FavouritesDetails } from '../model/favouritesDetails';
import { ProductPreference } from '../model/productPreference';
import { UpdateFavoritesRequest } from '../model/updateFavoritesRequest';
import { DashboardService} from '../services/dashboard.service';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/filter';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    TranslateService,
    AppSession,
    APIResponse
} from '../../shared';

@Component({
  selector: 'favouritesSettingsModal-component',
  templateUrl: './../templates/favouritesSettingsModal.html'
})
export class FavouritesSettingsModalComponent  implements OnInit{
    @Output() initDashboardDetailsEvent = new EventEmitter();
	public favouritesDetails: FavouritesDetails;
	favouritesSelected:Array<any> = [];
	public favList :Array<string>;
	constructor( private dashboardService: DashboardService,
                 private spinnerService: SpinnerService, 
    			 private sharedService: SharedService,
                 public templateService: TemplateService,
                 private router: Router) {}

	ngOnInit() {
		//this.initFavouritesDetails();
	}
	/*
    * Init method to fetch all products & Favourite products
    */
    initFavouritesDetails(){
        this.spinnerService.startSpinner('favouritesSetting');
    	this.favouritesSelected = [];
        this.dashboardService.fetchAllProducts()
            .subscribe(
                resp => this.handleFavouritesResp(resp),
                error => this.sharedService.handleError(error)
            );
    }
    /*
    * Handling the Favourites Response service calls
    */
    handleFavouritesResp(resp: any){
        this.spinnerService.stopSpinner('favouritesSetting');
        if(resp && resp.result.status == "success"){
            this.favouritesDetails = new FavouritesDetails();
            this.favouritesDetails = resp;
            this.initFavouritesCollection(this.favouritesDetails);
        }
    }
    /*
    * collecting the favourites which is selected already
    */
	initFavouritesCollection(resp: FavouritesDetails){
    	let data :ProductPreference[] = resp.productPreference;
    	data.map(obj => { 
		   if(obj.isFavorite){
		   	  this.favouritesSelected.push(obj);
		   }
		});
	}
    /*
    * Collecting the favourites in favouritesSelected
    */
	collectFavourites(data :ProductPreference, checked :boolean){
        this.favouritesDetails.productPreference.filter((product,index) => {
            if(product.prodRef == data.prodRef){
                product.isFavorite = checked;
            }
        });
		if(checked){
	      this.favouritesSelected.push(data);
	    }else{
          this.favouritesSelected = this.favouritesSelected.filter(product => product.prodRef !== data.prodRef);
	    }
	}
    /*
    * Save Favourites
    */
	saveFavourites(){
        this.spinnerService.startSpinner('favouritesSetting');
		let data :Array<string> = [];
		this.favouritesSelected.map(obj => { 
		   	data.push(obj.prodRef);
		});
        let updateFavoritesRequest = new UpdateFavoritesRequest();
        updateFavoritesRequest.productRef = data;
		this.dashboardService.saveFavourites(updateFavoritesRequest)
            .subscribe(
                resp => this.handleSaveFavResp(resp),
                error => this.sharedService.handleError(error)
            );
	}
    /*
    * Handle the Save Favourites response
    */
	handleSaveFavResp(resp: APIResponse){
        this.spinnerService.stopSpinner('favouritesSetting');
		if(resp && resp.result.status == "success"){
            let AppSess = AppSession.getInstance();
            (<any>$('.close')).click();
            (<any>$('#favCarouselRefresh')).click();

            this.initDashboardDetailsEvent.emit();
        }
	}
}