import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { DashboardService} from '../services/dashboard.service';
import { BillerListResp} from '../../payments/model/billerListResp';
import { Biller } from '../../beneficiaries/model/biller';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    TranslateService,
    GlobalVariable,
    UserContext
} from '../../shared';
import { PaymentsService} from '../../payments/services/payments.service';

@Component({
  selector: 'paymentModal-component',
  templateUrl: './../templates/paymentModal.html'
})
export class PaymentModalComponent {
	@Input() selectedPayment : any;  
	@Input() billerListResp :BillerListResp;
	public icons:any;
	@Input() tempBillerList :Biller[];

	constructor(  private sharedService: SharedService,
                  private errorService: ErrorService,
                  private spinnerService: SpinnerService,
                  public templateService: TemplateService,
                  private dashboardService:DashboardService,
                  private router: Router) {}

	init() {
        this.errorService.resetErrorResp();
        this.tempBillerList = [];
        this.icons = GlobalVariable.IMAGE_URL;        
        this.spinnerService.startSpinner('dashboardPaymentBiller'); 
        setTimeout(()=> {
          this.spinnerService.stopSpinner('dashboardPaymentBiller'); 
        }, 1000);       
    }

    payBill(biller:Biller,paymentType:string){
      if(paymentType == 'B_P'){
        UserContext.getInstance().biller = null;
        this.router.navigate([GlobalVariable.ROUTE_MAPPING.PAYMENTS_EXECUTE]);
      }
      if(paymentType == 'P'){
        UserContext.getInstance().biller = biller;
        this.router.navigate([GlobalVariable.ROUTE_MAPPING.PAYMENTS_EXECUTE]);
      }
      (<any>$('#payment-modal')).modal('hide');
    }	

    addAutoPayment(){
      UserContext.getInstance().addPaymentType = "ADD_SI_P";
      this.router.navigate([GlobalVariable.ROUTE_MAPPING.BENEFICIARIES_ADDBILLER]);
      (<any>$('#payment-modal')).modal('hide');
    }
}