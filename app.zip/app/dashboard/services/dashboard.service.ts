import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { GlobalVariable} from '../../shared/services/global';
import { ServiceInvoker} from '../../shared/connector/serviceInvoker.service';
import { EncryptionService} from '../../shared/services/encryption.service';
import { GlobalURL} from '../../shared/services/globalURL';
import { DashBoardDetails } from '../model/dashBoardDetails';
import { CustomerProducts } from '../../shared/model/customerProducts';
import { FavouritesDetails } from '../model/favouritesDetails';
import { UpdateFavoritesRequest } from '../model/updateFavoritesRequest';
import { APIResponse } from '../../shared/model/apiResponse';
import { BillerListResp} from '../../payments/model/billerListResp';

@Injectable()
export class DashboardService {

    constructor( private serviceInvoker: ServiceInvoker,
                 private encryptionService: EncryptionService) {}

    fetchDashBoardResults() : Observable < DashBoardDetails >{
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.DASHBOARD.DASHBOARD_DETAILS, null)
                                  .map(resp => JSON.parse(resp));
    }

    fetchAllProducts() : Observable < FavouritesDetails >{
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.DASHBOARD.ALL_PRODUCTS, null)
                                  .map(resp => JSON.parse(resp));
    }

    saveFavourites(updateFavoritesRequest : UpdateFavoritesRequest) : Observable < APIResponse >{
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.DASHBOARD.SAVE_FAVOURITIES, updateFavoritesRequest)
                                  .map(resp => JSON.parse(resp));
    }

    saveAsAllFavourites() : Observable < APIResponse >{
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.DASHBOARD.UPDATE_ALL_FAVOURITIES, null)
                                  .map(resp => JSON.parse(resp));
    }

    fetchBenePaymentList(): Observable <BillerListResp> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.BENEFICIARIES.BENE_PAYMENT_FETCH,null)
                                .map(resp => JSON.parse(resp));
    }
}

  

