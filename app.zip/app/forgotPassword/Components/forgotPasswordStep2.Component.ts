import { Component, OnInit, Input, Output, EventEmitter, ViewChild, OnDestroy } from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { CustomerData } from '../../register/model/customerData';
import { OTPComponent } from '../../shared/Components/otp.component';
import { ErrorService} from '../../shared/services/error.service';
import { SharedService } from '../../shared/services/shared.service';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'forgotpasswordstep2-component',
  templateUrl: './../templates/forgotPasswordStep2.html'
})
export class ForgotPasswordStep2Component{
	@Output() validateForgotPwdOTPEvent = new EventEmitter();
	@Output() forgotPwdBackEvent = new EventEmitter();
	@Output() initEvent = new EventEmitter();
	@ViewChild(OTPComponent) otpComponent:OTPComponent
	@Input() customerData: CustomerData;

	constructor( private errorService: ErrorService,
				 private sharedService: SharedService){}	

	validateOTP(otp : string){
		this.errorService.resetErrorResp();
		this.validateForgotPwdOTPEvent.emit(otp);
	}
	
	resetForm(code :string){
		this.otpComponent.resetOTPForm(code);
	}

	back(){
		this.forgotPwdBackEvent.emit(1);
	}

	accountLocked(){
		this.initEvent.emit();
	}
}