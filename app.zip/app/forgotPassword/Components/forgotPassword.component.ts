import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerData } from '../../register/model/customerData';
import { SharedService } from '../../shared/services/shared.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { ErrorService } from '../../shared/services/error.service';
import { ForgotPasswordService } from '../services/forgotPassword.service';
import { VerifyUsernameResponse } from '../../shared/model/verifyUsernameResponse';
import { AuthKey } from '../../shared/model/authKey';
import { AuthData } from '../../shared/model/authData';
import { SessionContext } from '../../shared/model/sessionContext';
import { ForgotPassword } from '../model/forgotPassword';
import { VerifyCustomerResponse } from '../../register/model/verifyCustomerResponse';
import { VerifyOtpResponse } from '../../shared/model/verifyOtpResponse';
import { ForgotPasswordStep2Component } from './forgotPasswordStep2.Component';

@Component({
  templateUrl: './../templates/forgotPassword.html'
})
export class ForgotPasswordComponent implements OnInit{
	@ViewChild(ForgotPasswordStep2Component) forgotPasswordStep2:ForgotPasswordStep2Component;
	public stepValue: number;
	public validUsername:boolean;
	public validPassword:boolean;
    public customerData: CustomerData;

    constructor( private forgotPasswordService: ForgotPasswordService, 
                 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService,
                 private router: Router) {}

	ngOnInit() {
        this.init();
    }

    init(){
        this.errorService.resetErrorResp(); 
        this.stepValue = 1;
        this.validUsername = false;
        this.customerData = new CustomerData();
    }
    
    /*
    * step 1: Register the Device ID
    */
    validateCustomerIdentificationForgotPwd(customerID: string){
        this.spinnerService.startSpinner('loader');
        this.customerData.customerID = customerID;
        let registerDeviceData = this.sharedService.setupAuthKeys();
        console.log("Register Device Data ::"+registerDeviceData);
        if(registerDeviceData && registerDeviceData.deviceID != null){
            this.sharedService.registerDevice(registerDeviceData)
                .subscribe(
                    resp => this.handleRegisterDeviceDataResp(resp),
                    error => this.sharedService.handleError(error)
                );
        }else{
            let sessCtx = SessionContext.getInstance();
            this.handleRegisterDeviceDataResp(sessCtx);
        }
    }
    /*
    * Step 2: Verify the customer ID to get the CIF number
    */
    private handleRegisterDeviceDataResp(resp: any){
        if(resp.authKey && resp.authKey.convID != null){
            console.log("validating customer identification " + this.customerData.customerID);
            let data = new ForgotPassword();
            data.customerID = this.customerData.customerID;
            this.forgotPasswordService.verifyCustomer(data)
                .subscribe(
                    resp => this.handleVerifyCustIDResp(resp),
                    error => this.sharedService.handleError(error)
                );
        }
    }
    /*
    * Handle the Response of Verify Customer ID
    * to get Mobile number and email and move to OTP Page
    */
    private handleVerifyCustIDResp(resp: VerifyCustomerResponse) {
        this.spinnerService.stopSpinner('loader');
        if(resp){
            this.stepValue = 2;
            this.customerData.mobileNumber = resp.mobileNumberMasked;
            this.customerData.emailID = resp.emailMasked;
            this.customerData.otpDuration = resp.otpDuration;
        }
    }
    /*
    * Step 3: Verify the OTP 
    */
    validateForgotPwdOTP(otp: string){
    	console.log("validating OTP " + otp);
        this.spinnerService.startSpinner('loader');
        let data = new ForgotPassword();
        data.otp = otp;
        this.forgotPasswordService.verifyOtp(data)
            .subscribe(
                resp => this.handleVerifyOtpResp(resp),
                error => this.sharedService.handleError(error)
            );
    }
    /*
    * Handle the Verify OTP Response
    */
    private handleVerifyOtpResp(resp: any) {
        this.spinnerService.stopSpinner('loader');
        if(resp.result.status == 'success'){
            this.customerData.name = resp.name;
            this.customerData.userName = resp.userName;
            // Forgotpassword is not having the option to edit the Username
            this.stepValue = 4;
        }else if(resp.result.status == 'error'){
            this.forgotPasswordStep2.resetForm(resp.result.errorInfo.code);
            this.errorService.setErrorResp(resp.result);
        }
    }

    /*
    * Handle the Username
    */
    validateForgotPwdUsername(userName: string, flag: boolean){
        this.spinnerService.startSpinner('loader');
        let editedUserName = (this.customerData.userName != userName) ? true : false;
        if(editedUserName){
            this.customerData.userName = userName;
            let data = new ForgotPassword();
            data.userName = userName;
            this.forgotPasswordService.verifyUsername(data)
            .subscribe(
                resp => this.handleVerifyUsernameResp(resp),
                error => this.sharedService.handleError(error)
            ); 
        }else{
            this.stepValue = 4;
        }
        
    }
    /*
    * Handle the username servcie response
    */
    private handleVerifyUsernameResp(resp: VerifyUsernameResponse) {
        this.spinnerService.stopSpinner('loader');
        if(resp && resp.result.status == 'success'){
            this.stepValue = 4;
        }else if(resp && resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
    }
    /*
    * Edit the Username in Registration step of Password
    */
    editUsernameForgotPwd(){
        this.stepValue = 3;
    }
    /*
    * Step 4: Change the New Username and Hashed Password 
    */
    validateForgotNewPassword(pwd: string){
    	console.log("validating Password " + pwd);
        this.spinnerService.startSpinner('loader');
        this.customerData.pwd = pwd;
        let data = new ForgotPassword();
        data.pwd = pwd;
        data.userName = this.customerData.userName;
        this.forgotPasswordService.resetPwd(data)
            .subscribe(
                resp => this.handleVerifyPwdResp(resp),
                error => this.sharedService.handleError(error)
            );
    }

    /*
    * Step 5: Verify the Username and Hashed Password 
    */
    private handleVerifyPwdResp(resp: any) {
        console.log('handleVerifyPwdResp ' + resp);
        this.spinnerService.stopSpinner('loader');
        if (resp && resp.result.status == "success") {
            this.stepValue = 5;            
        }
    }
    
    verifyForgotPasswordLogin(){
        this.router.navigate(['/login']);
        /*this.spinnerService.startSpinner('loader');        
        let data = new ForgotPassword();
        data.userName = this.customerData.userName;
        data.pwd = this.customerData.pwd;
        this.forgotPasswordService.verifyLogin(data)
            .subscribe(
                resp => this.handleLoginResp(resp),
                error => this.sharedService.handleError(error)
            );*/
    }

    /*
    * Handle the verify Login based on actions
    */
    /*private handleLoginResp(resp: any) {
        this.spinnerService.stopSpinner('loader');
        if (resp && resp.result.status == 'success') {
            this.router.navigate(['/dashboard']);
        }
    }*/

    forgotPwdBack(step : number){
        this.stepValue = step;
    }

}