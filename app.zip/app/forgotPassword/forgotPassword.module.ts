import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { routing } from './forgotPassword.routing';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '../shared/shared.module';
import { SharedService} from '../shared/services/shared.service';
import { TemplateService} from '../shared/services/template.service';
import { ForgotPasswordService} from './services/forgotPassword.service';
import { FormsModule } from '@angular/forms';
import { ForgotPasswordComponent } from './Components/forgotPassword.component';
import { ForgotPasswordStep1Component }   from './Components/forgotPasswordStep1.Component';
import { ForgotPasswordStep2Component }   from './Components/forgotPasswordStep2.Component';
import { ForgotPasswordStep3Component }   from './Components/forgotPasswordStep3.Component';
import { ForgotPasswordStep4Component }   from './Components/forgotPasswordStep4.Component';
import { ForgotPasswordStep5Component }   from './Components/forgotPasswordStep5.Component';

const FORGOTPASSWORD_COMPONENTS = [
    ForgotPasswordComponent,
    ForgotPasswordStep1Component,
    ForgotPasswordStep2Component,
    ForgotPasswordStep3Component,
    ForgotPasswordStep4Component,
    ForgotPasswordStep5Component
];

const FORGOTPASSWORD_DIRECTIVES = [
    
];

const FORGOTPASSWORD_PROVIDERS = [
   SharedService,
   TemplateService,
   ForgotPasswordService
];

@NgModule({
  	imports: [
	    routing,
	    TranslateModule.forChild(),
	    SharedModule,
	    FormsModule,
      CommonModule
	],
  	declarations: [
	    ...FORGOTPASSWORD_COMPONENTS/*,
      ...FORGOTPASSWORD_DIRECTIVES*/
	],
  	providers: [
  		...FORGOTPASSWORD_PROVIDERS
  	]
})
export class ForgotPasswordModule {}
