import { Component, OnInit, Input} from '@angular/core';
import { SharedService } from '../../shared/services/shared.service';
import { TemplateService } from '../../shared/services/template.service';
import { ErrorService } from '../../shared/services/error.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { LoansService } from '../services/loans.service';
import { Router } from '@angular/router';
import { SetupLoanDeferralResponse } from '../model/setupLoanDeferralResponse';
import { LoanDeferralRequest } from '../model/loanDeferralRequest';

@Component({
  templateUrl: './../templates/baseLoanDeferral.html'
})
export class BaseLoanDeferralComponent implements OnInit {
	public setupLoanDeferralResponse:any; //setupLoanDeferralResponse :SetupLoanDeferralResponse;
	public loanDeferralRequest :LoanDeferralRequest;
    public stepValue: number;
    public loanSelected :any[];
    public charges :number;

	constructor( private loansService: LoansService,
				 private templateService: TemplateService,
				 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService,
    			 private router: Router) {}

	ngOnInit() {
        this.init();
    }

    init(){
        this.errorService.resetErrorResp();
        this.stepValue = 1;
        this.loanSelected = [];
        this.charges = 0;
        //this.initLoanDeferral();
        this.loanDeferralRequest = new LoanDeferralRequest();
        this.loanDeferralRequest.loanDetails = [];
        this.setupLoanDeferralResponse = new SetupLoanDeferralResponse();
        this.setupLoanDeferralResponse = {"result":{"status":"success"},"notes":"Loan Deferral charge amount AED 100","loanDetails":[{"loanHolderName":"FGB SCRAMBLE SHORT NAME","loanAccountNumber":"MG1319900078","typeOfLoan":"Personal Loan","outstandingBalance":{"value":205857.4,"valueFmt":"205,857.40","currency":"USD"},"principalAmount":{"value":200472,"valueFmt":"200,472.00","currency":"USD"},"paymentFrequency":"","fundingAccountnumber":"1031591006860057","interestRate":"2.64956","numberOfReceivedInstallments":"1","installmentAmount":{"value":0,"valueFmt":"0.00","currency":"USD"},"nextInstallmentAmount":{"value":0,"valueFmt":"0.00","currency":"USD"},"nextPaymentDate":"02/07/2018","maturityDate":"02/07/2018","startDate":"18/07/2013"},{"loanHolderName":"FGB SCRAMBLE SHORT NAME","loanAccountNumber":"MG1319900068","typeOfLoan":"Personal Loan","outstandingBalance":{"value":205857.4,"valueFmt":"205,857.40","currency":"USD"},"principalAmount":{"value":200472,"valueFmt":"200,472.00","currency":"USD"},"paymentFrequency":"","fundingAccountnumber":"1031591006860057","interestRate":"2.64956","numberOfReceivedInstallments":"1","installmentAmount":{"value":0,"valueFmt":"0.00","currency":"USD"},"nextInstallmentAmount":{"value":0,"valueFmt":"0.00","currency":"USD"},"nextPaymentDate":"02/07/2018","maturityDate":"02/07/2018","startDate":"18/07/2013"}],"charge":{"value":100,"valueFmt":"100.00","currency":"AED"},"account":{"productType":"ACCOUNT","prodRef":"1011021006860023","balance":{"value":15114.82,"valueFmt":"15,114.82","currency":"AED"},"nickName":"Current Account","currency":"AED"}};
        this.loanDeferralRequest.account = this.setupLoanDeferralResponse.account;
        this.setupLoanDeferralResponse.loanDetails.map((obj,index) => {
           this.loanSelected[index] = obj;
           this.loanSelected[index].status = false;
        });        
    }

    /*
    * Fetch the init Loan Deferral
    */
    initLoanDeferral(){
        this.spinnerService.startSpinner('loanDeferralRequest');
        this.loansService.setupLoanDeferral()
        .subscribe(
            resp => this.handleSetupLoanDeferral(resp),
            error => this.sharedService.handleError(error)
        );
    }
    /*
    * Handle the response for init Loan Deferral
    */
    handleSetupLoanDeferral(resp :any){
        this.spinnerService.stopSpinner('loanDeferralRequest');
        this.setupLoanDeferralResponse = new SetupLoanDeferralResponse();
        if(resp && resp.result.status == 'success'){
            this.setupLoanDeferralResponse = resp;
            this.loanDeferralRequest.account = this.setupLoanDeferralResponse.account;
            this.setupLoanDeferralResponse.loanDetails.map((obj,index) => {
            this.loanSelected[index] = obj;
            this.loanSelected[index].status = false;
        });
        }else if(resp.result.status == 'error'){
            (<any>$('#loanDeferralError')).modal('show');
        }
    }
    /*
    * submit the Loan Deferral
    */
    submitLoanDeferral(){
        this.spinnerService.startSpinner('loanDeferralRequest');
        this.stepValue = 2;
        /*this.loansService.saveLoanDeferral(this.loanDeferralRequest)
        .subscribe(
            resp => this.handlesubmitLoanDeferral(resp),
            error => this.sharedService.handleError(error)
        );  */         
    }

    handlesubmitLoanDeferral(resp :any){
        this.spinnerService.stopSpinner('loanDeferralRequest');
        if(resp && resp.result.status == 'success'){
            this.stepValue = 2;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
    }

    
}