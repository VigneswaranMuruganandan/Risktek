import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { SharedService } from '../../shared/services/shared.service';
import { TemplateService } from '../../shared/services/template.service';
import { ErrorService } from '../../shared/services/error.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { LoansService } from '../services/loans.service';
import { Router } from '@angular/router';
import { SetupLoanDeferralResponse } from '../model/setupLoanDeferralResponse';

@Component({
  selector: 'loanDeferralSuccess-component',
  templateUrl: './../templates/loanDeferralSuccess.html'
})
export class LoanDeferralSuccessComponent {
  @Output() initEvent = new EventEmitter();

  reset(){
    this.initEvent.emit();
  }
}