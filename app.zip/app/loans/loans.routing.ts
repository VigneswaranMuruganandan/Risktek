import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoansComponent } from './Components/loans.component';
import { BaseLoanDeferralComponent } from './Components/baseLoanDeferral.component';


const routes: Routes = [
    {
        path: 'loansOverview',
        component: LoansComponent
    },
    {
        path: 'loanDeferral',
        component: BaseLoanDeferralComponent
    },
    {
        path: '',
        redirectTo: '',
        pathMatch: 'full'
    }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
