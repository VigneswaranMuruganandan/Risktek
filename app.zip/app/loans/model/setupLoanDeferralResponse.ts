import {APIResponse} from '../../shared/model/apiResponse';
import { Product } from '../../shared/model/product';
import { Amount } from '../../shared/model/amount';

export class SetupLoanDeferralResponse extends APIResponse{
	notes :string[];
	loanList :Product[];
	fundingSources :Product[];
	charge :Amount;
	months :string[];
}