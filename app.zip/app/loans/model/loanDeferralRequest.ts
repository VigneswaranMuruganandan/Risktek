import { Loan } from './loan';
import { Product } from '../../shared/model/product';

export class LoanDeferralRequest {
	loanDetails :Loan[];
	account :Product;
}