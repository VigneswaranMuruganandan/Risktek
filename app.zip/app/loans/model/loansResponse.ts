import {APIResponse} from '../../shared/model/apiResponse';
import { Loan } from './loan';

export class LoansResponse extends APIResponse{
	loanDetailList : Loan[];
}