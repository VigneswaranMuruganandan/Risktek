import { APIResponse } from '../../shared/model/apiResponse';
import { AlertDetail } from './alertDetail';

export class AlertCentreResp extends APIResponse {
	alertHistory:AlertDetail[];
}