import { AuthRequest } from '../../shared/model/authRequest';

export class UpdatePassword extends AuthRequest{
	oldPwd: string;
	newPwd: string;
	confirmPwd: string;
	pwd: string;
}