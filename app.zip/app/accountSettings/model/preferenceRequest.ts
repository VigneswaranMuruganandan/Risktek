export class PreferenceRequest {
	transactionCode :string;
}