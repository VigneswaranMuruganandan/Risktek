import { Component, ElementRef, Directive, HostListener, NgZone, Input, Output, EventEmitter } from '@angular/core';
import * as $ from 'jquery';
import {TemplateService} from '../../shared/services/template.service';
import { UpdatePassword } from '../model/updatePassword';

/*
* Personal Information Email Update for Registration
*/
@Directive({
    selector: '[ValidatePersonalInfoDirective]',
})
export class ValidatePersonalInfo {
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let personalInfoValidationSubmit ;
        this.zone.runOutsideAngular(() => {
            var personalInfoValidation = (<any>$("#personalInfoForm")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    email: {
                        required: true,
                        email: true
                    }
                },
                messages: {
                    email: {
                        required: "Please enter the email ID to be updated",
                        email: "Please enter valid email ID"
                    }
                }
            });
            personalInfoValidationSubmit = personalInfoValidation.form();
            this.templateService.setFormValidatorFlag(personalInfoValidationSubmit);
        });
    }
}

@Directive({
    selector: '[validateChangePassword]',
})
export class ValidateChangePasswordDirective {
    @Input() updatePassword: UpdatePassword;

    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let changePasswordValidationSubmit;
        this.zone.runOutsideAngular(() => {
            
            (<any>$).validator.addMethod("comparePassword", (value :any, element :any, param :any) => {
                var flag = false;
                (this.updatePassword.newPwd == this.updatePassword.confirmPwd) ? (flag = true) : (flag = false);                   
                return flag;
            });

            var changePasswordValidation = (<any>$("#passwordRegisterForm")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input")) {
                        element.parent().append(error);
                    }
                    if (element.is("select")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    oldPassword:{
                        required: true
                    },
                    password:{
                        required: true
                    },
                    confirmPassword:{
                        required: true,
                        comparePassword: true
                    }
                },
                messages: {
                    oldPassword:{
                        required: "Please fill in"
                    },
                    password:{
                        required: "Please fill in"
                    },
                    confirmPassword:{
                        required: "Please fill in",
                        comparePassword: "Please enter the same password"
                    }
                }
            });
            changePasswordValidationSubmit = changePasswordValidation.form();
            this.templateService.setFormValidatorFlag(changePasswordValidationSubmit);
        });
    }
}