import { Component, OnInit, Input,Output, EventEmitter} from '@angular/core';
import { AccountSettingsService } from '../services/accountSettings.service';
import { PreferenceRequest } from '../model/preferenceRequest';
import { EstmtPreferenceRequest } from '../model/estmtPreferenceRequest';
import { VerifyOtpResponse } from '../../shared/model/verifyOtpResponse';
import {
    SharedService, SpinnerService, ErrorService, TemplateService, Router, TranslateService, ServerError, Product, GlobalVariable, AppSession, UserDetails, UserContext
} from '../../shared';
import { CustomerData } from '../../register/model/customerData';

@Component({
  selector: 'updateEmail-component',
  templateUrl: './../templates/updateEmail.html'
})
export class UpdateEmailComponent {
	public stepValue: number;
	public userDetails: UserDetails;
    public customerData: CustomerData;
	public preferenceRequest :PreferenceRequest;
    public estmtPreferenceRequest :EstmtPreferenceRequest;

	constructor( private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private accountSettingsService: AccountSettingsService,
                 private errorService: ErrorService) {}
	
	init(){
		this.stepValue = 1;
		this.userDetails = UserContext.getInstance().userDetails;
        this.estmtPreferenceRequest = new EstmtPreferenceRequest();
		this.estmtPreferenceRequest.email = this.userDetails.unmaskedEmail;
        this.customerData = new CustomerData();
	}

	confirmUpdateEmail(){
		this.spinnerService.startSpinner('updateEmail');
        this.preferenceRequest = new PreferenceRequest();		
        this.preferenceRequest.transactionCode = GlobalVariable.TRANSACTION_CODES.EMAIL_UPDATE;
		this.accountSettingsService.otpForEmailEstatement(this.preferenceRequest)
            .subscribe(
                resp => this.handleOtpResp(resp),
                error => this.sharedService.handleError(error)
            );
	}

	handleOtpResp(resp :VerifyOtpResponse){
		this.spinnerService.stopSpinner('updateEmail');        
        if(resp.result.status == 'success'){
            this.customerData.mobileNumber = resp.mobileNumberMasked;
            this.customerData.emailID = resp.emailMasked;
            this.customerData.otpDuration = resp.otpDuration;
            this.estmtPreferenceRequest.txnRef = resp.txnRef;
            this.stepValue = 2;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
    }

	validateUpdateEmail(otp :string){
		this.spinnerService.startSpinner('updateEmail');
		this.estmtPreferenceRequest.authKey = otp;	
        this.accountSettingsService.updateEmailEstatement(this.estmtPreferenceRequest)
            .subscribe(
                resp => this.handleUpdateEmailIDResp(resp),
                error => this.sharedService.handleError(error)
            );	
	}

	handleUpdateEmailIDResp(resp: UserDetails){
		this.spinnerService.stopSpinner('updateEmail');
		if(resp && resp.result.status == 'success'){       
            this.userDetails.email = resp.email;
            this.userDetails.unmaskedEmail = resp.unmaskedEmail;
            this.stepValue = 3;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
	}

	backUpdateEmail(step :number){
        if(step){
		  this.stepValue = step;
        }
	}
}