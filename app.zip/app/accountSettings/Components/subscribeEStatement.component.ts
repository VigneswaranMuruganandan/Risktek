import { Component, OnInit, Input,Output, EventEmitter} from '@angular/core';
import { AccountSettingsService } from '../services/accountSettings.service';
import { PreferenceRequest } from '../model/preferenceRequest';
import { EstmtPreferenceRequest } from '../model/estmtPreferenceRequest';
import { VerifyOtpResponse } from '../../shared/model/verifyOtpResponse';
import {
    SharedService, SpinnerService, ErrorService, TemplateService, Router, TranslateService, ServerError, Product, GlobalVariable, AppSession, UserDetails, UserContext
} from '../../shared';
import { CustomerData } from '../../register/model/customerData';

@Component({
  selector: 'subscribeEStatement-component',
  templateUrl: './../templates/subscribeEStatement.html'
})
export class SubscribeEStatementComponent {
	public stepValue: number;
	public userDetails: UserDetails;
    public customerData: CustomerData;
	public preferenceRequest :PreferenceRequest;
    public estmtPreferenceRequest :EstmtPreferenceRequest;
    @Output() updateParentDataEvent = new EventEmitter();

	constructor( private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private accountSettingsService: AccountSettingsService,
                 private errorService: ErrorService) {}
	
	init(){
		this.stepValue = 1;
		this.userDetails = UserContext.getInstance().userDetails;
        this.estmtPreferenceRequest = new EstmtPreferenceRequest();
		this.estmtPreferenceRequest.email = this.userDetails.unmaskedEmail;
        this.customerData = new CustomerData();
	}

	confirmUpdateEStatement(otp :string){
		this.spinnerService.startSpinner('updateEstatement');
        this.preferenceRequest = new PreferenceRequest();		
        this.preferenceRequest.transactionCode = GlobalVariable.TRANSACTION_CODES.EMAIL_UPDATE;
		this.accountSettingsService.otpForEmailEstatement(this.preferenceRequest)
            .subscribe(
                resp => this.handleOtpResp(resp),
                error => this.sharedService.handleError(error)
            );
	}

	handleOtpResp(resp :VerifyOtpResponse){
		this.spinnerService.stopSpinner('updateEstatement');        
        if(resp.result.status == 'success'){
            this.customerData.mobileNumber = resp.mobileNumberMasked;
            this.customerData.emailID = resp.emailMasked;
            this.customerData.otpDuration = resp.otpDuration;
            this.estmtPreferenceRequest.txnRef = resp.txnRef;
            this.stepValue = 2;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
    }

	validateUpdateEStatement(otp :string){
		this.spinnerService.startSpinner('updateEstatement');
		this.estmtPreferenceRequest.authKey = otp;	
		this.estmtPreferenceRequest.eStatementPref = true;
        this.accountSettingsService.updateEmailEstatement(this.estmtPreferenceRequest)
            .subscribe(
                resp => this.handleUpdateEmailIDResp(resp),
                error => this.sharedService.handleError(error)
            );
	}

	handleUpdateEmailIDResp(resp: UserDetails){
		this.spinnerService.stopSpinner('updateEstatement');
		if(resp && resp.result.status == 'success'){       
            this.userDetails.email = resp.email;
            this.userDetails.unmaskedEmail = resp.unmaskedEmail;
            this.userDetails.estatementPreference = true;
            this.stepValue = 3;
            this.updateParentDataEvent.emit();
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
	}

	backUpdateEStatement(step :number){
		if(step){
		  this.stepValue = step;
        }
	}

}