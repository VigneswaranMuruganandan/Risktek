import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { PreferenceRequest } from '../model/preferenceRequest';
import { EstmtPreferenceRequest } from '../model/estmtPreferenceRequest';
import {
    SharedService, SpinnerService, ErrorService, TemplateService, Router, TranslateService
} from '../../shared';

@Component({
  selector: 'updateEmailStep1-component',
  templateUrl: './../templates/updateEmailStep1.html'
})
export class UpdateEmailStep1Component implements OnInit{
	@Output() confirmUpdateEmailEvent = new EventEmitter();
	@Input() estmtPreferenceRequest :EstmtPreferenceRequest;

	constructor( private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService) {}
	
	ngOnInit(){}

	confirm(){
		this.confirmUpdateEmailEvent.emit();
	}

}