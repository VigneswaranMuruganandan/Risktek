import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { UpdateEmailReq} from '../model/updateEmailReq';

@Component({
  selector: 'updateEmailStep1-component',
  templateUrl: './../templates/updateEmailStep1.html'
})
export class UpdateEmailStep1Component implements OnInit{
	@Output() confirmUpdateEmailEvent = new EventEmitter();
	@Input() updateEmailReq: UpdateEmailReq;

	constructor() {}
	
	ngOnInit(){}

	confirm(){
		this.confirmUpdateEmailEvent.emit();
	}

}