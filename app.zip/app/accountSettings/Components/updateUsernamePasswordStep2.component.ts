import { Component, OnInit, Input,Output, EventEmitter} from '@angular/core';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    AppSession,
    TranslateService,
    UserDetails,
    UserContext,
    NameValuePair
} from '../../shared';
import { CustomerData } from '../../register/model/customerData';

@Component({
  selector: 'updateUsernamePasswordStep2-component',
  templateUrl: './../templates/updateUsernamePasswordStep2.html'
})
export class UpdateUsernamePasswordStep2Component implements OnInit{
	@Output() validateUpdateUsernamePasswordEvent = new EventEmitter();
	@Output() backUpdateUsernamePasswordEvent = new EventEmitter();
	@Input() currentTabUserPwd: string;
	@Input() customerData: CustomerData;

	constructor(private sharedService: SharedService,
                private errorService: ErrorService,
                private spinnerService: SpinnerService,
                private router: Router) {}
	
	ngOnInit(){}

	validateOTP(otp : string){
		this.errorService.resetErrorResp();
		this.validateUpdateUsernamePasswordEvent.emit(otp);
	}

	back(){
		this.backUpdateUsernamePasswordEvent.emit(1);
	}

}