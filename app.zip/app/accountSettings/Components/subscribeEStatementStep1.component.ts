import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { PreferenceRequest } from '../model/preferenceRequest';
import { EstmtPreferenceRequest } from '../model/estmtPreferenceRequest';
import {
    SharedService, SpinnerService, ErrorService, TemplateService, Router, TranslateService
} from '../../shared';

@Component({
  selector: 'subscribeEStatementStep1-component',
  templateUrl: './../templates/subscribeEStatementStep1.html'
})
export class SubscribeEStatementStep1Component implements OnInit{
	@Output() confirmUpdateEStatementEvent = new EventEmitter();
	@Input() estmtPreferenceRequest :EstmtPreferenceRequest;

	constructor( private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService) {}
	
	ngOnInit(){}

	confirm(){
		this.confirmUpdateEStatementEvent.emit();
	}

}