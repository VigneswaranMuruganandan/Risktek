import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    AppSession,
    TranslateService,
    UserDetails,
    UserContext,
    NameValuePair
} from '../../shared';
import { UpdateUsername } from '../model/updateUsername';
import { UpdatePassword } from '../model/updatePassword';
import { CustomerData } from '../../register/model/customerData';

@Component({
  selector: 'updateUsernamePasswordStep1-component',
  templateUrl: './../templates/updateUsernamePasswordStep1.html'
})
export class UpdateUsernamePasswordStep1Component implements OnInit{
	@Output() setCurrentTabEvent = new EventEmitter();
	@Output() verifyUpdateUsernamePasswordEvent = new EventEmitter();
	@Input() currentTabUserPwd: string;
	@Input() customerData: CustomerData;
	@Input() updateUsername: UpdateUsername;
	@Input() updatePassword: UpdatePassword;
	validUsernameFlag: boolean;
	validPasswordFlag: boolean;
	
	constructor(private sharedService: SharedService,
				private templateService: TemplateService,
                private errorService: ErrorService,
                private spinnerService: SpinnerService,
                private router: Router) {}
	
	ngOnInit(){
		this.validUsernameFlag = false;
		this.validPasswordFlag = true;
	}

	setTab(tab :string){
		if(tab){
			this.setCurrentTabEvent.emit(tab);
		}
	}

	usernameValidations(flag :boolean){
    	this.validUsernameFlag = flag;
    }

	verifyUsername(){
		if(this.validUsernameFlag){
			this.errorService.resetErrorResp();
			this.verifyUpdateUsernamePasswordEvent.emit();
		}
	}

	passwordValidations(flag: boolean){
		this.validPasswordFlag = flag;
		this.templateService.resetFormValidatorFlag();
	}

	verifyPassword(valid :boolean){
		if(valid){
			this.errorService.resetErrorResp();
			this.templateService.resetFormValidatorFlag();
			this.verifyUpdateUsernamePasswordEvent.emit();
		}
	}

}