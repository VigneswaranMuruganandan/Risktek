import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'updateUsernamePasswordStep1-component',
  templateUrl: './../templates/updateUsernamePasswordStep1.html'
})
export class UpdateUsernamePasswordStep1Component implements OnInit{
	@Output() setCurrentTabEvent = new EventEmitter();
	@Output() confirmUpdateUsernamePasswordEvent = new EventEmitter();
	@Input() currentTabUserPwd: string;
	
	constructor() {}
	
	ngOnInit(){
		//test
	}

	setTab(tab :string){
		if(tab){
			this.setCurrentTabEvent.emit(tab);
		}
	}

	confirm(){
		this.confirmUpdateUsernamePasswordEvent.emit();
	}

}