import { Component, OnInit, Input,Output, EventEmitter} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { EstmtPreferenceRequest } from '../model/estmtPreferenceRequest';
@Component({
  selector: 'subscribeEStatementStep3-component',
  templateUrl: './../templates/subscribeEStatementStep3.html'
})
export class SubscribeEStatementStep3Component implements OnInit{
	@Input() estmtPreferenceRequest :EstmtPreferenceRequest;
	constructor() {}
	
	ngOnInit(){}

}