import { Component, OnInit, Input,Output, EventEmitter} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'subscribeEStatementStep3-component',
  templateUrl: './../templates/subscribeEStatementStep3.html'
})
export class SubscribeEStatementStep3Component implements OnInit{
	
	constructor() {}
	
	ngOnInit(){}

}