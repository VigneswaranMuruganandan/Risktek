import { Component, OnInit, Input,Output, EventEmitter} from '@angular/core';
import {
    SharedService, SpinnerService, ErrorService, TemplateService, Router, TranslateService
} from '../../shared';

@Component({
  selector: 'subscribeEStatementStep2-component',
  templateUrl: './../templates/subscribeEStatementStep2.html'
})
export class SubscribeEStatementStep2Component implements OnInit{
	@Output() validateUpdateEStatementEvent = new EventEmitter();
	@Output() backUpdateEStatementEvent = new EventEmitter();

	constructor( private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService) {}
	
	ngOnInit(){}

	validateOTP(otp : string){
		if(otp){
			this.errorService.resetErrorResp();
			this.validateUpdateEStatementEvent.emit(otp);
		}
	}

	back(){
		this.backUpdateEStatementEvent.emit(1);
	}

}