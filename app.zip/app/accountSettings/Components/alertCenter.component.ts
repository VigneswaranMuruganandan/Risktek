import { Component, OnInit, Input,Output, EventEmitter} from '@angular/core';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    TranslateService,
    GlobalVariable
} from '../../shared';
import { AlertDetail } from '../model/alertDetail';
import { AlertCentreResp } from '../model/alertCentreResp';
import {AccountSettingsService} from '../services/accountSettings.service';

@Component({
  selector: 'alertcentre-component',
  templateUrl: './../templates/alertCenter.html'
})
export class AlertCenterComponent implements OnInit{
	alertList: AlertDetail[];

	constructor( private accountSettingsService: AccountSettingsService,
		         private sharedService: SharedService,
                 private templateService: TemplateService,
		         private errorService: ErrorService,
		         private spinnerService: SpinnerService) {}

	ngOnInit(){
		this.getAlertsHistory();
	}
	
	/*
    * Fetch Alert Centre History 
    */
    getAlertsHistory(){
        this.spinnerService.startSpinner('alertCenter');
        this.accountSettingsService.fetchAlertsHistory()
            .subscribe(
                resp => this.handleAlertsHistoryResp(resp),
                error => this.sharedService.handleError(error)
            );
    }

    /*
    * Handle Alert Centre History Response
    */
    handleAlertsHistoryResp(resp: AlertCentreResp) {
        this.spinnerService.stopSpinner('alertCenter');
        if (resp.result.status == "success") {
            this.alertList = resp.alertHistory;
        } else if (resp.result.status == 'error') {
            this.errorService.setErrorResp(resp.result);
        }
    }
}