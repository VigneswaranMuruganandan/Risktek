import { Component, OnInit, Input,Output, EventEmitter} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'updateUsernamePassword-component',
  templateUrl: './../templates/updateUsernamePassword.html'
})
export class UpdateUsernamePasswordComponent implements OnInit{
	public stepValue: number;
	public currentTabUserPwd :string;

	constructor() {}
	
	ngOnInit(){
		this.stepValue = 1;
		this.currentTabUserPwd = "UPDATE_USERNAME"
	}

	setCurrentTab(tab :string){
		this.currentTabUserPwd = tab;
	}
	
	confirmUpdateUsernamePassword(){
		this.stepValue = 2;
	}

	validateUpdateUsernamePassword(otp :string){
		if(otp){
			this.stepValue = 3;
		}
	}

	backUpdateUsernamePassword(step :number){
		this.stepValue = step;
	}

}