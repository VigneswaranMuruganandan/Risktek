export class ChequeBookRequest{
	accountIdentifier :string;
	accountingUnitIdentifier :string;
	branchIdentifier :string;
	numberOfCheckbooks :string;
	chargeWaiverFlag :boolean ;
	addionalInformation :string;
	authKey :string;
	txnRef :string;

	constructor() { 
 		this.accountIdentifier = '';
 		this.numberOfCheckbooks = '';
	}
}