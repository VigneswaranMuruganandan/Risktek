import { Component, Input, Output, EventEmitter } from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { ServicesService } from '../services/services.service';
import { SharedService } from '../../shared/services/shared.service';
import { TemplateService} from '../../shared/services/template.service';
import { ErrorService} from '../../shared/services/error.service';
import { Product } from '../../shared/model/product';
import { ChequeBookAccountsResponse } from '../model/chequeBookAccountsResponse';
import { ChequeBookRequest } from '../model/chequeBookRequest';
import { ChequeBookChargeResponse } from '../model/chequeBookChargeResponse';
import { GlobalVariable} from '../../shared/services/global';

@Component({
  selector: 'chequeBookRequestForm-component',
  templateUrl: './../templates/chequeBookRequestForm.html'
})
export class ChequeBookRequestFormComponent {
	@Input() chequeBookRequest: ChequeBookRequest;
	@Output() validateChequeBookReqEvent = new EventEmitter();
    @Output() calculateChequeBookChargesEvent = new EventEmitter();
	@Input() chequeBookAccounts: ChequeBookAccountsResponse;
	public noOfchequeBook :number[]= GlobalVariable.NO_OF_CHEQUEBOOK;
	@Input() chequeBookcharges: ChequeBookChargeResponse;

	constructor( public servicesService: ServicesService, 
				 public sharedService: SharedService,
				 public templateService: TemplateService,
				 private errorService: ErrorService) {}

	ngOnInit() {
        //test
    }

    calculateCharges(){
    	if(this.chequeBookRequest.accountIdentifier!='' && this.chequeBookRequest.numberOfCheckbooks!=''){
    		this.calculateChequeBookChargesEvent.emit();
    	}
    }

	validateForm(valid: boolean){
		if(valid){
			this.templateService.resetFormValidatorFlag();
			this.validateChequeBookReqEvent.emit();
		}
	}

}



