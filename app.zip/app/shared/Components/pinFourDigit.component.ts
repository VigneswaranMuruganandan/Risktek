import {
    Component,
    Input,
    OnInit,
    ElementRef,
    ContentChild,
    Renderer,
    Directive,
    HostListener,
    Host,
    NgZone,
    Output,
    EventEmitter
} from '@angular/core';
import * as $ from 'jquery';


@Component({
    selector: 'pin-component',
    templateUrl: './../templates/pinFourDigit.html'
})
export class PinFourDigitComponent implements OnInit {
    @Output() backEvent = new EventEmitter();
    @Output() validatePinEvent = new EventEmitter();
    public pinList :Array<string>;

    constructor(private el: ElementRef) {}

    ngOnInit() { 
        this.pinList = ['','','',''];
    }

    changeFocus(id: number) {
        console.log(id);
        let elem = this.el.nativeElement;
        let nextElem = $(elem).find('ul li input:password')[id];
        if (id < 5) {
            $(nextElem).focus();
        }
    }

    backSpace(id: number) {
        let column = id - 1;
        let el = this.el.nativeElement;
        let currElement = $(el).find('ul li input:password')[column];
        let previousElement = $(el).find('ul li input:password')[column - 1];
        let currVal = $(currElement).val();
        if (currVal == '' && column > 0) {
            this.pinList[column - 1] = '';
            $(previousElement).focus();
        }
    }

    resetPinForm(){
        this.pinList = ['','','',''];
        var validator = (<any>$("#pinForm")).validate();
        validator.resetForm();
        this.changeFocus(0);    
    }

    back() {
        this.backEvent.emit();
    }

}



@Directive({
    selector: '[pinkeypress]',
})
export class PinKeypress {
    @Input() pinkeypress: number;
    

    constructor(private el: ElementRef, @Host() private pinComponent: PinFourDigitComponent) {}

    @HostListener('keydown', ['$event'])
    onKeyDown(event: KeyboardEvent) {
        let e = < KeyboardEvent > event;
        if (e.which == 8) {
            this.pinComponent.backSpace(this.pinkeypress);
        }
    }

    @HostListener('keyup', ['$event'])
    onKeyUp(event: any) {
        var el = $(this.el.nativeElement);

        let pinFormSubmit: boolean;
        let pinFormValidation = ( < any > $("#pinForm")).validate({
            highlight: function(element: any) {
                var field = $(element);
                field.addClass("field-error");
            },
            unhighlight: function(element: any, errorClass: any) {
                var field = $(element);
                field.removeClass("field-error");
            },
            errorPlacement: function(error: any, element: any) {
                console.log(error);
                if (element.is("input")) {
                    $('.custom-error-msg').append(error);
                }
            },
            rules: {
                pinBox1: {
                    required: true
                },
                pinBox2: {
                    required: true
                },
                pinBox3: {
                    required: true
                },
                pinBox4: {
                    required: true
                }
            },
            groups: {
                PinBoxError: "pinBox1 pinBox2 pinBox3 pinBox4"
            },
            messages: {
                pinBox1: {
                    required: "Please enter the Pin"
                },
                pinBox2: {
                    required: "Please enter the Pin"
                },
                pinBox3: {
                    required: "Please enter the Pin"
                },
                pinBox4: {
                    required: "Please enter the Pin"
                }
            }
        });
        pinFormSubmit = pinFormValidation.form();
        if (el.val() != '') {
            this.pinComponent.changeFocus(this.pinkeypress);
        }
        if (pinFormSubmit) {
            this.pinComponent.validatePinEvent.emit(this.pinComponent.pinList.join(''));
        }

        this.pinComponent.changeFocus(this.pinkeypress);
    }
}

@Directive({
    selector: '[reset-pin]',
})
export class ResetPIN {
    
    constructor(private el: ElementRef, 
                @Host() private pin: PinFourDigitComponent, 
                public zone: NgZone) {}
    
    ngAfterViewInit() {
    }

    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        this.pin.resetPinForm();
    }
}