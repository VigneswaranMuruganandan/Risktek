import { Component, OnInit } from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { Router, Routes, RouterModule }  from '@angular/router';
import { SharedService} from '../services/shared.service';
declare var google: any;

@Component({
  selector: 'googlemap-component',
  templateUrl: './../templates/googleMap.html'
})
export class GoogleMapComponent implements OnInit{
    coordinates : any;
    map :any;
    markers = [];
    currentTab :string;
    stubs :boolean;

    constructor( private router:Router, 
                 private translate: TranslateService,
                 private sharedService: SharedService) {}

    ngOnInit() {
      this.stubs = false;
      if(!this.stubs)
      this.fetchCoordinates();
    }

    fetchCoordinates(){
        this.sharedService.fetchATMBranch()
            .subscribe(
                resp => this.generateGoogleMap(resp),
                error => this.sharedService.handleError(error)
            );
    }

    generateGoogleMap(data: any){
        this.coordinates = data.atmBranchDetails;
        this.init_map();
    }

    init_map() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition((position) => {
                let lat = position.coords.latitude;
                let lng = position.coords.longitude;
                let myOptions = {
                    zoom: 16,
                    center: new google.maps.LatLng(lat, lng),
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                };
                this.map = new google.maps.Map(document.getElementById('gmap_canvas'), myOptions);
                this.allATMBranch();
            });
        }
    }

    allATMBranch(){
      this.currentTab = "ALL";
        this.deleteMarkers();
        for(var i=0;i<this.coordinates.length;i++){
            this.addMarker(this.coordinates[i]);
        }
    }

    onlyATM(){
        this.currentTab = "ATM";
        this.deleteMarkers();
        for(var j=0;j<this.coordinates.length;j++){
            if(this.coordinates[j].isAtm){
                this.addMarker(this.coordinates[j]);
            }
        }
    }

    onlyBranch(){
        this.currentTab = "BRANCH";
        this.deleteMarkers();
        for(var k=0;k<this.coordinates.length;k++){
            if(this.coordinates[k].isBranch){
                this.addMarker(this.coordinates[k]);
            }
        }
    }

    addMarker(location) {
        var marker = new google.maps.Marker({
          position: {lat: location.latitude, lng: location.longitude},
          map: this.map
        });
        var infowindow = new google.maps.InfoWindow({
            content: '<strong>'+location.branchName+'</strong><br><strong>Address:'+location.address+'</strong><br>'
        });
        google.maps.event.addListener(marker, 'click', function() {
            infowindow.open(this.map, marker);
        });
        this.markers.push(marker);
    }

    setMapOnAll(map) {
        for (var i = 0; i < this.markers.length; i++) {
          this.markers[i].setMap(map);
        }
    }

    clearMarkers() {
        this.setMapOnAll(null);
    }

    showMarkers() {
        this.setMapOnAll(this.map);
    }

    deleteMarkers() {
        this.clearMarkers();
        this.markers = [];
    }
}