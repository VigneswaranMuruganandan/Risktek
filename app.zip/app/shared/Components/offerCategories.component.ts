import { Component, OnInit, Input} from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { OffersService } from '../../offers/services/offers.service';
import { CategorieItems } from '../../offers/model/categorieItems';
import { Categories } from '../../offers/model/categories';
import { ErrorService } from '../services/error.service';
import { SharedService } from '../services/shared.service';
import { SpinnerService } from '../services/spinner.service';
import { GlobalVariable} from '../services/global';
import { AppSession} from '../model/appSession';
import { Router } from '@angular/router';
import * as $ from 'jquery';
import 'app/assets/js/slick.js';

@Component({
  selector: 'offer-categories',
  templateUrl: './../templates/offerCategories.html'
})
export class OfferCategoriesComponent implements OnInit {
	public categories: any[];
    public categoriesImages :any;
    @Input() type: number;

	constructor( private spinnerService: SpinnerService,
                 private errorService: ErrorService,
                 private sharedService: SharedService,
                 private router: Router) {}

	ngOnInit() {
		this.categories = new Array();
        this.fetchCategories();
        this.categoriesImages = GlobalVariable.OFFER_MERCHANTS;
    }

    ngAfterViewInit(){
        this.dashboardOffers();
    }
    /*
    * Custom Slick slider without using directive because 
    * it have 2 row property in configuration
    */
    dashboardOffers(){
        let property = GlobalVariable.SLIDER_PROPERTIES.dashboard_offers;
        setTimeout(()=> {
          (<any>$('#dashboard_offers')).slick(property);
        }, 1000);
    }
	/*
    * Fetch the Categories Service calls
    */
    fetchCategories(){
        this.sharedService.fetchCategories()
        .subscribe(
            resp => this.handleCategoriesResp(resp),
            error => this.sharedService.handleError(error)
        );
    }
    /*
    * Handle the Categories service calls
    */
    handleCategoriesResp(resp :Categories){
        if(resp.result.status == 'success'){
            this.categories = resp.items;
            this.categories.map(obj => {     
                obj['OfferSmallImage'] = 'app/assets/images/offers-category/'+this.categoriesImages[obj.Title.replace(/ /g, "_").toUpperCase()];
            });
            console.log(this.categories); 
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
    }
    /*
    * Handle the Selected Merchant and move to offers page
    */
    onSelectedMerchant(ItemID: string){
        let AppSess = AppSession.getInstance();
        AppSess.accountOfferMerchant = ItemID;
        this.router.navigate(['/offers']);
    }	
}