import { Component } from '@angular/core';
import { GlobalVariable} from '../../shared/services/global';
import {TranslateService} from '@ngx-translate/core';
import jsPDF from 'jspdf';

@Component({
  selector: 'download-pdf',
  template: `
  			<a href="javascript:void(0);" class="button border-only btn-md btn-blue" style="margin-right: 10px;" (click)="printPDF();">PRINT RECEIPT</a>
  			<a href="javascript:void(0);" class="button border-only btn-md btn-blue" (click)="downloadPDF();">SAVE AS PDF</a>
  			`
})
export class DownloadPDFComponent {
	public source :any;

	downloadPDF(){
		this.collectData();
		this.generatePDF();
 	}

 	printPDF(){
 		this.collectData();
 		this.generatePrint();
 	}	

 	collectData(){
		let parent_el = (<any>$('.printArea'));
 		this.source = '';
 		for(let el of parent_el){
	        let header = (<any>$(el)).find('.col-md-3 h3');
	        this.source = this.source + "<h3>"+header.text()+"<h3>";

	        let child_el = (<any>$(el)).find('.col-md-9 p');
	        if(child_el.length > 0){
		        this.source = this.source + "<table width='100%'><tbody>";
		        this.source = this.source + "<tr><td>Title</td><td>Description</td></tr>";
		        for(let cel of child_el){	        	
		        	this.source = this.source + "<tr>";
		        	let label = (<any>$(cel)).clone().children().remove().end();
		        	this.source = this.source + "<td>"+label.text().trim()+"</td>";
		        	let value = (<any>$(cel)).find('span');
		        	this.source = this.source + "<td>"+value.text().trim()+"</td>";
		        	this.source = this.source + "</tr>";
		        }
		        this.source = this.source + "</tbody></table>";
	    	}
	    }
	}

 	generatePDF(){
 		var pdf = new jsPDF('p', 'pt', 'letter');
		var source1 = this.source;
		var specialElementHandlers = {
		    '#bypassme': function(element, renderer) {
		        return true
		    }
		};
		var margins = {
		    top: 80,
		    bottom: 60,
		    left: 40,
		    width: 522
		};
		pdf.fromHTML(
		    source1,
		    margins.left,
		    margins.top, {
		        'width': margins.width,
		        'elementHandlers': specialElementHandlers
		    },
		    function(dispose) {
		        pdf.save(GlobalVariable.DOWNLOAD_FILE_NAME);
		    }, margins);
 	}

 	generatePrint(){
 		var printDoc = new jsPDF('p', 'pt', 'letter');
		var source1 = this.source;
		var specialElementHandlers = {
		    '#bypassme': function(element, renderer) {
		        return true
		    }
		};
		var margins = {
		    top: 80,
		    bottom: 60,
		    left: 40,
		    width: 522
		};
		printDoc.fromHTML(
		    source1,
		    margins.left,
		    margins.top, {
		        'width': margins.width,
		        'elementHandlers': specialElementHandlers
		    });
		printDoc.autoPrint();
        printDoc.output("dataurlnewwindow");
 	}


}