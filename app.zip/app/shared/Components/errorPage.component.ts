import { Component, OnInit, Input } from '@angular/core';
import { ServerError } from '../model/serverError';
import { Router } from '@angular/router';

@Component({
  selector: 'error-page',
  templateUrl: './../templates/errorPage.html'
})
export class ErrorPageComponent implements OnInit {
  @Input() serverError :ServerError;

  constructor(private router: Router) { }

  ngOnInit() {
  }

  routerNavigate(){
  	this.router.navigate([this.serverError.backButton.router]);
  }

}
