import {
    Component,
    Input,
    OnInit,
    ElementRef,
    ContentChild,
    Renderer,
    Directive,
    HostListener,
    Host,
    NgZone,
    Output,
    EventEmitter,
    OnDestroy
} from '@angular/core';
import * as $ from 'jquery';
import {Observable} from 'rxjs/Rx';
import { SharedService } from '../services/shared.service';
import { Subscription } from 'rxjs/Subscription';
import { SpinnerService } from '../services/spinner.service';
import { ErrorService } from '../services/error.service';
import { UserContext} from '../model/userContext';
import { UserDetails } from '../model/userDetails';
import { SendOtpRequest} from '../model/sendOtpRequest';
import { SendOtpResponse} from '../model/sendOtpResponse';

@Component({
    selector: 'otp-component',
    templateUrl: './../templates/otpForm.html'
})
export class OTPComponent implements OnInit {
    @Input() sendOtpRequest: SendOtpRequest;
    @Input() seconds: number; 
    @Output() validateOTPEvent = new EventEmitter();   
    @Output() backEvent = new EventEmitter();
    public subscription: Subscription;
    public subscriptionTimer: Subscription;
    public otpList :Array<string>;
    public timer: string;
    @Input() sendOtpResponse: SendOtpResponse;

    constructor( private el: ElementRef, 
                 public sharedService: SharedService,
                 public errorService :ErrorService) {}
    
    
    ngOnInit() { 
        this.init();
    }

    init(){
        this.otpList = ['','','','','',''];
        this.subscription = this.sharedService.$timer.subscribe(res => {
            this.timer = res;
        });
    }

    ngAfterViewInit() {
        this.startTimer(this.seconds);
        var el = this.el.nativeElement;
        var otpe1 = $(el).find('ul li input:text')[0];
        $(otpe1).focus();
    }

    changeFocus(id: number) {
        let el = this.el.nativeElement;
        let nextElement = $(el).find('ul li input:text')[id];
        if (id < 7)
          $(nextElement).focus();
    }

    backSpace(id: number){
        let column = id - 1;
        let el = this.el.nativeElement;
        let currElement = $(el).find('ul li input:text')[column];
        let previousElement = $(el).find('ul li input:text')[column-1];
        let currVal = $(currElement).val();
        if(currVal =='' && column > 0){
            this.otpList[column-1] = '';
            $(previousElement).focus();
        }
    }

    resetOTPForm(code: string){
        this.otpList = ['','','','','',''];
        var validator = (<any>$("#otpForm")).validate();
        validator.resetForm();
        this.changeFocus(0);
        if(code == 'VRFY_OTP_MAX_ATTEMPTS_EXCEEDED'){
            this.blockOTPComponent();
        }        
    }


    startTimer(duration) {
        let timer = duration;
        let minutes;
        let seconds;
        this.subscriptionTimer = Observable.timer(1000,1000)
                            .subscribe(()=>{
                                minutes = timer / 60;
                                seconds = timer % 60;
                                let dis_minutes = minutes < 10 ? "0" + parseInt(minutes) : minutes;
                                let dis_seconds = seconds < 10 ? "0" + parseInt(seconds) : seconds;
                                let otptimer =dis_minutes+":"+dis_seconds;
                                this.sharedService.updateTimer(otptimer);
                                if (--timer < 0) {
                                    timer = duration;
                                }
                                if(parseInt(minutes) == 0 && parseInt(seconds) == 0){
                                    this.resetTimer(0);
                                }
                            });
    }

    ngOnDestroy() {
        this.subscriptionTimer.unsubscribe();
        this.subscription.unsubscribe();
    }

    resetTimer(value : number) {
        this.subscriptionTimer.unsubscribe();
        this.seconds = value;
        this.startTimer(this.seconds);
    }

    blockOTPComponent(){
        this.resetTimer(0);
        $("ul.otp li input[type='text']").attr('disabled', 'disabled');
        $(".resendOTP").attr('disabled', 'disabled');
    }

    back(){
        this.backEvent.emit();
    }
}

@Directive({
    selector: '[otpkeypress]',
})
export class OTPKeypress {
    @Input() otpkeypress: number;
    
    constructor(private el: ElementRef, @Host() private otp: OTPComponent, private zone: NgZone) {}
    ngAfterViewInit() {}

    @HostListener('keydown', ['$event'])
    onKeyDown(event: KeyboardEvent) {
        let e = <KeyboardEvent> event;
        if(e.which == 8){
            this.otp.backSpace(this.otpkeypress);
        }
    }

    @HostListener('keyup', ['$event'])
    onKeyUp(event: KeyboardEvent) {
        let e = <KeyboardEvent> event;
        let el = $(this.el.nativeElement),
        otpFormSubmit;
        /*let otpFormValidation = ( < any > $("#otpForm")).validate({
            highlight: function(element: any) {
                var field = $(element);
                field.addClass("field-error");
            },
            unhighlight: function(element: any, errorClass: any) {
                var field = $(element);
                field.removeClass("field-error");
            },
            errorPlacement: function(error: any, element: any) {
                if (element.is("input")) {
                    $('.custom-error-msg').append(error);
                }
            },
            rules: {
                otpBox1: {
                    required: true
                },
                otpBox2: {
                    required: true
                },
                otpBox3: {
                    required: true
                },
                otpBox4: {
                    required: true
                },
                otpBox5: {
                    required: true
                },
                otpBox6: {
                    required: true
                }
            },
            groups: {
                OTPBoxError: "otpBox1 otpBox2 otpBox3 otpBox4 otpBox5 otpBox6"
            },
            messages: {
                otpBox1: {
                    required: "Please fill in"
                },
                otpBox2: {
                    required: "Please fill in"
                },
                otpBox3: {
                    required: "Please fill in"
                },
                otpBox4: {
                    required: "Please fill in"
                },
                otpBox5: {
                    required: "Please fill in"
                },
                otpBox6: {
                    required: "Please fill in"
                }
            }
        });
        otpFormSubmit = otpFormValidation.form();*/
        if (el.val() != '') {
            this.otp.changeFocus(this.otpkeypress);
        }
        //if (otpFormSubmit) {
            console.log("----------------------------------------------------------->"+this.otp.otpList);
            //this.otp.validateOTPEvent.emit(this.otp.otpList.join(''));
        //}
    }
}

@Directive({
    selector: '[resend-otp]',
})
export class ResendOTP {
    
    constructor(private el: ElementRef, 
                @Host() private otp: OTPComponent, 
                public zone: NgZone,
                public errorService: ErrorService,
                public spinnerService: SpinnerService,
                public sharedService: SharedService) {}
    
    ngAfterViewInit() {
    }

    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        this.spinnerService.startSpinner('loader');
        this.sharedService.resendOTP(this.otp.sendOtpRequest)
        .subscribe(
            resp => {
                this.spinnerService.stopSpinner('loader');
                if(resp.result.status == 'success'){
                    this.otp.resetTimer(300);
                    this.otp.resetOTPForm('');
                }else if(resp.result.status == 'error'){
                    this.otp.resetOTPForm('');
                    this.otp.resetTimer(0);
                    this.errorService.setErrorResp(resp.result);
                }
            },
            error => this.sharedService.handleError(error)
        );
    }
}

@Directive({
    selector: '[reset-otp]',
})
export class ResetOTP {
    
    constructor(private el: ElementRef, 
                @Host() private otp: OTPComponent, 
                public zone: NgZone,
                public errorService: ErrorService,
                public spinnerService: SpinnerService,
                public sharedService: SharedService) {}
    
    ngAfterViewInit() {
    }

    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        this.otp.resetOTPForm(this.errorService.getErrorCode());
    }
}