import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './auth-guard.service';


const routes: Routes = [
    {
        path: '',
        redirectTo: 'login',
        pathMatch: 'full'
    },
    {
        path: '',
        loadChildren: 'app/login/login.module#LoginModule',
    },
    {
        path: 'registration',
        loadChildren: 'app/register/register.module#RegisterModule'
    },
    {
        path: 'forgotPassword',
        loadChildren: 'app/forgotPassword/forgotPassword.module#ForgotPasswordModule'
    },
    {
        path: '',
        loadChildren: 'app/dashboard/dashboard.module#DashboardModule'
    }   
];

export const routing = RouterModule.forRoot(routes);
