import { Component, Input, OnInit, AfterViewInit,  ViewChild, ElementRef  } from '@angular/core';
import { DashboardService} from '../../dashboard/services/dashboard.service';
import { DashBoardDetails } from '../../dashboard/model/dashBoardDetails';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    TranslateService,
    ServerError,
    Product,
    GlobalVariable,
    AppSession,
    UserDetails,
    CustomerProducts,
    Loan,
    Account,
    Card
} from '../../shared';
import Chart from 'chart.js';

@Component({
  templateUrl: './../templates/myFABProducts.html'
})
export class MyFABProductsComponent implements OnInit {
	@ViewChild("accountCanvas") accountCanvas: ElementRef;
	@ViewChild("cardCanvas") cardCanvas: ElementRef;
	@ViewChild("loanCanvas") loanCanvas: ElementRef;
	@ViewChild("despoitCanvas") despoitCanvas: ElementRef;
	public dashBoardDetails: DashBoardDetails;
	public accounts :Account[];
	public totalAccountBalance :number;
    public cards :Card[];
    public totalCardBalance :number;
    public deposits :Account[];
    public totalDepositBalance :number;
    public loans :Loan[];
    public totalLoanBalance :number;
    public color :string[] = GlobalVariable.LOANS_COLOR;
    public view_mode :string;
    public url :string;
    public loansColor :string[] = GlobalVariable.LOANS_COLOR;
    public chartValues :any;

	constructor( private dashboardService: DashboardService,
                 private spinnerService: SpinnerService, 
                 private errorService: ErrorService,
                 private sharedService: SharedService,
                 public templateService: TemplateService,
                 private router: Router) {}

	ngOnInit() {
		this.view_mode = 'LIST';
        this.initDashboardDetails();
        this.chartValues = {'ACCOUNT':{'labels':[],'data':[] },'CARD':{ 'labels':[], 'data':[] },'LOAN':{ 'labels':[], 'data':[] },'DEPOSIT':{ 'labels':[], 'data':[] }}
    }

    initDashboardDetails(){
        this.spinnerService.startSpinner('dashboardFav');
        this.dashboardService.fetchDashBoardResults()
            .subscribe(
                resp => this.handleDashboardInitResp(resp),
                error => this.sharedService.handleError(error)
            );        
    }
    /*
    * Handling Dashboard Response
    */
    handleDashboardInitResp(resp: any){
        this.spinnerService.stopSpinner('dashboardFav');
        if(resp && resp.result.status == "success"){
            this.dashBoardDetails = new DashBoardDetails();
            this.dashBoardDetails = resp;
            this.generateCustomerProducts(this.dashBoardDetails.customerProducts);
        }
    }

    generateCustomerProducts(data :CustomerProducts){
        this.accounts = [];
        this.loans = [];
        this.cards =[];
        this.deposits = [];
        if(data){
            if(data.accounts){
                this.accounts = data.accounts;
                this.totalAccountBalance = 0;
                for(let acc of this.accounts){
                	this.totalAccountBalance = this.totalAccountBalance + acc.balance.value;
                }
            }
            if(data.loans){
                this.loans = data.loans;
                this.totalLoanBalance = 0;
                for(let loan of this.loans){
                	this.totalLoanBalance = this.totalLoanBalance + loan.availableBal.value;
                }
            }
            if(data.cards){
                this.cards = data.cards;
                this.totalCardBalance = 0;
                this.cards.map(obj => {                                    
                   obj['availableBalancePercentage'] = this.templateService.calAvailBalPercentage(obj.availableBalance.value,obj.cardLimit.value);
                   this.totalCardBalance = this.totalCardBalance + obj.availableBalance.value;
                });
            }
            if(data.deposits){
                this.deposits = data.deposits;
                for(let deposit of this.deposits){
                	this.totalDepositBalance = this.totalDepositBalance + deposit.balance.value;
                }
            }
        }
        this.mapCalculation();
    }

    applyForProducts(type :string){
		if(type){
			switch (type) {
			    case 'ACCOUNT':
			        this.url = GlobalVariable.ROUTE_MAPPING.APPLYFORPRODUCTSACCOUNT;
			        break;
			    case 'CARD':
			        this.url = GlobalVariable.ROUTE_MAPPING.APPLYFORPRODUCTSCARD;
			        break;
			    case 'DEPOSIT':
			        this.url = GlobalVariable.ROUTE_MAPPING.APPLYFORPRODUCTSDESPOSIT;
			        break;
			    case 'LOAN':
			        this.url = GlobalVariable.ROUTE_MAPPING.APPLYFORPRODUCTSLOAN;
			        break;
			}
			this.router.navigate([this.url]);
		}
	}

	updateViewMode(view :string){
		if(view)
		this.view_mode = view;
	}

	listViewCalculatePercentage(){

	}

	mapCalculation(){
		for(let accData of this.accounts){
			this.chartValues.ACCOUNT.labels.push(accData.number);
            let data = Math.round((accData.balance.value/this.totalAccountBalance)*100);
            this.chartValues.ACCOUNT.data.push(data);
		}
		this.generateAccountChart();
		for(let cardData of this.cards){
			this.chartValues.CARD.labels.push(cardData.cardNumber);
            let data = Math.round((cardData.availableBalance.value/this.totalCardBalance)*100);
            this.chartValues.CARD.data.push(data);
		}
		this.generateCardChart();
		for(let loanData of this.loans){
			this.chartValues.LOAN.labels.push(loanData.loanNumber);
            let data = Math.round((loanData.availableBal.value/this.totalLoanBalance)*100);
            this.chartValues.LOAN.data.push(data);
		}
		this.generateLoanChart()
		for(let depositData of this.deposits){
			this.chartValues.DEPOSIT.labels.push(depositData.number);
            let data = Math.round((depositData.balance.value/this.totalDepositBalance)*100);
            this.chartValues.DEPOSIT.data.push(data);
		}
		this.generateDepositChart()
	}


	generateAccountChart(){
		let acc_ctx = this.accountCanvas.nativeElement.getContext('2d');
		let acc_chart : CanvasRenderingContext2D = new Chart(acc_ctx, {
	        type: 'doughnut',
	        data: {
	            labels: this.chartValues.ACCOUNT.labels,
	            datasets: [{
	                backgroundColor: this.loansColor,
	                borderColor: 'white',
	                data: this.chartValues.ACCOUNT.data
	            }]
	        },
	        options: {
	            maintainAspectRatio: false,
	            legend: {
	                display: false,
	                position: 'bottom',
	                labels: {
	                    fontColor: 'rgb(255, 99, 132)'
	                }
	            },
	            cutoutPercentage: 90
	        }
	    });
	}
	generateCardChart(){
		let card_ctx = this.cardCanvas.nativeElement.getContext('2d');
		let card_chart : CanvasRenderingContext2D = new Chart(card_ctx, {
	        type: 'doughnut',
	        data: {
	            labels: this.chartValues.CARD.labels,
	            datasets: [{
	                backgroundColor: this.loansColor,
	                borderColor: 'white',
	                data: this.chartValues.CARD.data
	            }]
	        },
	        options: {
	            maintainAspectRatio: false,
	            legend: {
	                display: false,
	                position: 'bottom',
	                labels: {
	                    fontColor: 'rgb(255, 99, 132)'
	                }
	            },
	            cutoutPercentage: 90
	        }
	    });
	}
	generateLoanChart(){
		let loan_ctx = this.loanCanvas.nativeElement.getContext('2d');
		let loan_chart : CanvasRenderingContext2D = new Chart(loan_ctx, {
	        type: 'doughnut',
	        data: {
	            labels: this.chartValues.LOAN.labels,
	            datasets: [{
	                backgroundColor: this.loansColor,
	                borderColor: 'white',
	                data: this.chartValues.LOAN.data
	            }]
	        },
	        options: {
	            maintainAspectRatio: false,
	            legend: {
	                display: false,
	                position: 'bottom',
	                labels: {
	                    fontColor: 'rgb(255, 99, 132)'
	                }
	            },
	            cutoutPercentage: 90
	        }
	    });
	}
	generateDepositChart(){
		let deposit_ctx = this.despoitCanvas.nativeElement.getContext('2d');
		let deposit_chart : CanvasRenderingContext2D = new Chart(deposit_ctx, {
	        type: 'doughnut',
	        data: {
	            labels: this.chartValues.ACCOUNT.labels,
	            datasets: [{
	                backgroundColor: this.loansColor,
	                borderColor: 'white',
	                data: this.chartValues.ACCOUNT.data
	            }]
	        },
	        options: {
	            maintainAspectRatio: false,
	            legend: {
	                display: false,
	                position: 'bottom',
	                labels: {
	                    fontColor: 'rgb(255, 99, 132)'
	                }
	            },
	            cutoutPercentage: 90
	        }
	    });
	}
}