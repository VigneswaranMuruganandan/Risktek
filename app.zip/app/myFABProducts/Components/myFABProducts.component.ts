import { Component, Input, OnInit, AfterViewInit, ViewChild  } from '@angular/core';
import { DashboardService} from '../../dashboard/services/dashboard.service';
import { DashBoardDetails } from '../../dashboard/model/dashBoardDetails';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    TranslateService,
    ServerError,
    Product,
    GlobalVariable,
    AppSession,
    UserDetails,
    CustomerProducts,
    Loan,
    Account,
    Card
} from '../../shared';

@Component({
  templateUrl: './../templates/myFABProducts.html'
})
export class MyFABProductsComponent implements OnInit {
	public dashBoardDetails: DashBoardDetails;
	public accounts :Account[];
	public totalAccountBalance :number;
    public cards :Card[];
    public totalCardBalance :number;
    public deposits :Account[];
    public loans :Loan[];
    public totalLoanBalance :number;
    public color :string[] = GlobalVariable.LOANS_COLOR;

	constructor( private dashboardService: DashboardService,
                 private spinnerService: SpinnerService, 
                 private errorService: ErrorService,
                 private sharedService: SharedService,
                 public templateService: TemplateService,
                 private router: Router) {}

	ngOnInit() {
        this.initDashboardDetails();
    }

    initDashboardDetails(){
        this.spinnerService.startSpinner('dashboardFav');
        this.dashboardService.fetchDashBoardResults()
            .subscribe(
                resp => this.handleDashboardInitResp(resp),
                error => this.sharedService.handleError(error)
            );        
    }
    /*
    * Handling Dashboard Response
    */
    handleDashboardInitResp(resp: any){
        this.spinnerService.stopSpinner('dashboardFav');
        if(resp && resp.result.status == "success"){
            this.dashBoardDetails = new DashBoardDetails();
            this.dashBoardDetails = resp;
            this.generateCustomerProducts(this.dashBoardDetails.customerProducts);
        }
    }

    generateCustomerProducts(data :CustomerProducts){
        this.accounts = [];
        this.loans = [];
        this.cards =[];
        this.deposits = [];
        if(data){
            if(data.accounts){
                this.accounts = data.accounts;
                this.totalAccountBalance = 0;
                for(let acc of this.accounts){
                	this.totalAccountBalance = this.totalAccountBalance + acc.balance.value;
                }
            }
            if(data.loans){
                this.loans = data.loans;
            }
            if(data.cards){
                this.cards = data.cards;
                this.cards.map(obj => {                                    
                   obj['availableBalancePercentage'] = this.templateService.calAvailBalPercentage(obj.availableBalance.value,obj.cardLimit.value);
                });
            }
            if(data.deposits){
                this.deposits = data.deposits;
            }
        }
    }
}