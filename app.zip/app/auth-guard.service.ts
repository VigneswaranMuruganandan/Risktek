import { Injectable }     from '@angular/core';
import { Router, CanActivate, CanActivateChild }    from '@angular/router';
import { SessionContext} from './shared/model/sessionContext';

@Injectable()
export class AuthGuard implements CanActivate {
	
	constructor(private router: Router) {}


  	canActivate() {
  		/*let sessCtx = SessionContext.getInstance();
  		if(sessCtx.authKey && sessCtx.authKey.sessionType == 'IB_LOGIN'){
		    return true;
  		}
  		else if(sessCtx.authKey && sessCtx.authKey.sessionType == 'IB_ANON'){
  			this.router.navigate(['/login']);
  			return false;
  		}else{
        this.router.navigate(['/login']);
        return false;
      }*/
      return true;
  	}

  	canActivateChild() {
	    console.log('checking child route access');
	    return true;
	}
}