import { Component, OnInit, Input} from '@angular/core';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    AppSession,
    TranslateService,
    UserDetails,
    UserContext
} from '../../shared';
import { InvestmentsService } from '../services/investments.service';
import { PendingOrderResponse } from '../model/pendingOrderResponse';
import { OrderDetails } from '../model/orderDetails';
import { WealthEnquiryRequest } from '../model/wealthEnquiryRequest';
import {RelationshipManager} from '../model/relationshipManager';

@Component({
	templateUrl: './../templates/pendingOrderStatus.html'
})
export class PendingOrderStatusComponent implements OnInit {
	public rows :any;
	public columns :any;
	public columnsKey :any;
	public orderDetails :OrderDetails[];
	public wealthEnquiryRequest :WealthEnquiryRequest;
	public relationshipManager: RelationshipManager;

	constructor( private templateService: TemplateService,
				 private investmentsService: InvestmentsService, 
    			 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService) {}

	ngOnInit(){
		this.errorService.resetErrorResp();
		this.columnsKey = {	"orderDate": "Order Date", "orderNumber": "Order Number", "orderType": "Order Status", "securityName": "Security Name", "ccy": "Currency", "quantity": "Quantity", "amount": "Amount" };
		this.initRMDetails();
		this.initPendingOrder();
	}

	initRMDetails(){
		if(AppSession.getInstance().isRelationshipManager){
        	this.relationshipManager = new RelationshipManager();
        	this.relationshipManager = AppSession.getInstance().relationshipManager
        }
	}
	
	initPendingOrder(){
		this.spinnerService.startSpinner('PendingOrderStatus');
		this.wealthEnquiryRequest = new WealthEnquiryRequest();
		this.wealthEnquiryRequest.asOnDate = this.templateService.getTodaydate('YYYYMMDD');
		this.investmentsService.fetchPendingOrder(this.wealthEnquiryRequest)
            .subscribe(
                resp => this.handlePendingOrder(resp),
                error => this.sharedService.handleError(error)
            );
	}

	handlePendingOrder(resp :PendingOrderResponse){		
		if(resp.result.status == 'success'){
            this.orderDetails = resp.orderDetails;
            this.generateRows();
            this.generateColumns();
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);			
        }
        this.spinnerService.stopSpinner('PendingOrderStatus');
	}

	generateRows(){
		this.rows = [];
		Object.getOwnPropertyNames(this.columnsKey)
		.map((key: string) => {
			let obj = {};
			obj['label'] = this.columnsKey[key];
			for(let i in this.orderDetails){
				if(key == 'amount')
				obj['value'+i] = this.orderDetails[i][key].valueFmt;
				else
				obj['value'+i] = this.orderDetails[i][key];
			}
			this.rows.push(obj);
		});
	}

	generateColumns(){
		this.columns = [];
		this.columns.push({name: 'label',frozenLeft: true});
		for(let i in this.orderDetails){
			this.columns.push({name: 'value'+i});
		}
	}
}