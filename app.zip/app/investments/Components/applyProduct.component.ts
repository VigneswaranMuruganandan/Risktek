import { Component, OnInit, Input} from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { SharedService } from '../../shared/services/shared.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { ErrorService } from '../../shared/services/error.service';
import { UserDetails } from '../../shared/model/userDetails';
import { UserContext} from '../../shared/model/userContext';
import { InvestmentsService } from '../services/investments.service';
import { StaticDataResponse } from '../../shared/model/staticDataResponse';
import { StaticData } from '../../shared/model/StaticData';
import { Entity } from '../../shared/model/entity';
import { LeadRequest } from '../model/leadRequest';
import { LeadResponse } from '../model/leadResponse';



@Component({
	templateUrl: './../templates/applyProduct.html'
})
export class ApplyProductComponent implements OnInit {

	constructor( private investmentsService: InvestmentsService, 
    			 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService) {}

	stepFlag:number;
	products :StaticData[];
	emirates:StaticData[];
	leadRequest= new LeadRequest();
	userDetails:UserDetails;
	leadResponse = new LeadResponse();

	ngOnInit(){
		this.stepFlag=1;
		this.initApply();
		this.userDetails = UserContext.getInstance().userDetails;
		this.leadRequest.email = this.userDetails.email;
		this.leadRequest.name = this.userDetails.name;
		this.leadRequest.phoneNumber = this.userDetails.contactNumber;
	}

	/*
    * Fetch the Wealth Products
    */
	initApply(){
		this.spinnerService.startSpinner('loader');
		let data = new Entity();
		data.entityName = "ALL"
		this.sharedService.fetchStaticData(data)
				.subscribe(
					resp => this.handleStaticDataResponse(resp),
					error => this.sharedService.handleError(error)
				);
	}

	/*
    * Handle Wealth Products Response
    */
	handleStaticDataResponse(resp:StaticDataResponse){
		this.spinnerService.stopSpinner('loader');
		if(resp && resp.result.status == 'success'){
            this.products = resp.staticMasterDataMap["WEALTH_PRODUCTS"]; 
            this.emirates = resp.staticMasterDataMap["EMIRATES"];
        }else if(resp && resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);

        }

	}

	/*
    * Navigate to Step2 after selection of Products
    */
	applyProductSelectionSubmit(){
		this.stepFlag=2;
	}

	/*
    * Submit the Wealth lead
    */
	applyProductsNowSubmit(){
		if(!(this.leadRequest.products.length>0)){
			this.stepFlag=1
		}else{
			this.spinnerService.startSpinner('loader');
			this.sharedService.saveLead(this.leadRequest)
					.subscribe(
						resp => this.handleApplyNowWealthResponse(resp),
						error => this.sharedService.handleError(error)
					);
		}
		
	}

	/*
    * Handle the Lead Response
    */
	handleApplyNowWealthResponse(resp:LeadResponse){
	
		this.stepFlag=3;
		this.spinnerService.stopSpinner('loader');
		if(resp && resp.result.status == 'success'){
           	console.log("applynow "+ resp)
           	this.leadResponse= resp;
        }else if(resp && resp.result.status == 'error'){
            //this.errorService.setErrorResp(resp.result);
            console.log("applynow error"+ resp)
            this.leadResponse= resp;
        }
	}
}