import { Component, OnInit, Input} from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { SharedService } from '../../shared/services/shared.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { ErrorService } from '../../shared/services/error.service';
import { InvestmentsService } from '../services/investments.service';
import { StaticDataResponse } from '../../shared/model/staticDataResponse';
import { StaticData } from '../../shared/model/staticData';
import { Entity } from '../../shared/model/entity';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';


@Component({
  templateUrl: './../templates/investmentsMain.html'
})
export class InvestmentsMainComponent implements OnInit {
	public stepNumber: number;
	ourProducts :StaticData[];

	constructor( private investmentsService: InvestmentsService, 
    			 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService) {}
						
	ngOnInit(){
		this.stepNumber = 1;
		this.viewProducts();
	}

	viewProducts(){
		let data = new Entity();
		data.entityName = 'WEALTH_PRODUCTS';
		this.investmentsService.fetchProducts(data)
	            .subscribe(
	                resp => this.handleViewProductsDataResp(resp),
	                error => this.sharedService.handleError(error)
	            );
	}
	handleViewProductsDataResp(resp:StaticDataResponse){
		console.log("handleViewProductsDataResp:::"+ resp);
		if(resp && resp.result.status == 'success'){
            this.ourProducts = resp.staticMasterDataMap['WEALTH_PRODUCTS']; 
            console.log(this.ourProducts);
        }else if(resp && resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
	}

	validateNextToAboutUs(){
		this.stepNumber = 2;
	}

	validateOurProducts(){
		this.stepNumber = 3;
	}

	validateNextToInvestmentsDetails(){
		this.stepNumber = 1;
	}

	validateNextToInvestmentMain(){
		this.stepNumber = 1;
	}
}