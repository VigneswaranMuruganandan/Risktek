import { Component, OnInit, Input,EventEmitter,Output} from '@angular/core';
import {TemplateService} from '../../shared/services/template.service';
import * as $ from 'jquery';
import { StaticData } from '../../shared/model/StaticData';
import { LeadRequest } from '../model/leadRequest';

@Component({
  selector: 'applyproductstep1-component',
  templateUrl: './../templates/applyProductStep1.html'
})
export class ApplyProductStep1Component {

	constructor(public templateService: TemplateService) {}
	@Output() applyProductNextEvent = new EventEmitter();
	@Input() leadRequest:LeadRequest;
	@Input() products:StaticData[];
	productSelected =new Array<string>();	
	
	/*
    * Capture Products on selection and uncheck
    */
	onChange(value:string,checked:boolean){
		console.log(this.products);
	    if(checked){
	      this.productSelected.push(value)
	      this.leadRequest.products =this.productSelected;
	    }else{
	      this.leadRequest.products = this.productSelected.filter(product => product!=value);
	      this.productSelected = this.leadRequest.products;
	    }
  	}

  	/*
    * Upon Selection ,Navigate to Step 2
    */
	applyProductNext(valid:boolean){
		console.log(this.products)
		if(valid){
			this.applyProductNextEvent.emit();
			this.templateService.resetFormValidatorFlag();
		}
	}
}