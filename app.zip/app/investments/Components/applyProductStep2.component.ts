import { Component, OnInit, Input,Output,EventEmitter} from '@angular/core';
import { StaticData } from '../../shared/model/StaticData';
import { LeadRequest } from '../model/leadRequest';
import {TemplateService} from '../../shared/services/template.service';


@Component({
  selector: 'applyproductstep2-component',
  templateUrl: './../templates/applyProductStep2.html'
})
export class ApplyProductStep2Component implements OnInit{
	@Output() applyProductsNowEvent = new EventEmitter();
	@Output() applyProductBackEvent = new EventEmitter();
	@Input() leadRequest:LeadRequest;
	@Input() emirates:StaticData[];
	@Input() productSelected :any[];

	constructor(public templateService: TemplateService) {}
	
	
	
	ngOnInit(){
		
	}

	/*
    * Step 2: Can remove the selected Products
    */
	removeSelectedProducts(value:string, checked :boolean){
		this.leadRequest.products = [];
		this.productSelected.filter((product,index) => {
	    	if(product.description == value){
	    		this.productSelected[index].status = checked;
	    	}
	    	if(product.status){
	    		this.leadRequest.products.push(product.description);
	    	}
	    });
		if(!(this.leadRequest.products.length>0)){
			this.applyProductsNow(true);
		}
	}
	/*
    * Step 2: On submission of lead
    */
	applyProductsNow(valid:boolean){
		if(valid){			
			this.templateService.resetFormValidatorFlag();
			this.applyProductsNowEvent.emit();
		}
	}
	back(){
		this.applyProductBackEvent.emit(1);
	}
}