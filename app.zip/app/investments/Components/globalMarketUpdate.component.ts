import { Component, OnInit, Input} from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { SharedService } from '../../shared/services/shared.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { ErrorService } from '../../shared/services/error.service';
import { InvestmentsService } from '../services/investments.service';

@Component({
	templateUrl: './../templates/globalMarketUpdate.html'
})
export class GlobalMarketUpdateComponent implements OnInit {
	public globalmarket :any;
	public asOnDate :string;
	constructor( private investmentsService: InvestmentsService, 
    			 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService) {}

	ngOnInit(){
		this.errorService.resetErrorResp();
		this.asOnDate = '22/06/2014'
		this.globalmarket = [{
				"title": "Foreign Exchange",
				"description": "The dollar fell the most in 10 weeks against the euro after the Federal Reserve said it will keep interest rates at almost zero for a “considerable time” and cut interest rates for the first time since March 2012. The Canadian dollar rallied as inflation rose above the central bank’s target. Global currencies volatility sank to record low. The pound advanced to the strongest level in 5 ½ years against the dollar this week as bets the bank of England is moving closer to increasing its benchmark interest rate fueled demand for the U.K. currency. India’s rupee completed a fourth weekly decline, the longest losing streak since April, on concern a jump in international oil process will widen the nation’s trade deficit and add to inflation."
			},
			{
				"title": "Rates",
				"description": "The dollar fell the most in 10 weeks against the euro after the Federal Reserve said it will keep interest rates at almost zero for a “considerable time” and cut interest rates for the first time since March 2012. The Canadian dollar rallied as inflation rose above the central bank’s target. Global currencies volatility sank to record low. The pound advanced to the strongest level in 5 ½ years against the dollar this week as bets the bank of England is moving closer to increasing its benchmark interest rate fueled demand for the U.K. currency. India’s rupee completed a fourth weekly decline, the longest losing streak since April, on concern a jump in international oil process will widen the nation’s trade deficit and add to inflation."
			},
			{
				"title": "Commodities",
				"description": "The dollar fell the most in 10 weeks against the euro after the Federal Reserve said it will keep interest rates at almost zero for a “considerable time” and cut interest rates for the first time since March 2012. The Canadian dollar rallied as inflation rose above the central bank’s target. Global currencies volatility sank to record low. The pound advanced to the strongest level in 5 ½ years against the dollar this week as bets the bank of England is moving closer to increasing its benchmark interest rate fueled demand for the U.K. currency. India’s rupee completed a fourth weekly decline, the longest losing streak since April, on concern a jump in international oil process will widen the nation’s trade deficit and add to inflation."
			},
			{
				"title": "Stocks",
				"description": "The dollar fell the most in 10 weeks against the euro after the Federal Reserve said it will keep interest rates at almost zero for a “considerable time” and cut interest rates for the first time since March 2012. The Canadian dollar rallied as inflation rose above the central bank’s target. Global currencies volatility sank to record low. The pound advanced to the strongest level in 5 ½ years against the dollar this week as bets the bank of England is moving closer to increasing its benchmark interest rate fueled demand for the U.K. currency. India’s rupee completed a fourth weekly decline, the longest losing streak since April, on concern a jump in international oil process will widen the nation’s trade deficit and add to inflation."
			},
			{
				"title": "GCC News",
				"description": "The dollar fell the most in 10 weeks against the euro after the Federal Reserve said it will keep interest rates at almost zero for a “considerable time” and cut interest rates for the first time since March 2012. The Canadian dollar rallied as inflation rose above the central bank’s target. Global currencies volatility sank to record low. The pound advanced to the strongest level in 5 ½ years against the dollar this week as bets the bank of England is moving closer to increasing its benchmark interest rate fueled demand for the U.K. currency. India’s rupee completed a fourth weekly decline, the longest losing streak since April, on concern a jump in international oil process will widen the nation’s trade deficit and add to inflation."
			}];
	}
}