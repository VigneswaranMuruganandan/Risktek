import { Component, OnInit, Input} from '@angular/core';
import { LeadResponse } from '../model/leadResponse';


@Component({
  selector: 'applyproductstep3-component',
  templateUrl: './../templates/applyProductStep3.html'
})
export class ApplyProductStep3Component {
@Input() leadResponse:LeadResponse;
}