import { Component, OnInit, Input, ViewChild} from '@angular/core';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    AppSession,
    TranslateService
} from '../../shared'; 


@Component({
    templateUrl: './../templates/mutualFunds.html'
})
export class MutualFundsComponent implements OnInit {
    public rows:any;
    public temp:any;
    public columns:any;
    @ViewChild('table') tableElem: any;

    constructor( private sharedService: SharedService,
                 private templateService: TemplateService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService) {}


    ngOnInit(){
        this.rows = [{"fundName":"Bond Fund - Growth Plan 1","numberOfUnits":32943,"currentValue":{"value":158945943,"valueFmt":"158945,943","currency":"AED"},"totalInvestment":{"value":158945943,"valueFmt":"158945,943","currency":"AED"},"lastSubscriptionDate":"16-JUL-2017"},{"fundName":"Bond Fund - Growth Plan 2","numberOfUnits":32943,"currentValue":{"value":158945943,"valueFmt":"158945,943","currency":"AED"},"totalInvestment":{"value":158945943,"valueFmt":"158945,943","currency":"AED"},"lastSubscriptionDate":"16-JUL-2017"},{"fundName":"Bond Fund - Growth Plan 3","numberOfUnits":32943,"currentValue":{"value":158945943,"valueFmt":"158945,943","currency":"AED"},"totalInvestment":{"value":158945943,"valueFmt":"158945,943","currency":"AED"},"lastSubscriptionDate":"16-JUL-2017"},{"fundName":"Bond Fund - Growth Plan 4","numberOfUnits":32943,"currentValue":{"value":158945943,"valueFmt":"158945,943","currency":"AED"},"totalInvestment":{"value":158945943,"valueFmt":"158945,943","currency":"AED"},"lastSubscriptionDate":"16-JUL-2017"},{"fundName":"Bond Fund - Growth Plan 5","numberOfUnits":32943,"currentValue":{"value":158945943,"valueFmt":"158945,943","currency":"AED"},"totalInvestment":{"value":158945943,"valueFmt":"158945,943","currency":"AED"},"lastSubscriptionDate":"16-JUL-2017"},{"fundName":"Bond Fund - Growth Plan 6","numberOfUnits":32943,"currentValue":{"value":158945943,"valueFmt":"158945,943","currency":"AED"},"totalInvestment":{"value":158945943,"valueFmt":"158945,943","currency":"AED"},"lastSubscriptionDate":"16-JUL-2017"},{"fundName":"Bond Fund - Growth Plan 7","numberOfUnits":32943,"currentValue":{"value":158945943,"valueFmt":"158945,943","currency":"AED"},"totalInvestment":{"value":158945943,"valueFmt":"158945,943","currency":"AED"},"lastSubscriptionDate":"16-JUL-2017"},{"fundName":"Bond Fund - Growth Plan 8","numberOfUnits":32943,"currentValue":{"value":158945943,"valueFmt":"158945,943","currency":"AED"},"totalInvestment":{"value":158945943,"valueFmt":"158945,943","currency":"AED"},"lastSubscriptionDate":"16-JUL-2017"},{"fundName":"Bond Fund - Growth Plan 9","numberOfUnits":32943,"currentValue":{"value":158945943,"valueFmt":"158945,943","currency":"AED"},"totalInvestment":{"value":158945943,"valueFmt":"158945,943","currency":"AED"},"lastSubscriptionDate":"16-JUL-2017"},{"fundName":"Bond Fund - Growth Plan 10","numberOfUnits":32943,"currentValue":{"value":158945943,"valueFmt":"158945,943","currency":"AED"},"totalInvestment":{"value":158945943,"valueFmt":"158945,943","currency":"AED"},"lastSubscriptionDate":"16-JUL-2017"},{"fundName":"Bond Fund - Growth Plan 11","numberOfUnits":32943,"currentValue":{"value":158945943,"valueFmt":"158945,943","currency":"AED"},"totalInvestment":{"value":158945943,"valueFmt":"158945,943","currency":"AED"},"lastSubscriptionDate":"16-JUL-2017"},{"fundName":"Bond Fund - Growth Plan 12","numberOfUnits":32943,"currentValue":{"value":158945943,"valueFmt":"158945,943","currency":"AED"},"totalInvestment":{"value":158945943,"valueFmt":"158945,943","currency":"AED"},"lastSubscriptionDate":"16-JUL-2017"},{"fundName":"Bond Fund - Growth Plan 13","numberOfUnits":32943,"currentValue":{"value":158945943,"valueFmt":"158945,943","currency":"AED"},"totalInvestment":{"value":158945943,"valueFmt":"158945,943","currency":"AED"},"lastSubscriptionDate":"16-JUL-2017"},{"fundName":"Bond Fund - Growth Plan 14","numberOfUnits":32943,"currentValue":{"value":158945943,"valueFmt":"158945,943","currency":"AED"},"totalInvestment":{"value":158945943,"valueFmt":"158945,943","currency":"AED"},"lastSubscriptionDate":"16-JUL-2017"},{"fundName":"Bond Fund - Growth Plan 15","numberOfUnits":32943,"currentValue":{"value":158945943,"valueFmt":"158945,943","currency":"AED"},"totalInvestment":{"value":158945943,"valueFmt":"158945,943","currency":"AED"},"lastSubscriptionDate":"16-JUL-2017"}];
        this.temp = [...this.rows];
        this.columns = [
            { name: 'Fund Name', prop: 'fundName' },
            { name: 'Number Of Units', prop: 'numberOfUnits' },
            { name: 'Current Value', prop: 'currentValue.value' },
            { name: 'Total Investment', prop: 'totalInvestment.value' },
            { name: 'Last Subscription Date', prop: 'lastSubscriptionDate' }
          ];
    }

    updateFilter(event :any, type:string) {
        const val = event.target.value.toLowerCase();
        let typeList :any = type.split('.');
        //if(typeList[1])
        const temp = this.temp.filter(function(d) {
            console.log(d[typeList[0]])
          return d[typeList[0]].indexOf(val) !== -1 || !val;
        });
        this.rows = temp;
        this.tableElem.offset = 0;
    }
}