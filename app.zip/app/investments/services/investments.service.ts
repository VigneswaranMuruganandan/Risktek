import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import {GlobalVariable} from '../../shared/services/global';
import {ServiceInvoker} from '../../shared/connector/serviceInvoker.service';
import {EncryptionService} from '../../shared/services/encryption.service';
import {ErrorService} from '../../shared/services/error.service';
import {SessionContext} from '../../shared/model/sessionContext';
import {GlobalURL} from '../../shared/services/globalURL';
import { StaticDataResponse } from '../../shared/model/staticDataResponse';
import { WealthEnquiryRequest } from '../model/wealthEnquiryRequest';
import { AssetProductAllocationResponse } from '../model/assetProductAllocationResponse';
import { PendingOrderResponse } from '../model/pendingOrderResponse';
import { SecurityHoldingResponse } from '../model/securityHoldingResponse';
import { TransactionHistoryResponse  } from '../model/transactionHistoryResponse';
import { SetupWealthResponse  } from '../model/setupWealthResponse';
import { RMResponse } from '../model/RMResponse';

@Injectable()
export class InvestmentsService {

    constructor(private serviceInvoker: ServiceInvoker,
        private encryptionService: EncryptionService,
        private errorService: ErrorService) {}

    fetchProducts(data: any): Observable < StaticDataResponse > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.INVESTMENTS.VIEW_PRODUCTS, data)
            .map(resp => JSON.parse(resp));
    }

    fetchAssetAllocation(wealthEnquiryRequest: WealthEnquiryRequest): Observable < AssetProductAllocationResponse > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.INVESTMENTS.ASSET_ALLOCATION, null)
            .map(resp => JSON.parse(resp));
    }

    fetchProductAllocation(wealthEnquiryRequest: WealthEnquiryRequest): Observable < AssetProductAllocationResponse > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.INVESTMENTS.PRODUCT_ALLOCATION, null)
            .map(resp => JSON.parse(resp));
    }

    fetchSecurityHolding(wealthEnquiryRequest: WealthEnquiryRequest): Observable < SecurityHoldingResponse > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.INVESTMENTS.SECURITY_HOLDING, null)
            .map(resp => JSON.parse(resp));
    }
    
    fetchPendingOrder(wealthEnquiryRequest: WealthEnquiryRequest): Observable < PendingOrderResponse > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.INVESTMENTS.PENDING_ORDER, null)
            .map(resp => JSON.parse(resp));
    }

    setupTransactionHistory(): Observable < SetupWealthResponse > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.INVESTMENTS.TRANSACTIONHISTORYSETUP, null)
            .map(resp => JSON.parse(resp));
    }

    fetchTransactionHistoryList(wealthEnquiryRequest: WealthEnquiryRequest): Observable < TransactionHistoryResponse > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.INVESTMENTS.TRANSACTIONHISTORY, wealthEnquiryRequest)
            .map(resp => JSON.parse(resp));
    }

    fetchRMDetails(wealthEnquiryRequest: WealthEnquiryRequest): Observable < RMResponse > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.INVESTMENTS.RELATIONSHIPMANAGER, null)
            .map(resp => JSON.parse(resp));
    }
}