import {APIResponse} from '../../shared/model/apiResponse';
import {ProductDetails} from './productDetails';
import { Amount } from '../../shared/model/amount';

export class ProductInfo extends APIResponse{
	productClassName :string;
	productClassCode :string;
	sumOfMvinAED :Amount;
	sumPercAsset :Amount;
	productDetailsList :ProductDetails[];
}
