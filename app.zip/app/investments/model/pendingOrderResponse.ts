import {APIResponse} from '../../shared/model/apiResponse';
import {OrderDetails} from './orderDetails';

export class PendingOrderResponse extends APIResponse{
	orderDetails: OrderDetails[];
}
