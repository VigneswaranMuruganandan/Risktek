export class WealthEnquiryRequest {
	asOnDate :string; //mandatory
	productClassCode :string;
	startDate :string;
	endDate :string;
	securityCode :string;
}

