import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ApplyProductComponent }   from './Components/applyProduct.component';
import { InvestmentsOnboardingComponent }   from './Components/investmentsOnboarding.component';
import { TransactionHistoryComponent }   from './Components/transactionHistory.component';
import { AssetsAndProductAllocationComponent }   from './Components/assetsAndProductAllocation.component';
import { HoldingSummaryComponent }   from './Components/holdingSummary.component';
import { PendingOrderStatusComponent }   from './Components/pendingOrderStatus.component';
import { GlobalMarketUpdateComponent }   from './Components/globalMarketUpdate.component';
import { MutualFundsComponent }   from './Components/mutualFunds.component';
import { SubscriptionsBondFundComponent }   from './Components/SubscriptionsBondFund.component';
import { AuthGuard } from '../auth-guard.service';

const routes: Routes = [   
    {
        path: '',
        component: InvestmentsOnboardingComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'applyProducts',
        component: ApplyProductComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'transactionHistory',
        component: TransactionHistoryComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'assetsAndProductAllocation',
        component: AssetsAndProductAllocationComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'pendingOrderStatus',
        component: PendingOrderStatusComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'holdingSummary',
        component: HoldingSummaryComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'globalMarketUpdate',
        component: GlobalMarketUpdateComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'mutualFunds',
        component: MutualFundsComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'subscriptionsBondFund',
        component: SubscriptionsBondFundComponent,
        canActivate: [AuthGuard]
    },
    {
        path: '',
        redirectTo: '',
        pathMatch: 'full'
    }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
