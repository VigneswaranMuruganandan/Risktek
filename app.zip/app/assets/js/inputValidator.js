﻿(function( factory ) {
	if ( typeof define === "function" && define.amd ) {
		define( ["jquery"], factory );
	} else if (typeof module === "object" && module.exports) {
		module.exports = factory( require( "jquery" ) );
	} else {
		factory( jQuery );
	}
}(function( $ ) {

	$.extend( $.fn, {
		onlyNumber: function() {
			this.onlyAllow(/\d/);
	        $(this).bind('paste', function () {
				var maxLength = $(this).attr('maxlength');
				
				if(maxLength != null && maxLength > 0)
					$(this).removeAttr('maxlength');
				
	            var element = this;
	            setTimeout(function () {
	                var text = $(element).val();
	                var regex = /[a-zA-ZıçğüçöşİÇÖĞŞÜ#@æ$%&()=?!'^+/_é<>£½{}\|\- ]/g;
	                var _final = text.replace(regex, "");
					
					if(maxLength != null && maxLength > 0)
					{
						$(element).val(_final.substring(0, maxLength));
						$(element).attr('maxlength', maxLength);
					}
					else
					{
						$(element).val(_final);
					}
	                
					$(element).trigger('blur');
	                $(element).trigger('focus');
	            }, 100);
	        });
		},
		onlyEmail: function () {
	        this.disallow('şŞĞğÜüÇçÖöİı !#/*{[()]}');
	    },
	    onlyLetter: function () {
	        this.onlyAllow(/^[a-zA-ZıçğüçöşİÇÖĞŞÜ\s]+$/);

	        $(this).bind('paste', function () {
	            var element = this;
	            setTimeout(function () {
	                var text = $(element).val();
	                var regex = /[1234567890.#$%&()=?!'^+/_é<>£½{}\|\-]/g;
	                var _final = text.replace(regex, "");
	                $(element).val(_final);
	                $(element).trigger('blur');
	                $(element).trigger('focus');
	            }, 100);
	        });

	    },
	    alphaNumericEscape: function () {
	        this.onlyAllow(/^[a-zA-Z.,?!ıçğüçöşİÇÖĞŞÜ0-9\s]+$/);

	        $(this).bind('paste', function () {
	            var element = this;
	            setTimeout(function () {
	                var text = $(element).val();
	                var regex = /[#$%&()='^+/_é<>£½{}\|\-]/g;
	                var _final = text.replace(regex, "");
	                $(element).val(_final);
	                $(element).trigger('blur');
	                $(element).trigger('focus');
	            }, 100);
	        });

	    },
	    onlyAlphaNumeric: function () {
	        this.onlyAllow(/^[a-zA-ZıçğüçöşİÇÖĞŞÜ0-9\s]+$/);

	        $(this).bind('paste', function () {
	            var element = this;
	            setTimeout(function () {
	                var text = $(element).val();
	                var regex = /[.#$%&()=?!'^+/_é<>£½{}\|\-]/g;
	                var _final = text.replace(regex, "");
	                $(element).val(_final);
	                $(element).trigger('blur');
	                $(element).trigger('focus');
	            }, 100);
	        });

	    },
	    noChar: function () {
	        this.onlyAllow(/^[a-zA-ZıçğüçöşİÇÖĞŞ0123456789Ü\s]+$/);
	    },
		onlyAllow:function(filter){
			if (typeof filter === 'string') {
	            filter = filter.split('');
	        }
	        this.each(function () {
	            $(this).bind('keypress', function (e) {

	                //Firefox, Opera, Yandex Copy Fix
	                /*if(e.ctrlKey) {
	                    return true;
	                } else*/

	                if (e.charCode !== 0 && !e.ctrlKey) {
	                    var k = e.which || e.charCode;
	                    t = String.fromCharCode(k),
							valid = false;
	                    if (filter instanceof RegExp) {
	                        if (!filter.test(t)) {
	                            return false;
	                        }
	                    } else {
	                        if ($.isArray(filter)) {
	                            for (var i = 0; i < filter.length; i++) {
	                                if (t === filter[i]) {
	                                    valid = true;
	                                }
	                            }
	                            if (!valid) {
	                                return false;
	                            }
	                        }
	                    }
	                }
	            });
	        });
		},
		disallow: function (filter) {
	        if (typeof filter === 'string') {
	            filter = filter.split('');
	        }
	        this.each(function () {
	            $(this).bind('keypress', function (e) {
	                if (e.charCode !== 0) {
	                    var k = e.which || e.charCode;
	                    t = String.fromCharCode(k);
	                    if (filter instanceof RegExp) {
	                        if (filter.test(t)) {
	                            return false;
	                        }
	                    } else {
	                        if ($.isArray(filter)) {
	                            for (var i = 0; i < filter.length; i++) {
	                                if (t === filter[i]) {
	                                    return false;
	                                }
	                            }
	                        }
	                    }
	                }
	            });
	        });
	    }
	});
return $;
}));