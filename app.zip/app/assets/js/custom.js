$(document).ready(function() {
	//Registration steps
	$('.title-step-2, .title-step-3,  .title-step-4, .button-step-2a, .button-step-3').addClass('hide');
	$('.content-step-2, .content-step-2a, .content-step-3, .content-step-3a, .content-step-4').addClass('hide');

	$('.button-step-1').click(function(){
		$('.title-step-1').addClass('hide');
		$('.title-step-2').removeClass('hide').addClass('show');
		$('.content-step-1').addClass('hide');
		$('.content-step-2').addClass('show');
		$('ul.steps li:nth-child(1)').removeClass('check').addClass('success');
		$('ul.steps li:nth-child(2)').addClass('check')
	});

	$(".otp-success").keydown (function() {
        $('.title-step-2').removeClass('show').addClass('hide');
		$('.title-step-3').removeClass('hide').addClass('show');
		$('.content-step-2').removeClass('show').addClass('hide');
		$('.content-step-2a').removeClass('hide').addClass('show');
		$('ul.steps li:nth-child(2)').removeClass('check').addClass('success');
		$('ul.steps li:nth-child(3)').addClass('check')
    });

    $(".username").keydown (function() {
        $('.button-step-2a').removeClass('hide').css('display', 'inline-block');
        $('.content-step-2a ul.validate li').addClass('success');
    });

    $('.button-step-2a').click(function(){
		$('.content-step-2a').removeClass('show').addClass('hide');
		$('.content-step-3').removeClass('hide').addClass('show');
		$('ul.steps li:nth-child(3)').removeClass('check').addClass('success');
		$('ul.steps li:nth-child(4)').addClass('check')
	});

	$(".password").keydown (function() {
        $('.button-step-3').removeClass('hide').css('display', 'inline-block');
        $('.content-step-3 ul.validate li').addClass('success');
    });

    $('.button-step-3').click(function(){
		$('.content-step-3').removeClass('show').addClass('hide');
		$('.content-step-3a').removeClass('hide').addClass('show');
	});

	$(".confirm-password").keydown (function() {
		$('.title-step-3').removeClass('show').addClass('hide');
		$('.title-step-4').removeClass('hide').addClass('show');
		$('.content-step-3a').removeClass('show').addClass('hide');
		$('.content-step-4').removeClass('hide').addClass('show');
		$('ul.steps li:nth-child(4)').removeClass('check').addClass('success');
		//$('ul.steps li:nth-child(4)').addClass('check')
    });

	$('ul.otp input').on('keyup', function(e) {
		var next = $(this).closest('li').next().find('input');
		if(next.length) {
			next.focus();
		} else {
			$(this).closest('ul.otp').trigger('otp.done');
		}
	})


	//authencation options
    $("input[name$='option']").click(function() {
        var choose = $(this).val();
        $("div.desc").hide();
        $("#option" + choose).show();
    });


	$(".show-all-favourites").click(function () {
		$(".favourites-hidden").stop().slideToggle();
		// $(".showAll-text-hidden").stop().slideToggle();
		// $(".showAll-text").stop().slideToggle();
		return false;
	});	

    //wealth Slides
    $('.slide-2, .slide-3,  .slide-4, .slide-5, .slide-6').addClass('hide');

    $('.slide-1 .next-btn').click(function(){
		$('.slide-1').addClass('hide');
		$('.slide-2').removeClass('hide').addClass('show');
	});

	$('.slide-2 .next-btn').click(function(){
		$('.slide-2').removeClass('show').addClass('hide');
		$('.slide-3').removeClass('hide').addClass('show');
	});

	$('.slide-3 .next-btn').click(function(){
		$('.slide-3').removeClass('show').addClass('hide');
		$('.slide-4').removeClass('hide').addClass('show');
	});

	$('.slide-4 .next-btn').click(function(){
		$('.slide-4').removeClass('show').addClass('hide');
		$('.slide-5').removeClass('hide').addClass('show');
	});

	$('.slide-5 .button').click(function(){
		$('.slide-5').removeClass('show').addClass('hide');
		$('.slide-6').removeClass('hide').addClass('show');
	});

	// Activation
	$('.activate-card .card-confirm').change(function() {
		$('.begin-activation-btn').toggle(this.checked);
		$('.slide-1 .card-with-ring img').toggleClass('disabled');
	});
	$('.activate-card .slide-2 ul.otp').on('otp.done', function(){
		$('.slide-2').removeClass('show').addClass('hide');
		$('.slide-3').removeClass('hide').addClass('show');
	});
	$('.activate-card .slide-3 ul.otp').on('otp.done', function(){
		$('.slide-3').removeClass('show').addClass('hide');
		$('.slide-4').removeClass('hide').addClass('show');
	});
	$('.activate-card .slide-4 ul.otp').on('otp.done', function(){
		$('.slide-4').removeClass('show').addClass('hide');
		$('.slide-5').removeClass('hide').addClass('show');
		setTimeout(function(){
			$('#logoutModal').modal();
		}, 2000);
	});

	//Dashboard
	var slickConfig = {
		favorites: {
			dots:true,
			rtl:$('.arabic-design').length > 0,
			appendDots: '.slick-carousel-dots',
			dotsClass: 'carousel-dots',
			slidesToShow: 4,
  			slidesToScroll: 4,
			arrows: false,
			responsive: [
				{
					breakpoint: 1500,
					settings: {
						slidesToShow: 3,
						slidesToScroll: 3,
						infinite: true,
						dots: true
					}
				},
				{
					breakpoint: 1100,
					settings: {
						slidesToShow: 2,
						slidesToScroll: 2,
						infinite: true,
						dots: true
					}
				},
				{
					breakpoint: 600,
					settings: {
						slidesToShow: 2,
						slidesToScroll: 2
					}
				},
				{
					breakpoint: 520,
					settings: {
						slidesToShow: 1,
						slidesToScroll: 1
					}
				}
			]
		},
		payments: {
			dots:true,
			arrows: false,
			appendDots: '.slick-carousel-dots',
			dotsClass: 'carousel-dots',
			slidesToShow: 3,
  			slidesToScroll: 3,
			infinite: false,
			responsive: [
				{
					breakpoint: 1500,
					settings: {
						slidesToShow: 3,
						slidesToScroll: 3,
						infinite: true,
						dots: true
					}
				},
				{
					breakpoint: 1100,
					settings: {
						slidesToShow: 2,
						slidesToScroll: 2,
						infinite: true,
						dots: true
					}
				},
				{
					breakpoint: 500,
					settings: {
						slidesToShow: 1,
						slidesToScroll: 1
					}
				},
			]
		}
	};
	function createCarousel(block) {
		var conf = slickConfig[block.data('slick-config')];
		if(conf.appendDots && typeof conf.appendDots === 'string') {
			conf.appendDots = block.find(conf.appendDots);
		}
		$('.slick-carousel', block).slick(conf);
	}
	$('.slick-carousel-block').each(function() {
		createCarousel($(this));
	});

	//Hamburger Menu
	
	$('.hamburger-menu').on('click', function() {
		$('.hamburger').toggleClass('animate');

		checkMenuState();
	});
	showHideMenu();
	checkMenuState();

	$( window ).resize(function() {
	  	showHideMenu();
		checkMenuState();
	});

	$('[data-slick-disable]').click(function(){
		var $this = $(this);
		var conf = $this.data('slick-disable');
		var carousel = $('[data-slick-config="'+conf+'"]');
		carousel.find('.slick-carousel').slick('unslick');
		$this.hide();
		$('[data-slick-enable="'+conf+'"]').show();
	});

	$('[data-slick-enable]').click(function(){
		var $this = $(this);
		var conf = $this.data('slick-enable');
		var carousel = $('[data-slick-config="'+conf+'"]');
		createCarousel(carousel);
		$this.hide();
		$('[data-slick-disable="'+conf+'"]').show();
	});

	
	
	//Nav toggle
	$('.toggle').click(function(e) {
	  	e.preventDefault();
	  
	    var $this = $(this);
	  
	    if ($this.next().hasClass('show')) {
	        $this.next().removeClass('show');
	        $this.next().slideUp(350);
	        $this.parent().find('a').removeClass('active');
	    } else {
	        $this.parent().parent().find('li .inner').removeClass('show');
	        $this.parent().parent().find('li .inner').slideUp(350);
	        $this.parent().find('a').addClass('active');
	        $this.next().toggleClass('show');
	        $this.next().slideToggle(350);
	    }
	});

	//Search Toggle
	$( '.search-mobile-icon' ).click(function() {
	  $( '.search-box' ).slideToggle( 300, function() {
	    // Animation complete.
	  });
	});

	setTimeout(function() {
		$(window).trigger('resize');
	}, 250);

	//login Menu
	$(".header-account-settings").click(function(){
		$(".logged-in-menu").toggleClass( "show" );
	});

});

//Functions
function checkMenuState(){
	if( $( '.hamburger').hasClass( "animate" ) ){
		/*$('.main').addClass('push');*/
		if ($(window).width() >= 960) {
		   $('.main').addClass('push');
		}
		$('.sidebar').css('left','0');
	}else{
		$('.main').removeClass('push');
		$('.sidebar').css('left','-300px');
	}
	if( $( '.arabic-design .hamburger').hasClass( "animate" ) ){
		/*$('.main').addClass('push');*/
		if ($(window).width() >= 960) {
			$('.arabic-design .main').addClass('push');
		}
		$('.arabic-design .sidebar').css('right','0');
	}else{
		$('.arabic-design .main').removeClass('push');
		$('.arabic-design .sidebar').css('right','-300px');
	}
}
function showHideMenu(){
	if ($(window).width() < 959) {
	   $('.hamburger').removeClass('animate');
	}
	else {
	   $('.hamburger').addClass('animate');
	}
	if ($(window).width() < 959) {
		$('.arabic-design .hamburger').removeClass('animate');
	}
	else {
		$('.arabic-design .hamburger').addClass('animate');
	}
}
