import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';
import {AuthRequest} from '../../register/model/authRequest';
import {VerifyCustomerResponse} from '../../register/model/verifyCustomerResponse';
import {RegisterPwdResponse} from '../../register/model/registerPwdResponse';
import {VerifyOtpResponse} from '../../shared/model/verifyOtpResponse';
import {ResendOtpResponse} from '../../register/model/resendOtpResponse';
import {AuthKey} from '../../shared/model/authKey';
import {AuthData} from '../../shared/model/authData';
import {ServiceInvoker} from '../../shared/connector/serviceInvoker.service';
import {EncryptionService} from '../../shared/services/encryption.service';
import {SessionContext} from '../../shared/model/sessionContext';
import {AppSession} from '../../shared/model/appSession';
import {GlobalURL} from '../../shared/services/globalURL';
import {User} from '../model/user';
import {ErrorService} from '../../shared/services/error.service';
import {SharedService} from '../../shared/services/shared.service';

@Injectable()
export class LoginService {
    
    constructor(private serviceInvoker: ServiceInvoker, 
                private encryptionService: EncryptionService,
                private errorService: ErrorService,
                private sharedService: SharedService) {}

    verifyLogin(authRequest: User): Observable < AuthData > {
        console.log(SessionContext.getInstance().userID);
        let pwdHash = this.encryptionService.generatePwdHash(SessionContext.getInstance().userID, authRequest.pwd);
        authRequest.pwd = this.encryptionService.convertToBase64(pwdHash);
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.LOGIN.VERIFYLOGIN, authRequest)
                                  .map(resp => this.populateAuthReq(resp));
    }

    fetchCIFNumber(authRequest: User): Observable < string > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.LOGIN.VERIFYCUSTOMERID, authRequest)
                                  .map(resp => this.populateCustomerIDReq(resp));
    }

    /*
    * verifyLogin Handler
    */
    private populateAuthReq(resp: string) {        
        var respObj = JSON.parse(resp);
        if(respObj.result.status == 'success'){
            this.sharedService.updateSessionContext(respObj);        
            var responseObj = new AuthData();
            responseObj = respObj;
            return responseObj;
        }else if(respObj.result.status == 'error'){
            this.errorService.setErrorResp(respObj.result);
            return respObj;
        }      
    }

    private populateCustomerIDReq(resp: string){
        let respObj = JSON.parse(resp);
        if (respObj.result.status == 'success') {
            SessionContext.getInstance().userID = respObj.cif;
            return respObj;
        }else if(respObj.result.status == 'error'){
            $(".loader").fadeOut();
            this.errorService.setErrorResp(respObj.result);
        }
    }    
}
