import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';
import {AuthRequest} from '../../register/model/authRequest';
import {VerifyCustomerResponse} from '../../register/model/verifyCustomerResponse';
import {RegisterPwdResponse} from '../../register/model/registerPwdResponse';
import {VerifyOtpResponse} from '../../shared/model/verifyOtpResponse';
import {ResendOtpResponse} from '../../register/model/resendOtpResponse';
import {AuthKey} from '../../shared/model/authKey';
import {AuthData} from '../../shared/model/authData';
import {ServiceInvoker} from '../../shared/connector/serviceInvoker.service';
import {EncryptionService} from '../../shared/services/encryption.service';
import {User} from '../model/user';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { VerifyCredOTPRequest } from '../model/verifyCredOTPRequest';
import { VerifyUserLoginResponse } from '../model/verifyUserLoginResponse';
import {
    SharedService,
    ErrorService,
    SessionContext,
    AppSession,
    GlobalVariable,
    GlobalURL
} from '../../shared';

@Injectable()
export class LoginService {
    
    constructor(private serviceInvoker: ServiceInvoker, 
                private encryptionService: EncryptionService,
                private errorService: ErrorService,
                private sharedService: SharedService,
                public http: Http) {}

    verifyLogin(user: User): Observable < VerifyUserLoginResponse > {
        console.log(SessionContext.getInstance().userID);
        let pwdHash = this.encryptionService.generatePwdHash(SessionContext.getInstance().userID, user.pwd);
        user.pwd = this.encryptionService.convertToBase64(pwdHash);
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.LOGIN.VERIFYLOGIN, user)
                                  .map(resp => this.populateAuthReq(resp));
    }

    fetchCIFNumber(user: User): Observable < string > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.LOGIN.VERIFYCUSTOMERID, user)
                                  .map(resp => this.populateCustomerIDReq(resp));
    }

    fetchIPAddress(): Observable<any> {
        return this.http.get(GlobalURL.SERVICE_URL.LOGIN.GETIPADDRESS) 
        .map((resp:Response) => resp.json())    
    }


    verifyLoginOTP(user: VerifyCredOTPRequest): Observable < VerifyUserLoginResponse > {
        let pwdHash = this.encryptionService.generatePwdHash(SessionContext.getInstance().userID, user.pwd);
        user.pwd = this.encryptionService.convertToBase64(pwdHash);
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.FORGOT_PASSWORD.VERIFYOTPCRED, user)
                                  .map(resp => this.populateAuthReqOTP(resp));
    }

    /*
    * verifyLogin Handler
    */
    private populateAuthReq(resp: string) {        
        let respObj = JSON.parse(resp);
        if(respObj.result.status == 'success'){
            if(respObj.riskEvaluationAdvice && respObj.riskEvaluationAdvice == GlobalVariable.RISKEVALUATIONADVICE.ALLOW){
                this.sharedService.updateSessionContext(respObj); 
            }       
            return respObj;
        }else if(respObj.result.status == 'error'){
            this.errorService.setErrorResp(respObj.result);
            return respObj;
        }      
    }

    private populateAuthReqOTP(resp: string) {        
        let respObj = JSON.parse(resp);
        if(respObj.result.status == 'success'){
            this.sharedService.updateSessionContext(respObj); 
            return respObj;
        }else if(respObj.result.status == 'error'){
            this.errorService.setErrorResp(respObj.result);
            return respObj;
        }
    }

    private populateCustomerIDReq(resp: string){
        let respObj = JSON.parse(resp);
        if (respObj.result.status == 'success') {
            SessionContext.getInstance().userID = respObj.cif;
            return respObj;
        }else if(respObj.result.status == 'error'){
            $(".loader").fadeOut();
            this.errorService.setErrorResp(respObj.result);
        }
    }    
}
