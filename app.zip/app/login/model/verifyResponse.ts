import { APIResponse } from '../../shared/model/apiResponse';

export class VerifyResponse extends APIResponse{
	otpDuration :number;
	convID :string;
	cif :string;
	emailMasked :string;
	mobileNumberMasked :string;
	remainingOtpAttempts :number;
	riskEvaluationAdvice :string; // ALERT ,DENY, INCREASEAUTH, ALLOW
}