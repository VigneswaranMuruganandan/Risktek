export class CountOfBillersOrPaymentsOfCustomer{
	numberOfpayments :number;
	paymentOrTransferProviderName :string;
}