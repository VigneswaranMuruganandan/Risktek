export class PaymentTransferMaster{
	paymentTransferId :string;
	paymentTransferName :string;
	category :string;
}