import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {TemplateService} from '../../shared/services/template.service';
import { FormsModule} from '@angular/forms';
import { ErrorService} from '../../shared/services/error.service';

@Component({
  selector: 'openAccountForm-component',
  templateUrl: './../templates/openAccountForm.html'
})
export class OpenAccountFormComponent{
	@Output() validateCredentialsEvent = new EventEmitter();

    constructor( public templateService: TemplateService,
                 public errorService: ErrorService) {}

    datePicker(date :string){
      //
    }

    submit(valid){
    	if(valid){
    		this.validateCredentialsEvent.emit();
    	}
    }
}