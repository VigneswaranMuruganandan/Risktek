import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { FormsModule} from '@angular/forms';

import { LeadRequest } from '../../investments/model/leadRequest';
import { 
    GlobalVariable,
    StaticDataResponse, 
    StaticData,
    ErrorService,
    TranslateService,
    TemplateService
} from '../../shared';

@Component({
  selector: 'openAccountForm-component',
  templateUrl: './../templates/openAccountForm.html'
})
export class OpenAccountFormComponent{
	@Output() validateCredentialsEvent = new EventEmitter();
  @Input() applyforProduct: LeadRequest;
  @Input() staticData : Map<string,Array<StaticData>>;
  
  constructor( public templateService: TemplateService,
                 public errorService: ErrorService) {}

    datePicker(date :string){
      this.applyforProduct.dateOfBirth = date;
    }

    submit(valid){
    	if(valid){
    		this.validateCredentialsEvent.emit();
    	}
    }
}