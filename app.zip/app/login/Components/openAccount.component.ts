import { Component, OnInit, Input } from '@angular/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    TranslateService,
    ServerError,
    Product,
    SessionContext,
    AppSession,
    GlobalVariable
} from '../../shared';

@Component({
    templateUrl: './../templates/openAccount.html'
})
export class OpenAccountComponent implements OnInit {
    public stepValue :number;

    constructor( private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private templateService: TemplateService,
                 private errorService: ErrorService,
                 private router: Router) {}

    ngOnInit() {
      this.stepValue = 1;
    }

    submitforOpenAccount(){
        this.stepValue = 2;
    }
}