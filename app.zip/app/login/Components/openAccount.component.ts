import { Component, OnInit, Input } from '@angular/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import {
    StaticData,
    StaticDataResponse,
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    TranslateService,
    ServerError,
    Product,
    SessionContext,
    AppSession,
    GlobalVariable
} from '../../shared';
import { LeadRequest } from '../../investments/model/leadRequest';

@Component({
    templateUrl: './../templates/openAccount.html'
})
export class OpenAccountComponent implements OnInit {
    public stepValue :number;
    public applyforProduct :LeadRequest;
    public staticData : Map<string,Array<StaticData>>;

    constructor( private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private templateService: TemplateService,
                 private errorService: ErrorService,
                 private router: Router) {}

    ngOnInit() {
      this.initAccount();
    }

    initAccount(){
        this.errorService.resetErrorResp();
        this.stepValue = 1;
        this.applyforProduct = new LeadRequest();
        this.staticData = StaticDataResponse.getInstance().staticMasterDataMap;
        this.applyforProduct.productType = 'ACCOUNTS';
    } 

    submitforOpenAccount(){
        this.spinnerService.startSpinner('loader');
        this.sharedService.saveLead(this.applyforProduct)
            .subscribe(
                resp => this.handleApplyForAccount(resp),
                error => this.sharedService.handleError(error)
            );
    }

    handleApplyForAccount(resp :any){
        this.spinnerService.stopSpinner('loader');        
        if(resp && resp.result.status == 'success'){
            this.stepValue = 2;
        }else if(resp && resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
    }
}