import { Component, OnInit, Input } from '@angular/core';
import { LoginService } from '../services/login.service';
import { LoginRequest } from '../model/loginrequest';
import { User } from '../model/user';
import { CIFData } from '../model/cifdata';
import { AuthKey } from '../../shared/model/authKey';
import { AuthData } from '../../shared/model/authData';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    TranslateService,
    ServerError,
    Product,
    SessionContext,
    AppSession,
    GlobalVariable
} from '../../shared';

@Component({
    templateUrl: './../templates/login.html'
})
export class LoginComponent implements OnInit {
    public user: User;
    public stepValue :number;

    constructor( private loginService: LoginService, 
                 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private templateService: TemplateService,
                 private errorService: ErrorService,
                 private router: Router) {}

    ngOnInit() {
      this.initLogin();
    }

    initLogin(){
      this.errorService.resetErrorResp();
      this.stepValue = 1;
      this.user = new User();
      this.templateService.loginSetup(this.user);
    }
    /*
    * Step 1: Initate the Register Device before verifying the Credentials
    */
    validateCredentials() {
      this.spinnerService.startSpinner('loader');
      let registerDeviceData = this.sharedService.setupAuthKeys();
      if(registerDeviceData && registerDeviceData.deviceID != null){
        this.sharedService.registerDevice(registerDeviceData)
          .subscribe(
              resp => this.handleRegisterDeviceDataResp(resp),
              error => this.sharedService.handleError(error)
          );
      }else{
        let sessCtx = SessionContext.getInstance();
        this.handleRegisterDeviceDataResp(sessCtx)
      }      
    }
    /*
    * Step 2: With Username , fetch the CIF ID
    */
    private handleRegisterDeviceDataResp(resp: any){
      if(resp.authKey && resp.authKey.convID != null){
        let data = new LoginRequest();
        data.customerID = this.user.userName;
        this.loginService.fetchCIFNumber(data)
          .subscribe(
              resp => this.handleFetchCIFNumberLogin(resp),
              error => this.sharedService.handleError(error)
          );
      }
    }
    /*
    * Step 3: Verify the Username and Password
    */
    private handleFetchCIFNumberLogin(respObj: any) {
      if (respObj && respObj.cif != null) {
        let data = new User();
        data = Object.assign({}, this.user);
        this.loginService.verifyLogin(data)
            .subscribe(
                resp => this.handleVerifyLogin(resp),
                error => this.sharedService.handleError(error)
            );
      }
    }
    /*
    * Step 4: Mange the Succes of verify Login
    */
    private handleVerifyLogin(resp: any) {      
      this.spinnerService.stopSpinner('loader');
      if(resp && resp.result.status == 'success'){
            //this.router.navigate([GlobalVariable.ROUTE_MAPPING.DASHBOARD]);
            this.router.navigate([GlobalVariable.ROUTE_MAPPING.CONTACT_US]);          
      }else if(resp.result.status == 'error'){
          this.user.pwd = '';
      }
    }
}