import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {TemplateService} from '../../shared/services/template.service';
import { FormsModule} from '@angular/forms';
import { ErrorService} from '../../shared/services/error.service';

@Component({
  selector: 'openAccountSuccess-component',
  templateUrl: './../templates/openAccountSuccess.html'
})
export class OpenAccountSuccessComponent {

    constructor( public templateService: TemplateService,
                 public errorService: ErrorService) {}

}