import {APIResponse} from '../../shared/model/apiResponse';
import { Product } from '../../shared';

export class SetupForCharityResponse extends APIResponse {
	txnRef :string;
	fundingSources :Product[];
}

