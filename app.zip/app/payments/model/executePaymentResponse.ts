import {APIResponse} from '../../shared/model/apiResponse';
import {Amount} from '../../shared/model/amount';

export class ExecutePaymentResponse  extends APIResponse{
	transactionRefNo:string;
	balanceForFundingSource:Amount;
}

