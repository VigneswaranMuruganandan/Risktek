export class ExecuteCharityPaymentRequest {
	charityName :string;
	charityCode :string;
	amount :string;
	currency :string;
	sourceAccountNumber :string;
	txnRef :string;
	authKey :string;
	
	constructor() { 
 		this.sourceAccountNumber = '';
	}
}

