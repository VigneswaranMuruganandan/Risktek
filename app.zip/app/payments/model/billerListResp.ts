
import {APIResponse} from '../../shared/model/apiResponse';
import { Biller } from '../../beneficiaries/model/biller';

export class BillerListResp extends APIResponse{

  	billerList:Biller[];
}

