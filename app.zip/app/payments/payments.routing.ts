import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PaymentsComponent } from './Components/payments.component';
import { CharityComponent } from './Components/charity.component';
import { AddPaymentComponent } from './Components/addPayment.component';


const routes: Routes = [
	{
        path: '',
        component: PaymentsComponent
    },
	{
        path: 'charity',
        component: CharityComponent
    },
    {
        path: 'execute',
        component: AddPaymentComponent
    },
    {
	    path: '',
	    redirectTo: '',
	    pathMatch: 'full'
	}
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);