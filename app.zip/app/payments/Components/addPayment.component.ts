import { Component, OnInit, Input, ViewChild} from '@angular/core';
import { Router } from '@angular/router';
import { AppSession} from '../../shared/model/appSession';
import { ExecutePaymentRequest} from '../model/executePaymentRequest';
import { SetupForPaymentResponse} from '../../beneficiaries/model/setupForPaymentResponse';
import { SetupForPaymentRequest} from '../../beneficiaries/model/setupForPaymentRequest';
import { PaymentsService} from '../services/payments.service';
import { SharedService} from '../../shared/services/shared.service';
import { ErrorService } from '../../shared/services/error.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { SendOtpRequest} from '../../shared/model/sendOtpRequest';
import { SendOtpResponse} from '../../shared/model/sendOtpResponse';
import { GlobalVariable} from '../../shared/services/global';
import { ExecutePaymentResponse} from '../model/executePaymentResponse';
import { Biller} from '../../beneficiaries/model/biller';
import { UserContext} from '../../shared/model/userContext';
import { FetchBalanceForPaymentResponse } from '../model/fetchBalanceForPaymentResponse';
import { ValidateBeneficiaryRequest} from '../../beneficiaries/model/validateBeneficiaryRequest';
import { APIResponse } from '../../shared/model/apiResponse';
import { PaymentLimit} from '../../beneficiaries/model/paymentLimit';
import { TemplateService} from '../../shared/services/template.service';

@Component({
  templateUrl: './../templates/addPayment.html'
})
export class AddPaymentComponent implements OnInit{

    public stepValue: number;
    public appSession: AppSession;
    public billerTypes:any=[];
    public executePaymentRequest:ExecutePaymentRequest;
    public executePaymentResponse:ExecutePaymentResponse;
    public setupForPaymentResponse:SetupForPaymentResponse;
    public setupForPaymentRequest:SetupForPaymentRequest;
    public addBillerType:string;
    public sendOtpRequest:SendOtpRequest;
    public sendOtpResponse:SendOtpResponse;
    public createBillerBeneficiary:boolean;
    public billerBeneficiary:Biller;
    public salikAutoBy:string;
    public fetchBalanceForPaymentResponse:FetchBalanceForPaymentResponse;
    public validatebillerBeneReq:ValidateBeneficiaryRequest;
    public paymentLimit:PaymentLimit;

    constructor(  private sharedService: SharedService,
                  private errorService: ErrorService,
                  private spinnerService: SpinnerService,
                  private paymentsService:PaymentsService,
                  private templateService:TemplateService) {}

  	ngOnInit() { 
        this.initAddPayment();
    }

    initAddPayment(){
      this.billerBeneficiary = UserContext.getInstance().biller;
      this.executePaymentRequest = new ExecutePaymentRequest();
      if(this.billerBeneficiary && this.billerBeneficiary.billerId){
          this.createBillerBeneficiary = false;
          this.executePaymentRequest.agency = this.billerBeneficiary.billerName;
          this.executePaymentRequest.consumerNo = this.billerBeneficiary.consumerNo;
          this.executePaymentRequest.nickName = this.billerBeneficiary.nickName;
          if(this.billerBeneficiary.billerName=="SALIK"){
            this.executePaymentRequest.salikPinNo = this.billerBeneficiary.salikPinNo;
          }
      }else{
          this.createBillerBeneficiary = true;
          this.executePaymentRequest.createBiller = true;
          this.appSession = AppSession.getInstance();
          this.billerTypes=this.appSession.paymentTypes.filter(biller => GlobalVariable.BILLER_DESCRIPTION[biller.paymentTransferName]!=undefined);
      }
      this.stepValue = 1;
      this.executePaymentRequest.createAutopay=false;
      this.fetchPaymentSetup();
      this.errorService.resetErrorResp();
    }

    fetchPaymentSetup(){
        this.spinnerService.startSpinner('loader');
        this.setupForPaymentRequest = new SetupForPaymentRequest();
        this.setupForPaymentRequest.paymentType = "ALL";
        this.paymentsService.paymentSetup(this.setupForPaymentRequest)
            .subscribe(
                resp => this.handlePaymentSetupResp(resp),
                error => this.sharedService.handleError(error)
            );
    }

    handlePaymentSetupResp(resp:any){
        this.spinnerService.stopSpinner('loader');
        if (resp.result.status == "success") {
            this.setupForPaymentResponse = new SetupForPaymentResponse();
            this.setupForPaymentResponse = resp;
            //this.executePaymentRequest.accountOrCardNo= this.setupForPaymentResponse.fundingSources[0].prodRef;
            this.executePaymentRequest.accountOrCardNo="";
            this.paymentLimit = this.setupForPaymentResponse.paymentLimits[this.templateService.getSelectIndex(this.setupForPaymentResponse.paymentLimits,'paymentType',this.executePaymentRequest.agency)];
        }else if (resp.result.status == 'error') {
            this.errorService.setErrorResp(resp.result);
        }
    }

    validateAddBillerForm(data:any){
    	this.fetchBalanceForPaymentResponse = data.fetchBalanceForPaymentResponse;
    	this.salikAutoBy = data.salikAutoBy;
        if(this.executePaymentRequest.createBiller){
        	this.verifyBillerBeneficiary();
        }else{
          this.stepValue = 2;
        }
    }

    verifyBillerBeneficiary(){
      this.errorService.resetErrorResp();
      this.spinnerService.startSpinner('loader');
      this.validatebillerBeneReq  =  new ValidateBeneficiaryRequest();
      this.validatebillerBeneReq.paymentTypes = this.executePaymentRequest.agency;
      this.validatebillerBeneReq.consumerNo = this.executePaymentRequest.consumerNo;
      this.validatebillerBeneReq.operation  = GlobalVariable.OPERATION_TYPE.ADD;
      this.validatebillerBeneReq.accountOrCardNo  = this.executePaymentRequest.accountOrCardNo;
      this.validatebillerBeneReq.nickName = this.executePaymentRequest.nickName;
      this.paymentsService.validateBillerBeneficary(this.validatebillerBeneReq)
            .subscribe(
                resp => this.handleValidateBeneResp(resp),
                error => this.sharedService.handleError(error)
            );
    }

    handleValidateBeneResp(resp:APIResponse){
      this.spinnerService.stopSpinner('loader');
      if (resp.result.status == "success") {
          this.stepValue = 2;
      }else if (resp.result.status == 'error') {
          this.errorService.setErrorResp(resp.result);
      }
    }

    confirmBillerReviewButton(){
      this.errorService.resetErrorResp();
      this.spinnerService.startSpinner('loader');
      this.triggerOTP();
    }

    triggerOTP(){
        this.sendOtpRequest = new SendOtpRequest();
        this.sendOtpRequest.txnRef = this.setupForPaymentResponse.txnRef;
        this.sendOtpRequest.txnCode = GlobalVariable.TRANSACTION_CODES['BENEF_ADD_'+this.executePaymentRequest.agency+'_BILLPAYMENT'];
        this.sharedService.sendOTP(this.sendOtpRequest)
          .subscribe(
              resp => this.handleSendOTPResp(resp),
              error => this.sharedService.handleError(error)
          );
    }

    handleSendOTPResp(resp:SendOtpResponse){
      this.spinnerService.stopSpinner('loader');
      if (resp.result.status == "success") {
          this.sendOtpResponse = new SendOtpResponse();
          this.sendOtpResponse = resp;
          this.stepValue = 3;
      }else if (resp.result.status == 'error') {
          this.errorService.setErrorResp(resp.result);
      }
    }

    backBillerReviewButton(){
        this.stepValue = 1;
    }

    validateOTP(otp: string){
        if(otp){
            this.executePaymentRequest.authKey = otp;
            this.errorService.resetErrorResp();
            this.spinnerService.startSpinner('loader');
            if(this.salikAutoBy =="date" && this.executePaymentRequest.agency=="SALIK"
                     && this.executePaymentRequest.minAmount){
              delete this.executePaymentRequest.minAmount;
            }
            this.executePaymentRequest.txnRef = this.setupForPaymentResponse.txnRef;
            this.paymentsService.executePayment(this.executePaymentRequest)
                .subscribe(
                    resp => this.handleAddBeneResp(resp),
                    error => this.sharedService.handleError(error)
            );
        }  
    }

    handleAddBeneResp(resp:ExecutePaymentResponse){
      this.spinnerService.stopSpinner('loader');
      this.executePaymentResponse = new ExecutePaymentResponse();
      this.executePaymentResponse = resp;
      if (resp.result.status == "success") {
          this.stepValue = 4;
      }else if (resp.result.status == 'error') {
         let nextStep = this.errorService.handleOTPError(resp.result);
            if(nextStep) {
                this.stepValue = 4;
            }
      }
    }

    backOTPButton(){
        this.stepValue = 2;
    }
}
