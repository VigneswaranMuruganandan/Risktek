import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { Router } from '@angular/router';
import { GlobalVariable} from '../../shared/services/global';
import { ExecutePaymentRequest} from '../model/executePaymentRequest';
import { TemplateService} from '../../shared/services/template.service';
import { SetupForPaymentResponse} from '../model/setupForPaymentResponse';
import { FetchBalanceForPaymentRequest } from '../model/fetchBalanceForPaymentRequest';
import { FetchBalanceForPaymentResponse } from '../model/fetchBalanceForPaymentResponse';
import { PaymentsService} from '../services/payments.service';
import { SharedService} from '../../shared/services/shared.service';
import { ErrorService } from '../../shared/services/error.service';
import { SpinnerService } from '../../shared/services/spinner.service';

@Component({
  selector: 'addPaymentStep1-component',
  templateUrl: './../templates/addPaymentStep1.html'
})
export class AddPaymentStep1Component implements OnInit{

	@Input() billerTypes:any;
	@Input() executePaymentRequest:ExecutePaymentRequest;
	@Input() setupForPaymentResponse:SetupForPaymentResponse;
  @Input() createBillerBeneficiary:boolean;
	@Output() validateAddBillerFormEvent = new EventEmitter();
	public fetchBalanceForPaymentRequest:FetchBalanceForPaymentRequest;
  public fetchBalanceForPaymentResponse:FetchBalanceForPaymentResponse;
	public billerDescription:any;
	public temp : any = {};
  public imageUrl:any;
	

	constructor( public templateService: TemplateService,
				       private paymentsService:PaymentsService,
				       private sharedService: SharedService,
               private errorService: ErrorService,
               private spinnerService: SpinnerService) {}

	ngOnInit() { 
      if(!this.createBillerBeneficiary){
        this.verifyConsumerNumber();
      }else{
        this.executePaymentRequest.agency=this.billerTypes[0].paymentTransferName;
      }
      this.imageUrl = GlobalVariable.IMAGE_URL;
      this.temp.salikAutoBy = "amount";
      this.billerDescription = GlobalVariable.BILLER_DESCRIPTION;
    }

    balanceEnquiry(){
      if(this.executePaymentRequest.consumerNo && this.executePaymentRequest.consumerNo.length >0){
        this.verifyConsumerNumber();
      }
    }

    billerSelectionChange(){
    	this.executePaymentRequest.consumerNo="";
    	if(this.fetchBalanceForPaymentResponse){
    		this.fetchBalanceForPaymentResponse.amountDue.valueFmt ="";
    		this.executePaymentRequest.transactionAmount=0;
    		this.executePaymentRequest.salikPinNo = "";
    	}
    }


    verifyConsumerNumber(){
      this.spinnerService.startSpinner('loader');
      this.errorService.resetErrorResp();
      this.fetchBalanceForPaymentRequest = new FetchBalanceForPaymentRequest();
      this.fetchBalanceForPaymentRequest.agency = this.executePaymentRequest.agency;
      this.fetchBalanceForPaymentRequest.consumerNo = this.executePaymentRequest.consumerNo;
      this.fetchBalanceForPaymentRequest.telephoneNo = this.executePaymentRequest.consumerNo;
      if(this.executePaymentRequest.agency=='SALIK'){
          this.fetchBalanceForPaymentRequest.salikPinNo = this.executePaymentRequest.salikPinNo;
      }
      this.paymentsService.balanceEnquiryForPayment(this.fetchBalanceForPaymentRequest)
                .subscribe(
                    resp => this.handleBalanceEnqResp(resp),
                    error => this.sharedService.handleError(error)
            );
    }

    handleBalanceEnqResp(resp:FetchBalanceForPaymentResponse){
      this.spinnerService.stopSpinner('loader');
        if (resp.result.status == "success") {
            this.fetchBalanceForPaymentResponse = new FetchBalanceForPaymentResponse();
            this.fetchBalanceForPaymentResponse = resp;
            this.executePaymentRequest.transactionAmount = this.fetchBalanceForPaymentResponse.amountDue.value;
            this.executePaymentRequest.transactionId = this.fetchBalanceForPaymentResponse.transactionID;
            this.executePaymentRequest.availableBalance = this.fetchBalanceForPaymentResponse.availableBalance.value;
            this.executePaymentRequest.amountDue = this.fetchBalanceForPaymentResponse.amountDue.value;
            (<any>$('#paymentNext')).removeClass('disabled');
        }else if (resp.result.status == 'error') {
            this.errorService.setErrorResp(resp.result);
            //this.executePaymentRequest.transactionAmount = 0;
        }
    }

  	validateBillerForm(valid:boolean){
  		if(valid){
          this.templateService.resetFormValidatorFlag();
          this.validateAddBillerFormEvent.emit(this.temp.salikAutoBy);
      }  
  	}
    
}
