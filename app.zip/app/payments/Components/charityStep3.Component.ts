import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    TranslateService,
    StaticDataResponse, 
    StaticData,
    GlobalVariable,
    Product
} from '../../shared';
import { ExecuteCharityPaymentRequest} from '../model/executeCharityPaymentRequest';
import { SetupForCharityResponse} from '../model/setupForCharityResponse';

@Component({
  selector: 'charitystep3-component',
  templateUrl: './../templates/charityStep3.html'
})
export class CharityStep3Component implements OnInit {
	@Output() reviewCharityPaymentEvent = new EventEmitter();
	@Output() backbuttonCharityEvent = new EventEmitter();
    @Output() resetCharityEvent = new EventEmitter();
	@Input() charityItems :StaticDataResponse;
    @Input() charityPaymentRequest :ExecuteCharityPaymentRequest;
    @Input() setupForCharityResponse :SetupForCharityResponse;
    public GlobalVariable :any
    product :Product;

    constructor( private errorService: ErrorService,
				 private sharedService: SharedService,
				 public templateService: TemplateService){}

	ngOnInit() {
		this.product = this.setupForCharityResponse.fundingSources[this.templateService.getSelectIndex(this.setupForCharityResponse.fundingSources,'prodRef',this.charityPaymentRequest.sourceAccountNumber)];
        this.GlobalVariable = GlobalVariable;
	}

	reviewCharity(){
		this.reviewCharityPaymentEvent.emit();
	}

	removeCharity(){
		this.resetCharityEvent.emit();
	}

    back(){
        this.backbuttonCharityEvent.emit(2);
    }
}