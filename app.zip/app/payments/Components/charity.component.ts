import { Component, OnInit, Input} from '@angular/core';
import { 
    GlobalVariable, 
    SendOtpRequest, SendOtpResponse, AppSession,
    StaticDataResponse, 
    StaticData, 
    SharedService, 
    TemplateService, 
    ErrorService,
    SpinnerService 
} from '../../shared';
import { SetupForCharityResponse} from '../model/setupForCharityResponse';
import { ExecuteCharityPaymentRequest} from '../model/executeCharityPaymentRequest';
import { ExecutePaymentResponse} from '../model/executePaymentResponse';
import { PaymentsService } from '../services/payments.service';

@Component({
  templateUrl: './../templates/charity.html'
})
export class CharityComponent implements OnInit{
	public stepValue: number;
	public charityItems: StaticDataResponse;    
    public setupForCharityResponse :SetupForCharityResponse;
    public charityPaymentRequest :ExecuteCharityPaymentRequest;
    public charityPaymentResponse :ExecutePaymentResponse;
    public sendOtpRequest:SendOtpRequest;
    public sendOtpResponse:SendOtpResponse;

    constructor( private paymentsService: PaymentsService, 
                 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService) {}

	ngOnInit() { 
    	this.init();
    }

    init(){
        this.stepValue = 1;
        this.errorService.resetErrorResp();
        this.fetchCharityList();
        this.fetchSetupCharity();
        this.charityPaymentRequest = new ExecuteCharityPaymentRequest();
    }

    fetchCharityList(){
        this.spinnerService.startSpinner('charity');
        this.paymentsService.setupCharityList()
            .subscribe(
                resp => this.handleSetupCharityList(resp),
                error => this.sharedService.handleError(error)
            );
    }

    handleSetupCharityList(resp :StaticDataResponse){
        this.spinnerService.stopSpinner('charity');
        if(resp.result.status == 'success'){
            this.charityItems = new StaticDataResponse();
            this.charityItems = resp;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
            
        }
    }

    fetchSetupCharity(){
        this.paymentsService.setupCharity()
            .subscribe(
                resp => this.handleSetupCharity(resp),
                error => this.sharedService.handleError(error)
            );
    }

    handleSetupCharity(resp :SetupForCharityResponse){
        if(resp.result.status == 'success'){
            this.setupForCharityResponse = new SetupForCharityResponse();
            this.setupForCharityResponse = resp;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);            
        }
    }

    charitySelection(){
    	this.stepValue = 2;
    }

    submitCharityPayment(){
    	this.stepValue = 3;
    }

    reviewCharityPayment(){
        this.spinnerService.startSpinner('charity');
        this.sendOtpRequest = new SendOtpRequest();
        this.sendOtpRequest.txnCode = GlobalVariable.TRANSACTION_CODES.CHARITY_PAYMENT;
        this.sendOtpRequest.txnRef = this.setupForCharityResponse.txnRef;
        if(AppSession.getInstance().auth2Factor == GlobalVariable.AUTH2FACTOR[0]){
            this.sharedService.sendOTP(this.sendOtpRequest)
                .subscribe(
                    resp => this.handleSendOtpResp(resp),
                    error => this.sharedService.handleError(error)
                );
        }else{
            this.stepValue = 4;
        }
    }

    handleSendOtpResp(resp :SendOtpResponse){
    this.spinnerService.stopSpinner('charity');        
        if(resp.result.status == 'success'){
            this.sendOtpResponse = new SendOtpResponse();
            this.sendOtpResponse = resp;
            this.stepValue = 4;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
    }

    validateCharityOTP(otp :string){
        this.spinnerService.startSpinner('charity');
        if(otp){
            this.charityPaymentRequest.authKey = otp;
            this.charityPaymentRequest.txnRef = this.setupForCharityResponse.txnRef;
            this.paymentsService.executeCharityPayment(this.charityPaymentRequest)
            .subscribe(
                resp => this.handleExecuteCharityPayment(resp),
                error => this.sharedService.handleError(error)
            );
        }    	
    }

    handleExecuteCharityPayment(resp :ExecutePaymentResponse){
        this.spinnerService.stopSpinner('charity');
        this.charityPaymentResponse = resp;
        if(resp.result.status == 'success'){
            this.stepValue = 5;
        }else if(resp.result.status == 'error'){
            let nextStep = this.errorService.handleOTPError(resp.result);
            if(nextStep) {
                this.stepValue = 5;
            }            
        }
    }

    backbuttonCharity(step :number){
        if(step){
            this.stepValue = step;
        }
    }

    resetCharity(){
        this.stepValue = 1;
        this.errorService.resetErrorResp();
        this.charityPaymentRequest = new ExecuteCharityPaymentRequest();
    }

    reloadCharity(){
        this.init();
    }
}