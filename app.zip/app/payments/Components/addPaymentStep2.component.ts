import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { Router } from '@angular/router';
import { ExecutePaymentRequest} from '../model/executePaymentRequest';
import { GlobalVariable} from '../../shared/services/global';
import { Product } from '../../shared/model/product';
import { SetupForPaymentResponse} from '../model/setupForPaymentResponse';
import { TemplateService } from '../../shared/services/template.service';

@Component({
  selector: 'addPaymentStep2-component',
  templateUrl: './../templates/addPaymentStep2.html'
})
export class AddPaymentStep2Component implements OnInit  {

	public imageUrl:any;

	@Output() confirmBillerReviewButtonEvent = new EventEmitter();
	@Output() backBillerReviewButtonEvent = new EventEmitter();
	@Input() salikAutoBy:string;
	@Input() executePaymentRequest:ExecutePaymentRequest;
	@Input() setupForPaymentResponse:SetupForPaymentResponse;
	public product:Product;

	constructor( public templateService: TemplateService){}

	ngOnInit() { 
	  this.imageUrl = GlobalVariable.IMAGE_URL;
	  this.product = this.setupForPaymentResponse.fundingSources[this.templateService.getSelectIndex(this.setupForPaymentResponse.fundingSources,'prodRef',this.executePaymentRequest.accountOrCardNo)];
	  this.executePaymentRequest.productType = this.product.productType;
	}
	
	confirmBillerReview(){
		this.confirmBillerReviewButtonEvent.emit();
	}

	backBillerReview(){
		this.backBillerReviewButtonEvent.emit();
	}
    

    
}
