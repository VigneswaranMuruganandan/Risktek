import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { routing } from './payments.routing';
import { TranslateModule } from '@ngx-translate/core';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { SharedModule } from '../shared/shared.module';
import { SharedService} from '../shared/services/shared.service';
import { TemplateService} from '../shared/services/template.service';
import { PaymentsService} from './services/payments.service';
import { FormsModule } from '@angular/forms';
import { CharityComponent } from './Components/charity.component';
import { CharityStep1Component }   from './Components/charityStep1.Component';
import { CharityStep2Component }   from './Components/charityStep2.Component';
import { CharityStep3Component }   from './Components/charityStep3.Component';
import { CharityStep4Component }   from './Components/charityStep4.Component';
import { CharityStep5Component }   from './Components/charityStep5.Component';
import { PaymentsComponent } from './Components/payments.component';
import { PaymentsTransactionsComponent }   from './Components/paymentsTransactions.component';
import { AddPaymentComponent } from './Components/addPayment.component';
import { AddPaymentStep1Component }   from './Components/addPaymentStep1.Component';
import { AddPaymentStep2Component }   from './Components/addPaymentStep2.Component';
import { AddPaymentStep3Component }   from './Components/addPaymentStep3.Component';
import { AddPaymentStep4Component }   from './Components/addPaymentStep4.Component';
import { 
  ValidateAddPayment, ValidateCharityDirective
 } from './directives/validatePayments.directive';


const PAYMENTS_COMPONENTS = [
    CharityComponent,
    CharityStep1Component,
    CharityStep2Component,
    CharityStep3Component,
    CharityStep4Component,
    CharityStep5Component,
    PaymentsComponent,
    PaymentsTransactionsComponent,
    AddPaymentComponent,
    AddPaymentStep1Component,
    AddPaymentStep2Component,
    AddPaymentStep3Component,
    AddPaymentStep4Component
];

const PAYMENTS_PROVIDERS = [
   SharedService,
   TemplateService,
   PaymentsService
];

const PAYMENTS_DIRECTIVES = [
   ValidateAddPayment,
   ValidateCharityDirective
];


@NgModule({
  	imports: [
	    routing,
	    TranslateModule.forChild(),
	    SharedModule,
	    FormsModule,
		  CommonModule,
      NgxDatatableModule
	],
  	declarations: [
	    ...PAYMENTS_COMPONENTS,
      ...PAYMENTS_DIRECTIVES
	],
  	providers: [
  		...PAYMENTS_PROVIDERS
  	]
})
export class PaymentsModule {}
