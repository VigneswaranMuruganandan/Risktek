import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { LeadRequest } from '../../investments/model/leadRequest';
import { 
    GlobalVariable, 
    AppSession
} from '../../shared';

@Component({
  selector: 'applyForNewCardStep3-component',
  templateUrl: './../templates/applyForNewCardStep3.html'
})
export class ApplyForNewCardStep3Component {
	@Input() applyforProduct: LeadRequest;
	@Input() leadResponse: any;
	public routeMapping = GlobalVariable.ROUTE_MAPPING;

}