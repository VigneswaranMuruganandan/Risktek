import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { LeadRequest } from '../../investments/model/leadRequest';

@Component({
  selector: 'applyForNewLoanStep2-component',
  templateUrl: './../templates/applyForNewLoanStep2.html'
})
export class ApplyForNewLoanStep2Component {
	@Input() applyforProduct: LeadRequest;
	@Output() reviewApplyForProductEvent = new EventEmitter();
	@Output() backApplyForProductEvent = new EventEmitter();
	
	review(){
		this.reviewApplyForProductEvent.emit();
	}

	back(){
		this.backApplyForProductEvent.emit(1);
	}
}