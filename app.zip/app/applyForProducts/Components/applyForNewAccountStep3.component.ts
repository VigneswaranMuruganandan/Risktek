import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { LeadRequest } from '../../investments/model/leadRequest';
import { 
    GlobalVariable, 
    AppSession
} from '../../shared';



@Component({
  selector: 'applyForNewAccountStep3-component',
  templateUrl: './../templates/applyForNewAccountStep3.html'
})
export class ApplyForNewAccountStep3Component {
	@Input() applyforProduct: LeadRequest;
	@Input() leadResponse: any;
	public routeMapping = GlobalVariable.ROUTE_MAPPING;
}