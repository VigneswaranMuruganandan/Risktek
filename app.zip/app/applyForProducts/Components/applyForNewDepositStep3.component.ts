import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { LeadRequest } from '../../investments/model/leadRequest';
import { 
    GlobalVariable, 
    AppSession
} from '../../shared';

@Component({
  selector: 'applyForNewDepositStep3-component',
  templateUrl: './../templates/applyForNewDepositStep3.html'
})
export class ApplyForNewDepositStep3Component {
	@Input() applyforProduct: LeadRequest;
	@Input() leadResponse: any;
	public routeMapping = GlobalVariable.ROUTE_MAPPING;

}