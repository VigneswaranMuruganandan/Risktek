import { Component, OnInit, Input} from '@angular/core';
import { LeadRequest } from '../../investments/model/leadRequest';
import { 
    GlobalVariable, 
    SendOtpRequest, SendOtpResponse, AppSession,
    Entity,
    StaticDataResponse, 
    StaticData, 
    SharedService, 
    TemplateService, 
    ErrorService,
    SpinnerService ,
    Router
} from '../../shared';

@Component({
  templateUrl: './../templates/baseApplyForNewCard.html'
})
export class BaseApplyForNewCardComponent implements OnInit {
	public stepValue :number;
    public applyforProduct :LeadRequest;
    public staticData : Map<string,Array<StaticData>>;
    public leadResponse :any;

	constructor( private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService,
                 private router: Router) {}

	ngOnInit() {
        this.initCard();
    }

    initCard(){
        this.errorService.resetErrorResp();
        this.stepValue = 1;
        this.applyforProduct = new LeadRequest();
        this.staticData = StaticDataResponse.getInstance().staticMasterDataMap;
        this.applyforProduct.productType = 'CREDIT_CARDS';
    }

    validateApplyForProduct(){
    	this.stepValue = 2;
    }

    reviewApplyForProduct(){
        this.spinnerService.startSpinner('loader');
        this.sharedService.saveLead(this.applyforProduct)
            .subscribe(
                resp => this.handleApplyProducts(resp),
                error => this.sharedService.handleError(error)
            );
    }

    handleApplyProducts(resp :any){
        this.spinnerService.stopSpinner('loader');        
        if(resp && resp.result.status == 'success'){
            this.stepValue = 3;
            this.leadResponse = resp;
        }else if(resp && resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
    }

    backApplyForProduct(value :number){
        if(value){
            this.stepValue = value;
        }
    }
}