import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { TemplateService} from '../../shared/services/template.service';
import { LeadRequest } from '../../investments/model/leadRequest';
import { 
    GlobalVariable,
    StaticDataResponse, 
    StaticData
} from '../../shared';

@Component({
  selector: 'applyForNewDepositStep1-component',
  templateUrl: './../templates/applyForNewDepositStep1.html'
})
export class ApplyForNewDepositStep1Component {
	@Input() applyforProduct: LeadRequest;
	@Input() staticData : Map<string,Array<StaticData>>;
	@Output() validateApplyForProductEvent = new EventEmitter();
	
	constructor( public templateService: TemplateService){}

	validate(valid :boolean){
		if(valid){
			this.validateApplyForProductEvent.emit();	
		}	
	}
}