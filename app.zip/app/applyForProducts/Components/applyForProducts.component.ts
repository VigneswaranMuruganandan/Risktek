import { Component, OnInit, Input} from '@angular/core';
import { 
    GlobalVariable, 
    SendOtpRequest, SendOtpResponse, AppSession,
    StaticDataResponse, 
    StaticData, 
    SharedService, 
    TemplateService, 
    ErrorService,
    SpinnerService ,
    Router
} from '../../shared';

@Component({
  templateUrl: './../templates/applyForProducts.html'
})
export class ApplyForProductsComponent {
	public url :string; 
	constructor( private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService,
                 private router: Router) {}

	ngOnInit() {}

	applyForProducts(type :string){
		if(type){
			switch (type) {
			    case 'ACCOUNT':
			        this.url = GlobalVariable.ROUTE_MAPPING.APPLYFORPRODUCTSACCOUNT;
			        break;
			    case 'CARD':
			        this.url = GlobalVariable.ROUTE_MAPPING.APPLYFORPRODUCTSCARD;
			        break;
			    case 'DEPOSIT':
			        this.url = GlobalVariable.ROUTE_MAPPING.APPLYFORPRODUCTSDESPOSIT;
			        break;
			    case 'LOAN':
			        this.url = GlobalVariable.ROUTE_MAPPING.APPLYFORPRODUCTSLOAN;
			        break;
			    case 'INVESTMENT':
			        this.url = GlobalVariable.ROUTE_MAPPING.APPLY_FOR_AN_INVESTMENT;
			        break;
			    case 'ISAVE':
			        this.url = GlobalVariable.ROUTE_MAPPING.ISAVE_WELCOME;
			        break;
			}
			this.router.navigate([this.url]);
		}
	}
}