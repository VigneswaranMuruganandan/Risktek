import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { LeadRequest } from '../../investments/model/leadRequest';
import { 
    GlobalVariable, 
    AppSession
} from '../../shared';

@Component({
  selector: 'applyForNewLoanStep3-component',
  templateUrl: './../templates/applyForNewLoanStep3.html'
})
export class ApplyForNewLoanStep3Component {
	@Input() applyforProduct: LeadRequest;
	@Input() leadResponse: any;

	public routeMapping = GlobalVariable.ROUTE_MAPPING;

}