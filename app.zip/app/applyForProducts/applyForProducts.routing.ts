import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ApplyForProductsComponent } from './Components/applyForProducts.component';
import { BaseApplyForNewAccountComponent } from './Components/baseApplyForNewAccount.component';
import { BaseApplyForNewCardComponent } from './Components/baseApplyForNewCard.component';
import { BaseApplyForNewLoanComponent } from './Components/baseApplyForNewLoan.component';
import { BaseApplyForNewDepositComponent } from './Components/baseApplyForNewDeposit.component';
import { AuthGuard } from '../auth-guard.service';

const routes: Routes = [
	{
        path: '',
        component: ApplyForProductsComponent
    },
    {
        path: 'account',
        component: BaseApplyForNewAccountComponent
    },
    {
        path: 'card',
        component: BaseApplyForNewCardComponent
    },
    {
        path: 'loan',
        component: BaseApplyForNewLoanComponent
    },
    {
        path: 'desposit',
        component: BaseApplyForNewDepositComponent
    },
    {
	    path: '',
	    redirectTo: '',
	    pathMatch: 'full'
	}
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);