export class FTDetailReq {
	accountNo:string;
	transactionId:string;
}

