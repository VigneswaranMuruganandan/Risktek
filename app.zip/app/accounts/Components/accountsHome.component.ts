import { Component, OnInit, Input,ViewChild} from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { Router } from '@angular/router';
import { AccountsService} from '../services/accounts.service';
import { SharedService} from '../../shared/services/shared.service';
import { Account } from '../../shared/model/account';
import { CustomerAccountsResponse} from '../model/customerAccountsResponse';
import { ErrorService } from '../../shared/services/error.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { AppSession} from '../../shared/model/appSession';
import { UpdateFavoritesProduct } from '../../dashboard/model/updateFavoritesProduct';


@Component({
    templateUrl: './../templates/accountsHome.html'
})
export class AccountsHomeComponent implements OnInit {

    public customerAccountsResponse: CustomerAccountsResponse;
    public account: Account;
    public accountsList:Account[];
    public productNameList:any=[];
    @ViewChild('table') tableElem: any;
    temp: any = [];
    rows: any = [];
    appSession: AppSession;

    constructor( private accountsService: AccountsService,
                 private sharedService: SharedService,
                 private errorService: ErrorService,
                 private spinnerService: SpinnerService,
                 private router: Router) {}

    ngOnInit() {
        this.spinnerService.startSpinner('loader');
        this.fetchAccounts();
        this.errorService.resetErrorResp();
    }

    /*
     * Fetch all Accounts of the customer
     */
    fetchAccounts() {
        this.accountsService.fetchCustomerAccounts()
          .subscribe(
              resp => this.handleCustAcctsResp(resp),
              error => this.sharedService.handleError(error)
          );
    }
    /*
     * Handle Accounts Response
     */
    private handleCustAcctsResp(resp: CustomerAccountsResponse) {
        this.spinnerService.stopSpinner('loader');
        if (resp.result.status == "success") {
            this.customerAccountsResponse = new CustomerAccountsResponse();
            this.customerAccountsResponse = resp;
            this.initTableData(this.customerAccountsResponse.customerProducts.accounts);
            let account;
            if (this.customerAccountsResponse.customerProducts.accounts &&
                this.customerAccountsResponse.customerProducts.accounts.length > 0) {
                  this.accountsList = this.customerAccountsResponse.customerProducts.accounts;
                  this.fetchProductNames();
            }
        } else if (resp.result.status == 'error') {
            this.errorService.setErrorResp(resp.result);
        }
    }

    /*
     * Fetch Different Product Name: Used for Filter
     */
    fetchProductNames(){
        for(let acc of this.customerAccountsResponse.customerProducts.accounts){
            if ($.inArray(acc.productName, this.productNameList) < 0) {
              this.productNameList.push(acc.productName);
            }
        }
    }

    /*
     * On click of account should be redirected to Accounts Detail page
     */
    accountDetail(account:any){
      AppSession.getInstance().dashboardAccount = account.number;
      this.router.navigate(['/accounts/accountDetail']);
    }

    /*
     * Init List View Table 
     */
    initTableData(accountList:any){
      this.rows=accountList;
      this.temp=accountList;
      this.tableElem.offset = 0;
    }

    /*
     * Onclick:Toggle List / Grid View
     */
    listView(event){
      $('#grid-filter').show();
      $(event.currentTarget).hide();
      $('.grid-wrapper-acc').hide();
      $('.list-wrapper-acc').show();
    }

    /*
     * Onclick:Toggle List / Grid View
     */
    gridView(event){
      $('#list-filter').show();
      $(event.currentTarget).hide();
      $('.grid-wrapper-acc').show();
      $('.list-wrapper-acc').hide();
    }

    /*
     * Accounts Filter
     */
    accountfilter(event,productName:string){
    if(productName!=="ALL"){
        this.accountsList = this.temp.filter(acc => acc.productName == productName);
        this.rows = this.accountsList;
        $( "#dropdownMenuAccounts" ).html(event.currentTarget.text);
        this.tableElem.offset = 0;
    }else{
        this.accountsList = this.temp;
        this.rows = this.accountsList;
        $( "#dropdownMenuAccounts" ).html(event.currentTarget.text);
        this.tableElem.offset = 0;
    }
  }
    
}
