import { Component, OnInit, Input,EventEmitter,Output} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { GlobalVariable} from '../../shared/services/global';
import { Router } from '@angular/router';

@Component({
  selector: '[accounts-rightcontent]',
  templateUrl: './../templates/accountsRightContent.html'
})
export class AccountsRightContentComponent {
	@Output() carouselAccountEvent = new EventEmitter();
	@Input() accountsData:any;

	constructor(private router: Router) {}

	redirectTo(module:string){
		switch (module) {
			case "AccountSetting":
				this.router.navigate([GlobalVariable.ROUTE_MAPPING.ACCOUNT_SETTINGS]);
				break;
			case "ChequeBook":
				this.router.navigate([GlobalVariable.ROUTE_MAPPING.CHEQUE_BOOK_REQUEST]);
				break;
			case "Transfer":
				this.router.navigate([GlobalVariable.ROUTE_MAPPING.TRANSFER_MONEY]);
				break;
			case "Payment":
				this.router.navigate([GlobalVariable.ROUTE_MAPPING.PAYMENTS]);
				break;	
			default:
				this.router.navigate([GlobalVariable.ROUTE_MAPPING.DASHBOARD]);
				break;
		}
	}

	viewAllAccounts(){
		this.router.navigate([GlobalVariable.ROUTE_MAPPING.MY_ACCOUNTS]);
	}

	carouselAccount(account:any){
	  this.carouselAccountEvent.emit(account);
	}

}