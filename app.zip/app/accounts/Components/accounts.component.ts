import { Component, OnInit, Input,ViewChild} from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { Router } from '@angular/router';
import { AccountsService} from '../services/accounts.service';
import { SharedService} from '../../shared/services/shared.service';
import { Account } from '../../shared/model/account';
import { CustomerAccountsResponse} from '../model/customerAccountsResponse';
import { AccountDetailsResponse} from '../model/accountDetailsResponse';
import { ErrorService } from '../../shared/services/error.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { AppSession} from '../../shared/model/appSession';
import { AccountsTransactionsComponent} from './accountsTransactions.component';
import { AccountTransactionsResp } from '../model/accountTransactionsResp';
import { UpdateFavoritesProduct } from '../../dashboard/model/updateFavoritesProduct';
import { TemplateService } from '../../shared/services/template.service';
import { GlobalVariable} from '../../shared/services/global';

@Component({
    templateUrl: './../templates/accounts.html'
})
export class AccountsComponent implements OnInit {
    @ViewChild(AccountsTransactionsComponent) accountsTransactionsComponent: AccountsTransactionsComponent;
    customerAccountsResponse: CustomerAccountsResponse;
    accountDetailsResponse: AccountDetailsResponse;
    accountTransactionsResp: AccountTransactionsResp;
    accountsList:Account[];
    carouselAccountList: any;
    account: Account;
    appSession: AppSession;
    makePaymentRoute:string;
    makeTransferRoute:string;

    constructor( private accountsService: AccountsService,
                 private sharedService: SharedService,
                 private errorService: ErrorService,
                 private spinnerService: SpinnerService,
                 public templateService: TemplateService,
                 private router: Router) {}

    ngOnInit() {
        this.spinnerService.startSpinner('loader');
        this.fetchAccounts();
        this.errorService.resetErrorResp();
        this.appSession = AppSession.getInstance();
        this.makePaymentRoute = GlobalVariable.ROUTE_MAPPING.PAYMENTS;
        this.makeTransferRoute = GlobalVariable.ROUTE_MAPPING.TRANSFER_MONEY;
    }

    /*
     * Fetch all Accounts of the customer
     */
    fetchAccounts() {
        this.accountsService.fetchCustomerAccounts()
          .subscribe(
              resp => this.handleCustAcctsResp(resp),
              error => this.sharedService.handleError(error)
          );
    }
    /*
     * Handle Accounts Response
     */
    private handleCustAcctsResp(resp: CustomerAccountsResponse) {
        if (resp.result.status == "success") {
            this.customerAccountsResponse = new CustomerAccountsResponse();
            this.customerAccountsResponse = resp;
            let account;
            if (this.customerAccountsResponse.customerProducts.accounts &&
                this.customerAccountsResponse.customerProducts.accounts.length > 0) {
                this.accountsList = this.customerAccountsResponse.customerProducts.accounts;
                if (this.appSession.dashboardAccount && this.appSession.dashboardAccount != "") {
                    let dashBoardAccount = this.accountsList.filter(accountItem => accountItem.number == this.appSession.dashboardAccount);
                    account = dashBoardAccount[0];
                    this.appSession.dashboardAccount = "";
                } else {
                    account = this.accountsList[0];
                }
                this.accountToBeDisplayed(account);
            }
        } else if (resp.result.status == 'error') {
            this.errorService.setErrorResp(resp.result);
        }
    }
    /*
     * Initialise the Account To be displayed 
     * and update rest Accounts in carousel
     */
    accountToBeDisplayed(account: Account) {
        this.account = account;
        this.updateCarouselAccounts(account);
        this.getAccountDetails(account);
        this.getAccountTransactions(account);
    }
    updateCarouselAccounts(account: Account) {
        let accountsList = this.customerAccountsResponse.customerProducts.accounts;
        this.carouselAccountList = accountsList.filter(accountItem => accountItem.number !== account.number);
    }
    /*
     * Fetch Account Details
     */
    getAccountDetails(account: Account) {
        this.spinnerService.startSpinner('loader');
        let data = { accountId: "" };
        data.accountId = account.number;
        this.errorService.resetErrorResp();
        this.accountsService.fetchAccountDetails(data)
          .subscribe(
              resp => this.handleAcctDetailResp(resp),
              error => this.sharedService.handleError(error)
          );
    }
    /*
     * Handle Account Detail Response
     */
    private handleAcctDetailResp(resp: AccountDetailsResponse) {
        this.spinnerService.stopSpinner('loader');
        if (resp.result.status == "success") {
            this.accountDetailsResponse = new AccountDetailsResponse();
            this.accountDetailsResponse = resp;
            this.accessControl();
        } else {
            this.errorService.setErrorResp(resp.result);
        }
    }

    /*
     * View More details
     */
    viewMoreDetails (){
        $('.more-details').slideToggle();
    }

    /*
     * Fetch Account Transactions 
     */
    getAccountTransactions(account: Account) {
        let data = { accountId: "" };
        data.accountId = account.number;
        this.errorService.resetErrorResp();
        this.accountsTransactionsComponent.loadingTransactions = true;
        this.accountsService.fetchAccountTransactions(data)
          .subscribe(
              resp => this.handleAcctTransactionsResp(resp),
              error => this.sharedService.handleError(error)
          );
    }
    /*
     * Handle Account Transactions Response
     */
    private handleAcctTransactionsResp(resp: AccountTransactionsResp) {
        //this.spinnerService.stopSpinner('loader');
        this.accountsTransactionsComponent.loadingTransactions = false;
        if (resp.result.status == "success") {
            this.accountTransactionsResp = new AccountTransactionsResp();
            this.accountTransactionsResp = resp;
        } else {
            this.errorService.setErrorResp(resp.result);
            this.accountsTransactionsComponent.rows = [];
        }
    }
    /*
     * On click of any Carousel Account
     */
    carouselAccountSelection(account: Account) {
        this.spinnerService.startSpinner('loader');
        this.accountToBeDisplayed(account);
    }

    /*
     * Set Account has Favourite
     */
    favouriteSelectedAccount(){
      this.spinnerService.startSpinner('loader');
      if(this.account){
        let updateFavoritesProduct = new UpdateFavoritesProduct();
        updateFavoritesProduct.productRef = this.account.number;
        updateFavoritesProduct.favoriteState = !this.account.isFavorite;
        this.sharedService.unFavouriteProduct(updateFavoritesProduct)
            .subscribe(
                resp => {
                    this.spinnerService.stopSpinner('loader');
                    if(resp && resp.result.status == "success"){
                      this.account.isFavorite = updateFavoritesProduct.favoriteState;
                      let index= this.templateService.getSelectIndex(this.customerAccountsResponse.customerProducts.accounts,'number',this.account.number);
                      this.customerAccountsResponse.customerProducts.accounts[index].isFavorite = this.account.isFavorite;
                    }
                },
                error => this.sharedService.handleError(error)
            );
      }
    }

    /*
     * Click of Next account
     */
     nextAccount(){
       let index= this.templateService.getSelectIndex(this.customerAccountsResponse.customerProducts.accounts,'number',this.account.number);
       this.account = this.customerAccountsResponse.customerProducts.accounts[index+1];
       this.accountToBeDisplayed(this.account);

     }

     /*
     * Click of Previous account
     */
     previousAccount(){
       let index= this.templateService.getSelectIndex(this.customerAccountsResponse.customerProducts.accounts,'number',this.account.number);
       this.account = this.customerAccountsResponse.customerProducts.accounts[index-1];
       this.accountToBeDisplayed(this.account);
     }

     /*
     * Restrict options according to access control 
     */
    accessControl(){
        if(this.accountDetailsResponse.accessPermission.downloadEstatement){
            $('#download-estatement').removeClass('disabled');
        }else{
            $('#download-estatement').addClass('disabled');
        }
    }
}
