import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { routing } from './accounts.routing';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '../shared/shared.module';
import {SharedService} from '../shared/services/shared.service';
import {TemplateService} from '../shared/services/template.service';
import { AccountsComponent }   from './Components/accounts.component';
import { AccountsDetailComponent }   from './Components/accountsDetail.component';
import { AccountsTransactionsComponent }   from './Components/accountsTransactions.component';
import { AccountsRightContentComponent }   from './Components/accountsRightContent.component';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import {AccountsService} from './services/accounts.service';



import { FormsModule } from '@angular/forms';

const ACCOUNTS_COMPONENTS = [
    AccountsComponent,
    AccountsDetailComponent,
    AccountsTransactionsComponent,
    AccountsRightContentComponent
];

const ACCOUNTS_PROVIDERS = [
   SharedService,
   TemplateService,
   AccountsService
];

@NgModule({
  	imports: [
	    routing,
	    TranslateModule.forChild(),
	    SharedModule,
	    FormsModule,
		CommonModule,
		NgxDatatableModule
	],
  	declarations: [
	    ...ACCOUNTS_COMPONENTS
	],
  	providers: [
  		...ACCOUNTS_PROVIDERS
  	]
})
export class AccountsModule {}
