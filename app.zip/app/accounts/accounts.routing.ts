import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AccountsComponent } from './Components/accounts.component';
import { AccountsHomeComponent }   from './Components/accountsHome.component';
import { AuthGuard } from '../auth-guard.service';


const routes: Routes = [
    {
        path: '',
        component: AccountsHomeComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'accountDetail',
        component: AccountsComponent,
        canActivate: [AuthGuard]
    },
    {
        path: '',
        redirectTo: '',
        pathMatch: 'full'
    }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
