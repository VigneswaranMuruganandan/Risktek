import {APIResponse} from '../../shared/model/apiResponse';
export class RegisterPwdResponse extends APIResponse{
	
	
}