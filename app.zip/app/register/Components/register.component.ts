import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { RegisterService } from '../services/register.service';
import { SharedService } from '../../shared/services/shared.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { ErrorService } from '../../shared/services/error.service';
import { SessionContext } from '../../shared/model/sessionContext';
import { VerifyUsernameResponse } from '../../shared/model/verifyUsernameResponse';
import { AuthRequest } from '../model/authRequest';
import { CustomerData } from '../model/customerData';
import { VerifyCustomerResponse } from '../model/verifyCustomerResponse';
import { VerifyOtpResponse } from '../../shared/model/verifyOtpResponse';
import { ResendOtpResponse } from '../model/resendOtpResponse';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Rx';
import { AuthKey } from '../../shared/model/authKey';
import { AuthData } from '../../shared/model/authData';
import { RegistrationStep2Component } from './registrationStep2.Component';

@Component({
    templateUrl: './../templates/register.html'
})
export class RegisterComponent implements OnInit {
    @ViewChild(RegistrationStep2Component) registrationStep2:RegistrationStep2Component;
    public stepValue: number;
    public validUsername: boolean;
    public validPassword: boolean;
    public customerData: CustomerData;

    constructor( private registerService: RegisterService, 
    			 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService,
    			 private router: Router) {}

    ngOnInit() {
        this.errorService.resetErrorResp();
        this.stepValue = 1;
        this.validUsername = false;
        this.customerData = new CustomerData();
    }

    ViewRegisterTermsandConditions() {

    }
    /*
    * Step 1: Register the Device ID
    */
    validateCustomerIdentification(customerID: string) {
        this.spinnerService.startSpinner('loader');
    	this.customerData.customerID = customerID;
    	let registerDeviceData = this.sharedService.setupAuthKeys();
	    if(registerDeviceData && registerDeviceData.deviceID != null){
	        this.sharedService.registerDevice(registerDeviceData)
	            .subscribe(
	                resp => this.handleRegisterDeviceDataResp(resp),
	                error => this.sharedService.handleError(error)
	            );
	    }else{
            let sessCtx = SessionContext.getInstance();
            this.handleRegisterDeviceDataResp(sessCtx);
        }
    }
    /*
    * Step 2: Verify the customer ID to get the CIF number
    */
    private handleRegisterDeviceDataResp(resp: any){        
    	if(resp.authKey && resp.authKey.convID != null){
	        let data = new AuthRequest();
	        data.customerID = this.customerData.customerID;
	        this.registerService.verifyCustomer(data)
	            .subscribe(
	                resp => this.handleVerifyCustIDResp(resp),
	                error => this.sharedService.handleError(error)
	            );
    	}
    }
    /*
    * Handle the Response of Verify Customer ID
    * to get Mobile number and email and move to OTP Page
    */
    private handleVerifyCustIDResp(resp: VerifyCustomerResponse) {
        this.spinnerService.stopSpinner('loader');
        if(resp){
            this.stepValue = 2;
            this.customerData.mobileNumber = resp.mobileNumberMasked;
            this.customerData.emailID = resp.emailMasked;
            this.customerData.otpDuration = resp.otpDuration;
        }
    }
    /*
    * Step 3: Verify the OTP 
    */
    validateRegistrationOTP(otp: string) {
        this.spinnerService.startSpinner('loader');
        let data = new AuthRequest();
        data.otp = otp;
        this.registerService.verifyOtp(data)
            .subscribe(
                resp => this.handleVerifyOtpResp(resp),
                error => this.sharedService.handleError(error)
            );
    }
    /*
    * Handle the Verify OTP Response
    */
    private handleVerifyOtpResp(resp: VerifyOtpResponse) {
        this.spinnerService.stopSpinner('loader');
        if(resp.result.status == 'success'){
            this.customerData.name = resp.name;
            this.stepValue = 3;
        }else if(resp.result.status == 'error'){
            this.registrationStep2.resetForm(resp.result.errorInfo.code);
            this.errorService.setErrorResp(resp.result);
        }
    }
    /*
    * Verify the Username
    */
    validateRegistrationUsername(userName: string) {
        this.spinnerService.startSpinner('loader');
        this.customerData.userName = userName;
        let data = new AuthRequest();
        data.userName = userName;
        this.registerService.verifyUsername(data)
            .subscribe(
                resp => this.handleVerifyUsernameResp(resp),
                error => this.sharedService.handleError(error)
            );
    }
    /*
    * Handle the username servcie response
    */
    private handleVerifyUsernameResp(resp: VerifyUsernameResponse) {
        this.spinnerService.stopSpinner('loader');
        if(resp && resp.result.status == 'success'){
            this.stepValue = 4;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
    }
    /*
    * Edit the Username in Registration step of Password
    */
    editUsernameRegister(){
        this.stepValue = 3;
    }

    /*
    * Step 4: Register the  Username and Hashed Password 
    */
    validateRegistrationPassword(pwd: string) {
        this.spinnerService.startSpinner('loader');
        this.customerData.pwd = pwd;
        let data = new AuthRequest();
        data.pwd = pwd;
        data.userName = this.customerData.userName;
        this.registerService.registerPwd(data)
            .subscribe(
                resp => this.handleVerifyPwdResp(resp),
                error => this.sharedService.handleError(error)
            );
    }
    /*
    * Step 5: Verify the Username and Hashed Password 
    */
    private handleVerifyPwdResp(resp: any) {
        if (resp && resp.result.status == "success") {
            let data = new AuthRequest();
            data.userName = this.customerData.userName;
            data.pwd = this.customerData.pwd;
            this.registerService.verifyLogin(data)
                .subscribe(
                    resp => this.handleLoginResp(resp),
                    error => this.sharedService.handleError(error)
                );
        }
    }

    /*
    * Handle the verify Login based on actions
    */
    private handleLoginResp(resp: any) {
        this.spinnerService.stopSpinner('loader');
        if (resp && resp.result.status == 'success') {
        	this.stepValue = 5;
        }
    }
    /*
    * Based on Action, if VIEW_SECOND_FACTOR, 
    * Save the Authentication Method and take the user to dashboard
    */
    saveRegistration(authenticationMethod: string) {
        this.spinnerService.startSpinner('loader');
        let data = new AuthRequest();
        data.otpMethod = authenticationMethod;
        this.registerService.saveAuthenticationMethod(data)
            .subscribe(
                resp => this.handleVerifyAuthenticationResp(resp),
                error => this.sharedService.handleError(error)
            );
    }

    private handleVerifyAuthenticationResp(resp: any) {
        this.spinnerService.stopSpinner('loader');
        if (resp && resp.result.status == 'success') {
            this.router.navigate(['/dashboard']);
        }
    }

    registrationBack(step : number){
        this.stepValue = step;
    }
}