import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '../auth-guard.service';
import { OpenGoldAccountComponent }   from './Components/openGoldAccount.component';

const routes: Routes = [
	{
        path: '',
        component: OpenGoldAccountComponent
    },
    /*{
    	path: 'contactUs',
        component: OpenGoldAccountComponent,
        canActivate: [AuthGuard]
    },*/
    {
	    path: '',
	    redirectTo: '',
	    pathMatch: 'full'
	}
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);