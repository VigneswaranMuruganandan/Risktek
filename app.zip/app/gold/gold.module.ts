import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { routing } from './gold.routing';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '../shared/shared.module';
import { SharedService} from '../shared/services/shared.service';
import { TemplateService} from '../shared/services/template.service';
import { GoldService } from './services/gold.service';
import { FormsModule } from '@angular/forms';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { OpenGoldAccountComponent }   from './Components/openGoldAccount.component';

const GOLD_COMPONENTS = [
    OpenGoldAccountComponent
];

const GOLD_PROVIDERS = [
   SharedService,
   TemplateService,
   GoldService
];

@NgModule({
  	imports: [
	    routing,
	    TranslateModule.forChild(),
	    SharedModule,
	    FormsModule,
      CommonModule,
      NgxDatatableModule
	],
  	declarations: [
	    ...GOLD_COMPONENTS
	],
  	providers: [
  		...GOLD_PROVIDERS
  	]
})
export class GoldModule {}
