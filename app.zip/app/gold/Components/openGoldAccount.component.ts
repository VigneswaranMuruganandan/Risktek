import { Component, OnInit, Input} from '@angular/core';
import { SharedService} from '../../shared/services/shared.service';
import { ErrorService } from '../../shared/services/error.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { TemplateService} from '../../shared/services/template.service';
import { TranslateService} from '@ngx-translate/core';
import { GoldService} from '../services/gold.service';

@Component({
  templateUrl: './../templates/openGoldAccount.html'
})
export class OpenGoldAccountComponent implements OnInit{
	
	public stepValue: number;

	constructor( private sharedService: SharedService,
	              public templateService: TemplateService,
	              private errorService: ErrorService,
	              private spinnerService: SpinnerService,
	              private goldService: GoldService) {}

	ngOnInit() {
		this.initGoldAccount();
    }

    initGoldAccount(){
    	this.stepValue=1;
    }

    openGoldAcc(){
    	this.stepValue=2;
    }
}