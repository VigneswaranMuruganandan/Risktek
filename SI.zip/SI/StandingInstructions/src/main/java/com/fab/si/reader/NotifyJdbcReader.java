/**
 * 
 */
package com.fab.si.reader;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.beans.factory.annotation.Autowired;

import com.fab.si.common.QueryConstants;
import com.fab.si.model.common.SIDetails;
import com.fab.si.processor.SIRowMapper;

/**
 * @author o4359
 *
 */
public class NotifyJdbcReader extends JdbcCursorItemReader<SIDetails> {

	private Logger log = LoggerFactory.getLogger(getClass());

	@Autowired
	private DataSource pbDataSource;

	@Autowired
	private SIRowMapper resultSetMapper;

	@Override
	public void afterPropertiesSet() throws Exception {
		log.info("########### NOTIFY RECORD: START ##########");
		setDataSource(pbDataSource);
		setSql(QueryConstants.SELECT_NOTIFICATION_QUERY);
		setRowMapper(resultSetMapper);
		super.afterPropertiesSet();
	}
}
