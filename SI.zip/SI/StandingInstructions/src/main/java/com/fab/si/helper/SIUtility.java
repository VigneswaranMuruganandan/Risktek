/**
 * 
 */
package com.fab.si.helper;

import java.sql.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fab.si.common.ApplicationConstants;
import com.fab.si.common.ErrorCodes;
import com.fab.si.common.Frequency;
import com.fab.si.common.TemplateId;
import com.fab.si.common.TransactionStatus;
import com.fab.si.model.common.SIDetails;
import com.fab.si.model.common.SITransaction;
import com.fab.si.model.payment.BalanceEnquiryRequest;
import com.fab.si.model.payment.BalanceEnquiryResponse;
import com.fab.si.model.payment.BillerPaymentRequest;
import com.fab.si.model.payment.BillerPaymentResponse;
import com.fab.si.model.transfer.BeneficiaryDetails;
import com.fab.si.model.transfer.FundsTransferRequest;
import com.fab.si.model.transfer.FundsTransferResponse;
import com.fab.si.model.transfer.ResponseStatus;
import com.fab.si.repository.CustomerRepository;

/**
 * @author o4359
 *
 */
@Component
public class SIUtility {

	private Logger log = LoggerFactory.getLogger(getClass());

	@Autowired
	private CustomerRepository custRepo;

	public Map<String, String> populateHeaders(final String channelId, final String customerIdentifier) {
		Map<String, String> headers = new HashMap<>();
		headers.put(ApplicationConstants.CHANNELID, channelId);
		headers.put(ApplicationConstants.XREF, channelId.concat(System.currentTimeMillis() + ""));
		headers.put(ApplicationConstants.ACCESSTOKEN, "Bearer testToken ".concat(customerIdentifier));
		return headers;
	}

	/**
	 * This method is to prepare BalanceEnquiryRequest Object
	 * 
	 * @param siDetails
	 * @return BalanceEnquiryRequest Object
	 */
	public BalanceEnquiryRequest prepareBalEnqReq(final SIDetails siDetails, final String agency) {
		BalanceEnquiryRequest balEnqReq = null;
		final String consumerNo = siDetails.getCreditAcctNo();
		if (StringUtils.isNotBlank(consumerNo)) {
			balEnqReq = new BalanceEnquiryRequest();
			balEnqReq.setAgency(agency);
			balEnqReq.setConsumerNo(consumerNo);
		}
		return balEnqReq;
	}

	/**
	 * This method is to prepare BalanceEnquiryRequest Object
	 * 
	 * @param siDetails
	 * @return BalanceEnquiryRequest Object
	 */
	public BalanceEnquiryRequest prepareWaselBalEnqReq(final SIDetails siDetails, final String agency) {
		BalanceEnquiryRequest balEnqReq = null;
		final String consumerNo = siDetails.getCreditAcctNo();
		if (StringUtils.isNotBlank(consumerNo)) {
			balEnqReq = new BalanceEnquiryRequest();
			balEnqReq.setAgency(agency);
			balEnqReq.setTelephoneNo(consumerNo);
		}
		return balEnqReq;
	}

	/**
	 * This method is to prepare BillerPaymentRequest Object
	 * 
	 * @param siDetails
	 * @param balEnqRes
	 * @return BillerPaymentRequest Object
	 */
	public BillerPaymentRequest preparePaymentReq(final SIDetails siDetails, final BalanceEnquiryResponse balEnqRes) {
		BillerPaymentRequest paymentRequest = new BillerPaymentRequest();
		if (ApplicationConstants.ACCOUNT.equalsIgnoreCase(siDetails.getSourceType())) {
			paymentRequest.setAccountNo(siDetails.getDebitAccountNo());
		} else if (ApplicationConstants.CARD.equalsIgnoreCase(siDetails.getSourceType())) {
			paymentRequest.setCreditCardNo(siDetails.getDebitAccountNo());
		}
		paymentRequest.setCurrencyCode(siDetails.getCurrency());
		paymentRequest.setTransactionAmount(siDetails.getMaxAmount());
		paymentRequest.setAmountDue(balEnqRes.getAmountDue());
		paymentRequest.setTransactionId(balEnqRes.getTransactionID());
		paymentRequest.setAvailableBalance(balEnqRes.getAvailableBalance());
		return paymentRequest;
	}

	/**
	 * This method is to prepare FundsTransferRequest Object
	 * 
	 * @param siDetails
	 * @return FundsTransferRequest Object
	 */
	public FundsTransferRequest prepareFundsTransferReq(final SIDetails siDetails, final BeneficiaryDetails beneDetails, final TemplateId transferType) {
		FundsTransferRequest ftRequest = new FundsTransferRequest();
		ftRequest.setCif(siDetails.getCustomerIdentifier());
		ftRequest.setAccountingUnitIdentifier(custRepo.getCompanyForCardAccount(siDetails.getDebitAccountNo(), ApplicationConstants.ACCOUNT));
		ftRequest.setDebitAccountNo(siDetails.getDebitAccountNo());
		ftRequest.setCreditAccountNo(siDetails.getCreditAcctNo());
		ftRequest.setTransactionAmount(siDetails.getMaxAmount());
		ftRequest.setTransactionCurrency(siDetails.getCurrency());
		if (!TemplateId.OWN_ACCT_FT.equals(transferType)) {
			ftRequest.setCreditAccountCurrency(custRepo.getCurrencyFromAccount(siDetails.getCreditAcctNo()));
		}
		if (beneDetails != null) {
			ftRequest.setChargeBearerIndicationType(beneDetails.getChargeType());
			ftRequest.setTransferType("REM");// FIXME
			// ftRequest.setContainsBeneficiary(beneDetails);
		}
		if (TemplateId.WITHIN_BANK_FT.equals(transferType) && beneDetails != null) {
			ftRequest.setTransferType(beneDetails.getBeneType());
		}
		return ftRequest;
	}

	/**
	 * This method is to prepare FundsTransferRequest Object
	 * 
	 * @param siDetails
	 * @return FundsTransferRequest Object
	 */
	public com.fab.si.model.payment.ResponseStatus prepareFailureResponseStatus() {
		com.fab.si.model.payment.ResponseStatus status = new com.fab.si.model.payment.ResponseStatus();
		status.setStatus(ApplicationConstants.ERROR);
		status.setErrorCode(ErrorCodes.BALANCE_ENQ_FAILED.getCode());
		status.setErrorDesc(ErrorCodes.BALANCE_ENQ_FAILED.getDesc());
		return status;
	}

	/**
	 * This method is to prepare SITransaction Update Object
	 * 
	 * @param paymentRes
	 * @param siDetails
	 * @return SITransaction Object
	 */
	public SITransaction prepareSiTransactionUpdateRequest(final BillerPaymentResponse paymentRes, final SIDetails siDetails, final TransactionStatus txnStatus,
			final com.fab.si.model.payment.ResponseStatus resStatus) {
		SITransaction siTxn = new SITransaction();
		if (paymentRes != null && txnStatus.name().equals(TransactionStatus.PAYMENT_STATUS.name())) {
			log.info("Payment Response Not null & TransactionStatus: {}", txnStatus.name());
			final String status = paymentRes.getResponseStatus().get(0).getStatus();
			if (ApplicationConstants.SUCCESS.equalsIgnoreCase(status)) {
				log.info("Payment Success");
				siTxn.setTxnStatus(TransactionStatus.PAYMENT_SUCCESS.name());
				siTxn.setTxnId(paymentRes.getFgbTransactionRefNo());
				siTxn.setPerDayRetryCount(0);
				siTxn.setCompletedCount(1);
				siTxn.setSmsStatus(TransactionStatus.SMS_FOR_PAYMENT_SUCCESS.name());
				// NEXT RUN ON DATE
				// if
				// (!TemplateId.SALIK_BILLPAYMENT_BYAMOUNT.getTemplateId().equalsIgnoreCase(siDetails.getTemplateId()))
				// {
				if (siDetails.getNextRunOnDate() != null) {
					siTxn.setNxtRunOn(this.getNextRunOnDate(siDetails.getNextRunOnDate(), Frequency.valueOf(siDetails.getFrequency())));
				} else {
					siTxn.setNxtRunOn(this.getNextRunOnDate(siDetails.getStartDate(), Frequency.valueOf(siDetails.getFrequency())));
				}
				// }
			} else if (ApplicationConstants.ERROR.equalsIgnoreCase(status)) {
				log.info("Payment Failed");
				siTxn.setTxnStatus(TransactionStatus.PAYMENT_FAILED.name());
				siTxn.setStatusCode(paymentRes.getResponseStatus().get(0).getErrorCode());
				siTxn.setStatusDesc(paymentRes.getResponseStatus().get(0).getErrorDesc());
				siTxn.setPerDayRetryCount(1);
				siTxn.setCompletedCount(0);
				siTxn.setSmsStatus(TransactionStatus.SMS_FOR_PAYMENT_FAILURE.name());
			}
		} else if (paymentRes == null && txnStatus.name().equals(TransactionStatus.INTERNAL_ERROR.name())) {
			log.info("Payment Response null & TransactionStatus: {}", txnStatus.name());
			siTxn.setTxnStatus(TransactionStatus.INTERNAL_ERROR.name());
			siTxn.setPerDayRetryCount(1);
			siTxn.setSmsStatus(TransactionStatus.SMS_FOR_PAYMENT_FAILURE.name());
		} else if (paymentRes == null && txnStatus.name().equals(TransactionStatus.VALIDATE_RULES_FAILED.name())) {
			log.info("Payment Response null & TransactionStatus: {}", txnStatus.name());
			siTxn.setTxnStatus(txnStatus.name());
			siTxn.setPerDayRetryCount(0);
			siTxn.setCompletedCount(1);
			siTxn.setSmsStatus(TransactionStatus.SMS_FOR_PAYMENT_FAILURE.name());
			if (resStatus != null) {
				siTxn.setStatusCode(resStatus.getErrorCode());
				siTxn.setStatusDesc(resStatus.getErrorDesc());
			}
			// if
			// (!TemplateId.SALIK_BILLPAYMENT_BYAMOUNT.getTemplateId().equalsIgnoreCase(siDetails.getTemplateId()))
			// {
			// NEXT RUN ON DATE
			if (siDetails.getNextRunOnDate() != null) {
				siTxn.setNxtRunOn(this.getNextRunOnDate(siDetails.getNextRunOnDate(), Frequency.valueOf(siDetails.getFrequency())));
			} else {
				siTxn.setNxtRunOn(this.getNextRunOnDate(siDetails.getStartDate(), Frequency.valueOf(siDetails.getFrequency())));
			}
			// }
		} else {
			log.info("TransactionStatus: {}", txnStatus.name());
			siTxn.setTxnStatus(txnStatus.name());
			siTxn.setPerDayRetryCount(0);
			siTxn.setCompletedCount(0);
			siTxn.setSmsStatus(TransactionStatus.PENDING.name());
		}
		siTxn.setCreatedBy(siDetails.getCustomerIdentifier());
		siTxn.setSiId(siDetails.getSiID());
		siTxn.setModifiedBy(siDetails.getCustomerIdentifier());
		return siTxn;
	}

	/**
	 * This method is to prepare SITransaction Update Object
	 * 
	 * @param ftPaymentRes
	 * @param siDetails
	 * @return SITransaction Object
	 */
	public SITransaction prepareSiTransactionUpdateFtRequest(final FundsTransferResponse ftPaymentRes, final SIDetails siDetails, final TransactionStatus txnStatus, final ResponseStatus resStatus) {
		SITransaction siTxn = new SITransaction();
		if (ftPaymentRes != null && txnStatus.name().equals(TransactionStatus.PAYMENT_STATUS.name())) {
			log.info("Payment Response Not null & TransactionStatus: {}", txnStatus.name());
			final String status = ftPaymentRes.getStatus();
			if (ApplicationConstants.SUCCESS.equalsIgnoreCase(status)) {
				log.info("Payment Success");
				siTxn.setTxnStatus(TransactionStatus.PAYMENT_SUCCESS.name());
				siTxn.setTxnId(ftPaymentRes.getFgbTransactionRefNo());
				siTxn.setPerDayRetryCount(0);
				siTxn.setCompletedCount(1);
				siTxn.setSmsStatus(TransactionStatus.SMS_FOR_PAYMENT_SUCCESS.name());
				// NEXT RUN ON DATE
				if (siDetails.getNextRunOnDate() != null) {
					siTxn.setNxtRunOn(this.getNextRunOnDate(siDetails.getNextRunOnDate(), Frequency.valueOf(siDetails.getFrequency())));
				} else {
					siTxn.setNxtRunOn(this.getNextRunOnDate(siDetails.getStartDate(), Frequency.valueOf(siDetails.getFrequency())));
				}
			} else if (ApplicationConstants.ERROR.equalsIgnoreCase(status)) {
				log.info("Payment Failed");
				siTxn.setTxnStatus(TransactionStatus.PAYMENT_FAILED.name());
				siTxn.setStatusCode(ftPaymentRes.getResponseStatus().get(0).getErrorDetails().get(0).getErrorCode());
				siTxn.setStatusDesc(ftPaymentRes.getResponseStatus().get(0).getErrorDetails().get(0).getErrorDesc());
				siTxn.setPerDayRetryCount(1);
				siTxn.setCompletedCount(0);
				siTxn.setSmsStatus(TransactionStatus.SMS_FOR_PAYMENT_FAILURE.name());
			}
		} else if (ftPaymentRes == null && txnStatus.name().equals(TransactionStatus.INTERNAL_ERROR.name())) {
			log.info("Payment Response null & TransactionStatus: {}", txnStatus.name());
			siTxn.setTxnStatus(TransactionStatus.INTERNAL_ERROR.name());
			siTxn.setPerDayRetryCount(1);
			siTxn.setSmsStatus(TransactionStatus.SMS_FOR_PAYMENT_FAILURE.name());
		} else if (ftPaymentRes == null && txnStatus.name().equals(TransactionStatus.VALIDATE_RULES_FAILED.name())) {
			log.info("Payment Response null & TransactionStatus: {}", txnStatus.name());
			siTxn.setTxnStatus(txnStatus.name());
			siTxn.setPerDayRetryCount(0);
			siTxn.setCompletedCount(1);
			siTxn.setSmsStatus(TransactionStatus.SMS_FOR_PAYMENT_FAILURE.name());
			if (resStatus != null) {
				siTxn.setStatusCode(resStatus.getErrorDetails().get(0).getErrorCode());
				siTxn.setStatusDesc(resStatus.getErrorDetails().get(0).getErrorDesc());
			}
			// NEXT RUN ON DATE
			if (siDetails.getNextRunOnDate() != null) {
				siTxn.setNxtRunOn(this.getNextRunOnDate(siDetails.getNextRunOnDate(), Frequency.valueOf(siDetails.getFrequency())));
			} else {
				siTxn.setNxtRunOn(this.getNextRunOnDate(siDetails.getStartDate(), Frequency.valueOf(siDetails.getFrequency())));
			}
		} else {
			log.info("TransactionStatus: {}", txnStatus.name());
			siTxn.setTxnStatus(txnStatus.name());
			siTxn.setPerDayRetryCount(0);
			siTxn.setCompletedCount(0);
			siTxn.setSmsStatus(TransactionStatus.PENDING.name());
		}
		siTxn.setCreatedBy(siDetails.getCustomerIdentifier());
		siTxn.setSiId(siDetails.getSiID());
		siTxn.setModifiedBy(siDetails.getCustomerIdentifier());
		return siTxn;
	}

	public Date getNextRunOnDate(final Date initialDate, final Frequency frequency) {
		DateTime dt = new DateTime(initialDate);
		switch (frequency) {
		case WEEKLY:
			dt = dt.plusWeeks(1);
			break;

		case MONTHLY:
			dt = dt.plusMonths(1);
			break;

		case FORTNIGHT:
			dt = dt.plusWeeks(2);
			break;

		case QUARTERLY:
			dt = dt.plusMonths(3);
			break;

		case HALFYEARLY:
			dt = dt.plusMonths(6);
			break;

		default:
			break;
		}
		return new Date(dt.getMillis());
	}

	public static void main(String[] args) {
		// UBPUtility obj = new UBPUtility();
		// System.out.println("Monthly Increment: " + obj.getNextRunOnDate(new
		// java.util.Date(), Frequency.MONTHLY));
	}
}
