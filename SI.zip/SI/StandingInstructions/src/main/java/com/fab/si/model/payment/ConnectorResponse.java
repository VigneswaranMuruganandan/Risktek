/**
 * 
 */
package com.fab.si.model.payment;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Pratik Das
 *
 */
public class ConnectorResponse {

    private byte[] response;
    private String jsonResponse;
    private int responseStatus;
    private Map<String, String> headers;
    private String contentType;

    public String getContentType() {
	return contentType;
    }

    public void setContentType(String contentType) {
	this.contentType = contentType;
    }

    public byte[] getResponse() {
	return response;
    }

    public void setResponse(byte[] response) {
	this.response = response;
    }

    public int getResponseStatus() {
	return responseStatus;
    }

    public void setResponseStatus(int responseStatus) {
	this.responseStatus = responseStatus;
    }

    public void addHeader(String name, String value) {
	if (headers == null) {
	    headers = new HashMap<String, String>();
	}
	headers.put(name, value);
    }

    public Map<String, String> getHeaders() {
	return headers;
    }

    public void setHeaders(Map<String, String> headers) {
	this.headers = headers;
    }

    /**
     * @return the jsonResponse
     */
    public String getJsonResponse() {
	return jsonResponse;
    }

    /**
     * @param jsonResponse
     *            the jsonResponse to set
     */
    public void setJsonResponse(String jsonResponse) {
	this.jsonResponse = jsonResponse;
    }

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ConnectorResponse [response=");
		builder.append(Arrays.toString(response));
		builder.append(", jsonResponse=");
		builder.append(jsonResponse);
		builder.append(", responseStatus=");
		builder.append(responseStatus);
		builder.append(", headers=");
		builder.append(headers);
		builder.append(", contentType=");
		builder.append(contentType);
		builder.append("]");
		return builder.toString();
	}
}
