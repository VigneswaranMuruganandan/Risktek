/**
 * 
 */
package com.fab.si.model.payment;

/**
 * @author o4359
 *
 */
public class BalanceEnquiryRequest {

	private String agency;
	private String consumerNo;
	private String telephoneNo;

	/**
	 * @return the agency
	 */
	public String getAgency() {
		return agency;
	}

	/**
	 * @param agency
	 *            the agency to set
	 */
	public void setAgency(String agency) {
		this.agency = agency;
	}

	/**
	 * @return the consumerNo
	 */
	public String getConsumerNo() {
		return consumerNo;
	}

	/**
	 * @param consumerNo
	 *            the consumerNo to set
	 */
	public void setConsumerNo(String consumerNo) {
		this.consumerNo = consumerNo;
	}

	/**
	 * @return the telephoneNo
	 */
	public String getTelephoneNo() {
		return telephoneNo;
	}

	/**
	 * @param telephoneNo
	 *            the telephoneNo to set
	 */
	public void setTelephoneNo(String telephoneNo) {
		this.telephoneNo = telephoneNo;
	}
}
