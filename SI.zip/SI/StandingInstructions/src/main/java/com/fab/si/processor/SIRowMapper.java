/**
 * 
 */
package com.fab.si.processor;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.fab.si.model.common.SIDetails;

/**
 * @author o4359
 *
 */
@Component
public class SIRowMapper implements RowMapper<SIDetails> {

	@Override
	public SIDetails mapRow(ResultSet rs, int rowNum) throws SQLException {

		int i = 0;
		SIDetails obj = new SIDetails();
		obj.setSiID(rs.getString(++i));
		obj.setCustomerIdentifier(rs.getString(++i));
		obj.setDebitAccountNo(rs.getString(++i));
		obj.setSourceType(rs.getString(++i));
		obj.setCurrency(rs.getString(++i));
		obj.setPaymentTransferName(rs.getString(++i));
		obj.setTemplateId(rs.getString(++i));
		obj.setCreditAcctNo(rs.getString(++i));
		obj.setDestType(rs.getString(++i));
		obj.setBeneId(rs.getString(++i));
		obj.setFrequency(rs.getString(++i));
		obj.setMaxAmount(rs.getString(++i));
		obj.setMinAmount(rs.getDouble(++i));
		obj.setChannelId(rs.getString(++i));
		obj.setRefNo(rs.getString(++i));
		obj.setTxnDesc(rs.getString(++i));
		obj.setExecutionCount(rs.getInt(++i));
		obj.setCompletedCount(rs.getInt(++i));
		obj.setStartDate(rs.getDate(++i));
		obj.setNextRunOnDate(rs.getDate(++i));
		obj.setStatusCode(rs.getString(++i));
		obj.setStatusDesc(rs.getString(++i));
		obj.setTxnId(rs.getString(++i));
		obj.setRetryCount(rs.getInt(++i));
		obj.setTxnStatus(rs.getString(++i));
		obj.setCreatedBy(rs.getString(++i));
		obj.setSmsStatus(rs.getString(++i));
		return obj;
	}
}
