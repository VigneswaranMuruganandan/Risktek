/**
 * 
 */
package com.fab.si.model.payment;

/**
 * @author o4359
 *
 */
public class SalikBalanceEnquiryRequest {

	private String accountNo;
	private String salikPinNo;

	/**
	 * @return the accountNo
	 */
	public String getAccountNo() {
		return accountNo;
	}

	/**
	 * @param accountNo
	 *            the accountNo to set
	 */
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	/**
	 * @return the salikPinNo
	 */
	public String getSalikPinNo() {
		return salikPinNo;
	}

	/**
	 * @param salikPinNo
	 *            the salikPinNo to set
	 */
	public void setSalikPinNo(String salikPinNo) {
		this.salikPinNo = salikPinNo;
	}
}
