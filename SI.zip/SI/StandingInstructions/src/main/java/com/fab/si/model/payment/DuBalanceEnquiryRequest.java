/**
 * 
 */
package com.fab.si.model.payment;

/**
 * @author o4359
 *
 */
public class DuBalanceEnquiryRequest {

	private BalanceEnquiryRequest duConsumer;

	/**
	 * @return the duConsumer
	 */
	public BalanceEnquiryRequest getDuConsumer() {
		return duConsumer;
	}

	/**
	 * @param duConsumer
	 *            the duConsumer to set
	 */
	public void setDuConsumer(BalanceEnquiryRequest duConsumer) {
		this.duConsumer = duConsumer;
	}

}
