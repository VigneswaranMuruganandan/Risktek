/**
 * 
 */
package com.fab.si.common;

/**
 * @author kaushikmukherjee
 *
 */
public interface QueryConstants {

	// SELECT SI MASTER, SI TRANSACTION QUERY
	String SELECT_SALIK_SI_QUERY = "SELECT sim.si_id,sim.cif_id,sim.source_account,sim.source_type,sim.transaction_currency,sim.payment_transfer_name,sim.template_id,sim.credit_account_no,sim.dest_type,sim.bene_nickname,sim.frequency,sim.max_amt,sim.min_amt,sim.channelid,sim.ref_num,sim.transaction_desc,sim.execution_count,sit.completed_count,sim.start_date,sit.next_run_on,sit.status_code,sit.status_desc,sit.txnid,sit.perday_retry_count,sit.txn_status,sit.created_by,sit.sms_status FROM si_master sim, si_transaction sit "
			+ "WHERE sim.isactive='Y' AND sim.payment_transfer_name = 'SALIK' AND sit.si_id = sim.si_id AND sit.completed_count <= sim.execution_count AND sit.perday_retry_count < ? AND sit.txn_status NOT IN ('PAYMENT_SUCCESS','VALIDATE_RULES_FAILED') AND trunc(sim.start_date) <= trunc(sysdate) AND (sit.next_run_on IS NULL OR trunc(sit.next_run_on) <= trunc(sysdate))";

	String SELECT_SEWA_SI_QUERY = "SELECT sim.si_id,sim.cif_id,sim.source_account,sim.source_type,sim.transaction_currency,sim.payment_transfer_name,sim.template_id,sim.credit_account_no,sim.dest_type,sim.bene_nickname,sim.frequency,sim.max_amt,sim.min_amt,sim.channelid,sim.ref_num,sim.transaction_desc,sim.execution_count,sit.completed_count,sim.start_date,sit.next_run_on,sit.status_code,sit.status_desc,sit.txnid,sit.perday_retry_count,sit.txn_status,sit.created_by,sit.sms_status FROM si_master sim, si_transaction sit "
			+ "WHERE sim.isactive='Y' AND sim.payment_transfer_name = 'SEWA' AND sit.si_id = sim.si_id AND sit.completed_count <= sim.execution_count AND sit.perday_retry_count < ? AND sit.txn_status NOT IN ('PAYMENT_SUCCESS','VALIDATE_RULES_FAILED') AND trunc(sim.start_date) <= trunc(sysdate) AND (sit.next_run_on IS NULL OR trunc(sit.next_run_on) <= trunc(sysdate))";

	String SELECT_AADC_SI_QUERY = "SELECT sim.si_id,sim.cif_id,sim.source_account,sim.source_type,sim.transaction_currency,sim.payment_transfer_name,sim.template_id,sim.credit_account_no,sim.dest_type,sim.bene_nickname,sim.frequency,sim.max_amt,sim.min_amt,sim.channelid,sim.ref_num,sim.transaction_desc,sim.execution_count,sit.completed_count,sim.start_date,sit.next_run_on,sit.status_code,sit.status_desc,sit.txnid,sit.perday_retry_count,sit.txn_status,sit.created_by,sit.sms_status FROM si_master sim, si_transaction sit "
			+ "WHERE sim.isactive='Y' AND sim.payment_transfer_name = 'AADC' AND sit.si_id = sim.si_id AND sit.completed_count <= sim.execution_count AND sit.perday_retry_count < ? AND sit.txn_status NOT IN ('PAYMENT_SUCCESS','VALIDATE_RULES_FAILED') AND trunc(sim.start_date) <= trunc(sysdate) AND (sit.next_run_on IS NULL OR trunc(sit.next_run_on) <= trunc(sysdate))";

	String SELECT_ADDC_SI_QUERY = "SELECT sim.si_id,sim.cif_id,sim.source_account,sim.source_type,sim.transaction_currency,sim.payment_transfer_name,sim.template_id,sim.credit_account_no,sim.dest_type,sim.bene_nickname,sim.frequency,sim.max_amt,sim.min_amt,sim.channelid,sim.ref_num,sim.transaction_desc,sim.execution_count,sit.completed_count,sim.start_date,sit.next_run_on,sit.status_code,sit.status_desc,sit.txnid,sit.perday_retry_count,sit.txn_status,sit.created_by,sit.sms_status FROM si_master sim, si_transaction sit "
			+ "WHERE sim.isactive='Y' AND sim.payment_transfer_name = 'ADDC' AND sit.si_id = sim.si_id AND sit.completed_count <= sim.execution_count AND sit.perday_retry_count < ? AND sit.txn_status NOT IN ('PAYMENT_SUCCESS','VALIDATE_RULES_FAILED') AND trunc(sim.start_date) <= trunc(sysdate) AND (sit.next_run_on IS NULL OR trunc(sit.next_run_on) <= trunc(sysdate))";

	String SELECT_DU_SI_QUERY = "SELECT sim.si_id,sim.cif_id,sim.source_account,sim.source_type,sim.transaction_currency,sim.payment_transfer_name,sim.template_id,sim.credit_account_no,sim.dest_type,sim.bene_nickname,sim.frequency,sim.max_amt,sim.min_amt,sim.channelid,sim.ref_num,sim.transaction_desc,sim.execution_count,sit.completed_count,sim.start_date,sit.next_run_on,sit.status_code,sit.status_desc,sit.txnid,sit.perday_retry_count,sit.txn_status,sit.created_by,sit.sms_status FROM si_master sim, si_transaction sit "
			+ "WHERE sim.isactive='Y' AND sim.payment_transfer_name = 'DU' AND sit.si_id = sim.si_id AND sit.completed_count <= sim.execution_count AND sit.perday_retry_count < ? AND sit.txn_status NOT IN ('PAYMENT_SUCCESS','VALIDATE_RULES_FAILED') AND trunc(sim.start_date) <= trunc(sysdate) AND (sit.next_run_on IS NULL OR trunc(sit.next_run_on) <= trunc(sysdate))";

	String SELECT_FEWA_SI_QUERY = "SELECT sim.si_id,sim.cif_id,sim.source_account,sim.source_type,sim.transaction_currency,sim.payment_transfer_name,sim.template_id,sim.credit_account_no,sim.dest_type,sim.bene_nickname,sim.frequency,sim.max_amt,sim.min_amt,sim.channelid,sim.ref_num,sim.transaction_desc,sim.execution_count,sit.completed_count,sim.start_date,sit.next_run_on,sit.status_code,sit.status_desc,sit.txnid,sit.perday_retry_count,sit.txn_status,sit.created_by,sit.sms_status FROM si_master sim, si_transaction sit "
			+ "WHERE sim.isactive='Y' AND sim.payment_transfer_name = 'FEWA' AND sit.si_id = sim.si_id AND sit.completed_count <= sim.execution_count AND sit.perday_retry_count < ? AND sit.txn_status NOT IN ('PAYMENT_SUCCESS','VALIDATE_RULES_FAILED') AND trunc(sim.start_date) <= trunc(sysdate) AND (sit.next_run_on IS NULL OR trunc(sit.next_run_on) <= trunc(sysdate))";

	String SELECT_ETISALAT_SI_QUERY = "SELECT sim.si_id,sim.cif_id,sim.source_account,sim.source_type,sim.transaction_currency,sim.payment_transfer_name,sim.template_id,sim.credit_account_no,sim.dest_type,sim.bene_nickname,sim.frequency,sim.max_amt,sim.min_amt,sim.channelid,sim.ref_num,sim.transaction_desc,sim.execution_count,sit.completed_count,sim.start_date,sit.next_run_on,sit.status_code,sit.status_desc,sit.txnid,sit.perday_retry_count,sit.txn_status,sit.created_by,sit.sms_status FROM si_master sim, si_transaction sit "
			+ "WHERE sim.isactive='Y' AND sim.payment_transfer_name = 'ETISALAT' AND sit.si_id = sim.si_id AND sit.completed_count <= sim.execution_count AND sit.perday_retry_count < ? AND sit.txn_status NOT IN ('PAYMENT_SUCCESS','VALIDATE_RULES_FAILED') AND trunc(sim.start_date) <= trunc(sysdate) AND (sit.next_run_on IS NULL OR trunc(sit.next_run_on) <= trunc(sysdate))";

	String SELECT_DEWA_SI_QUERY = "SELECT sim.si_id,sim.cif_id,sim.source_account,sim.source_type,sim.transaction_currency,sim.payment_transfer_name,sim.template_id,sim.credit_account_no,sim.dest_type,sim.bene_nickname,sim.frequency,sim.max_amt,sim.min_amt,sim.channelid,sim.ref_num,sim.transaction_desc,sim.execution_count,sit.completed_count,sim.start_date,sit.next_run_on,sit.status_code,sit.status_desc,sit.txnid,sit.perday_retry_count,sit.txn_status,sit.created_by,sit.sms_status FROM si_master sim, si_transaction sit "
			+ "WHERE sim.isactive='Y' AND sim.payment_transfer_name = 'DEWA' AND sit.si_id = sim.si_id AND sit.completed_count <= sim.execution_count AND sit.perday_retry_count < ? AND sit.txn_status NOT IN ('PAYMENT_SUCCESS','VALIDATE_RULES_FAILED') AND trunc(sim.start_date) <= trunc(sysdate) AND (sit.next_run_on IS NULL OR trunc(sit.next_run_on) <= trunc(sysdate))";

	String SELECT_FTOWN_SI_QUERY = "SELECT sim.si_id,sim.cif_id,sim.source_account,sim.source_type,sim.transaction_currency,sim.payment_transfer_name,sim.template_id,sim.credit_account_no,sim.dest_type,sim.bene_nickname,sim.frequency,sim.max_amt,sim.min_amt,sim.channelid,sim.ref_num,sim.transaction_desc,sim.execution_count,sit.completed_count,sim.start_date,sit.next_run_on,sit.status_code,sit.status_desc,sit.txnid,sit.perday_retry_count,sit.txn_status,sit.created_by,sit.sms_status FROM si_master sim, si_transaction sit "
			+ "WHERE sim.isactive='Y' AND sim.payment_transfer_name = 'OWN_ACCT_FUNDS_TRANSFER' AND sit.si_id = sim.si_id AND sit.completed_count <= sim.execution_count AND sit.perday_retry_count < ? AND sit.txn_status NOT IN ('PAYMENT_SUCCESS','VALIDATE_RULES_FAILED') AND trunc(sim.start_date) <= trunc(sysdate) AND (sit.next_run_on IS NULL OR trunc(sit.next_run_on) <= trunc(sysdate))";

	String SELECT_FTWITHINUAE_SI_QUERY = "SELECT sim.si_id,sim.cif_id,sim.source_account,sim.source_type,sim.transaction_currency,sim.payment_transfer_name,sim.template_id,sim.credit_account_no,sim.dest_type,sim.bene_nickname,sim.frequency,sim.max_amt,sim.min_amt,sim.channelid,sim.ref_num,sim.transaction_desc,sim.execution_count,sit.completed_count,sim.start_date,sit.next_run_on,sit.status_code,sit.status_desc,sit.txnid,sit.perday_retry_count,sit.txn_status,sit.created_by,sit.sms_status FROM si_master sim, si_transaction sit "
			+ "WHERE sim.isactive='Y' AND sim.payment_transfer_name = 'WITHIN_UAE_FUNDS_TRANSFER' AND sit.si_id = sim.si_id AND sit.completed_count <= sim.execution_count AND sit.perday_retry_count < ? AND sit.txn_status NOT IN ('PAYMENT_SUCCESS','VALIDATE_RULES_FAILED') AND trunc(sim.start_date) <= trunc(sysdate) AND (sit.next_run_on IS NULL OR trunc(sit.next_run_on) <= trunc(sysdate))";

	String SELECT_FTWITHINBANK_SI_QUERY = "SELECT sim.si_id,sim.cif_id,sim.source_account,sim.source_type,sim.transaction_currency,sim.payment_transfer_name,sim.template_id,sim.credit_account_no,sim.dest_type,sim.bene_nickname,sim.frequency,sim.max_amt,sim.min_amt,sim.channelid,sim.ref_num,sim.transaction_desc,sim.execution_count,sit.completed_count,sim.start_date,sit.next_run_on,sit.status_code,sit.status_desc,sit.txnid,sit.perday_retry_count,sit.txn_status,sit.created_by,sit.sms_status FROM si_master sim, si_transaction sit "
			+ "WHERE sim.isactive='Y' AND sim.payment_transfer_name = 'WITHIN_BANK_FUNDS_TRANSFER' AND sit.si_id = sim.si_id AND sit.completed_count <= sim.execution_count AND sit.perday_retry_count < ? AND sit.txn_status NOT IN ('PAYMENT_SUCCESS','VALIDATE_RULES_FAILED') AND trunc(sim.start_date) <= trunc(sysdate) AND (sit.next_run_on IS NULL OR trunc(sit.next_run_on) <= trunc(sysdate))";

	String SELECT_FTINTERNATIONAL_SI_QUERY = "SELECT sim.si_id,sim.cif_id,sim.source_account,sim.source_type,sim.transaction_currency,sim.payment_transfer_name,sim.template_id,sim.credit_account_no,sim.dest_type,sim.bene_nickname,sim.frequency,sim.max_amt,sim.min_amt,sim.channelid,sim.ref_num,sim.transaction_desc,sim.execution_count,sit.completed_count,sim.start_date,sit.next_run_on,sit.status_code,sit.status_desc,sit.txnid,sit.perday_retry_count,sit.txn_status,sit.created_by,sit.sms_status FROM si_master sim, si_transaction sit "
			+ "WHERE sim.isactive='Y' AND sim.payment_transfer_name = 'INTERNATIONAL_FUNDS_TRANSFER' AND sit.si_id = sim.si_id AND sit.completed_count <= sim.execution_count AND sit.perday_retry_count < ? AND sit.txn_status NOT IN ('PAYMENT_SUCCESS','VALIDATE_RULES_FAILED') AND trunc(sim.start_date) <= trunc(sysdate) AND (sit.next_run_on IS NULL OR trunc(sit.next_run_on) <= trunc(sysdate))";

	// UPDATE SI TRANSACTION QUERY
	String UPDATE_SI_TRANSACTION_SUCCESS_QUERY = "UPDATE si_transaction SET sms_status = ? , txn_status = ?, status_code = ?, status_desc = ?, txnid = ?, next_run_on = ?, perday_retry_count = (perday_retry_count + ?) , completed_count = (completed_count + ?), modified_by = ?, modified_on = sysdate WHERE si_id = ?";

	// UPDATE SI SMS QUERY
	String UPDATE_SI_SMS_STATUS_QUERY = "UPDATE si_transaction SET sms_status = ?, modified_by = ?, modified_on = sysdate WHERE si_id = ?";

	// INSERT SI TRANSACTION AUDIT QUERY
	String INSERT_SI_TRANSACTION_AUDIT_QUERY = "INSERT INTO si_transaction_audit (si_id,sms_status,txn_status,status_code,status_desc,txnid,next_run_on,perday_retry_count,completed_count,created_on,modified_on,created_by,modified_by) VALUES (?,?,?,?,?,?,?,?,?,sysdate,sysdate,?,?)";

	// SELECT NOTIFICATION QUERY
	String SELECT_NOTIFICATION_QUERY = "SELECT sim.si_id,sim.cif_id,sim.source_account,sim.source_type,sim.transaction_currency,sim.payment_transfer_name,sim.template_id,sim.credit_account_no,sim.dest_type,sim.bene_nickname,sim.frequency,sim.max_amt,sim.min_amt,sim.channelid,sim.ref_num,sim.transaction_desc,sim.execution_count,sit.completed_count,sim.start_date,sit.next_run_on,sit.status_code,sit.status_desc,sit.txnid,sit.perday_retry_count,sit.txn_status,sit.created_by,sit.sms_status FROM si_master sim, si_transaction sit WHERE sit.si_id = sim.si_id AND sit.sms_status IN ('SMS_FOR_PAYMENT_FAILURE','SMS_FOR_PAYMENT_SUCCESS')";
	String SELECT_FGB_USER_MOBILE_MASTER_QUERY = "SELECT mobile_number FROM fgb_user_mobile_master WHERE cif = ? AND smartsms_reg = 'Y'";
	String SELECT_ACCT_EMAIL_QUERY = "SELECT email FROM mstacctemailreg WHERE idcif = ? AND status = 'Y'";
	String SELECT_EMAIL_QUERY = "SELECT email FROM mstemailreg WHERE idcif = ? AND status = 'Y'";

	// SELECT CONTENT ITEM
	String SELECT_CONTENT_ITEM_BY_PATH = "SELECT cont_id, path, contents, contents_bin, content_type, version, metadata FROM content_item WHERE path=?";

	// VALIDATE CUSTOMER ACCOUNT QUERY
	String SELECT_ACCT_VALIDATE_QUERY = "SELECT a.TXTACCTSTATUS, a.NUMAVAILBAL FROM MSTACCOUNT a , MSTCORPACCT b WHERE a.IDACCOUNT = ? AND a.idaccount = b.idaccount AND b.idcorporate IN (SELECT IDCORPORATE FROM CIFCUSTMAP WHERE IDCIF = ?) AND b.rel in ('0','7','16')";
	String SELECT_ACCOUNT_DETAILS = "SELECT NUMAVAILBAL , COMPANY_CODE , TXTACCTSTATUS , CODACCTCURR , COMPANY FROM MSTACCOUNT WHERE IDACCOUNT = ?";

	// BENEFICIARY CUSTOMER
	String SELECT_BENE_CUSTOMER_QUERY = "SELECT cif_id,bene_nickname,template_id,bene_name,bene_account,bene_type,bene_addr1,bene_addr2,bene_addr3,routing_code,transfer_currency,bene_bank_country,bene_bank_name,bene_branch,bene_bank_addr1,bene_bank_addr2,bene_description,swift_code,charge_type,correspondant_bank FROM beneficiary_customer WHERE cif_id = ? AND bene_nickname = ? AND template_id = ?";

	String SELECT_COMPANY_FROM_CARDS_QUERY = "SELECT company FROM mstcards WHERE nbrcard = ?";
	String SELECT_COMPANY_FROM_ACCTS_QUERY = "SELECT company FROM mstaccount WHERE idaccount = ?";
	String SELECT_CURR_FROM_ACCTS_QUERY = "SELECT codacctcurr FROM mstaccount WHERE idaccount = ?";
}
