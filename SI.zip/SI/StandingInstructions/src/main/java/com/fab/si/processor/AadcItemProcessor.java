/**
 * 
 */
package com.fab.si.processor;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fab.si.common.ApplicationConstants;
import com.fab.si.common.ServiceUrls;
import com.fab.si.common.TransactionStatus;
import com.fab.si.helper.HttpConnector;
import com.fab.si.helper.JsonUtils;
import com.fab.si.helper.SIUtility;
import com.fab.si.model.common.SIDetails;
import com.fab.si.model.payment.AadcBalanceEnquiryRequest;
import com.fab.si.model.payment.AadcBillPaymentRequest;
import com.fab.si.model.payment.BalanceEnquiryResponse;
import com.fab.si.model.payment.BillerPaymentResponse;
import com.fab.si.model.payment.ConnectorResponse;
import com.fab.si.repository.SITransactionRepository;

/**
 * @author o4359
 *
 */
@Component
public class AadcItemProcessor implements ItemProcessor<SIDetails, SIDetails> {

	private Logger log = LoggerFactory.getLogger(getClass());

	@Autowired
	private HttpConnector httpConnect;

	@Autowired
	private SIUtility siUtility;

	@Autowired
	private SITransactionRepository siTxnRepo;

	@Override
	public SIDetails process(SIDetails siDetails) throws Exception {

		final String siId = siDetails.getSiID();
		log.info("{} - AADC Object in Item Processor: {}", siId, siDetails);

		// UPDATE IN SI TRANSACTIONS
		siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.VALIDATE_RULES, null));
		// CALL AADC BALANCE ENQUIRY
		BalanceEnquiryResponse balEnqRes = this.aadcBalanceEnquiry(siDetails);
		if (balEnqRes != null) {
			final String amountDue = balEnqRes.getAmountDue();
			log.info("{} - Aadc Amount Due: {} ", siId, amountDue);

			if (StringUtils.isNotBlank(amountDue)) {
				BillerPaymentResponse paymentRes = null;
				if (ApplicationConstants.ACCOUNT.equalsIgnoreCase(siDetails.getSourceType())) {
					// UPDATE IN SI TRANSACTIONS
					siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.PAYMENT_PROCESSING, null));
					// PAYMENT
					paymentRes = this.aadcAccountPayment(balEnqRes, siDetails);
					// UPDATE IN SI TRANSACTIONS
					if (paymentRes != null) {
						siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(paymentRes, siDetails, TransactionStatus.PAYMENT_STATUS, null));
					} else {
						siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(paymentRes, siDetails, TransactionStatus.INTERNAL_ERROR, null));
					}
				} else if (ApplicationConstants.CARD.equalsIgnoreCase(siDetails.getSourceType())) {
					// UPDATE IN SI TRANSACTIONS
					siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.PAYMENT_PROCESSING, null));
					paymentRes = this.aadcCardPayment(balEnqRes, siDetails);
					// UPDATE IN SI TRANSACTIONS
					if (paymentRes != null) {
						siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(paymentRes, siDetails, TransactionStatus.PAYMENT_STATUS, null));
					} else {
						siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(paymentRes, siDetails, TransactionStatus.INTERNAL_ERROR, null));
					}
				}
			} else {
				log.info("{} - Invalid Aadc Balance Enquiry Response: {}", siId);
				siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.VALIDATE_RULES_FAILED, siUtility.prepareFailureResponseStatus()));
			}
		}
		return siDetails;
	}

	/**
	 * This method is to prepare AadcBalanceEnquiryRequest Object
	 * 
	 * @param siDetails
	 * @return AadcBalanceEnquiryRequest Object
	 */
	private AadcBalanceEnquiryRequest prepareAadcBalEnqReq(final SIDetails siDetails) {
		AadcBalanceEnquiryRequest aadcBalanceReq = new AadcBalanceEnquiryRequest();
		final String aadcConsumerNo = siDetails.getCreditAcctNo();
		if (StringUtils.isNotBlank(aadcConsumerNo)) {
			aadcBalanceReq.setAadcConsumer(siUtility.prepareBalEnqReq(siDetails, ApplicationConstants.AADC));
		}
		return aadcBalanceReq;
	}

	/**
	 * This method is to execute Balance Inquiry Service
	 * 
	 * @param siDetails
	 * @return BalanceEnquiryResponse Object
	 */
	private BalanceEnquiryResponse aadcBalanceEnquiry(final SIDetails siDetails) {
		BalanceEnquiryResponse response = null;
		final String siId = siDetails.getSiID();
		final String requestJson = JsonUtils.convertToJson(this.prepareAadcBalEnqReq(siDetails));
		log.info("{} - Aadc Balance Enquiry Request: {}", siId, requestJson);
		// CREATE HTTP HEADERS
		Map<String, String> headers = siUtility.populateHeaders(siDetails.getChannelId(), siDetails.getCustomerIdentifier());
		ConnectorResponse connResponse = httpConnect.post(ServiceUrls.AADC_BALANCE_ENQ, requestJson, headers);
		if (connResponse.getResponseStatus() == 200) {
			log.info("{} - Aadc Balance Enquiry Response: {}", siId, connResponse.getJsonResponse());
			response = JsonUtils.convertToObject(BalanceEnquiryResponse.class, connResponse.getJsonResponse());
		}
		log.info("{} - Aadc BalanceEnquiryResponse: {}", siId, response);
		return response;
	}

	/**
	 * This method is to execute Account Payment Service
	 * 
	 * @param balEnqRes
	 * @param siDetails
	 * @return BillerPaymentResponse Object
	 */
	private BillerPaymentResponse aadcAccountPayment(final BalanceEnquiryResponse balEnqRes, final SIDetails siDetails) {
		BillerPaymentResponse response = null;
		final String siId = siDetails.getSiID();
		AadcBillPaymentRequest aadcPayment = new AadcBillPaymentRequest();
		aadcPayment.setAadcConsumer(siUtility.prepareBalEnqReq(siDetails, ApplicationConstants.AADC));
		aadcPayment.setAccountPayment(siUtility.preparePaymentReq(siDetails, balEnqRes));
		final String requestJson = JsonUtils.convertToJson(aadcPayment);
		log.info("{} - Aadc Account Payment Request: {}", siId, requestJson);
		// CREATE HTTP HEADERS
		Map<String, String> headers = siUtility.populateHeaders(siDetails.getChannelId(), siDetails.getCustomerIdentifier());
		ConnectorResponse connResponse = httpConnect.post(ServiceUrls.AADC_PAYMENT_BYACCOUNT, requestJson, headers);
		if (connResponse.getResponseStatus() == 200) {
			log.info("{} - Aadc Account Payment JSON Response: {}", siId, connResponse.getJsonResponse());
			response = JsonUtils.convertToObject(BillerPaymentResponse.class, connResponse.getJsonResponse());
		}
		log.info("{} - Aadc Account BillerPaymentResponse: {}", siId, response);
		return response;
	}

	/**
	 * This method is to execute Card Payment Service
	 * 
	 * @param balEnqRes
	 * @param siDetails
	 * @return BillerPaymentResponse Object
	 */
	private BillerPaymentResponse aadcCardPayment(final BalanceEnquiryResponse balEnqRes, final SIDetails siDetails) {
		BillerPaymentResponse response = null;
		final String siId = siDetails.getSiID();
		AadcBillPaymentRequest aadcPayment = new AadcBillPaymentRequest();
		aadcPayment.setAadcConsumer(siUtility.prepareBalEnqReq(siDetails, ApplicationConstants.AADC));
		aadcPayment.setCardPayment(siUtility.preparePaymentReq(siDetails, balEnqRes));
		final String requestJson = JsonUtils.convertToJson(aadcPayment);
		log.info("{} - Aadc Card Payment Request: {}", siId, requestJson);
		// CREATE HTTP HEADERS
		Map<String, String> headers = siUtility.populateHeaders(siDetails.getChannelId(), siDetails.getCustomerIdentifier());
		ConnectorResponse connResponse = httpConnect.post(ServiceUrls.AADC_PAYMENT_BYCARD, requestJson, headers);
		if (connResponse.getResponseStatus() == 200) {
			log.info("{} - Aadc Card Payment Response: {}", siId, connResponse.getJsonResponse());
			response = JsonUtils.convertToObject(BillerPaymentResponse.class, connResponse.getJsonResponse());
		}
		log.info("{} - Aadc Card BillerPaymentResponse: {}", siId, response);
		return response;
	}
}
