/**
 * 
 */
package com.fab.si.config;

/*import java.util.HashMap;
import java.util.Map;

import org.springframework.batch.core.configuration.JobLocator;
import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;*/

/**
 * @author o4359
 *
 */
//@Configuration
public class SIJobs {

	/*@Autowired
	private JobLauncher jobLauncher;
	
	@Autowired
	private JobLocator jobLocator;
	
	@Bean
	public JobDetailFactoryBean salikJobDetail() {
		JobDetailFactoryBean factory = new JobDetailFactoryBean();
		factory.setJobClass(JobLauncherDetails.class);
		factory.setGroup("quartz-batch");
		factory.setJobDataAsMap(this.getJobDataAsMap("salikJob", jobRegistry, jobLauncher));
		return factory;
	}

	private Map<String, Object> getJobDataAsMap(final String jobName, final JobRegistry jobRegistry, final JobLauncher jobLauncher) {
		Map<String, Object> map = new HashMap<>();
		map.put("jobName", jobName);
		map.put("jobLauncher", jobLauncher);
		map.put("jobLocator", jobRegistry);
		return map;
	}*/
}
