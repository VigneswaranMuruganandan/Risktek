/**
 * 
 */
package com.fab.si.model.payment;

/**
 * @author o4359
 *
 */
public class FewaBalanceEnquiryRequest {

	private BalanceEnquiryRequest fewaConsumer;

	/**
	 * @return the fewaConsumer
	 */
	public BalanceEnquiryRequest getFewaConsumer() {
		return fewaConsumer;
	}

	/**
	 * @param fewaConsumer
	 *            the fewaConsumer to set
	 */
	public void setFewaConsumer(BalanceEnquiryRequest fewaConsumer) {
		this.fewaConsumer = fewaConsumer;
	}

}
