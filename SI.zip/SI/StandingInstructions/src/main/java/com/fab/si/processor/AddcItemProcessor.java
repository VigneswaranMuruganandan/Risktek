/**
 * 
 */
package com.fab.si.processor;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fab.si.common.ApplicationConstants;
import com.fab.si.common.ServiceUrls;
import com.fab.si.common.TransactionStatus;
import com.fab.si.helper.HttpConnector;
import com.fab.si.helper.JsonUtils;
import com.fab.si.helper.SIUtility;
import com.fab.si.model.common.SIDetails;
import com.fab.si.model.payment.AadcBalanceEnquiryRequest;
import com.fab.si.model.payment.AddcBillPaymentRequest;
import com.fab.si.model.payment.BalanceEnquiryResponse;
import com.fab.si.model.payment.BillerPaymentResponse;
import com.fab.si.model.payment.ConnectorResponse;
import com.fab.si.repository.SITransactionRepository;

/**
 * @author o4359
 *
 */
@Component
public class AddcItemProcessor implements ItemProcessor<SIDetails, SIDetails> {

	private Logger log = LoggerFactory.getLogger(getClass());

	@Autowired
	private HttpConnector httpConnect;

	@Autowired
	private SIUtility siUtility;

	@Autowired
	private SITransactionRepository siTxnRepo;

	@Override
	public SIDetails process(SIDetails siDetails) throws Exception {

		final String siId = siDetails.getSiID();
		log.info("{} - ADDC Object in Item Processor: {}", siId, siDetails);

		// UPDATE IN SI TRANSACTIONS
		siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.VALIDATE_RULES, null));
		// CALL ADDC BALANCE ENQUIRY
		BalanceEnquiryResponse balEnqRes = this.addcBalanceEnquiry(siDetails);
		if (balEnqRes != null) {
			final String amountDue = balEnqRes.getAmountDue();
			log.info("{} - Addc Amount Due: {} ", siId, amountDue);

			if (StringUtils.isNotBlank(amountDue)) {
				BillerPaymentResponse paymentRes = null;
				if (ApplicationConstants.ACCOUNT.equalsIgnoreCase(siDetails.getSourceType())) {
					// UPDATE IN SI TRANSACTIONS
					siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.PAYMENT_PROCESSING, null));
					// PAYMENT
					paymentRes = this.addcAccountPayment(balEnqRes, siDetails);
					// UPDATE IN SI TRANSACTIONS
					if (paymentRes != null) {
						siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(paymentRes, siDetails, TransactionStatus.PAYMENT_STATUS, null));
					} else {
						siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(paymentRes, siDetails, TransactionStatus.INTERNAL_ERROR, null));
					}
				} else if (ApplicationConstants.CARD.equalsIgnoreCase(siDetails.getSourceType())) {
					// UPDATE IN SI TRANSACTIONS
					siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.PAYMENT_PROCESSING, null));
					paymentRes = this.addcCardPayment(balEnqRes, siDetails);
					// UPDATE IN SI TRANSACTIONS
					if (paymentRes != null) {
						siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(paymentRes, siDetails, TransactionStatus.PAYMENT_STATUS, null));
					} else {
						siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(paymentRes, siDetails, TransactionStatus.INTERNAL_ERROR, null));
					}
				}
			} else {
				log.info("{} - Invalid Addc Balance Enquiry Response", siId);
				siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.VALIDATE_RULES_FAILED, siUtility.prepareFailureResponseStatus()));
			}
		}
		return siDetails;
	}

	/**
	 * This method is to prepare AddcBalanceEnquiryRequest Object
	 * 
	 * @param siDetails
	 * @return AadcBalanceEnquiryRequest Object
	 */
	private AadcBalanceEnquiryRequest prepareAddcBalEnqReq(final SIDetails siDetails) {
		AadcBalanceEnquiryRequest aadcBalanceReq = new AadcBalanceEnquiryRequest();
		final String aadcConsumerNo = siDetails.getCreditAcctNo();
		if (StringUtils.isNotBlank(aadcConsumerNo)) {
			aadcBalanceReq.setAadcConsumer(siUtility.prepareBalEnqReq(siDetails, ApplicationConstants.ADDC));
		}
		return aadcBalanceReq;
	}

	/**
	 * This method is to execute Balance Inquiry Service
	 * 
	 * @param siDetails
	 * @return BalanceEnquiryResponse Object
	 */
	private BalanceEnquiryResponse addcBalanceEnquiry(final SIDetails siDetails) {
		BalanceEnquiryResponse response = null;
		final String siId = siDetails.getSiID();
		final String requestJson = JsonUtils.convertToJson(this.prepareAddcBalEnqReq(siDetails));
		log.info("{} - Addc Balance Enquiry Request: {}", siId, requestJson);
		// CREATE HTTP HEADERS
		Map<String, String> headers = siUtility.populateHeaders(siDetails.getChannelId(), siDetails.getCustomerIdentifier());
		ConnectorResponse connResponse = httpConnect.post(ServiceUrls.ADDC_BALANCE_ENQ, requestJson, headers);
		if (connResponse.getResponseStatus() == 200) {
			log.info("{} - Addc Balance Enquiry Response: {}", siId, connResponse.getJsonResponse());
			response = JsonUtils.convertToObject(BalanceEnquiryResponse.class, connResponse.getJsonResponse());
		}
		log.info("{} - Addc BalanceEnquiryResponse: {}", siId, response);
		return response;
	}

	/**
	 * This method is to execute Account Payment Service
	 * 
	 * @param balEnqRes
	 * @param siDetails
	 * @return BillerPaymentResponse Object
	 */
	private BillerPaymentResponse addcAccountPayment(final BalanceEnquiryResponse balEnqRes, final SIDetails siDetails) {
		BillerPaymentResponse response = null;
		final String siId = siDetails.getSiID();
		AddcBillPaymentRequest addcPayment = new AddcBillPaymentRequest();
		addcPayment.setAddcConsumer(siUtility.prepareBalEnqReq(siDetails, ApplicationConstants.ADDC));
		addcPayment.setAccountPayment(siUtility.preparePaymentReq(siDetails, balEnqRes));
		final String requestJson = JsonUtils.convertToJson(addcPayment);
		log.info("{} - Addc Account Payment Request: {}", siId, requestJson);
		// CREATE HTTP HEADERS
		Map<String, String> headers = siUtility.populateHeaders(siDetails.getChannelId(), siDetails.getCustomerIdentifier());
		ConnectorResponse connResponse = httpConnect.post(ServiceUrls.ADDC_PAYMENT_BYACCOUNT, requestJson, headers);
		if (connResponse.getResponseStatus() == 200) {
			log.info("{} - Addc Account Payment JSON Response: {}", siId, connResponse.getJsonResponse());
			response = JsonUtils.convertToObject(BillerPaymentResponse.class, connResponse.getJsonResponse());
		}
		log.info("{} - Addc Account BillerPaymentResponse: {}", siId, response);
		return response;
	}

	/**
	 * This method is to execute Card Payment Service
	 * 
	 * @param balEnqRes
	 * @param siDetails
	 * @return BillerPaymentResponse Object
	 */
	private BillerPaymentResponse addcCardPayment(final BalanceEnquiryResponse balEnqRes, final SIDetails siDetails) {
		BillerPaymentResponse response = null;
		final String siId = siDetails.getSiID();
		AddcBillPaymentRequest addcPayment = new AddcBillPaymentRequest();
		addcPayment.setAddcConsumer(siUtility.prepareBalEnqReq(siDetails, ApplicationConstants.ADDC));
		addcPayment.setCardPayment(siUtility.preparePaymentReq(siDetails, balEnqRes));
		final String requestJson = JsonUtils.convertToJson(addcPayment);
		log.info("{} - Addc Card Payment Request: {}", siId , requestJson);
		// CREATE HTTP HEADERS
		Map<String, String> headers = siUtility.populateHeaders(siDetails.getChannelId(), siDetails.getCustomerIdentifier());
		ConnectorResponse connResponse = httpConnect.post(ServiceUrls.ADDC_PAYMENT_BYCARD, requestJson, headers);
		if (connResponse.getResponseStatus() == 200) {
			log.info("{} - Addc Card Payment Response: {}", siId, connResponse.getJsonResponse());
			response = JsonUtils.convertToObject(BillerPaymentResponse.class, connResponse.getJsonResponse());
		}
		log.info("{} - Addc Card BillerPaymentResponse: {}", siId , response);
		return response;
	}
}
