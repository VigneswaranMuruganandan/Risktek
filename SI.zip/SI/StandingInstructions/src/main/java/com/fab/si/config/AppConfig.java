/**
 * 
 */
package com.fab.si.config;

/**
 * @author o4359
 *
 */
//@Configuration
//@ComponentScan(value = {"com.fab"})
public class AppConfig {

}
