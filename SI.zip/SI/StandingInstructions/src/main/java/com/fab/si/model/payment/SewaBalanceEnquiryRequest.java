/**
 * 
 */
package com.fab.si.model.payment;

/**
 * @author o4359
 *
 */
public class SewaBalanceEnquiryRequest {

	private BalanceEnquiryRequest sewaConsumer;

	/**
	 * @return the sewaConsumer
	 */
	public BalanceEnquiryRequest getSewaConsumer() {
		return sewaConsumer;
	}

	/**
	 * @param sewaConsumer
	 *            the sewaConsumer to set
	 */
	public void setSewaConsumer(BalanceEnquiryRequest sewaConsumer) {
		this.sewaConsumer = sewaConsumer;
	}

}
