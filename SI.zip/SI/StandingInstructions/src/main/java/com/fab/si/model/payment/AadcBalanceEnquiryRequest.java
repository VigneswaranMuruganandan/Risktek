/**
 * 
 */
package com.fab.si.model.payment;

/**
 * @author o4359
 *
 */
public class AadcBalanceEnquiryRequest {

	private BalanceEnquiryRequest aadcConsumer;

	/**
	 * @return the aadcConsumer
	 */
	public BalanceEnquiryRequest getAadcConsumer() {
		return aadcConsumer;
	}

	/**
	 * @param aadcConsumer
	 *            the aadcConsumer to set
	 */
	public void setAadcConsumer(BalanceEnquiryRequest aadcConsumer) {
		this.aadcConsumer = aadcConsumer;
	}

}
