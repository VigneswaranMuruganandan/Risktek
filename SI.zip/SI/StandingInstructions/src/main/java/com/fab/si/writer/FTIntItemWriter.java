/**
 * 
 */
package com.fab.si.writer;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;

import com.fab.si.model.common.SIDetails;

/**
 * @author o4359
 *
 */
public class FTIntItemWriter implements ItemWriter<SIDetails>{

	private Logger log = LoggerFactory.getLogger(getClass());
	
	@Override
	public void write(List<? extends SIDetails> arg0) throws Exception {
		log.info("Funds Transfer International Item Writer: {}", arg0);
		log.info("############# FUNDS TRANSFER INTERNATIONAL RECORD: END ################");
	}

}
