/**
 * 
 */
package com.fab.si.model.transfer;

/**
 * @author o4359
 *
 */
public class FundsTransferResponse extends BaseApiResponse {

	private String fgbTransactionRefNo;
	private String status;

	/**
	 * @return the fgbTransactionRefNo
	 */
	public String getFgbTransactionRefNo() {
		return fgbTransactionRefNo;
	}

	/**
	 * @param fgbTransactionRefNo
	 *            the fgbTransactionRefNo to set
	 */
	public void setFgbTransactionRefNo(String fgbTransactionRefNo) {
		this.fgbTransactionRefNo = fgbTransactionRefNo;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

}
