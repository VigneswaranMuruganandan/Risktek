/**
 * 
 */
package com.fab.si.reader;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fab.si.common.QueryConstants;
import com.fab.si.model.common.SIDetails;
import com.fab.si.processor.SIPreparedStmtSetter;
import com.fab.si.processor.SIRowMapper;

/**
 * @author kaushikmukherjee
 *
 */
@Component
public class FTOwnJdbcReader extends JdbcCursorItemReader<SIDetails> {

	private Logger log = LoggerFactory.getLogger(getClass());

	@Autowired
	private DataSource pbDataSource;

	@Autowired
	private SIPreparedStmtSetter preparedStmtSetter;

	@Autowired
	private SIRowMapper resultSetMapper;

	@Override
	public void afterPropertiesSet() throws Exception {
		log.info("########### FUNDS TRANSFER OWN RECORD: START ##########");
		setDataSource(pbDataSource);
		setSql(QueryConstants.SELECT_FTOWN_SI_QUERY);
		setPreparedStatementSetter(preparedStmtSetter);
		setRowMapper(resultSetMapper);
		super.afterPropertiesSet();
	}
}
