/**
 * 
 */
package com.fab.si.model.transfer;

/**
 * @author o4359
 *
 */
public class BeneficiaryDetails {

	private String cifId;
	private String beneNickName;
	private String templateId;
	private String beneficiaryName;
	private String beneAccount;
	private String beneType;
	private String beneAddr1;
	private String beneAddr2;
	private String beneAddr3;
	private String routingCode;
	private String transferCurrency;
	private String beneBankCountry;
	private String receiverBankName;
	private String beneBranchName;
	private String beneBankAddr1;
	private String beneBankAddr2;
	private String beneDescription;
	private String receiverBankSWIFTCode;
	private String chargeType;
	private String correspondantBank;

	/**
	 * @return the cifId
	 */
	public String getCifId() {
		return cifId;
	}

	/**
	 * @param cifId
	 *            the cifId to set
	 */
	public void setCifId(String cifId) {
		this.cifId = cifId;
	}

	/**
	 * @return the beneNickName
	 */
	public String getBeneNickName() {
		return beneNickName;
	}

	/**
	 * @param beneNickName
	 *            the beneNickName to set
	 */
	public void setBeneNickName(String beneNickName) {
		this.beneNickName = beneNickName;
	}

	/**
	 * @return the templateId
	 */
	public String getTemplateId() {
		return templateId;
	}

	/**
	 * @param templateId
	 *            the templateId to set
	 */
	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}

	/**
	 * @return the beneAccount
	 */
	public String getBeneAccount() {
		return beneAccount;
	}

	/**
	 * @param beneAccount
	 *            the beneAccount to set
	 */
	public void setBeneAccount(String beneAccount) {
		this.beneAccount = beneAccount;
	}

	/**
	 * @return the beneType
	 */
	public String getBeneType() {
		return beneType;
	}

	/**
	 * @param beneType
	 *            the beneType to set
	 */
	public void setBeneType(String beneType) {
		this.beneType = beneType;
	}

	/**
	 * @return the beneAddr1
	 */
	public String getBeneAddr1() {
		return beneAddr1;
	}

	/**
	 * @param beneAddr1
	 *            the beneAddr1 to set
	 */
	public void setBeneAddr1(String beneAddr1) {
		this.beneAddr1 = beneAddr1;
	}

	/**
	 * @return the beneAddr2
	 */
	public String getBeneAddr2() {
		return beneAddr2;
	}

	/**
	 * @param beneAddr2
	 *            the beneAddr2 to set
	 */
	public void setBeneAddr2(String beneAddr2) {
		this.beneAddr2 = beneAddr2;
	}

	/**
	 * @return the beneAddre3
	 */
	public String getBeneAddr3() {
		return beneAddr3;
	}

	/**
	 * @param beneAddre3
	 *            the beneAddre3 to set
	 */
	public void setBeneAddr3(String beneAddre3) {
		this.beneAddr3 = beneAddre3;
	}

	/**
	 * @return the routingCode
	 */
	public String getRoutingCode() {
		return routingCode;
	}

	/**
	 * @param routingCode
	 *            the routingCode to set
	 */
	public void setRoutingCode(String routingCode) {
		this.routingCode = routingCode;
	}

	/**
	 * @return the transferCurrency
	 */
	public String getTransferCurrency() {
		return transferCurrency;
	}

	/**
	 * @param transferCurrency
	 *            the transferCurrency to set
	 */
	public void setTransferCurrency(String transferCurrency) {
		this.transferCurrency = transferCurrency;
	}

	/**
	 * @return the beneBankCountry
	 */
	public String getBeneBankCountry() {
		return beneBankCountry;
	}

	/**
	 * @param beneBankCountry
	 *            the beneBankCountry to set
	 */
	public void setBeneBankCountry(String beneBankCountry) {
		this.beneBankCountry = beneBankCountry;
	}

	/**
	 * @return the beneBranchName
	 */
	public String getBeneBranchName() {
		return beneBranchName;
	}

	/**
	 * @param beneBranchName
	 *            the beneBranchName to set
	 */
	public void setBeneBranchName(String beneBranchName) {
		this.beneBranchName = beneBranchName;
	}

	/**
	 * @return the beneBankAddr1
	 */
	public String getBeneBankAddr1() {
		return beneBankAddr1;
	}

	/**
	 * @param beneBankAddr1
	 *            the beneBankAddr1 to set
	 */
	public void setBeneBankAddr1(String beneBankAddr1) {
		this.beneBankAddr1 = beneBankAddr1;
	}

	/**
	 * @return the beneBankAddr2
	 */
	public String getBeneBankAddr2() {
		return beneBankAddr2;
	}

	/**
	 * @param beneBankAddr2
	 *            the beneBankAddr2 to set
	 */
	public void setBeneBankAddr2(String beneBankAddr2) {
		this.beneBankAddr2 = beneBankAddr2;
	}

	/**
	 * @return the beneDescription
	 */
	public String getBeneDescription() {
		return beneDescription;
	}

	/**
	 * @param beneDescription
	 *            the beneDescription to set
	 */
	public void setBeneDescription(String beneDescription) {
		this.beneDescription = beneDescription;
	}

	/**
	 * @return the chargeType
	 */
	public String getChargeType() {
		return chargeType;
	}

	/**
	 * @param chargeType
	 *            the chargeType to set
	 */
	public void setChargeType(String chargeType) {
		this.chargeType = chargeType;
	}

	/**
	 * @return the correspondantBank
	 */
	public String getCorrespondantBank() {
		return correspondantBank;
	}

	/**
	 * @param correspondantBank
	 *            the correspondantBank to set
	 */
	public void setCorrespondantBank(String correspondantBank) {
		this.correspondantBank = correspondantBank;
	}

	/**
	 * @return the beneficiaryName
	 */
	public String getBeneficiaryName() {
		return beneficiaryName;
	}

	/**
	 * @param beneficiaryName the beneficiaryName to set
	 */
	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}

	/**
	 * @return the receiverBankName
	 */
	public String getReceiverBankName() {
		return receiverBankName;
	}

	/**
	 * @param receiverBankName the receiverBankName to set
	 */
	public void setReceiverBankName(String receiverBankName) {
		this.receiverBankName = receiverBankName;
	}

	/**
	 * @return the receiverBankSWIFTCode
	 */
	public String getReceiverBankSWIFTCode() {
		return receiverBankSWIFTCode;
	}

	/**
	 * @param receiverBankSWIFTCode the receiverBankSWIFTCode to set
	 */
	public void setReceiverBankSWIFTCode(String receiverBankSWIFTCode) {
		this.receiverBankSWIFTCode = receiverBankSWIFTCode;
	}
}
