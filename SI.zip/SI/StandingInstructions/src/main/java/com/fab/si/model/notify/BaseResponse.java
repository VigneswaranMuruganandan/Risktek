package com.fab.si.model.notify;

import java.io.Serializable;

public class BaseResponse implements Serializable {

	private static final long serialVersionUID = -1916606269935289307L;
	protected String requestID;
	protected String responseID;
	protected String smsACK;

	public String getResponseID() {
		return responseID;
	}

	public String getRequestID() {
		return requestID;
	}

	public void setRequestID(String requestID) {
		this.requestID = requestID;
	}

	public void setResponseID(String responseID) {
		this.responseID = responseID;
	}

	public String getSmsACK() {
		return smsACK;
	}

	public void setSmsACK(String smsACK) {
		this.smsACK = smsACK;
	}
}
