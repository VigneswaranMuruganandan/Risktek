/**
 * 
 */
package com.fab.si.model.payment;

/**
 * @author o4359
 *
 */
public class EtisalatBalanceEnquiryRequest {

	private BalanceEnquiryRequest etisalatConsumer;

	/**
	 * @return the etisalatConsumer
	 */
	public BalanceEnquiryRequest getEtisalatConsumer() {
		return etisalatConsumer;
	}

	/**
	 * @param etisalatConsumer
	 *            the etisalatConsumer to set
	 */
	public void setEtisalatConsumer(BalanceEnquiryRequest etisalatConsumer) {
		this.etisalatConsumer = etisalatConsumer;
	}

}
