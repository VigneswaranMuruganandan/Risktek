/**
 * 
 */
package com.fab.si.common;

/**
 * @author o4359
 *
 */
public enum ServiceUrls {

	// NOTIFICATION SERVICE
	NOTIFY_SMS(ApplicationConstants.WAS_SERVICE, "/NotificationService/nsapi/sms/sendsms/single"),
	NOTIFY_EMAIL(ApplicationConstants.WAS_SERVICE, "/NotificationService/nsapi/email/sendemail"),
	
	// SALIK IIB SERVICE
	SALIK_BALANCE_ENQ(ApplicationConstants.IIB_SERVICE, "/utility/salik/v1/bills/balance"),
	SALIK_PAYMENT_BYACCOUNT(ApplicationConstants.IIB_SERVICE,"/utility/salik/v1/bills/payment/byaccount"),
	SALIK_PAYMENT_BYCARD(ApplicationConstants.IIB_SERVICE,"/utility/salik/v1/bills/payment/bycreditcard"),
	
	// AADC IIB SERVICE
	AADC_BALANCE_ENQ(ApplicationConstants.IIB_SERVICE, "/utility/aadc/v1/bills/balance"),
	AADC_PAYMENT_BYACCOUNT(ApplicationConstants.IIB_SERVICE,"/utility/aadc/v1/bills/payment/byaccount"),
	AADC_PAYMENT_BYCARD(ApplicationConstants.IIB_SERVICE,"/utility/aadc/v1/bills/payment/bycreditcard"),
	
	// ADDC IIB SERVICE
	ADDC_BALANCE_ENQ(ApplicationConstants.IIB_SERVICE, "/utility/addc/v1/bills/balance"),
	ADDC_PAYMENT_BYACCOUNT(ApplicationConstants.IIB_SERVICE,"/utility/addc/v1/bills/payment/byaccount"),
	ADDC_PAYMENT_BYCARD(ApplicationConstants.IIB_SERVICE,"/utility/addc/v1/bills/payment/bycreditcard"),
	
	// SEWA IIB SERVICE
	SEWA_BALANCE_ENQ(ApplicationConstants.IIB_SERVICE, "/utility/sewa/v1/bills/balance"),
	SEWA_PAYMENT_BYACCOUNT(ApplicationConstants.IIB_SERVICE,"/utility/sewa/v1/bills/payment/byaccount"),
	SEWA_PAYMENT_BYCARD(ApplicationConstants.IIB_SERVICE,"/utility/sewa/v1/bills/payment/bycreditcard"),
	
	// DEWA IIB SERVICE
	DEWA_BALANCE_ENQ(ApplicationConstants.IIB_SERVICE, "/utility/dewa/v1/bills/balance"),
	DEWA_PAYMENT_BYACCOUNT(ApplicationConstants.IIB_SERVICE,"/utility/dewa/v1/bills/payment/byaccount"),
	DEWA_PAYMENT_BYCARD(ApplicationConstants.IIB_SERVICE,"/utility/dewa/v1/bills/payment/bycreditcard"),
	
	// FEWA IIB SERVICE
	FEWA_BALANCE_ENQ(ApplicationConstants.IIB_SERVICE, "/utility/fewa/v1/bills/balance"),
	FEWA_PAYMENT_BYACCOUNT(ApplicationConstants.IIB_SERVICE,"/utility/fewa/v1/bills/payment/byaccount"),
	FEWA_PAYMENT_BYCARD(ApplicationConstants.IIB_SERVICE,"/utility/fewa/v1/bills/payment/bycreditcard"),
	
	// DU IIB SERVICE
	DU_BALANCE_ENQ(ApplicationConstants.IIB_SERVICE, "/utility/du/v1/bills/balance"),
	DU_PAYMENT_BYACCOUNT(ApplicationConstants.IIB_SERVICE,"/utility/du/v1/bills/payment/byaccount"),
	DU_PAYMENT_BYCARD(ApplicationConstants.IIB_SERVICE,"/utility/du/v1/bills/payment/bycreditcard"),
	
	// ETISALAT IIB SERVICE
	ETISALAT_BALANCE_ENQ(ApplicationConstants.IIB_SERVICE, "/utility/etisalat/v1/bills/balance"),
	ETISALAT_PAYMENT_BYACCOUNT(ApplicationConstants.IIB_SERVICE,"/utility/etisalat/v1/bills/payment/byaccount"),
	ETISALAT_PAYMENT_BYCARD(ApplicationConstants.IIB_SERVICE,"/utility/etisalat/v1/bills/payment/bycreditcard"),
	ETISALAT_WASEL_RECHARGE_BALANCE_ENQ(ApplicationConstants.IIB_SERVICE, "/utility/etisalat/v1/waselrecharge/balance/{0}"),
	ETISALAT_WASEL_RECHARGE_BYACCOUNT(ApplicationConstants.IIB_SERVICE,"/utility/etisalat/v1/waselrecharge/payment/byaccount"),
	ETISALAT_WASEL_RECHARGE_BYCARD(ApplicationConstants.IIB_SERVICE,"/utility/etisalat/v1/waselrecharge/payment/bycreditcard"),
	ETISALAT_WASEL_RENEWAL_BALANCE_ENQ(ApplicationConstants.IIB_SERVICE, "/utility/etisalat/v1/waselrenew/balance/{0}"),
	ETISALAT_WASEL_RENEWAL_BYACCOUNT(ApplicationConstants.IIB_SERVICE,"/utility/etisalat/v1/waselrenew/payment/byaccount"),
	ETISALAT_WASEL_RENEWAL_BYCARD(ApplicationConstants.IIB_SERVICE,"/utility/etisalat/v1/waselrenew/payment/bycreditcard"),
	
	// FUND TRANSFER SERVICE
	FT_OWN_ACCT(ApplicationConstants.IIB_SERVICE,"/financial/transactions/v1/payments/ownaccount"),
	FT_WITHIN_UAE(ApplicationConstants.IIB_SERVICE,"/financial/transactions/v1/payments/withinuae"),
	FT_WITHIN_BANK(ApplicationConstants.IIB_SERVICE,"/financial/transactions/v1/payments/withinbank"),
	FT_INTERNATIONAL(ApplicationConstants.IIB_SERVICE,"/financial/transactions/v1/payments/international"),
	
	// CHARITY PAYMENT
	CHARITY_PAYMENT_BYCARD(ApplicationConstants.IIB_SERVICE,"/financial/transactions/v1/payment/charity/creditcard"),
	CHARITY_PAYMENT_BYACCOUNT(ApplicationConstants.IIB_SERVICE,"/financial/transactions/v1/payment/charity/account");

	private String url;
	private String targetSystem;

	private ServiceUrls(String targetSystem, String url) {
		this.targetSystem = targetSystem;
		this.url = url;
	}
	public String getUrl() {
		return url;
	}

	public String getTargetSystem() {
		return targetSystem;
	}
}
