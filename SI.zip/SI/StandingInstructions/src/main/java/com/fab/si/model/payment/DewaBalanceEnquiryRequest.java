/**
 * 
 */
package com.fab.si.model.payment;

/**
 * @author o4359
 *
 */
public class DewaBalanceEnquiryRequest {

	private BalanceEnquiryRequest dewaConsumer;

	/**
	 * @return the dewaConsumer
	 */
	public BalanceEnquiryRequest getDewaConsumer() {
		return dewaConsumer;
	}

	/**
	 * @param dewaConsumer
	 *            the dewaConsumer to set
	 */
	public void setDewaConsumer(BalanceEnquiryRequest dewaConsumer) {
		this.dewaConsumer = dewaConsumer;
	}

}
