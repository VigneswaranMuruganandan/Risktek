/**
 * 
 */
package com.fab.si.model.transfer;

import java.util.List;

/**
 * @author o4359
 *
 */
public class BaseApiResponse {

	private List<ResponseStatus> responseStatus;

	/**
	 * @return the responseStatus
	 */
	public List<ResponseStatus> getResponseStatus() {
		return responseStatus;
	}

	/**
	 * @param responseStatus
	 *            the responseStatus to set
	 */
	public void setResponseStatus(List<ResponseStatus> responseStatus) {
		this.responseStatus = responseStatus;
	}
}
