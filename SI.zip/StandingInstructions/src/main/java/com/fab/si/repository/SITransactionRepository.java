/**
 * 
 */
package com.fab.si.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fab.si.common.ApplicationConstants;
import com.fab.si.common.QueryConstants;
import com.fab.si.common.TransactionCodes;
import com.fab.si.model.common.LimitDetails;
import com.fab.si.model.common.SITransaction;

/**
 * @author o4359
 *
 */
@Component("siTxnRepo")
public class SITransactionRepository {

	private Logger log = LoggerFactory.getLogger(getClass());

	@Autowired
	private DataSource pbDataSource;

	@Resource(name = "diDs")
	private DataSource diDs;

	public void updateSiTransaction(final SITransaction siTxn) {
		try (Connection con = pbDataSource.getConnection(); 
				PreparedStatement psSiUpdate = con.prepareStatement(QueryConstants.UPDATE_SI_TRANSACTION_SUCCESS_QUERY);) {

			// UPDATE SI TRANSACTION IN CASE OF SUCCESS
			int i = 0;
			psSiUpdate.setString(++i, siTxn.getSmsStatus());
			psSiUpdate.setString(++i, siTxn.getTxnStatus());
			psSiUpdate.setString(++i, siTxn.getStatusCode());
			psSiUpdate.setString(++i, siTxn.getStatusDesc());
			psSiUpdate.setString(++i, siTxn.getTxnId());
			psSiUpdate.setDate(++i, siTxn.getNxtRunOn());
			psSiUpdate.setInt(++i, siTxn.getPerDayRetryCount());
			psSiUpdate.setInt(++i, siTxn.getCompletedCount());
			psSiUpdate.setString(++i, siTxn.getModifiedBy());
			psSiUpdate.setString(++i, siTxn.getSiId());
			int rowCount = psSiUpdate.executeUpdate();
			log.info("{} Row Updated For SI ID: {}", rowCount, siTxn.getSiId());

			// AUDIT TABLE
			this.insertSiTransactionAudit(siTxn);

		} catch (SQLException exe) {
			log.error("Exception Occured in updateSiTransaction: {} ", exe);
		}
	}

	public void updateSiSmsTransaction(final SITransaction siTxn) {
		try (Connection con = pbDataSource.getConnection(); 
				PreparedStatement psSiUpdate = con.prepareStatement(QueryConstants.UPDATE_SI_SMS_STATUS_QUERY);) {

			// UPDATE SI SMS TRANSACTION STATUS
			psSiUpdate.setString(1, siTxn.getSmsStatus());
			psSiUpdate.setString(2, ApplicationConstants.NOTIFY_JOB);
			psSiUpdate.setString(3, siTxn.getSiId());
			int rowCount = psSiUpdate.executeUpdate();
			log.info("{} Row Updated For SI ID: {}", rowCount, siTxn.getSiId());

			// AUDIT TABLE
			this.insertSiTransactionAudit(siTxn);

		} catch (SQLException exe) {
			log.error("Exception Occured in updateSiTransaction: {} ", exe);
		}
	}

	public void insertSiTransactionAudit(final SITransaction siTxn) {
		try (Connection con = pbDataSource.getConnection(); 
				PreparedStatement psSiInsert = con.prepareStatement(QueryConstants.INSERT_SI_TRANSACTION_AUDIT_QUERY);) {

			// INSERT SI TRANSACTION AUDIT
			int i = 0;
			psSiInsert.setString(++i, siTxn.getSiId());
			psSiInsert.setString(++i, siTxn.getSmsStatus());
			psSiInsert.setString(++i, siTxn.getTxnStatus());
			psSiInsert.setString(++i, siTxn.getStatusCode());
			psSiInsert.setString(++i, siTxn.getStatusDesc());
			psSiInsert.setString(++i, siTxn.getTxnId());
			psSiInsert.setDate(++i, siTxn.getNxtRunOn());
			psSiInsert.setInt(++i, siTxn.getPerDayRetryCount());
			psSiInsert.setInt(++i, siTxn.getCompletedCount());
			psSiInsert.setString(++i, siTxn.getCreatedBy());
			psSiInsert.setString(++i, siTxn.getModifiedBy());
			int rowCount = psSiInsert.executeUpdate();
			log.info("{} Row Inserted For SI ID: {}", rowCount, siTxn.getSiId());

		} catch (SQLException exe) {
			log.error("Exception Occured in insertSiTransactionAudit: {} ", exe);
		}
	}

	public LimitDetails getTransactionLimit(final String paymentTransferName) {
		LimitDetails response = null;
		ResultSet rs = null;
		try (Connection con = diDs.getConnection(); 
				PreparedStatement ps = con.prepareStatement(QueryConstants.LIMIT_DETAILS_QUERY);) {

			if (StringUtils.isNotBlank(paymentTransferName)) {
				ps.setString(1, TransactionCodes.valueOf(paymentTransferName.toUpperCase()).getDesc());
				rs = ps.executeQuery();
				while (rs.next()) {
					response = new LimitDetails();
					response.setMinAmount(rs.getDouble(1));
					response.setMaxAmount(rs.getDouble(2));
					response.setInMultiplesOf(rs.getInt(3));
				}
			}
		} catch (SQLException exe) {
			log.error("Exception Occured in getTransactionLimit: {} ", exe);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					log.error("Exception Occured in getTransactionLimit: {} ", e);
				}
			}
		}
		return response;
	}
}
