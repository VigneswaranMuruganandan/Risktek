/**
 * 
 */
package com.fab.si.processor;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fab.si.common.ApplicationConstants;
import com.fab.si.common.ErrorCodes;
import com.fab.si.common.ServiceUrls;
import com.fab.si.common.TemplateId;
import com.fab.si.common.TransactionStatus;
import com.fab.si.helper.HttpConnector;
import com.fab.si.helper.JsonUtils;
import com.fab.si.helper.SIUtility;
import com.fab.si.model.common.ConnectorResponse;
import com.fab.si.model.common.SIDetails;
import com.fab.si.model.payment.BalanceEnquiryResponse;
import com.fab.si.model.payment.BillerPaymentResponse;
import com.fab.si.model.payment.PaymentResponseStatus;
import com.fab.si.model.payment.SalikBalanceEnquiryRequest;
import com.fab.si.model.payment.SalikBillPaymentRequest;
import com.fab.si.repository.SITransactionRepository;

/**
 * @author o4359
 *
 */
@Component("salikItemProcessor")
public class SalikItemProcessor implements ItemProcessor<SIDetails, SIDetails> {

	private Logger log = LoggerFactory.getLogger(getClass());

	@Autowired
	private HttpConnector httpConnect;

	@Autowired
	private SIUtility siUtility;

	@Autowired
	private SITransactionRepository siTxnRepo;

	@Override
	public SIDetails process(SIDetails siDetails) throws Exception {

		final String siId = siDetails.getSiID();
		log.info("{} - Salik Object in Item Processor: {}", siId, siDetails);

		// UPDATE IN SI TRANSACTIONS
		siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.VALIDATE_RULES, null));
		// CALL SALIK BALANCE ENQUIRY
		BalanceEnquiryResponse balEnqRes = this.salikBalanceEnquiry(siDetails);

		if (balEnqRes != null) {
			final String txnId = balEnqRes.getTransactionID();
			final String availableBalance = balEnqRes.getAvailableBalance();
			log.info("{} - Salik TxnId: {}", siId, txnId);
			log.info("{} - Salik Available Balance: {}", siId, availableBalance);

			// VALIDATE LIMIT AND TXN AMOUNT
			if (!siUtility.isValidTxnAmount(siDetails, balEnqRes)) {
				log.info("{} - Transaction Amount Is not valid", siId);
				siTxnRepo.updateSiTransaction(
						siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.VALIDATE_RULES_FAILED, siUtility.prepareFailureResponseStatus(ErrorCodes.LIMIT_CHK_FAILED)));
				return siDetails;
			}

			if (StringUtils.isNotBlank(txnId) && StringUtils.isNotBlank(availableBalance)) {

				// CHECK FOR AMOUNT DUE
				if (Double.valueOf(availableBalance) < 0) {
					siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.VALIDATE_RULES_FAILED,
							siUtility.prepareFailureResponseStatus(ErrorCodes.AMOUNT_DUE_INVALID)));
					log.info("{} - Amount Due is Overpaid", siId);
					return siDetails;
				}

				BillerPaymentResponse paymentRes = null;
				PaymentResponseStatus status = this.checkSalikPaymentByAmount(siDetails, availableBalance);
				if (ApplicationConstants.ACCOUNT.equalsIgnoreCase(siDetails.getSourceType())) {
					if (ApplicationConstants.SUCCESS.equalsIgnoreCase(status.getStatus())) {
						// UPDATE IN SI TRANSACTIONS
						siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.PAYMENT_PROCESSING, null));
						// PAYMENT
						paymentRes = this.salikAccountPayment(balEnqRes, siDetails);
						// UPDATE IN SI TRANSACTIONS
						if (paymentRes != null) {
							siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(paymentRes, siDetails, TransactionStatus.PAYMENT_STATUS, null));
						} else {
							siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(paymentRes, siDetails, TransactionStatus.INTERNAL_ERROR, null));
						}
					}
				} else if (ApplicationConstants.CARD.equalsIgnoreCase(siDetails.getSourceType())) {

					if (ApplicationConstants.SUCCESS.equalsIgnoreCase(status.getStatus())) {
						// UPDATE IN SI TRANSACTIONS
						siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.PAYMENT_PROCESSING, null));
						paymentRes = this.salikCardPayment(balEnqRes, siDetails);
						// UPDATE IN SI TRANSACTIONS
						if (paymentRes != null) {
							siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(paymentRes, siDetails, TransactionStatus.PAYMENT_STATUS, null));
						} else {
							siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(paymentRes, siDetails, TransactionStatus.INTERNAL_ERROR, null));
						}
					}
				}
			} else {
				log.info("{} - Invalid Salik Balance Enquiry Response", siId);
				siTxnRepo.updateSiTransaction(
						siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.VALIDATE_RULES_FAILED, siUtility.prepareFailureResponseStatus(ErrorCodes.BALANCE_ENQ_FAILED)));
			}
		} else {
			log.info("{} - Invalid Salik Balance Enquiry Response", siId);
			siTxnRepo.updateSiTransaction(
					siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.VALIDATE_RULES_FAILED, siUtility.prepareFailureResponseStatus(ErrorCodes.BALANCE_ENQ_FAILED)));
		}
		return siDetails;
	}

	private PaymentResponseStatus checkSalikPaymentByAmount(final SIDetails siDetails, final String availableBalance) {
		PaymentResponseStatus status = new PaymentResponseStatus();
		status.setStatus(ApplicationConstants.SUCCESS);
		if (TemplateId.SALIK_BILLPAYMENT_BYAMOUNT.getTemplateId().equalsIgnoreCase(siDetails.getTemplateId())) {
			if (!(siDetails.getMinAmount() != null && Double.valueOf(availableBalance) < siDetails.getMinAmount())) {
				status.setStatus(ApplicationConstants.ERROR);
				status.setErrorCode(ErrorCodes.SALIK_MAX_MIN_AMT.getCode());
				status.setErrorDesc(ErrorCodes.SALIK_MAX_MIN_AMT.getDesc());
			}
		}
		log.info("{} - Check Salik Payment By Amount: {}", siDetails.getSiID(), status);
		return status;
	}

	/**
	 * This method is to prepare SalikBalanceEnquiryRequest Object
	 * 
	 * @param siDetails
	 * @return SalikBalanceEnquiryRequest Object
	 */
	private SalikBalanceEnquiryRequest prepareSalikBalEnqReq(final SIDetails siDetails) {
		SalikBalanceEnquiryRequest salikBalanceReq = null;
		final String salikConsumerNo = siDetails.getCreditAcctNo();
		if (StringUtils.isNotBlank(salikConsumerNo) && salikConsumerNo.length() == 12) {
			salikBalanceReq = new SalikBalanceEnquiryRequest();
			salikBalanceReq.setAccountNo(salikConsumerNo.substring(0, 8));
			salikBalanceReq.setSalikPinNo(salikConsumerNo.substring(8, 12));
			salikBalanceReq.setCustomerIdentifier(siDetails.getCustomerIdentifier());
		}
		return salikBalanceReq;
	}

	/**
	 * This method is to execute Balance Inquiry Service
	 * 
	 * @param siDetails
	 * @return BalanceEnquiryResponse Object
	 */
	private BalanceEnquiryResponse salikBalanceEnquiry(final SIDetails siDetails) {
		BalanceEnquiryResponse response = null;
		final String siId = siDetails.getSiID();
		final String requestJson = JsonUtils.convertToJson(this.prepareSalikBalEnqReq(siDetails));
		log.info("{} - Salik Balance Enquiry Request: {}", siId, requestJson);
		// CREATE HTTP HEADERS
		Map<String, String> headers = siUtility.populateHeaders();
		ConnectorResponse connResponse = httpConnect.post(ServiceUrls.SALIK_BALANCE_ENQ, requestJson, headers);
		if (connResponse.getResponseStatus() == 200) {
			log.info("{} - Salik Balance Enquiry Response: {}", siId, connResponse.getJsonResponse());
			response = JsonUtils.convertToObject(BalanceEnquiryResponse.class, connResponse.getJsonResponse());
		}
		log.info("{} - Salik BalanceEnquiryResponse: {}", siId, response);
		return response;
	}

	/**
	 * This method is to execute Account Payment Service
	 * 
	 * @param balEnqRes
	 * @param siDetails
	 * @return BillerPaymentResponse Object
	 */
	private BillerPaymentResponse salikAccountPayment(final BalanceEnquiryResponse balEnqRes, final SIDetails siDetails) {
		BillerPaymentResponse response = null;
		final String siId = siDetails.getSiID();
		SalikBillPaymentRequest salikPayment = new SalikBillPaymentRequest();
		salikPayment.setSalikConsumer(this.prepareSalikBalEnqReq(siDetails));
		salikPayment.setAccountPayment(siUtility.preparePaymentReq(siDetails, balEnqRes));
		salikPayment.setCustomerIdentifier(siDetails.getCustomerIdentifier());
		final String requestJson = JsonUtils.convertToJson(salikPayment);
		log.info("{} - Salik Account Payment Request: {}", siId, requestJson);
		// CREATE HTTP HEADERS
		Map<String, String> headers = siUtility.populateHeaders();
		ConnectorResponse connResponse = httpConnect.post(ServiceUrls.SALIK_PAYMENT_BYACCOUNT, requestJson, headers);
		if (connResponse.getResponseStatus() == 200) {
			log.info("{} - Salik Account Payment JSON Response: {}", siId, connResponse.getJsonResponse());
			response = JsonUtils.convertToObject(BillerPaymentResponse.class, connResponse.getJsonResponse());
		}
		log.info("{} - Salik Account BillerPaymentResponse: {}", siId, response);
		return response;
	}

	/**
	 * This method is to execute Card Payment Service
	 * 
	 * @param balEnqRes
	 * @param siDetails
	 * @return BillerPaymentResponse Object
	 */
	private BillerPaymentResponse salikCardPayment(final BalanceEnquiryResponse balEnqRes, final SIDetails siDetails) {
		BillerPaymentResponse response = null;
		final String siId = siDetails.getSiID();
		SalikBillPaymentRequest salikPayment = new SalikBillPaymentRequest();
		salikPayment.setSalikConsumer(this.prepareSalikBalEnqReq(siDetails));
		salikPayment.setCardPayment(siUtility.preparePaymentReq(siDetails, balEnqRes));
		salikPayment.setCustomerIdentifier(siDetails.getCustomerIdentifier());
		final String requestJson = JsonUtils.convertToJson(salikPayment);
		log.info("{} - Salik Card Payment Request: {}", siId, requestJson);
		// CREATE HTTP HEADERS
		Map<String, String> headers = siUtility.populateHeaders();
		ConnectorResponse connResponse = httpConnect.post(ServiceUrls.SALIK_PAYMENT_BYCARD, requestJson, headers);
		if (connResponse.getResponseStatus() == 200) {
			log.info("{} - Salik Card Payment Response: {}", siId, connResponse.getJsonResponse());
			response = JsonUtils.convertToObject(BillerPaymentResponse.class, connResponse.getJsonResponse());
		}
		log.info("{} - Salik Card BillerPaymentResponse: {}", siId, response);
		return response;
	}
}
