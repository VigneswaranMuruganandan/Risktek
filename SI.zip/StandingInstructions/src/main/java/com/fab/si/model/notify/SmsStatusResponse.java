package com.fab.si.model.notify;

import java.io.Serializable;

public class SmsStatusResponse extends BaseResponse implements Serializable {

	private static final long serialVersionUID = -6198569306485556957L;
	protected String deliveryStatus;
	protected String errorDesc;

	public String getDeliveryStatus() {
		return deliveryStatus;
	}

	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}

	public String getErrorDesc() {
		return errorDesc;
	}

	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("SMSStatusResponse [requestID=");
		builder.append(requestID);
		builder.append(", smsACK=");
		builder.append(smsACK);
		builder.append(", deliveryStatus=");
		builder.append(deliveryStatus);
		builder.append(", errorDesc=");
		builder.append(errorDesc);
		builder.append("]");
		return builder.toString();
	}
}
