/**
 * 
 */
package com.fab.si.model.payment;

/**
 * @author o4359
 *
 */
public class EtisalatBalanceEnquiryRequest {

	private BalanceEnquiryRequest etisalatConsumer;
	private String customerIdentifier;

	/**
	 * @return the etisalatConsumer
	 */
	public BalanceEnquiryRequest getEtisalatConsumer() {
		return etisalatConsumer;
	}

	/**
	 * @param etisalatConsumer
	 *            the etisalatConsumer to set
	 */
	public void setEtisalatConsumer(BalanceEnquiryRequest etisalatConsumer) {
		this.etisalatConsumer = etisalatConsumer;
	}

	/**
	 * @return the customerIdentifier
	 */
	public String getCustomerIdentifier() {
		return customerIdentifier;
	}

	/**
	 * @param customerIdentifier
	 *            the customerIdentifier to set
	 */
	public void setCustomerIdentifier(String customerIdentifier) {
		this.customerIdentifier = customerIdentifier;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("EtisalatBalanceEnquiryRequest [etisalatConsumer=");
		builder.append(etisalatConsumer);
		builder.append(", customerIdentifier=");
		builder.append(customerIdentifier);
		builder.append("]");
		return builder.toString();
	}

}
