
package com.fab.si.model.notify;

import java.util.List;

//@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class MultiRecepientSmsRequest extends BaseRequest {

	private static final long serialVersionUID = 2608109526674289303L;
	private List<String> mobileNo;
	private String smsText;
	private String sender;

	public List<String> getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(List<String> mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getSmsText() {
		return smsText;
	}

	public void setSmsText(String smsText) {
		this.smsText = smsText;
	}

	public String getSender() {
		return sender;
	}

	public void setSender(String entityName) {
		this.sender = entityName;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("SMSRequest [mobileNo=");
		builder.append(mobileNo);
		builder.append(", smsText=");
		builder.append(smsText);
		builder.append(", entityName=");
		builder.append(sender);
		builder.append("]");
		return builder.toString();
	}
}
