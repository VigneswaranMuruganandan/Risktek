package com.fab.si.common;

public enum ContentID {

	SI_UBP_REG(""), 
	SI_UBP_DREG(""), 
	SI_UBP_SALIK_BY_AMOUNT_REG(""), 
	SI_UBP_PAYMENT_SUCCESS("SMS_FOR_PAYMENT_SUCCESS"), 
	SI_UBP_PAYMENT_FAILURE("SMS_FOR_PAYMENT_FAILURE");

	private String code;
	private String transactionStatus;

	ContentID(String transactionStatus) {
		this.code = this.name();
		this.transactionStatus = transactionStatus;
	}

	public static String getContentIdBySmsStatus(final String smsStatus) {
		ContentID[] values = ContentID.values();
		String contentCode = null;
		for (ContentID contentId : values) {
			if (contentId.getTransactionStatus().equalsIgnoreCase(smsStatus)) {
				contentCode = contentId.getCode();
			}
		}
		return contentCode;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @param code
	 *            the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @return the transactionStatus
	 */
	public String getTransactionStatus() {
		return transactionStatus;
	}

	/**
	 * @param transactionStatus
	 *            the transactionStatus to set
	 */
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

}
