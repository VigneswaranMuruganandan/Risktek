/**
 * 
 */
package com.fab.si.common;

/**
 * @author o4359
 *
 */
public enum TransactionCodes {

    SALIK("TXN_SALIK_SI_AMT"),
    AADC("TXN_AADC_ACC"),
    ADDC("TXN_ADDC_ACC"),
    DEWA("TXN_DEWA_ACC"),
    ETISALAT("TXN_ETI_ACC"),
    ETISALAT_WASEL_RECHARGE("TXN_WS_REC_ACC"),
    ETISALAT_WASEL_RENEWAL("TXN_WS_REN_ACC"),
    FEWA("TXN_FEWA_ACC"),// ENTRY SHOULD BE ADDED IN DB
    DU("TXN_DU_ACC");
    
    private String code;
    private String desc;
    
    TransactionCodes(String description) {
		this.code = this.name();
		this.desc = description;
    }

    /**
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * @param code the code to set
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * @return the desc
     */
    public String getDesc() {
        return desc;
    }

    /**
     * @param desc the desc to set
     */
    public void setDesc(String desc) {
        this.desc = desc;
    }
}
