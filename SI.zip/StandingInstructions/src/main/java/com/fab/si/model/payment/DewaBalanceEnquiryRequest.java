/**
 * 
 */
package com.fab.si.model.payment;

/**
 * @author o4359
 *
 */
public class DewaBalanceEnquiryRequest {

	private BalanceEnquiryRequest dewaConsumer;
	private String customerIdentifier;

	/**
	 * @return the dewaConsumer
	 */
	public BalanceEnquiryRequest getDewaConsumer() {
		return dewaConsumer;
	}

	/**
	 * @param dewaConsumer
	 *            the dewaConsumer to set
	 */
	public void setDewaConsumer(BalanceEnquiryRequest dewaConsumer) {
		this.dewaConsumer = dewaConsumer;
	}

	/**
	 * @return the customerIdentifier
	 */
	public String getCustomerIdentifier() {
		return customerIdentifier;
	}

	/**
	 * @param customerIdentifier the customerIdentifier to set
	 */
	public void setCustomerIdentifier(String customerIdentifier) {
		this.customerIdentifier = customerIdentifier;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DewaBalanceEnquiryRequest [dewaConsumer=");
		builder.append(dewaConsumer);
		builder.append(", customerIdentifier=");
		builder.append(customerIdentifier);
		builder.append("]");
		return builder.toString();
	}

}
