/**
 * 
 */
package com.fab.si.exception;

import java.io.Serializable;

import com.fab.si.common.ErrorCodes;

/**
 * @author Pratik Das
 *
 */

public class AppException extends RuntimeException implements Serializable {
	
	private static final long serialVersionUID = -8928763986741797671L;
	ErrorCodes errorCode;
	private Throwable err;

	/**
	 * @param error
	 *            code enumeration
	 */
	public AppException(ErrorCodes error) {
		this.errorCode = error;
	}

	/**
	 * @param err001
	 */
	public AppException(ErrorCodes error, Throwable err) {
		this.errorCode = error;
		this.err = err;
	}

	public ErrorCodes getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(ErrorCodes errorCode) {
		this.errorCode = errorCode;
	}

	public Throwable getErr() {
		return err;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("AppException [errorCode=");
		builder.append(errorCode);
		builder.append(", err=");
		builder.append(err);
		builder.append("]");
		return builder.toString();
	}
}
