/**
 * 
 */
package com.fab.si.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fab.si.common.ApplicationConstants;
import com.fab.si.common.ContentGroup;
import com.fab.si.common.ContentID;
import com.fab.si.common.DocumentContentTypes;
import com.fab.si.common.QueryConstants;
import com.fab.si.helper.TextUtils;
import com.fab.si.model.common.SIDetails;
import com.fab.si.model.payment.ContentItem;

/**
 * @author o4359
 *
 */
@Component("notifyRepo")
public class NotificationRepository {

	private Logger log = LoggerFactory.getLogger(getClass());

	@Autowired
	private DataSource pbDataSource;

	@Resource(name = "ciDs")
	private DataSource ciDs;

	public String getCustomerEmailId(final SIDetails siTxn) {
		String emailId = null;
		ResultSet rs1 = null;
		ResultSet rs2 = null;
		try (Connection con = ciDs.getConnection();
				PreparedStatement ps1 = con.prepareStatement(QueryConstants.SELECT_EMAIL_QUERY);
				PreparedStatement ps2 = con.prepareStatement(QueryConstants.SELECT_ACCT_EMAIL_QUERY);) {

			ps1.setString(1, siTxn.getCustomerIdentifier());
			rs1 = ps1.executeQuery();
			while (rs1.next()) {
				emailId = rs1.getString(1);
			}

			if (StringUtils.isBlank(emailId)) {
				ps2.setString(1, siTxn.getCustomerIdentifier());
				rs2 = ps2.executeQuery();
				while (rs2.next()) {
					emailId = rs2.getString(1);
				}
			}
		} catch (SQLException exe) {
			log.error("Exception Occured in getCustomerEmailId: {} ", exe);
		} finally {
			if (rs1 != null) {
				try {
					rs1.close();
				} catch (SQLException e) {
					log.error("Exception Occured in getCustomerEmailId while closing the resultset: {} ", e);
				}
			}
			if (rs2 != null) {
				try {
					rs2.close();
				} catch (SQLException e) {
					log.error("Exception Occured in getCustomerEmailId while closing the resultset: {} ", e);
				}
			}
		}
		return emailId;
	}

	public String getCustomerMobileNo(final SIDetails siTxn) {
		String mobileNo = null;
		ResultSet rs1 = null;
		try (Connection con = ciDs.getConnection(); 
				PreparedStatement ps1 = con.prepareStatement(QueryConstants.SELECT_FGB_USER_MOBILE_MASTER_QUERY);) {

			ps1.setString(1, siTxn.getCustomerIdentifier());
			rs1 = ps1.executeQuery();
			while (rs1.next()) {
				mobileNo = rs1.getString(1);
			}
		} catch (SQLException exe) {
			log.error("Exception Occured in getCustomerMobileNo: {} ", exe);
		} finally {
			if (rs1 != null) {
				try {
					rs1.close();
				} catch (SQLException e) {
					log.error("Exception Occured in getCustomerMobileNo while closing the resultset: {} ", e);
				}
			}
		}
		return mobileNo;
	}

	public ContentItem getSmsEmailMsgByContentId(ContentID contentId, ContentGroup contentGrp, final String channelId, final String smsEmail) {
		ContentItem item = null;
		ResultSet rs1 = null;
		try (Connection con = pbDataSource.getConnection(); 
				PreparedStatement ps1 = con.prepareStatement(QueryConstants.SELECT_CONTENT_ITEM_BY_PATH);) {

			String contentPath = null;
			if (smsEmail == null || smsEmail.isEmpty()) {
				contentPath = TextUtils.createTextFromTemplate(ApplicationConstants.CONTENT_PATH_2, contentGrp.name(), contentId.name(), channelId, ApplicationConstants.EN);
			} else {
				contentPath = TextUtils.createTextFromTemplate(ApplicationConstants.CONTENT_PATH, contentGrp.name(), contentId.name(), channelId, (smsEmail == null ? "" : smsEmail), ApplicationConstants.EN);
			}
			log.info("Generated path:{}", contentPath);

			ps1.setString(1, contentPath);
			rs1 = ps1.executeQuery();
			while (rs1.next()) {
				int i = 0;
				item = new ContentItem();
				item.setContentID(rs1.getString(++i));
				item.setPath(rs1.getString(++i));
				item.setContentText(rs1.getString(++i));
				item.setContentBin(rs1.getBytes(++i));
				item.setContentType(DocumentContentTypes.getContentType(rs1.getString(++i)));
				item.setContentExtension(ApplicationConstants.DOT.concat(rs1.getString(i).toLowerCase()));
				item.setVersion(rs1.getString(++i));
				item.setMetadata(rs1.getString(++i));
			}

		} catch (SQLException exe) {
			log.error("Exception Occured in getSmsEmailMsgByContentId: {} ", exe);
		} finally {
			if (rs1 != null) {
				try {
					rs1.close();
				} catch (SQLException e) {
					log.error("Exception Occured in getSmsEmailMsgByContentId while closing the resultset: {} ", e);
				}
			}
		}
		return item;
	}
}
