/**
 * 
 */
package com.fab.si.model.payment;

/**
 * @author o4359
 *
 */
public class DuBalanceEnquiryRequest {

	private BalanceEnquiryRequest duConsumer;
	private String customerIdentifier;

	/**
	 * @return the duConsumer
	 */
	public BalanceEnquiryRequest getDuConsumer() {
		return duConsumer;
	}

	/**
	 * @param duConsumer
	 *            the duConsumer to set
	 */
	public void setDuConsumer(BalanceEnquiryRequest duConsumer) {
		this.duConsumer = duConsumer;
	}

	/**
	 * @return the customerIdentifier
	 */
	public String getCustomerIdentifier() {
		return customerIdentifier;
	}

	/**
	 * @param customerIdentifier the customerIdentifier to set
	 */
	public void setCustomerIdentifier(String customerIdentifier) {
		this.customerIdentifier = customerIdentifier;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DuBalanceEnquiryRequest [duConsumer=");
		builder.append(duConsumer);
		builder.append(", customerIdentifier=");
		builder.append(customerIdentifier);
		builder.append("]");
		return builder.toString();
	}

}
