/**
 * 
 */
package com.fab.si.model.notify;

import java.util.ArrayList;
import java.util.List;

/**
 * @author o4359
 *
 */
public class EmailRequest extends BaseRequest {

	private static final long serialVersionUID = 2595619818586497642L;
	private String fromAddress;
	private String entityName;
	private List<String> toAddress;
	private List<String> ccAddress;
	private List<String> bccAddress;
	private String emailSubject;
	private String emailBodyContent;
	private String emailBodyContentType;
	private List<EmailAttachment> attachment;

	/**
	 * @return the fromAddress
	 */
	public String getFromAddress() {
		return fromAddress;
	}

	/**
	 * @param fromAddress
	 *            the fromAddress to set
	 */
	public void setFromAddress(String fromAddress) {
		this.fromAddress = fromAddress;
	}

	/**
	 * @return the toAddress
	 */
	public List<String> getToAddress() {
		return toAddress;
	}

	/**
	 * @param toAddress
	 *            the toAddress to set
	 */
	public void setToAddress(List<String> toAddress) {
		this.toAddress = toAddress;
	}
	
	public void addToAddress(final String toAddr) {
		if (toAddress == null) {
			toAddress = new ArrayList<String>();
		}
		toAddress.add(toAddr);
	}
	
	public void addEmailAttachment(final EmailAttachment attch) {
		if (attachment == null) {
			attachment = new ArrayList<EmailAttachment>();
		}
		attachment.add(attch);
	}

	/**
	 * @return the ccAddress
	 */
	public List<String> getCcAddress() {
		return ccAddress;
	}

	/**
	 * @param ccAddress
	 *            the ccAddress to set
	 */
	public void setCcAddress(List<String> ccAddress) {
		this.ccAddress = ccAddress;
	}

	/**
	 * @return the bccAddress
	 */
	public List<String> getBccAddress() {
		return bccAddress;
	}

	/**
	 * @param bccAddress
	 *            the bccAddress to set
	 */
	public void setBccAddress(List<String> bccAddress) {
		this.bccAddress = bccAddress;
	}

	/**
	 * @return the emailSubject
	 */
	public String getEmailSubject() {
		return emailSubject;
	}

	/**
	 * @param emailSubject
	 *            the emailSubject to set
	 */
	public void setEmailSubject(String emailSubject) {
		this.emailSubject = emailSubject;
	}

	/**
	 * @return the emailBodyContent
	 */
	public String getEmailBodyContent() {
		return emailBodyContent;
	}

	/**
	 * @param emailBodyContent
	 *            the emailBodyContent to set
	 */
	public void setEmailBodyContent(String emailBodyContent) {
		this.emailBodyContent = emailBodyContent;
	}

	/**
	 * @return the emailBodyContentType
	 */
	public String getEmailBodyContentType() {
		return emailBodyContentType;
	}

	/**
	 * @param emailBodyContentType
	 *            the emailBodyContentType to set
	 */
	public void setEmailBodyContentType(String emailBodyContentType) {
		this.emailBodyContentType = emailBodyContentType;
	}

	/**
	 * @return the attachment
	 */
	public List<EmailAttachment> getAttachment() {
		return attachment;
	}

	/**
	 * @param attachment
	 *            the attachment to set
	 */
	public void setAttachment(List<EmailAttachment> attachment) {
		this.attachment = attachment;
	}

	/**
	 * @return the entityName
	 */
	public String getEntityName() {
		return entityName;
	}

	/**
	 * @param entityName the entityName to set
	 */
	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}
}
