/**
 * 
 */
package com.fab.si.model.transfer;

import java.util.ArrayList;
import java.util.List;

/**
 * @author o4359
 *
 */
public class TransferResponseStatus {

	private String status;
	private List<ErrorDetails> errorDetails;

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the errorDetails
	 */
	public List<ErrorDetails> getErrorDetails() {
		if (errorDetails == null) {
			errorDetails = new ArrayList<>();
		}
		return errorDetails;
	}

	/**
	 * @param errorDetails
	 *            the errorDetails to set
	 */
	public void setErrorDetails(List<ErrorDetails> errorDetails) {
		this.errorDetails = errorDetails;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ResponseStatus [status=");
		builder.append(status);
		builder.append(" , errorDetails=");
		builder.append(errorDetails);
		builder.append(" ]");
		return builder.toString();
	}
}
