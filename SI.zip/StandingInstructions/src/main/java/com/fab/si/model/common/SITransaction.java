/**
 * 
 */
package com.fab.si.model.common;

import java.sql.Date;
import java.sql.Timestamp;

/**
 * @author o4359
 *
 */
public class SITransaction {

	private String siId;
	private String smsStatus;
	private String txnStatus;
	private String statusCode;
	private String statusDesc;
	private String txnId;
	private Date nxtRunOn;
	private Integer perDayRetryCount;
	private Integer execCount;
	private Integer completedCount;
	private String createdBy;
	private Timestamp createdOn;
	private String modifiedBy;
	private Timestamp modifiedOn;

	/**
	 * @return the siId
	 */
	public String getSiId() {
		return siId;
	}

	/**
	 * @param siId
	 *            the siId to set
	 */
	public void setSiId(String siId) {
		this.siId = siId;
	}

	/**
	 * @return the smsStatus
	 */
	public String getSmsStatus() {
		return smsStatus;
	}

	/**
	 * @param smsStatus
	 *            the smsStatus to set
	 */
	public void setSmsStatus(String smsStatus) {
		this.smsStatus = smsStatus;
	}

	/**
	 * @return the txnStatus
	 */
	public String getTxnStatus() {
		return txnStatus;
	}

	/**
	 * @param txnStatus
	 *            the txnStatus to set
	 */
	public void setTxnStatus(String txnStatus) {
		this.txnStatus = txnStatus;
	}

	/**
	 * @return the statusCode
	 */
	public String getStatusCode() {
		return statusCode;
	}

	/**
	 * @param statusCode
	 *            the statusCode to set
	 */
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	/**
	 * @return the statusDesc
	 */
	public String getStatusDesc() {
		return statusDesc;
	}

	/**
	 * @param statusDesc
	 *            the statusDesc to set
	 */
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	/**
	 * @return the txnId
	 */
	public String getTxnId() {
		return txnId;
	}

	/**
	 * @param txnId
	 *            the txnId to set
	 */
	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}

	/**
	 * @return the perDayRetryCount
	 */
	public Integer getPerDayRetryCount() {
		return perDayRetryCount;
	}

	/**
	 * @param perDayRetryCount
	 *            the perDayRetryCount to set
	 */
	public void setPerDayRetryCount(Integer perDayRetryCount) {
		this.perDayRetryCount = perDayRetryCount;
	}

	/**
	 * @return the execCount
	 */
	public Integer getExecCount() {
		return execCount;
	}

	/**
	 * @param execCount
	 *            the execCount to set
	 */
	public void setExecCount(Integer execCount) {
		this.execCount = execCount;
	}

	/**
	 * @return the completedCount
	 */
	public Integer getCompletedCount() {
		return completedCount;
	}

	/**
	 * @param completedCount
	 *            the completedCount to set
	 */
	public void setCompletedCount(Integer completedCount) {
		this.completedCount = completedCount;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy
	 *            the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the createdOn
	 */
	public Timestamp getCreatedOn() {
		return createdOn;
	}

	/**
	 * @param createdOn
	 *            the createdOn to set
	 */
	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}

	/**
	 * @return the modifiedBy
	 */
	public String getModifiedBy() {
		return modifiedBy;
	}

	/**
	 * @return the nxtRunOn
	 */
	public Date getNxtRunOn() {
		return nxtRunOn;
	}

	/**
	 * @param nxtRunOn
	 *            the nxtRunOn to set
	 */
	public void setNxtRunOn(Date nxtRunOn) {
		this.nxtRunOn = nxtRunOn;
	}

	/**
	 * @param modifiedBy
	 *            the modifiedBy to set
	 */
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	/**
	 * @return the modifiedOn
	 */
	public Timestamp getModifiedOn() {
		return modifiedOn;
	}

	/**
	 * @param modifiedOn
	 *            the modifiedOn to set
	 */
	public void setModifiedOn(Timestamp modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("SIID=");
		builder.append(siId);
		builder.append(" , smsStatus=");
		builder.append(smsStatus);
		builder.append(" , txnStatus=");
		builder.append(txnStatus);
		builder.append(" , sourceType=");
		builder.append(statusCode);
		builder.append("statusDesc=");
		builder.append(statusDesc);
		builder.append(" , txnId=");
		builder.append(txnId);
		builder.append(" , nxtRunOn=");
		builder.append(nxtRunOn);
		builder.append("perDayRetryCount=");
		builder.append(perDayRetryCount);
		builder.append(" , execCount=");
		builder.append(execCount);
		builder.append(" , completedCount=");
		builder.append(completedCount);
		return builder.toString();
	}
}
