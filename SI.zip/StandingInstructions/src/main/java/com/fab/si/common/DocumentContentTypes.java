package com.fab.si.common;

public enum DocumentContentTypes {

	PDF("PDF", "application/pdf"), 
	BMP("BMP", ""), 
	PNG("PNG", ""), 
	GIF("GIF", ""), 
	JPG("JPG", ""), 
	JPEG("JPEG", ""), 
	XLS("XLS", ""), 
	XLSX("XLSX", ""), 
	PPT("PPT", ""), 
	PPTX("PPTX", ""), 
	DOC("DOC", ""), 
	DOCX("DOCX", ""), 
	RTF("RTF", ""), 
	TXT("TEXT", "text/plain");
	
	private String dbShortCode;
	private String contentType;

	private DocumentContentTypes(String dbShortCode, String contentType) {
		this.dbShortCode = dbShortCode;
		this.contentType = contentType;
	}
	
	public static String getContentType(String dbShortCode) {
		DocumentContentTypes[] values = DocumentContentTypes.values();
		for (DocumentContentTypes contentType : values) {
			if(contentType.getDbShortCode().equalsIgnoreCase(dbShortCode)) {
				return contentType.getContentType();
			}
		}
		return org.apache.http.entity.ContentType.APPLICATION_OCTET_STREAM.getMimeType(); 
	}
	
	public String getDbShortCode() {
		return dbShortCode;
	}

	public String getContentType() {
		return contentType;
	}

}
