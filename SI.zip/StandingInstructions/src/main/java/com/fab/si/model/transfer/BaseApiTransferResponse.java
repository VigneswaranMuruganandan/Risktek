/**
 * 
 */
package com.fab.si.model.transfer;

import java.util.List;

/**
 * @author o4359
 *
 */
public class BaseApiTransferResponse {

	private List<TransferResponseStatus> responseStatus;

	/**
	 * @return the responseStatus
	 */
	public List<TransferResponseStatus> getResponseStatus() {
		return responseStatus;
	}

	/**
	 * @param responseStatus
	 *            the responseStatus to set
	 */
	public void setResponseStatus(List<TransferResponseStatus> responseStatus) {
		this.responseStatus = responseStatus;
	}
}
