/**
 * 
 */
package com.fab.si.helper;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.fab.si.common.ApplicationConstants;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;
import net.sf.ehcache.config.CacheConfiguration;
import net.sf.ehcache.config.Configuration;

/**
 * @author o4359
 *
 */
@Component("cacheUtil")
public class CacheUtil<T> {

	private Logger log = LoggerFactory.getLogger(getClass());

	private static CacheManager cacheManager = null;

	@PostConstruct
	public void init() {
		Configuration cacheManagerConfig = new Configuration();
		CacheConfiguration txnLimit = new CacheConfiguration(ApplicationConstants.TXN_LIMIT_CACHE_NAME, 300).eternal(false).maxEntriesLocalDisk(1000).diskSpoolBufferSizeMB(20).timeToIdleSeconds(600)
				.timeToLiveSeconds(86400).memoryStoreEvictionPolicy(ApplicationConstants.FIFO);

		cacheManager = new CacheManager(cacheManagerConfig);
		cacheManager.addCache(new Cache(txnLimit));
	}

	public void addToCache(String cacheName, String key, Object value) {
		if (value != null) {
			Cache cache = cacheManager.getCache(cacheName);
			cache.put(new Element(key, value));
			log.info("Cache Add {} {}", cacheName, key);
		}
	}

	public void removeFromCache(String cacheName, String key) {
		Cache cache = cacheManager.getCache(cacheName);
		boolean result = cache.remove(key);
		log.info("Cache remove {} {}", cacheName, String.valueOf(result) + key);
	}

	@SuppressWarnings("unchecked")
	public T getFromCache(String cacheName, String key) {
		log.info("Cache Get {} {}", cacheName, key);
		Cache cache = cacheManager.getCache(cacheName);
		Element elem = cache.get(key);
		return (T) (elem != null ? elem.getObjectValue() : elem);
	}
}
