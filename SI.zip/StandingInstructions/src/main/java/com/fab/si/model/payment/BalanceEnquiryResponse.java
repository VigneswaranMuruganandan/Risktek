/**
 * 
 */
package com.fab.si.model.payment;

/**
 * @author o4359
 *
 */
public class BalanceEnquiryResponse extends BaseApiPaymentResponse {

	private String transactionID;
	private String availableBalance;
	private String minimumAmount;
	private String maximumAmount;
	private String inMultiplesOf;
	private String amountDue;

	/**
	 * @return the transactionID
	 */
	public String getTransactionID() {
		return transactionID;
	}

	/**
	 * @param transactionID
	 *            the transactionID to set
	 */
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}

	/**
	 * @return the availableBalance
	 */
	public String getAvailableBalance() {
		return availableBalance;
	}

	/**
	 * @param availableBalance
	 *            the availableBalance to set
	 */
	public void setAvailableBalance(String availableBalance) {
		this.availableBalance = availableBalance;
	}

	/**
	 * @return the minimumAmount
	 */
	public String getMinimumAmount() {
		return minimumAmount;
	}

	/**
	 * @param minimumAmount
	 *            the minimumAmount to set
	 */
	public void setMinimumAmount(String minimumAmount) {
		this.minimumAmount = minimumAmount;
	}

	/**
	 * @return the maximumAmount
	 */
	public String getMaximumAmount() {
		return maximumAmount;
	}

	/**
	 * @param maximumAmount
	 *            the maximumAmount to set
	 */
	public void setMaximumAmount(String maximumAmount) {
		this.maximumAmount = maximumAmount;
	}

	/**
	 * @return the inMultiplesOf
	 */
	public String getInMultiplesOf() {
		return inMultiplesOf;
	}

	/**
	 * @param inMultiplesOf
	 *            the inMultiplesOf to set
	 */
	public void setInMultiplesOf(String inMultiplesOf) {
		this.inMultiplesOf = inMultiplesOf;
	}

	/**
	 * @return the amountDue
	 */
	public String getAmountDue() {
		return amountDue;
	}

	/**
	 * @param amountDue the amountDue to set
	 */
	public void setAmountDue(String amountDue) {
		this.amountDue = amountDue;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BalanceEnquiryResponse [transactionID=");
		builder.append(transactionID);
		builder.append(", availableBalance=");
		builder.append(availableBalance);
		builder.append(", minimumAmount=");
		builder.append(minimumAmount);
		builder.append(", maximumAmount=");
		builder.append(maximumAmount);
		builder.append(", inMultiplesOf=");
		builder.append(inMultiplesOf);
		builder.append(", amountDue=");
		builder.append(amountDue);
		builder.append("]");
		return builder.toString();
	}

}
