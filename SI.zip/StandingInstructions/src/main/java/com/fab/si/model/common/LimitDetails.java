/**
 * 
 */
package com.fab.si.model.common;

/**
 * @author o4359
 *
 */
public class LimitDetails {

	private Double minAmount;
	private Double maxAmount;
	private Integer inMultiplesOf;

	/**
	 * @return the minAmount
	 */
	public Double getMinAmount() {
		return minAmount;
	}

	/**
	 * @param minAmount
	 *            the minAmount to set
	 */
	public void setMinAmount(Double minAmount) {
		this.minAmount = minAmount;
	}

	/**
	 * @return the maxAmount
	 */
	public Double getMaxAmount() {
		return maxAmount;
	}

	/**
	 * @param maxAmount
	 *            the maxAmount to set
	 */
	public void setMaxAmount(Double maxAmount) {
		this.maxAmount = maxAmount;
	}

	/**
	 * @return the inMultiplesOf
	 */
	public Integer getInMultiplesOf() {
		return inMultiplesOf;
	}

	/**
	 * @param inMultiplesOf
	 *            the inMultiplesOf to set
	 */
	public void setInMultiplesOf(Integer inMultiplesOf) {
		this.inMultiplesOf = inMultiplesOf;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("LimitDetails [minAmount=");
		builder.append(minAmount);
		builder.append(", maxAmount=");
		builder.append(maxAmount);
		builder.append(", inMultiplesOf=");
		builder.append(inMultiplesOf);
		builder.append("]");
		return builder.toString();
	}
}
