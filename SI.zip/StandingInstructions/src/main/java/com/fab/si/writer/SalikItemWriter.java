/**
 * 
 */
package com.fab.si.writer;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.stereotype.Component;

import com.fab.si.model.common.SIDetails;

/**
 * @author o4359
 *
 */
@Component("salikItemWriter")
public class SalikItemWriter implements ItemWriter<SIDetails>{

	private Logger log = LoggerFactory.getLogger(getClass());
	
	@Override
	public void write(List<? extends SIDetails> arg0) throws Exception {
		//log.info("Salik Item Writer: {}", arg0);
		log.info("############# SALIK RECORD: END ################");
	}

}
