/**
 * 
 */
package com.fab.si.processor;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Component;

import com.fab.si.helper.PropertyConfig;

/**
 * @author o4359
 *
 */
@Component("preparedStmtSetter")
public class SIPreparedStmtSetter implements PreparedStatementSetter {

	@Autowired
	private PropertyConfig propConfig;

	@Override
	public void setValues(PreparedStatement setter) throws SQLException {
		int i = 0;
		setter.setInt(++i, propConfig.getRetryCount());
	}
}
