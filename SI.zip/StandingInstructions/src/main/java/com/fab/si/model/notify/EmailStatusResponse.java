/**
 * 
 */
package com.fab.si.model.notify;

/**
 * @author o4359
 *
 */
public class EmailStatusResponse extends BaseResponse {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8920304620049954936L;

	private String errorDesc;
	private String status;

	/**
	 * @return the errorDesc
	 */
	public String getErrorDesc() {
		return errorDesc;
	}

	/**
	 * @param errorDesc
	 *            the errorDesc to set
	 */
	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("EmailStatusResponse [requestID=");
		builder.append(requestID);
		builder.append(", responseID=");
		builder.append(responseID);
		builder.append(", status=");
		builder.append(status);
		builder.append(", errorDesc=");
		builder.append(errorDesc);
		builder.append("]");
		return builder.toString();
	}

}
