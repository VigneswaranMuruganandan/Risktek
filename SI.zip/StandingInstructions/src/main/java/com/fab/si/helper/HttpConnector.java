/**
 * 
 */
package com.fab.si.helper;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyStore;
import java.security.Security;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpHead;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fab.si.common.ApplicationConstants;
import com.fab.si.common.ErrorCodes;
import com.fab.si.common.ServiceUrls;
import com.fab.si.exception.AppException;
import com.fab.si.model.common.ConnectorResponse;

/**
 * @author o4359
 *
 */
@Component("httpConnect")
public class HttpConnector {

	private final Logger log = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private Properties propertyConfigurer;
	
	@Autowired
	private PropertyConfig propConfig;

	private static int TIMEOUT = 120000;

	// IBM JDK
	private static final String IBMJSSE2 = "IBMJSSE2";
	private static final String SSL = "SSL";
	//private static final String JKS = "JKS";

	//private static final String SUNX509 = "SunX509";
	//private static final String IBMX509 = "IbmX509";

	private static final String TLSV1 = "TLSv1.1";
	private static final String TLSV1_2 = "TLSv1.2";
	private static final String SSLV3 = "SSLv3";

	public ConnectorResponse post(ServiceUrls serviceUrl, String request, Map<String, String> headers) {
		// TODO property Loader
		//final String hostUrl = propertyConfigurer.getProperty(serviceUrl.getTargetSystem());
		final String hostUrl = propConfig.getIibServiceUrl();
		log.info("invoke {} {}", hostUrl, serviceUrl);
		final String url = hostUrl.concat(serviceUrl.getUrl());
		return invoke(url, serviceUrl.getTargetSystem(), ApplicationConstants.POST, request, headers);
	}

	public ConnectorResponse get(ServiceUrls serviceUrl, Map<String, String> headers) {
		final String hostUrl = propertyConfigurer.getProperty(serviceUrl.getTargetSystem());
		log.info("invoke {} {}", hostUrl, serviceUrl);
		String url = hostUrl.concat(serviceUrl.getUrl());
		return invoke(url, serviceUrl.getTargetSystem(), ApplicationConstants.GET, null, headers);
	}

	public ConnectorResponse get(String url, Map<String, String> headers, ServiceUrls serviceUrl) {
		final String hostUrl = propConfig.getIibServiceUrl();
		log.info("invoke {} {}", hostUrl, serviceUrl);
		return invoke(hostUrl.concat(url), serviceUrl.getTargetSystem(), ApplicationConstants.GET, null, headers);
	}

	/**
	 * Invoke Http request
	 * 
	 * @param url
	 * @param requestType
	 * @param request
	 * @param headers
	 * @return
	 * @throws AppException
	 */
	private ConnectorResponse invoke(String url, String targetSystem, String requestType, String request, Map<String, String> headers) throws AppException {
		long t = System.currentTimeMillis();
		log.info("Headers: {}", headers);
		log.info("Connecting to URL:{}, RequestType:{} ", url, requestType);

		int statusCode = 0;
		CloseableHttpClient httpClient = null;
		CloseableHttpResponse response = null;
		ConnectorResponse connectorResponse = null;
		List<Header> httpHeaders = new ArrayList<>();

		// Whether HTTP or HTTPS
		//String protocol = url.substring(0, url.indexOf(":"));
		//Header header = new BasicHeader("XREF", "PB" + System.currentTimeMillis());
		//httpHeaders.add(header);
		//header = new BasicHeader("CHANNELID", "IB");
		//httpHeaders.add(header);

		RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(TIMEOUT).setConnectTimeout(TIMEOUT).setConnectionRequestTimeout(TIMEOUT).build();

		try {
			this.copyRequestHeaders(headers, httpHeaders);
			log.info("Headers: {}", headers);
			log.info("Connecting to URL:{}, RequestType:{} ", url, requestType);

			if (ApplicationConstants.IIB_SERVICE.equals(targetSystem)) {
				// SSLContext sslcontext = this.getTwowaySSLContext()
				SSLContext sslcontext = this.getSSLContext(targetSystem);
				// Trust own CA and all self-signed certs
				SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslcontext, new String[] { TLSV1, TLSV1_2, SSLV3 }, null, NoopHostnameVerifier.INSTANCE);
				httpClient = HttpClients.custom().setDefaultRequestConfig(requestConfig).setDefaultHeaders(httpHeaders).setSSLSocketFactory(sslsf).build();
			} else {
				SSLContext sslcontext = this.getSSLContext(targetSystem);
				SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslcontext, new String[] { TLSV1, TLSV1_2, SSLV3 }, null, NoopHostnameVerifier.INSTANCE);
				httpClient = HttpClients.custom().setDefaultRequestConfig(requestConfig).setDefaultHeaders(httpHeaders).setSSLSocketFactory(sslsf).build();
			}

			// Prepare http request
			HttpRequestBase httpRequestBase = this.prepareRequest(url, requestType, request);
			response = httpClient.execute(httpRequestBase, new BasicHttpContext());
			// Prepare http response
			connectorResponse = this.prepareResponse(requestType, response);
		} catch (ConnectTimeoutException cte) {
			log.error("Http connection timed out:{} errorcause:{}", url, cte);
			throw new AppException(ErrorCodes.SYS_HTTP_CON_FLD);
		} catch (Exception e) {
			log.error("Http postings failed:{} errorcause:{}", url, e);
			e.printStackTrace(System.out);
			throw new AppException(ErrorCodes.SYS_ERROR);
		} finally {
			log.info("Time to execute {} {}", statusCode, System.currentTimeMillis() - t);
			IOUtils.closeQuietly(response);
			IOUtils.closeQuietly(httpClient);
		}
		return connectorResponse;
	}

	private ConnectorResponse prepareResponse(String requestType, HttpResponse response) throws IOException {

		ConnectorResponse connectorResponse = new ConnectorResponse();
		int statusCode = response.getStatusLine().getStatusCode();
		log.info("Response Status Code :{}", statusCode);
		connectorResponse.setResponseStatus(statusCode);

		try (ByteArrayOutputStream outs = new ByteArrayOutputStream();) {
			String contentType = this.getContentType(response.getAllHeaders());
			connectorResponse.setContentType(contentType);

			if (!requestType.equals(ApplicationConstants.HEAD)) {
				HttpEntity responseEntity = response.getEntity();

				if (contentType.indexOf(ContentType.APPLICATION_JSON.getMimeType()) > -1 || contentType.indexOf(ContentType.TEXT_PLAIN.getMimeType()) > -1) {
					String jsonResponse = EntityUtils.toString(responseEntity);

					connectorResponse.setResponse(jsonResponse.getBytes());
					connectorResponse.setJsonResponse(jsonResponse);
				} else {
					responseEntity.writeTo(outs);
					connectorResponse.setResponse(outs.toByteArray());
					log.info("RESPONSE length {}", outs.size());
				}
			}
			// Add response headers
			this.copyResponseHeaders(response.getAllHeaders(), connectorResponse);
		}

		return connectorResponse;
	}

	private HttpRequestBase prepareRequest(String url, String requestType, String request) {
		HttpRequestBase httpRequestBase = null;
		switch (requestType) {
		case ApplicationConstants.POST:
			httpRequestBase = new HttpPost(url);
			((HttpPost) httpRequestBase).setEntity(this.getStringEntity(request));
			break;
		case ApplicationConstants.PUT:
			httpRequestBase = new HttpPut(url);
			((HttpPut) httpRequestBase).setEntity(this.getStringEntity(request));
			break;
		case ApplicationConstants.GET:
			httpRequestBase = new HttpGet(url);
			break;
		case ApplicationConstants.HEAD:
			httpRequestBase = new HttpHead(url);
			break;
		default:
			log.error("Invalid request method type received.");
			break;
		}
		return httpRequestBase;
	}

	private String getContentType(Header[] responseHeaders) {
		String contentType = null;
		if (responseHeaders != null) {
			for (Header header : responseHeaders) {
				if (HTTP.CONTENT_TYPE.equalsIgnoreCase(header.getName())) {
					contentType = header.getValue();
					break;
				}
			}
		}
		return contentType;
	}

	private void copyRequestHeaders(Map<String, String> headers, List<Header> httpHeaders) {
		if (Objects.nonNull(headers)) {
			headers.forEach((key, value) -> {
				httpHeaders.add(new BasicHeader(key, value));
			});
		}
	}

	private void copyResponseHeaders(Header[] responseHeaders, ConnectorResponse connectorResponse) {
		if (responseHeaders != null) {
			for (Header header : responseHeaders) {
				log.debug("response header {} {}", header.getName(), header.getValue());
				connectorResponse.addHeader(header.getName(), header.getValue());
			}
		}
	}

	private StringEntity getStringEntity(String request) {
		StringEntity entity = new StringEntity(request, HTTP.DEF_PROTOCOL_CHARSET);
		entity.setContentType(ContentType.APPLICATION_JSON.getMimeType());
		return entity;
	}

	private SSLContext getSSLContext(String targetSystem) throws Exception {
		/*String jksFilePath = propertyConfigurer.getProperty("");
		String keyStorePwd = propertyConfigurer.getProperty("");*/
		String jksFilePath = propConfig.getIibServiceJksPath();
		String keyStorePwd = propConfig.getIibServiceJksPwd();
		if (jksFilePath == null || keyStorePwd == null) {
			log.error("Env variable..keystore path or password is missing..");
			throw new AppException(ErrorCodes.SYS_ERROR);
		}

		log.info("Keystore Path:{}", jksFilePath);
		SSLContext sslContext = null;
		try (FileInputStream inStream = new FileInputStream(new File(jksFilePath));) {

			KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
			ks.load(inStream, keyStorePwd.toCharArray());

			KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
			kmf.init(ks, keyStorePwd.toCharArray());
			TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
			tmf.init(ks);
			TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					return null;
				}

				public void checkClientTrusted(X509Certificate[] certs, String authType) {
				}

				public void checkServerTrusted(X509Certificate[] certs, String authType) {
				}
			} };

			sslContext = SSLContext.getInstance(SSL);
			sslContext.init(kmf.getKeyManagers(), trustAllCerts, new java.security.SecureRandom());
		} catch (Exception e) {
			log.error("Error while getting ssl context:{}", e);
			throw new AppException(ErrorCodes.SYS_HTTPS_CON_FLD);
		}
		return sslContext;
	}

	@SuppressWarnings("unused")
	private SSLContext getTwowaySSLContext(String targetSystem) throws Exception {

		final String keystorePath = propertyConfigurer.getProperty("");
		final String keyStorePwd = propertyConfigurer.getProperty("");
		final String keyStoreType = propertyConfigurer.getProperty("");
		final String trustStorePath = propertyConfigurer.getProperty("");
		final String trustStorePwd = propertyConfigurer.getProperty("");
		log.info("Keystore Path:{}, Truststore Path:{}", keystorePath, trustStorePath);

		if (StringUtils.isNotBlank(keystorePath) || StringUtils.isNotBlank(keyStorePwd) || StringUtils.isNotBlank(trustStorePath) || StringUtils.isNotBlank(trustStorePwd)) {
			log.error("Env variable..keystore path or password is missing..");
			throw new AppException(ErrorCodes.SYS_MISSING_MAND_CONFIG);
		}

		SSLContext sslContext = null;

		try (FileInputStream keyStoreFileStream = new FileInputStream(new File(keystorePath)); FileInputStream trustStoreFileStream = new FileInputStream(new File(trustStorePath));) {

			KeyStore keystore = KeyStore.getInstance(keyStoreType);
			keystore.load(keyStoreFileStream, keyStorePwd.toCharArray());
			KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
			kmf.init(keystore, keyStorePwd.toCharArray());
			log.info("Keystore Loaded");

			// LOAD TRUSTORE
			KeyStore truststore = KeyStore.getInstance(KeyStore.getDefaultType());
			truststore.load(trustStoreFileStream, trustStorePwd.toCharArray());
			TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
			tmf.init(truststore);
			log.info("Truststore Loaded");

			sslContext = SSLContext.getInstance(TLSV1_2, Security.getProvider(IBMJSSE2));
			sslContext.init(kmf.getKeyManagers(), tmf.getTrustManagers(), new java.security.SecureRandom());
			log.info("SSLContext Loaded");

		} catch (Exception e) {
			log.error("Error while getting two way ssl context:{}", e);
			throw new AppException(ErrorCodes.SYS_HTTPS_CON_FLD);
		}
		return sslContext;
	}

	public static void main(String[] args) {
		System.out.println(" " + ContentType.APPLICATION_JSON);
		System.out.println(" " + ContentType.APPLICATION_JSON.getMimeType());
		System.out.println(" " + ContentType.APPLICATION_JSON.getCharset());

		System.out.println(" " + ContentType.TEXT_PLAIN);
		System.out.println(" " + ContentType.TEXT_PLAIN.getMimeType());
		System.out.println(" " + HTTP.CONTENT_TYPE);

	}
}
