/**
 * 
 */
package com.fab.si.model.notify;

/**
 * @author o4359
 *
 */
public class EmailAttachment {

	private String attachementBytes;
	private String mimeType;
	private String fileName;

	/**
	 * @return the attachementBytes
	 */
	public String getAttachementBytes() {
		return attachementBytes;
	}

	/**
	 * @param attachementBytes
	 *            the attachementBytes to set
	 */
	public void setAttachementBytes(String attachementBytes) {
		this.attachementBytes = attachementBytes;
	}

	/**
	 * @return the mimeType
	 */
	public String getMimeType() {
		return mimeType;
	}

	/**
	 * @param mimeType
	 *            the mimeType to set
	 */
	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}

	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * @param fileName
	 *            the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

}
