/**
 * 
 */
package com.fab.si.helper;

import java.io.IOException;

import com.fab.si.exception.AppException;
import com.fab.si.common.ErrorCodes;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.Option;
import com.jayway.jsonpath.ReadContext;

/**
 * @author Kaushik
 *
 */
public class JsonUtils {

	public static <T> String convertToJson(T t) {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(Include.NON_NULL);
		String json = null;
		try {
			json = mapper.writeValueAsString(t);
		} catch (JsonProcessingException e) {
			throw new AppException(ErrorCodes.SYS_CONVRT, e);
		}
		return json;
	}

	public static <T> T convertToObject(Class<T> clazz, String json) {
		T t = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			String cleanedJson = cleanUpJsonBOM(json);
			t = mapper.readValue(cleanedJson, clazz);
		} catch (IOException e) {
			throw new AppException(ErrorCodes.SYS_CONVRT, e);
		}
		return t;
	}

	private static String cleanUpJsonBOM(String json) {
		return json.trim().replaceFirst("\ufeff", "");
	}

	public static <R> R getJsonPrimitive(String json, String expression) {
		Configuration conf = Configuration.defaultConfiguration().addOptions(Option.DEFAULT_PATH_LEAF_TO_NULL);
		ReadContext ctx = JsonPath.using(conf).parse(json);
		return ctx.read(expression);
	}
}
