/**
 * 
 */
package com.fab.si.common;

/**
 * @author kaushikmukherjee
 *
 */
public interface ApplicationConstants {

	String JOB_NAME = "jobName";
	String POST = "POST";
	String GET = "GET";
	String PUT = "PUT";
	String HEAD = "HEAD";

	String XREF = "XREF";
	String CHANNELID = "CHANNELID";
	String ACCESSTOKEN = "ACCESSTOKEN";

	String ACCOUNT = "ACCOUNT";
	String CARD = "CARD";
	String SUCCESS = "SUCCESS";
	String ERROR = "ERROR";
	String MOBILE_PREFIX = "+971";
	String DATE_DDMMMYYYYHHMISS = "dd/MMM/yyyy hh:mi:ss";
	String DATE_DDMMMYYYYHHMMSS = "dd/MMM/yyyy HH:mm:ss";
	String DATE_DDMMYYYHHMMSS = "dd/mm/yyyy HH:mm:ss";
	String DATE_DDMMYYYY = "dd/MM/yyyy";
	String DATE_YYYMMDD = "yyyy-MM-dd";
	String Y = "Y";
	String YES = "YES";
	String CONTENT_PATH = "{0}/{1}/{2}/{3}/{4}";
	String CONTENT_PATH_2 = "{0}/{1}/{2}/{3}";
	String DOT = ".";
	String EMAIL = "EMAIL";
	String SMS = "SMS";
	String EN = "EN";

	// BILLER
	String AADC = "AADC";
	String ADDC = "ADDC";
	String SEWA = "SEWA";
	String DEWA = "DEWA";
	String FEWA = "FEWA";
	String DU = "DU";
	String SALIK = "SALIK";
	String ETISALAT = "ETISALAT";

	// PROPERTY CONSTANTS
	String IIB_SERVICE = "IIB_SERVICE";
	String WAS_SERVICE = "WAS_SERVICE";

	// JOB DETAILS
	String NOTIFY_JOB = "NOTIFY_JOB";
	String MEDIATYPE_TXTPLAIN = "text/plain";

	// DATABASE PARAMETRS
	String TXTACCTSTATUS = "TXTACCTSTATUS";
	String NUMAVAILBAL = "NUMAVAILBAL";
	String E = "E";
	String TWO = "2";
	
	// CACHE PARAMETERS
	String FIFO = "FIFO";
	String TXN_LIMIT_CACHE_NAME = "txnLimitCache";
	String TXNLIMIT = "TXNLIMIT";
}
