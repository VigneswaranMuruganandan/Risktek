/**
 * 
 */
package com.fab.si.helper;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author o4359
 *
 */
@Component("propConfig")
public class PropertyConfig {

	@Value("${IIB_SERVICE}")
	private String iibServiceUrl;

	@Value("${IIB_SERVICE_KS_PATH}")
	private String iibServiceJksPath;

	@Value("${IIB_SERVICE_KS_PWD}")
	private String iibServiceJksPwd;

	@Value("${SI_UBP_RETRY_COUNT}")
	private Integer retryCount;

	@Value("${WAS_SERVICE}")
	private String wasServiceUrl;

	@Value("${WAS_SERVICE_KS_PATH}")
	private String wasServiceJksPath;

	@Value("${WAS_SERVICE_KS_PWD}")
	private String wasServiceJksPwd;

	@Value("${EMAIL_FROM_ADDRESS}")
	private String fromAddress;

	@Value("${NOTIFY_ENTITY_NAME}")
	private String entityName;

	/**
	 * @return the wasServiceUrl
	 */
	public String getWasServiceUrl() {
		return wasServiceUrl;
	}

	/**
	 * @return the wasServiceJksPath
	 */
	public String getWasServiceJksPath() {
		return wasServiceJksPath;
	}

	/**
	 * @return the wasServiceJksPwd
	 */
	public String getWasServiceJksPwd() {
		return wasServiceJksPwd;
	}

	/**
	 * @return the iibServiceUrl
	 */
	public String getIibServiceUrl() {
		return iibServiceUrl;
	}

	/**
	 * @return the retryCount
	 */
	public Integer getRetryCount() {
		return retryCount;
	}

	/**
	 * @return the iibServiceJksPath
	 */
	public String getIibServiceJksPath() {
		return iibServiceJksPath;
	}

	/**
	 * @return the iibServiceJksPwd
	 */
	public String getIibServiceJksPwd() {
		return iibServiceJksPwd;
	}

	/**
	 * @return the fromAddress
	 */
	public String getFromAddress() {
		return fromAddress;
	}

	/**
	 * @return the entityName
	 */
	public String getEntityName() {
		return entityName;
	}

}
