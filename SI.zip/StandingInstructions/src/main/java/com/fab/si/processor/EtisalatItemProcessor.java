/**
 * 
 */
package com.fab.si.processor;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fab.si.common.ApplicationConstants;
import com.fab.si.common.ErrorCodes;
import com.fab.si.common.ServiceUrls;
import com.fab.si.common.TemplateId;
import com.fab.si.common.TransactionStatus;
import com.fab.si.helper.HttpConnector;
import com.fab.si.helper.JsonUtils;
import com.fab.si.helper.TextUtils;
import com.fab.si.helper.SIUtility;
import com.fab.si.model.common.ConnectorResponse;
import com.fab.si.model.common.SIDetails;
import com.fab.si.model.payment.BalanceEnquiryResponse;
import com.fab.si.model.payment.BillerPaymentResponse;
import com.fab.si.model.payment.EtisalatBalanceEnquiryRequest;
import com.fab.si.model.payment.EtisalatBillPaymentRequest;
import com.fab.si.repository.SITransactionRepository;

/**
 * @author o4359
 *
 */
@Component("etisalatItemProcessor")
public class EtisalatItemProcessor implements ItemProcessor<SIDetails, SIDetails> {

	private Logger log = LoggerFactory.getLogger(getClass());

	@Autowired
	private HttpConnector httpConnect;

	@Autowired
	private SIUtility siUtility;

	@Autowired
	private SITransactionRepository siTxnRepo;

	@Override
	public SIDetails process(SIDetails siDetails) throws Exception {

		final String siId = siDetails.getSiID();
		log.info("{} - ETISALAT Object in Item Processor: {}", siId, siDetails);

		// UPDATE IN SI TRANSACTIONS
		siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.VALIDATE_RULES, null));
		// CALL ETISALAT BALANCE ENQUIRY
		BalanceEnquiryResponse balEnqRes = null;
		final String templateId = siDetails.getTemplateId();
		if (StringUtils.isBlank(templateId)) {
			return siDetails;
		} else if (TemplateId.ETISALAT_WASEL_RECHARGE.getTemplateId().equalsIgnoreCase(templateId)) {
			balEnqRes = this.waselRechargeBalanceEnquiry(siDetails);
		} else if (TemplateId.ETISALAT_WASEL_RENEWAL.getTemplateId().equalsIgnoreCase(templateId)) {
			balEnqRes = this.waselRenewalBalanceEnquiry(siDetails);
		} else {
			balEnqRes = this.etisalatBalanceEnquiry(siDetails);
		}

		if (balEnqRes != null) {
			final String amountDue = balEnqRes.getAmountDue();
			log.info("{} - Etisalat Amount Due: {} ", siId, amountDue);

			// CHECK FOR AMOUNT DUE IN CASE OF POSTPAID
			if (!TemplateId.ETISALAT_WASEL_RECHARGE.getTemplateId().equalsIgnoreCase(templateId) && !TemplateId.ETISALAT_WASEL_RENEWAL.getTemplateId().equalsIgnoreCase(templateId)
					&& StringUtils.isBlank(amountDue)) {
				siTxnRepo.updateSiTransaction(
						siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.VALIDATE_RULES_FAILED, siUtility.prepareFailureResponseStatus(ErrorCodes.BALANCE_ENQ_FAILED)));
				return siDetails;
			}

			// VALIDATE LIMIT AND TXN AMOUNT
			if (!siUtility.isValidTxnAmount(siDetails, balEnqRes)) {
				log.info("{} - Transaction Amount Is not valid", siId);
				siTxnRepo.updateSiTransaction(
						siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.VALIDATE_RULES_FAILED, siUtility.prepareFailureResponseStatus(ErrorCodes.LIMIT_CHK_FAILED)));
				return siDetails;
			}

			if (StringUtils.isNotBlank(balEnqRes.getTransactionID())) {

				// CHECK FOR AMOUNT DUE
				if (StringUtils.isNotBlank(amountDue) && Double.valueOf(amountDue) < 0) {
					siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.VALIDATE_RULES_FAILED,
							siUtility.prepareFailureResponseStatus(ErrorCodes.AMOUNT_DUE_INVALID)));
					log.info("{} - Amount Due is Overpaid", siId);
					return siDetails;
				}

				BillerPaymentResponse paymentRes = null;
				if (ApplicationConstants.ACCOUNT.equalsIgnoreCase(siDetails.getSourceType())) {
					// UPDATE IN SI TRANSACTIONS
					siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.PAYMENT_PROCESSING, null));
					// PAYMENT
					paymentRes = this.etisalatAccountPayment(balEnqRes, siDetails);
					// UPDATE IN SI TRANSACTIONS
					if (paymentRes != null) {
						siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(paymentRes, siDetails, TransactionStatus.PAYMENT_STATUS, null));
					} else {
						siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(paymentRes, siDetails, TransactionStatus.INTERNAL_ERROR, null));
					}
				} else if (ApplicationConstants.CARD.equalsIgnoreCase(siDetails.getSourceType())) {
					// UPDATE IN SI TRANSACTIONS
					siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.PAYMENT_PROCESSING, null));
					paymentRes = this.etisalatCardPayment(balEnqRes, siDetails);
					// UPDATE IN SI TRANSACTIONS
					if (paymentRes != null) {
						siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(paymentRes, siDetails, TransactionStatus.PAYMENT_STATUS, null));
					} else {
						siTxnRepo.updateSiTransaction(siUtility.prepareSiTransactionUpdateRequest(paymentRes, siDetails, TransactionStatus.INTERNAL_ERROR, null));
					}
				}
			} else {
				log.info("{} - Invalid Etisalat Balance Enquiry Response", siId);
				siTxnRepo.updateSiTransaction(
						siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.VALIDATE_RULES_FAILED, siUtility.prepareFailureResponseStatus(ErrorCodes.BALANCE_ENQ_FAILED)));
			}
		} else {
			log.info("{} - Invalid Etisalat Balance Enquiry Response", siId);
			siTxnRepo.updateSiTransaction(
					siUtility.prepareSiTransactionUpdateRequest(null, siDetails, TransactionStatus.VALIDATE_RULES_FAILED, siUtility.prepareFailureResponseStatus(ErrorCodes.BALANCE_ENQ_FAILED)));
		}
		return siDetails;
	}

	/**
	 * This method is to prepare EtisalatBalanceEnquiryRequest Object
	 * 
	 * @param siDetails
	 * @return EtisalatBalanceEnquiryRequest Object
	 */
	private EtisalatBalanceEnquiryRequest prepareEtisalatBalEnqReq(final SIDetails siDetails) {
		EtisalatBalanceEnquiryRequest etisalatBalanceReq = new EtisalatBalanceEnquiryRequest();
		final String etisalatConsumerNo = siDetails.getCreditAcctNo();
		if (StringUtils.isNotBlank(etisalatConsumerNo)) {
			etisalatBalanceReq.setEtisalatConsumer(siUtility.prepareBalEnqReq(siDetails, ApplicationConstants.ETISALAT));
		}
		etisalatBalanceReq.setCustomerIdentifier(siDetails.getCustomerIdentifier());
		return etisalatBalanceReq;
	}

	/**
	 * This method is to execute Balance Inquiry Service
	 * 
	 * @param siDetails
	 * @return BalanceEnquiryResponse Object
	 */
	private BalanceEnquiryResponse etisalatBalanceEnquiry(final SIDetails siDetails) {
		BalanceEnquiryResponse response = null;
		final String siId = siDetails.getSiID();
		final String requestJson = JsonUtils.convertToJson(this.prepareEtisalatBalEnqReq(siDetails));
		log.info("{} - Etisalat Balance Enquiry Request: {}", siId, requestJson);
		// CREATE HTTP HEADERS
		Map<String, String> headers = siUtility.populateHeaders();
		ConnectorResponse connResponse = httpConnect.post(ServiceUrls.ETISALAT_BALANCE_ENQ, requestJson, headers);
		if (connResponse.getResponseStatus() == 200) {
			log.info("{} - Etisalat Balance Enquiry Response: {}", siId, connResponse.getJsonResponse());
			response = JsonUtils.convertToObject(BalanceEnquiryResponse.class, connResponse.getJsonResponse());
		}
		log.info("{} - Etisalat BalanceEnquiryResponse: {}", siId, response);
		return response;
	}

	/**
	 * This method is to execute Balance Inquiry Service
	 * 
	 * @param siDetails
	 * @return BalanceEnquiryResponse Object
	 */
	private BalanceEnquiryResponse waselRechargeBalanceEnquiry(final SIDetails siDetails) {
		BalanceEnquiryResponse response = null;
		final String siId = siDetails.getSiID();
		final String consumerNo = siDetails.getCreditAcctNo();
		if (StringUtils.isNotBlank(consumerNo)) {
			final String url = TextUtils.createTextFromTemplate(ServiceUrls.ETISALAT_WASEL_RECHARGE_BALANCE_ENQ.getUrl(), consumerNo);
			// CREATE HTTP HEADERS
			Map<String, String> headers = siUtility.populateHeaders(siDetails.getCustomerIdentifier());
			ConnectorResponse connResponse = httpConnect.get(url, headers, ServiceUrls.ETISALAT_WASEL_RECHARGE_BALANCE_ENQ);
			if (connResponse.getResponseStatus() == 200) {
				log.info("{} - Etisalat Wasel Recharge Balance Enquiry Response: {}", siId, connResponse.getJsonResponse());
				response = JsonUtils.convertToObject(BalanceEnquiryResponse.class, connResponse.getJsonResponse());
			}
		}
		log.info("{} - Etisalat Wasel Recharge BalanceEnquiryResponse: {}", siId, response);
		return response;
	}

	/**
	 * This method is to execute Balance Inquiry Service
	 * 
	 * @param siDetails
	 * @return BalanceEnquiryResponse Object
	 */
	private BalanceEnquiryResponse waselRenewalBalanceEnquiry(final SIDetails siDetails) {
		BalanceEnquiryResponse response = null;
		final String siId = siDetails.getSiID();
		final String consumerNo = siDetails.getCreditAcctNo();
		if (StringUtils.isNotBlank(consumerNo)) {
			final String url = TextUtils.createTextFromTemplate(ServiceUrls.ETISALAT_WASEL_RENEWAL_BALANCE_ENQ.getUrl(), consumerNo);
			// CREATE HTTP HEADERS
			Map<String, String> headers = siUtility.populateHeaders(siDetails.getCustomerIdentifier());
			ConnectorResponse connResponse = httpConnect.get(url, headers, ServiceUrls.ETISALAT_WASEL_RECHARGE_BALANCE_ENQ);
			if (connResponse.getResponseStatus() == 200) {
				log.info("{} - Etisalat Wasel Renewal Balance Enquiry Response: {}", siId, connResponse.getJsonResponse());
				response = JsonUtils.convertToObject(BalanceEnquiryResponse.class, connResponse.getJsonResponse());
			}
		}
		log.info("{} - Etisalat Wasel Renewal BalanceEnquiryResponse: {}", siId, response);
		return response;
	}

	/**
	 * This method is to execute Account Payment Service
	 * 
	 * @param balEnqRes
	 * @param siDetails
	 * @return BillerPaymentResponse Object
	 */
	private BillerPaymentResponse etisalatAccountPayment(final BalanceEnquiryResponse balEnqRes, final SIDetails siDetails) {
		BillerPaymentResponse response = null;
		final String siId = siDetails.getSiID();
		final String templateId = siDetails.getTemplateId();
		EtisalatBillPaymentRequest etisalatPayment = new EtisalatBillPaymentRequest();
		etisalatPayment.setAccountPayment(siUtility.preparePaymentReq(siDetails, balEnqRes));
		etisalatPayment.setCustomerIdentifier(siDetails.getCustomerIdentifier());
		// CREATE HTTP HEADERS
		ConnectorResponse connResponse = null;
		Map<String, String> headers = siUtility.populateHeaders();
		if (TemplateId.ETISALAT_WASEL_RECHARGE.getTemplateId().equalsIgnoreCase(templateId)) {

			etisalatPayment.setEtisalatConsumer(siUtility.prepareWaselBalEnqReq(siDetails, ApplicationConstants.ETISALAT));
			final String requestJson = JsonUtils.convertToJson(etisalatPayment);
			log.info("{} - Etisalat Wasel Recharge Account Payment Request: {}", siId, requestJson);
			connResponse = httpConnect.post(ServiceUrls.ETISALAT_WASEL_RECHARGE_BYACCOUNT, requestJson, headers);

		} else if (TemplateId.ETISALAT_WASEL_RENEWAL.getTemplateId().equalsIgnoreCase(templateId)) {

			etisalatPayment.setEtisalatConsumer(siUtility.prepareWaselBalEnqReq(siDetails, ApplicationConstants.ETISALAT));
			final String requestJson = JsonUtils.convertToJson(etisalatPayment);
			log.info("{} - Etisalat Wasel Renewal Account Payment Request: {}", siId, requestJson);
			connResponse = httpConnect.post(ServiceUrls.ETISALAT_WASEL_RENEWAL_BYACCOUNT, requestJson, headers);

		} else {
			etisalatPayment.setEtisalatConsumer(siUtility.prepareBalEnqReq(siDetails, ApplicationConstants.ETISALAT));
			final String requestJson = JsonUtils.convertToJson(etisalatPayment);
			log.info("{} - Etisalat Account Payment Request: {}", siId, requestJson);
			connResponse = httpConnect.post(ServiceUrls.ETISALAT_PAYMENT_BYACCOUNT, requestJson, headers);
		}

		if (connResponse != null && connResponse.getResponseStatus() == 200) {
			log.info("{} - Etisalat Account Payment JSON Response: {}", siId, connResponse.getJsonResponse());
			response = JsonUtils.convertToObject(BillerPaymentResponse.class, connResponse.getJsonResponse());
		}
		log.info("{} - Etisalat Account BillerPaymentResponse: {}", siId, response);
		return response;
	}

	/**
	 * This method is to execute Card Payment Service
	 * 
	 * @param balEnqRes
	 * @param siDetails
	 * @return BillerPaymentResponse Object
	 */
	private BillerPaymentResponse etisalatCardPayment(final BalanceEnquiryResponse balEnqRes, final SIDetails siDetails) {
		BillerPaymentResponse response = null;
		final String siId = siDetails.getSiID();
		final String templateId = siDetails.getTemplateId();
		EtisalatBillPaymentRequest etisalatPayment = new EtisalatBillPaymentRequest();
		etisalatPayment.setCardPayment(siUtility.preparePaymentReq(siDetails, balEnqRes));
		etisalatPayment.setCustomerIdentifier(siDetails.getCustomerIdentifier());

		// CREATE HTTP HEADERS
		ConnectorResponse connResponse = null;
		Map<String, String> headers = siUtility.populateHeaders();
		if (TemplateId.ETISALAT_WASEL_RECHARGE.getTemplateId().equalsIgnoreCase(templateId)) {

			etisalatPayment.setEtisalatConsumer(siUtility.prepareWaselBalEnqReq(siDetails, ApplicationConstants.ETISALAT));
			final String requestJson = JsonUtils.convertToJson(etisalatPayment);
			log.info("{} - Etisalat Wasel Recharge Card Payment Request: {}", siId, requestJson);
			connResponse = httpConnect.post(ServiceUrls.ETISALAT_WASEL_RECHARGE_BYCARD, requestJson, headers);

		} else if (TemplateId.ETISALAT_WASEL_RENEWAL.getTemplateId().equalsIgnoreCase(templateId)) {

			etisalatPayment.setEtisalatConsumer(siUtility.prepareWaselBalEnqReq(siDetails, ApplicationConstants.ETISALAT));
			final String requestJson = JsonUtils.convertToJson(etisalatPayment);
			log.info("{} - Etisalat Wasel Renewal Card Payment Request: {}", siId, requestJson);
			connResponse = httpConnect.post(ServiceUrls.ETISALAT_WASEL_RENEWAL_BYCARD, requestJson, headers);

		} else {

			etisalatPayment.setEtisalatConsumer(siUtility.prepareBalEnqReq(siDetails, ApplicationConstants.ETISALAT));
			final String requestJson = JsonUtils.convertToJson(etisalatPayment);
			log.info("{} - Etisalat Card Payment Request: {}", siId, requestJson);
			connResponse = httpConnect.post(ServiceUrls.ETISALAT_PAYMENT_BYCARD, requestJson, headers);
		}
		if (connResponse != null && connResponse.getResponseStatus() == 200) {
			log.info("{} - Etisalat Card Payment Response: {}", siId, connResponse.getJsonResponse());
			response = JsonUtils.convertToObject(BillerPaymentResponse.class, connResponse.getJsonResponse());
		}
		log.info("{} - Etisalat Card BillerPaymentResponse: {}", siId, response);
		return response;
	}
}
