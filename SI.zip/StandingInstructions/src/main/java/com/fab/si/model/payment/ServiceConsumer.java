/**
 * 
 */
package com.fab.si.model.payment;

/**
 * @author o4359
 *
 */
public class ServiceConsumer {

	private String serviceType;

	/**
	 * @return the serviceType
	 */
	public String getServiceType() {
		return serviceType;
	}

	/**
	 * @param serviceType
	 *            the serviceType to set
	 */
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

}
