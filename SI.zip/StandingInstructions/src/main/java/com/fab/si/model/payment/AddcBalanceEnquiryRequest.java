/**
 * 
 */
package com.fab.si.model.payment;

/**
 * @author o4359
 *
 */
public class AddcBalanceEnquiryRequest {

	private BalanceEnquiryRequest addcConsumer;
	private String customerIdentifier;

	/**
	 * @return the addcConsumer
	 */
	public BalanceEnquiryRequest getAddcConsumer() {
		return addcConsumer;
	}

	/**
	 * @param addcConsumer
	 *            the addcConsumer to set
	 */
	public void setAddcConsumer(BalanceEnquiryRequest addcConsumer) {
		this.addcConsumer = addcConsumer;
	}

	/**
	 * @return the customerIdentifier
	 */
	public String getCustomerIdentifier() {
		return customerIdentifier;
	}

	/**
	 * @param customerIdentifier
	 *            the customerIdentifier to set
	 */
	public void setCustomerIdentifier(String customerIdentifier) {
		this.customerIdentifier = customerIdentifier;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("AddcBalanceEnquiryRequest [addcConsumer=");
		builder.append(addcConsumer);
		builder.append(", customerIdentifier=");
		builder.append(customerIdentifier);
		builder.append("]");
		return builder.toString();
	}

}
