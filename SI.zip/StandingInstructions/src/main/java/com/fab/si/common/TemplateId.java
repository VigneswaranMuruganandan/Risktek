/**
 * 
 */
package com.fab.si.common;

/**
 * @author o4359
 *
 */
public enum TemplateId {

	ADDC_BILLPAYMENT("ADDC-BILLPAYMENT"),
	DEWA_BILLPAYMENT("DEWA-BILLPAYMENT"),
	AADC_BILLPAYMENT("AADC-BILLPAYMENT"),
	SEWA_BILLPAYMENT("SEWA-BILLPAYMENT"),
	SALIK_BILLPAYMENT_BYAMOUNT("SALIK-BILLPAYMENT-BYAMOUNT"),
	SALIK_BILLPAYMENT_BYDATE("SALIK-BILLPAYMENT-BYDATE"),
	FEWA_BILLPAYMENT("FEWA-BILLPAYMENT"),
	ETISALAT_WASEL_RECHARGE("ETISALAT-PREPAID-RECHARGE"),
	ETISALAT_WASEL_RENEWAL("ETISALAT-PREPAID-RENEWAL"),
	DU_BILLPAYMENT("DU-BILLPAYMENT"),
	OWN_ACCT_FT("OWN-ACCT-FT"),
	WITHIN_BANK_FT("WITHIN-BANK-FT"),
	WITHIN_UAE_FT("WITHIN-UAE-FT"),
	INTERNATIONAL_FT("INTERNATIONAL-FT");

	private String templateId;

	TemplateId(String templateId) {
		this.templateId = templateId;
	}

	/**
	 * @return the templateId
	 */
	public String getTemplateId() {
		return templateId;
	}

	/**
	 * @param templateId
	 *            the templateId to set
	 */
	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}
}
