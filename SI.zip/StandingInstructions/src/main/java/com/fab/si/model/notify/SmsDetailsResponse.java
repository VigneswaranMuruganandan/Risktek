package com.fab.si.model.notify;

import java.io.Serializable;

public class SmsDetailsResponse extends SmsStatusResponse implements Serializable {

	private static final long serialVersionUID = -6198569306485556957L;
	protected String creationDate;
	protected String deliveryDate;

	public String getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}

	public String getDeliveryDate() {
		return deliveryDate;
	}

	public void setDeliveryDate(String deliveryDate) {
		this.deliveryDate = deliveryDate;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("SMSStatusResponse [smsACK=");
		builder.append(smsACK);
		builder.append(", creationDate=");
		builder.append(creationDate);
		builder.append(", deliveryStatus=");
		builder.append(deliveryStatus);
		builder.append(", deliveryDate=");
		builder.append(deliveryDate);
		builder.append(", errorDesc=");
		builder.append(errorDesc);
		builder.append("]");
		return builder.toString();
	}
}
