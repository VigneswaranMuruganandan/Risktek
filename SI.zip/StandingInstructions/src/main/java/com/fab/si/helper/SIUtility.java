/**
 * 
 */
package com.fab.si.helper;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fab.si.common.ApplicationConstants;
import com.fab.si.common.ErrorCodes;
import com.fab.si.common.Frequency;
import com.fab.si.common.TemplateId;
import com.fab.si.common.TransactionStatus;
import com.fab.si.model.common.LimitDetails;
import com.fab.si.model.common.SIDetails;
import com.fab.si.model.common.SITransaction;
import com.fab.si.model.payment.BalanceEnquiryRequest;
import com.fab.si.model.payment.BalanceEnquiryResponse;
import com.fab.si.model.payment.BillerPaymentRequest;
import com.fab.si.model.payment.BillerPaymentResponse;
import com.fab.si.model.payment.PaymentResponseStatus;
import com.fab.si.model.transfer.BeneficiaryDetails;
import com.fab.si.model.transfer.FundsTransferRequest;
import com.fab.si.model.transfer.FundsTransferResponse;
import com.fab.si.model.transfer.TransferResponseStatus;
import com.fab.si.repository.CustomerRepository;
import com.fab.si.repository.SITransactionRepository;

/**
 * @author o4359
 *
 */
@Component("siUtility")
public class SIUtility {

	private Logger log = LoggerFactory.getLogger(getClass());

	@Autowired
	private CustomerRepository custRepo;

	@Autowired
	private SITransactionRepository siTxnRepo;

	@Autowired
	private PropertyConfig propConfig;

	@SuppressWarnings("rawtypes")
	@Autowired
	private CacheUtil cacheUtil;

	public Map<String, String> populateHeaders() {
		Map<String, String> headers = new HashMap<>();
		headers.put(ApplicationConstants.CHANNELID, ApplicationConstants.SYNC_21);
		headers.put(ApplicationConstants.XREF, ApplicationConstants.SYNC_21.concat(System.currentTimeMillis() + ApplicationConstants.EMPTY));
		return headers;
	}

	public Map<String, String> populateHeaders(final String customerIdentifier) {
		Map<String, String> headers = new HashMap<>();
		headers.put(ApplicationConstants.CHANNELID, ApplicationConstants.SYNC_21);
		headers.put(ApplicationConstants.XREF, ApplicationConstants.SYNC_21.concat(System.currentTimeMillis() + ApplicationConstants.EMPTY));
		headers.put(ApplicationConstants.CIF, customerIdentifier);
		return headers;
	}

	public boolean isValidTxnAmount(final SIDetails siDetails, final BalanceEnquiryResponse balResponse) {
		boolean isValid = true;

		// CHECK FOR DUPLICATE PAYMENT
		if (!custRepo.isValidPaymentFired(siDetails)) {
			isValid = false;
			return isValid;
		}
		LimitDetails limitDetails = null;
		final String billerName = siDetails.getPaymentTransferName();
		// IF BILLER IS NOT SEWA
		if (!ApplicationConstants.SEWA.equalsIgnoreCase(billerName)) {
			final String key = billerName.concat(ApplicationConstants.TXNLIMIT);
			Object obj = cacheUtil.getFromCache(ApplicationConstants.TXN_LIMIT_CACHE_NAME, key);
			if (obj == null) {
				limitDetails = siTxnRepo.getTransactionLimit(siDetails.getPaymentTransferName());
				cacheUtil.addToCache(ApplicationConstants.TXN_LIMIT_CACHE_NAME, key, limitDetails);
			} else {
				limitDetails = (LimitDetails) obj;
			}
			log.info("Limit Details: {}", limitDetails);

			if (Objects.nonNull(balResponse.getAmountDue()) || Objects.nonNull(balResponse.getAvailableBalance())) {
				final Double amountDue = balResponse.getAmountDue() == null ? Double.valueOf(balResponse.getAvailableBalance()) : Double.valueOf(balResponse.getAmountDue());
				final Double txnAmount = Double.valueOf(siDetails.getMaxAmount());
				log.info("Amount Due: {} Txn Amount: {}", amountDue, txnAmount);

				if (limitDetails != null) {
					// MIN AMOUNT
					if (this.checkNull(limitDetails.getMinAmount()) != 0 && !(txnAmount >= limitDetails.getMinAmount())) {
						isValid = false;
					}
					// MAX AMOUNT
					if (this.checkNull(limitDetails.getMaxAmount()) != 0 && !(txnAmount <= limitDetails.getMaxAmount())) {
						isValid = false;
					}
					// CHECK ONLY FOR SALIK
					if (ApplicationConstants.SALIK.equalsIgnoreCase(siDetails.getPaymentTransferName())) {
						// IN MULTIPLES OF
						if (this.checkNull(limitDetails.getInMultiplesOf()) != 0 && Double.valueOf(siDetails.getMaxAmount()) % limitDetails.getInMultiplesOf() != 0) {
							isValid = false;
						}
					}
				}
			}
		}
		log.info("isValid: {}", isValid);
		return isValid;
	}

	private Double checkNull(Double val) {
		if (val == null) {
			val = Double.valueOf("0");
		}
		return val;
	}

	private Integer checkNull(Integer val) {
		if (val == null) {
			val = 0;
		}
		return val;
	}

	/**
	 * This method is to prepare BalanceEnquiryRequest Object
	 * 
	 * @param siDetails
	 * @return BalanceEnquiryRequest Object
	 */
	public BalanceEnquiryRequest prepareBalEnqReq(final SIDetails siDetails, final String agency) {
		BalanceEnquiryRequest balEnqReq = null;
		final String consumerNo = siDetails.getCreditAcctNo();
		if (StringUtils.isNotBlank(consumerNo)) {
			balEnqReq = new BalanceEnquiryRequest();
			balEnqReq.setAgency(agency);
			balEnqReq.setConsumerNo(consumerNo);
		}
		return balEnqReq;
	}

	/**
	 * This method is to prepare BalanceEnquiryRequest Object
	 * 
	 * @param siDetails
	 * @return BalanceEnquiryRequest Object
	 */
	public BalanceEnquiryRequest prepareWaselBalEnqReq(final SIDetails siDetails, final String agency) {
		BalanceEnquiryRequest balEnqReq = null;
		final String consumerNo = siDetails.getCreditAcctNo();
		if (StringUtils.isNotBlank(consumerNo)) {
			balEnqReq = new BalanceEnquiryRequest();
			balEnqReq.setAgency(agency);
			balEnqReq.setTelephoneNo(consumerNo);
		}
		return balEnqReq;
	}

	/**
	 * This method is to prepare BillerPaymentRequest Object
	 * 
	 * @param siDetails
	 * @param balEnqRes
	 * @return BillerPaymentRequest Object
	 */
	public BillerPaymentRequest preparePaymentReq(final SIDetails siDetails, final BalanceEnquiryResponse balEnqRes) {
		BillerPaymentRequest paymentRequest = new BillerPaymentRequest();
		if (ApplicationConstants.ACCOUNT.equalsIgnoreCase(siDetails.getSourceType())) {
			paymentRequest.setAccountNo(siDetails.getDebitAccountNo());
		} else if (ApplicationConstants.CARD.equalsIgnoreCase(siDetails.getSourceType())) {
			paymentRequest.setCreditCardNo(siDetails.getDebitAccountNo());
		}
		paymentRequest.setCurrencyCode(siDetails.getCurrency());
		final String amountDue = balEnqRes.getAmountDue() == null ? balEnqRes.getAvailableBalance() : balEnqRes.getAmountDue();
		// DETERMINE THE TRANSACTION AMOUNT
		if (!ApplicationConstants.SEWA.equalsIgnoreCase(siDetails.getPaymentTransferName())) {
			if (StringUtils.isBlank(amountDue) || Double.valueOf(siDetails.getMaxAmount()) < Double.valueOf(amountDue)) {
				paymentRequest.setTransactionAmount(siDetails.getMaxAmount());
			} else {
				paymentRequest.setTransactionAmount(amountDue);
			}
		} else {
			paymentRequest.setTransactionAmount(amountDue);
		}
		paymentRequest.setAmountDue(balEnqRes.getAmountDue());
		paymentRequest.setTransactionId(balEnqRes.getTransactionID());
		paymentRequest.setAvailableBalance(balEnqRes.getAvailableBalance());
		return paymentRequest;
	}

	/**
	 * This method is to prepare FundsTransferRequest Object
	 * 
	 * @param siDetails
	 * @return FundsTransferRequest Object
	 */
	public FundsTransferRequest prepareFundsTransferReq(final SIDetails siDetails, final BeneficiaryDetails beneDetails, final TemplateId transferType) {
		FundsTransferRequest ftRequest = new FundsTransferRequest();
		ftRequest.setCif(siDetails.getCustomerIdentifier());
		ftRequest.setAccountingUnitIdentifier(custRepo.getCompanyForCardAccount(siDetails.getDebitAccountNo(), ApplicationConstants.ACCOUNT));
		ftRequest.setDebitAccountNo(siDetails.getDebitAccountNo());
		ftRequest.setCreditAccountNo(siDetails.getCreditAcctNo());
		ftRequest.setTransactionAmount(siDetails.getMaxAmount());
		ftRequest.setTransactionCurrency(siDetails.getCurrency());
		if (!TemplateId.OWN_ACCT_FT.equals(transferType)) {
			ftRequest.setCreditAccountCurrency(custRepo.getCurrencyFromAccount(siDetails.getCreditAcctNo()));
		}
		if (beneDetails != null) {
			ftRequest.setChargeBearerIndicationType(beneDetails.getChargeType());
			ftRequest.setTransferType("REM");// FIXME
			// ftRequest.setContainsBeneficiary(beneDetails);
		}
		if (TemplateId.WITHIN_BANK_FT.equals(transferType) && beneDetails != null) {
			ftRequest.setTransferType(beneDetails.getBeneType());
		}
		return ftRequest;
	}

	/**
	 * This method is to prepare PaymentResponseStatus Object
	 * 
	 * @return PaymentResponseStatus Object
	 */
	public PaymentResponseStatus prepareFailureResponseStatus(final ErrorCodes code) {
		PaymentResponseStatus status = new PaymentResponseStatus();
		status.setStatus(ApplicationConstants.ERROR);
		status.setErrorCode(code.getCode());
		status.setErrorDesc(code.getDesc());
		return status;
	}

	/**
	 * This method is to prepare SITransaction Update Object
	 * 
	 * @param paymentRes
	 * @param siDetails
	 * @return SITransaction Object
	 */
	public SITransaction prepareSiTransactionUpdateRequest(final BillerPaymentResponse paymentRes, final SIDetails siDetails, final TransactionStatus txnStatus,
			final com.fab.si.model.payment.PaymentResponseStatus resStatus) {
		SITransaction siTxn = new SITransaction();
		if (paymentRes != null && txnStatus.name().equals(TransactionStatus.PAYMENT_STATUS.name())) {
			log.info("Payment Response Not null & TransactionStatus: {}", txnStatus.name());
			final String status = paymentRes.getResponseStatus().get(0).getStatus();
			if (ApplicationConstants.SUCCESS.equalsIgnoreCase(status)) {
				log.info("Payment Success");
				siTxn.setTxnStatus(TransactionStatus.PAYMENT_SUCCESS.name());
				siTxn.setTxnId(paymentRes.getFgbTransactionRefNo());
				siTxn.setPerDayRetryCount(0);
				siTxn.setCompletedCount(1);
				siTxn.setSmsStatus(TransactionStatus.SMS_FOR_PAYMENT_SUCCESS.name());
				siTxn.setNxtRunOn(this.calNextRunOnDate(siDetails));
			} else if (ApplicationConstants.ERROR.equalsIgnoreCase(status)) {
				log.info("Payment Failed");
				final String errorCode = paymentRes.getResponseStatus().get(0).getErrorCode();

				siTxn.setTxnStatus(TransactionStatus.PAYMENT_FAILED.name());
				siTxn.setStatusCode(errorCode);
				siTxn.setStatusDesc(paymentRes.getResponseStatus().get(0).getErrorDesc());
				siTxn.setPerDayRetryCount(1);
				siTxn.setCompletedCount(0);
				siTxn.setSmsStatus(TransactionStatus.PENDING.name());
				if (propConfig.getRetryCount() - 1 == siDetails.getRetryCount()) {
					siTxn.setNxtRunOn(this.calNextRunOnDate(siDetails));
					siTxn.setSmsStatus(TransactionStatus.SMS_FOR_PAYMENT_FAILURE.name());
				}
			}
		} else if (paymentRes == null && txnStatus.name().equals(TransactionStatus.INTERNAL_ERROR.name())) {
			log.info("Payment Response null & TransactionStatus: {}", txnStatus.name());
			siTxn.setTxnStatus(TransactionStatus.INTERNAL_ERROR.name());
			siTxn.setPerDayRetryCount(1);
			siTxn.setSmsStatus(TransactionStatus.SMS_FOR_PAYMENT_FAILURE.name());
			if (propConfig.getRetryCount() - 1 == siDetails.getRetryCount()) {
				siTxn.setNxtRunOn(this.calNextRunOnDate(siDetails));
			}
		} else if (paymentRes == null && txnStatus.name().equals(TransactionStatus.VALIDATE_RULES_FAILED.name())) {
			log.info("Payment Response null & TransactionStatus: {}", txnStatus.name());
			siTxn.setTxnStatus(txnStatus.name());
			siTxn.setPerDayRetryCount(1);
			siTxn.setCompletedCount(0);
			siTxn.setSmsStatus(TransactionStatus.SMS_FOR_PAYMENT_FAILURE.name());
			if (resStatus != null) {
				siTxn.setStatusCode(resStatus.getErrorCode());
				siTxn.setStatusDesc(resStatus.getErrorDesc());
			}
			if (propConfig.getRetryCount() - 1 == siDetails.getRetryCount()) {
				siTxn.setNxtRunOn(this.calNextRunOnDate(siDetails));
				siTxn.setCompletedCount(1);
			}
		} else {
			log.info("TransactionStatus: {}", txnStatus.name());
			siTxn.setTxnStatus(txnStatus.name());
			siTxn.setPerDayRetryCount(0);
			siTxn.setCompletedCount(0);
			siTxn.setSmsStatus(TransactionStatus.PENDING.name());
		}
		siTxn.setCreatedBy(siDetails.getCustomerIdentifier());
		siTxn.setSiId(siDetails.getSiID());
		siTxn.setModifiedBy(siDetails.getCustomerIdentifier());
		return siTxn;
	}

	/**
	 * This method is to prepare SITransaction Update Object
	 * 
	 * @param ftPaymentRes
	 * @param siDetails
	 * @return SITransaction Object
	 */
	public SITransaction prepareSiTransactionUpdateFtRequest(final FundsTransferResponse ftPaymentRes, final SIDetails siDetails, final TransactionStatus txnStatus,
			final TransferResponseStatus resStatus) {
		SITransaction siTxn = new SITransaction();
		if (ftPaymentRes != null && txnStatus.name().equals(TransactionStatus.PAYMENT_STATUS.name())) {
			log.info("Payment Response Not null & TransactionStatus: {}", txnStatus.name());
			final String status = ftPaymentRes.getStatus();
			if (ApplicationConstants.SUCCESS.equalsIgnoreCase(status)) {
				log.info("Payment Success");
				siTxn.setTxnStatus(TransactionStatus.PAYMENT_SUCCESS.name());
				siTxn.setTxnId(ftPaymentRes.getFgbTransactionRefNo());
				siTxn.setPerDayRetryCount(0);
				siTxn.setCompletedCount(1);
				siTxn.setSmsStatus(TransactionStatus.SMS_FOR_PAYMENT_SUCCESS.name());
				siTxn.setNxtRunOn(this.calNextRunOnDate(siDetails));
			} else if (ApplicationConstants.ERROR.equalsIgnoreCase(status)) {
				log.info("Payment Failed");
				siTxn.setTxnStatus(TransactionStatus.PAYMENT_FAILED.name());
				siTxn.setStatusCode(ftPaymentRes.getResponseStatus().get(0).getErrorDetails().get(0).getErrorCode());
				siTxn.setStatusDesc(ftPaymentRes.getResponseStatus().get(0).getErrorDetails().get(0).getErrorDesc());
				siTxn.setPerDayRetryCount(1);
				siTxn.setCompletedCount(0);
				siTxn.setSmsStatus(TransactionStatus.SMS_FOR_PAYMENT_FAILURE.name());
			}
		} else if (ftPaymentRes == null && txnStatus.name().equals(TransactionStatus.INTERNAL_ERROR.name())) {
			log.info("Payment Response null & TransactionStatus: {}", txnStatus.name());
			siTxn.setTxnStatus(TransactionStatus.INTERNAL_ERROR.name());
			siTxn.setPerDayRetryCount(1);
			siTxn.setSmsStatus(TransactionStatus.SMS_FOR_PAYMENT_FAILURE.name());
		} else if (ftPaymentRes == null && txnStatus.name().equals(TransactionStatus.VALIDATE_RULES_FAILED.name())) {
			log.info("Payment Response null & TransactionStatus: {}", txnStatus.name());
			siTxn.setTxnStatus(txnStatus.name());
			siTxn.setPerDayRetryCount(0);
			siTxn.setCompletedCount(1);
			siTxn.setSmsStatus(TransactionStatus.SMS_FOR_PAYMENT_FAILURE.name());
			if (resStatus != null) {
				siTxn.setStatusCode(resStatus.getErrorDetails().get(0).getErrorCode());
				siTxn.setStatusDesc(resStatus.getErrorDetails().get(0).getErrorDesc());
			}
			siTxn.setNxtRunOn(this.calNextRunOnDate(siDetails));
		} else {
			log.info("TransactionStatus: {}", txnStatus.name());
			siTxn.setTxnStatus(txnStatus.name());
			siTxn.setPerDayRetryCount(0);
			siTxn.setCompletedCount(0);
			siTxn.setSmsStatus(TransactionStatus.PENDING.name());
		}
		siTxn.setCreatedBy(siDetails.getCustomerIdentifier());
		siTxn.setSiId(siDetails.getSiID());
		siTxn.setModifiedBy(siDetails.getCustomerIdentifier());
		return siTxn;
	}

	private Date calNextRunOnDate(final SIDetails siDetails) {
		Date nxtRunOnDate = null;
		// NEXT RUN ON DATE
		if (siDetails.getNextRunOnDate() != null) {
			if (siDetails.getExecutionDay() != null) {
				nxtRunOnDate = this.getNextRunOnDate(siDetails.getNextRunOnDate(), Frequency.valueOf(siDetails.getFrequency()), siDetails.getExecutionDay());
			} else {
				nxtRunOnDate = this.getNextRunOnDate(siDetails.getNextRunOnDate(), Frequency.valueOf(siDetails.getFrequency()), null);
			}
		} else if (siDetails.getExecutionDay() != null && siDetails.getStartDate() == null) {
			nxtRunOnDate = this.getNextRunOnDate(null, Frequency.valueOf(siDetails.getFrequency()), siDetails.getExecutionDay());
		} else {
			nxtRunOnDate = this.getNextRunOnDate(siDetails.getStartDate(), Frequency.valueOf(siDetails.getFrequency()), null);
		}
		return nxtRunOnDate;
	}

	public Date getNextRunOnDate(Date initialDate, final Frequency frequency, Integer executionDay) {
		if (initialDate == null) {
			initialDate = TextUtils.currSqlDate();
		}
		DateTime dt = new DateTime(initialDate);
		switch (frequency) {

		case DAILY:
			dt = dt.plusDays(1);
			break;

		case ONETIME:
			// dt = null;
			break;

		case WEEKLY:
			dt = dt.plusWeeks(1);
			break;

		case MONTHLY:
			if (executionDay != null) {
				int month = dt.getMonthOfYear();
				int year = dt.getYear();
				int day = dt.getDayOfMonth();
				// CHECK FOR FEB MONTH
				if (month + 1 == 2 && executionDay > 28) {
					// CHECK FOR LEAP YEAR
					if (year % 4 == 0) {
						if (year % 100 == 0) {
							if (year % 400 == 0) {
								executionDay = 29;
							}
						} else {
							executionDay = 29;
						}
					} else {
						executionDay = 28;
					}
				}
				if (executionDay > day) {
					dt = dt.plusDays(executionDay - day);
				} else {
					dt = dt.plusMonths(1).withDayOfMonth(executionDay);
				}
			} else {
				dt = dt.plusMonths(1);
			}
			break;

		case FORTNIGHT:
			dt = dt.plusWeeks(2);
			break;

		case QUARTERLY:
			dt = dt.plusMonths(3);
			break;

		case HALFYEARLY:
			dt = dt.plusMonths(6);
			break;

		case YEARLY:
			dt = dt.plusYears(1);
			break;

		default:
			break;
		}
		return new Date(dt.getMillis());
	}

	public static void main(String[] args) throws ParseException {
		SIUtility obj = new SIUtility();
		java.util.Date utilDate = new java.util.Date();

		SimpleDateFormat dtFormat = new SimpleDateFormat("dd/MM/yyyy");
		utilDate = dtFormat.parse("30/01/2016");

		Date sqlDate = new Date(utilDate.getTime());
		System.out.println("Current Month:" + new DateTime(utilDate).getMonthOfYear());
		System.out.println("Current Date: " + sqlDate);
		System.out.println("Monthly Increment: " + obj.getNextRunOnDate(sqlDate, Frequency.MONTHLY, null));
		System.out.println("Monthly Increment By Execution Day: " + obj.getNextRunOnDate(sqlDate, Frequency.MONTHLY, Integer.valueOf(30)));
		System.out.println("Monthly Increment By Execution Day: " + obj.getNextRunOnDate(null, Frequency.MONTHLY, Integer.valueOf(30)));
		boolean isValid = Double.valueOf("50") < Double.valueOf("-21111.50");
		System.out.println("Double Value: " + isValid);
	}
}
