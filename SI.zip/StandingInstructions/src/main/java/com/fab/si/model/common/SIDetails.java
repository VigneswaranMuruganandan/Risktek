/**
 * 
 */
package com.fab.si.model.common;

import java.sql.Date;

/**
 * @author kaushikmukherjee
 *
 */
public class SIDetails {

	private String siID;
	private String customerIdentifier;
	private String debitAccountNo;
	private String sourceType;
	private String currency;
	private String paymentTransferName;
	private String templateId;
	private String creditAcctNo;
	private String beneId;
	private String frequency;
	private String maxAmount;
	private Double minAmount;
	private String channelId;
	private String refNo;
	private String txnDesc;
	private Integer executionCount;
	private Integer completedCount;
	private Date startDate;
	private Date nextRunOnDate;
	private String statusCode;
	private String statusDesc;
	private String txnId;
	private Integer retryCount;
	private String txnStatus;
	private String createdBy;
	private String smsStatus;
	private Integer executionDay;

	/**
	 * @return the txnDesc
	 */
	public String getTxnDesc() {
		return txnDesc;
	}

	/**
	 * @param txnDesc
	 *            the txnDesc to set
	 */
	public void setTxnDesc(String txnDesc) {
		this.txnDesc = txnDesc;
	}

	/**
	 * @return the creditAcctNo
	 */
	public String getCreditAcctNo() {
		return creditAcctNo;
	}

	/**
	 * @param creditAcctNo
	 *            the creditAcctNo to set
	 */
	public void setCreditAcctNo(String creditAcctNo) {
		this.creditAcctNo = creditAcctNo;
	}

	/**
	 * @return the debitAccountNo
	 */
	public String getDebitAccountNo() {
		return debitAccountNo;
	}

	/**
	 * @param debitAccountNo
	 *            the debitAccountNo to set
	 */
	public void setDebitAccountNo(String debitAccountNo) {
		this.debitAccountNo = debitAccountNo;
	}

	/**
	 * @return the startDate
	 */
	public Date getStartDate() {
		return startDate;
	}

	/**
	 * @param startDate
	 *            the startDate to set
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	/**
	 * @return the nextRunOnDate
	 */
	public Date getNextRunOnDate() {
		return nextRunOnDate;
	}

	/**
	 * @param nextRunOnDate
	 *            the nextRunOnDate to set
	 */
	public void setNextRunOnDate(Date nextRunOnDate) {
		this.nextRunOnDate = nextRunOnDate;
	}

	/**
	 * @return the siID
	 */
	public String getSiID() {
		return siID;
	}

	/**
	 * @param siID
	 *            the siID to set
	 */
	public void setSiID(String siID) {
		this.siID = siID;
	}

	/**
	 * @return the customerIdentifier
	 */
	public String getCustomerIdentifier() {
		return customerIdentifier;
	}

	/**
	 * @param customerIdentifier
	 *            the customerIdentifier to set
	 */
	public void setCustomerIdentifier(String customerIdentifier) {
		this.customerIdentifier = customerIdentifier;
	}

	/**
	 * @return the sourceType
	 */
	public String getSourceType() {
		return sourceType;
	}

	/**
	 * @param sourceType
	 *            the sourceType to set
	 */
	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}

	/**
	 * @return the statusCode
	 */
	public String getStatusCode() {
		return statusCode;
	}

	/**
	 * @param statusCode
	 *            the statusCode to set
	 */
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	/**
	 * @return the statusDesc
	 */
	public String getStatusDesc() {
		return statusDesc;
	}

	/**
	 * @param statusDesc
	 *            the statusDesc to set
	 */
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	/**
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}

	/**
	 * @param currency
	 *            the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}

	/**
	 * @return the retryCount
	 */
	public Integer getRetryCount() {
		return retryCount;
	}

	/**
	 * @return the txnStatus
	 */
	public String getTxnStatus() {
		return txnStatus;
	}

	/**
	 * @return the smsStatus
	 */
	public String getSmsStatus() {
		return smsStatus;
	}

	/**
	 * @param smsStatus
	 *            the smsStatus to set
	 */
	public void setSmsStatus(String smsStatus) {
		this.smsStatus = smsStatus;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy
	 *            the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @param txnStatus
	 *            the txnStatus to set
	 */
	public void setTxnStatus(String txnStatus) {
		this.txnStatus = txnStatus;
	}

	/**
	 * @param retryCount
	 *            the retryCount to set
	 */
	public void setRetryCount(Integer retryCount) {
		this.retryCount = retryCount;
	}

	/**
	 * @return the paymentTransferName
	 */
	public String getPaymentTransferName() {
		return paymentTransferName;
	}

	/**
	 * @param paymentTransferName
	 *            the paymentTransferName to set
	 */
	public void setPaymentTransferName(String paymentTransferName) {
		this.paymentTransferName = paymentTransferName;
	}

	/**
	 * @return the templateId
	 */
	public String getTemplateId() {
		return templateId;
	}

	/**
	 * @param templateId
	 *            the templateId to set
	 */
	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}

	/**
	 * @return the txnId
	 */
	public String getTxnId() {
		return txnId;
	}

	/**
	 * @param txnId
	 *            the txnId to set
	 */
	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}

	/**
	 * @return the beneId
	 */
	public String getBeneId() {
		return beneId;
	}

	/**
	 * @param beneId
	 *            the beneId to set
	 */
	public void setBeneId(String beneId) {
		this.beneId = beneId;
	}

	/**
	 * @return the maxAmount
	 */
	public String getMaxAmount() {
		return maxAmount;
	}

	/**
	 * @return the executionCount
	 */
	public Integer getExecutionCount() {
		return executionCount;
	}

	/**
	 * @param executionCount
	 *            the executionCount to set
	 */
	public void setExecutionCount(Integer executionCount) {
		this.executionCount = executionCount;
	}

	/**
	 * @return the frequency
	 */
	public String getFrequency() {
		return frequency;
	}

	/**
	 * @param frequency
	 *            the frequency to set
	 */
	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	/**
	 * @return the completedCount
	 */
	public Integer getCompletedCount() {
		return completedCount;
	}

	/**
	 * @param completedCount
	 *            the completedCount to set
	 */
	public void setCompletedCount(Integer completedCount) {
		this.completedCount = completedCount;
	}

	/**
	 * @param maxAmount
	 *            the maxAmount to set
	 */
	public void setMaxAmount(String maxAmount) {
		this.maxAmount = maxAmount;
	}

	/**
	 * @return the channelId
	 */
	public String getChannelId() {
		return channelId;
	}

	/**
	 * @param channelId
	 *            the channelId to set
	 */
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	/**
	 * @return the refNo
	 */
	public String getRefNo() {
		return refNo;
	}

	/**
	 * @param refNo
	 *            the refNo to set
	 */
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	/**
	 * @return the minAmount
	 */
	public Double getMinAmount() {
		return minAmount;
	}

	/**
	 * @param minAmount
	 *            the minAmount to set
	 */
	public void setMinAmount(Double minAmount) {
		this.minAmount = minAmount;
	}

	/**
	 * @return the executionDay
	 */
	public Integer getExecutionDay() {
		return executionDay;
	}

	/**
	 * @param executionDay the executionDay to set
	 */
	public void setExecutionDay(Integer executionDay) {
		this.executionDay = executionDay;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("SIDetails [siID=");
		builder.append(siID);
		builder.append(", customerIdentifier=");
		builder.append(customerIdentifier);
		builder.append(", debitAccountNo=");
		builder.append(debitAccountNo);
		builder.append(", sourceType=");
		builder.append(sourceType);
		builder.append(", currency=");
		builder.append(currency);
		builder.append(", paymentTransferName=");
		builder.append(paymentTransferName);
		builder.append(", templateId=");
		builder.append(templateId);
		builder.append(", creditAcctNo=");
		builder.append(creditAcctNo);
		builder.append(", beneId=");
		builder.append(beneId);
		builder.append(", frequency=");
		builder.append(frequency);
		builder.append(", maxAmount=");
		builder.append(maxAmount);
		builder.append(", minAmount=");
		builder.append(minAmount);
		builder.append(", channelId=");
		builder.append(channelId);
		builder.append(", refNo=");
		builder.append(refNo);
		builder.append(", txnDesc=");
		builder.append(txnDesc);
		builder.append(", executionCount=");
		builder.append(executionCount);
		builder.append(", completedCount=");
		builder.append(completedCount);
		builder.append(", startDate=");
		builder.append(startDate);
		builder.append(", nextRunOnDate=");
		builder.append(nextRunOnDate);
		builder.append(", statusCode=");
		builder.append(statusCode);
		builder.append(", statusDesc=");
		builder.append(statusDesc);
		builder.append(", txnId=");
		builder.append(txnId);
		builder.append(", retryCount=");
		builder.append(retryCount);
		builder.append(", txnStatus=");
		builder.append(txnStatus);
		builder.append(", createdBy=");
		builder.append(createdBy);
		builder.append(", smsStatus=");
		builder.append(smsStatus);
		builder.append(", executionDay=");
		builder.append(executionDay);
		builder.append("]");
		return builder.toString();
	}
	
}
