/**
 * 
 */
package com.fab.si.model.payment;

/**
 * @author o4359
 *
 */
public class SewaBalanceEnquiryRequest {

	private BalanceEnquiryRequest sewaConsumer;
	private String customerIdentifier;

	/**
	 * @return the sewaConsumer
	 */
	public BalanceEnquiryRequest getSewaConsumer() {
		return sewaConsumer;
	}

	/**
	 * @param sewaConsumer
	 *            the sewaConsumer to set
	 */
	public void setSewaConsumer(BalanceEnquiryRequest sewaConsumer) {
		this.sewaConsumer = sewaConsumer;
	}

	/**
	 * @return the customerIdentifier
	 */
	public String getCustomerIdentifier() {
		return customerIdentifier;
	}

	/**
	 * @param customerIdentifier
	 *            the customerIdentifier to set
	 */
	public void setCustomerIdentifier(String customerIdentifier) {
		this.customerIdentifier = customerIdentifier;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("SewaBalanceEnquiryRequest [sewaConsumer=");
		builder.append(sewaConsumer);
		builder.append(", customerIdentifier=");
		builder.append(customerIdentifier);
		builder.append("]");
		return builder.toString();
	}

}
