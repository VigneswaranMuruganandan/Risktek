package com.fab.si.config;

//import java.util.Arrays;
//import org.springframework.boot.CommandLineRunner;
//import org.springframework.boot.SpringApplication;
//import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
//import org.springframework.boot.autoconfigure.SpringBootApplication;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.context.ApplicationContext;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.ImportResource;
import org.springframework.context.support.ClassPathXmlApplicationContext;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
//import de.codecentric.boot.admin.config.EnableAdminServer;
//import org.springframework.scheduling.annotation.EnableScheduling;

//@Configuration
//@EnableAdminServer
//@SpringBootApplication
//@EnableAutoConfiguration
//@EnableScheduling
//@EnableBatchProcessing
//@ImportResource({ "classpath:applicationContext.xml" })
public class App {

	private static final String START = "start";
	private static final String SPRING_CONTEXT_XML = "applicationContext.xml";

	public static void main(String[] args) {
		
		if (args.length > 0) {
			final String action = args[0];
			if (action.equalsIgnoreCase(START)) {
				// CHECK IF SI START BATCH APPLICATION
				//SpringApplication.run(App.class, args);
				new ClassPathXmlApplicationContext(SPRING_CONTEXT_XML);
			}
		}
	}
}
