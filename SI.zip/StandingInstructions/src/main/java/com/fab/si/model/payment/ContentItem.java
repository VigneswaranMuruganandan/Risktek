/**
 * 
 */
package com.fab.si.model.payment;

/**
 * @author Pratik Das
 *
 */
public final class ContentItem {

	private String contentID;
	private String path;
	private String contentText;
	private byte[] contentBin;
	private String contentType;
	private String version;
	private String metadata;
	private String contentExtension;

	/**
	 * @return the contentExtension
	 */
	public String getContentExtension() {
		return contentExtension;
	}

	/**
	 * @param contentExtension the contentExtension to set
	 */
	public void setContentExtension(String contentExtension) {
		this.contentExtension = contentExtension;
	}

	public String getContentID() {
		return contentID;
	}

	public void setContentID(String contentID) {
		this.contentID = contentID;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getContentText() {
		return contentText;
	}

	public void setContentText(String contentText) {
		this.contentText = contentText;
	}

	public byte[] getContentBin() {
		return contentBin;
	}

	public void setContentBin(byte[] contentBin) {
		this.contentBin = contentBin;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getMetadata() {
		return metadata;
	}

	public void setMetadata(String metadata) {
		this.metadata = metadata;
	}
}
