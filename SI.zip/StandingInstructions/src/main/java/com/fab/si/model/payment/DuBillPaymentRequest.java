/**
 * 
 */
package com.fab.si.model.payment;

/**
 * @author o4359
 *
 */
public class DuBillPaymentRequest extends DuBalanceEnquiryRequest {

	private BillerPaymentRequest accountPayment;
	private BillerPaymentRequest cardPayment;
	private String customerIdentifier;

	/**
	 * @return the accountPayment
	 */
	public BillerPaymentRequest getAccountPayment() {
		return accountPayment;
	}

	/**
	 * @param accountPayment
	 *            the accountPayment to set
	 */
	public void setAccountPayment(BillerPaymentRequest accountPayment) {
		this.accountPayment = accountPayment;
	}

	/**
	 * @return the cardPayment
	 */
	public BillerPaymentRequest getCardPayment() {
		return cardPayment;
	}

	/**
	 * @param cardPayment
	 *            the cardPayment to set
	 */
	public void setCardPayment(BillerPaymentRequest cardPayment) {
		this.cardPayment = cardPayment;
	}

	/**
	 * @return the customerIdentifier
	 */
	public String getCustomerIdentifier() {
		return customerIdentifier;
	}

	/**
	 * @param customerIdentifier the customerIdentifier to set
	 */
	public void setCustomerIdentifier(String customerIdentifier) {
		this.customerIdentifier = customerIdentifier;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DuBillPaymentRequest [accountPayment=");
		builder.append(accountPayment);
		builder.append(", cardPayment=");
		builder.append(cardPayment);
		builder.append(", customerIdentifier=");
		builder.append(customerIdentifier);
		builder.append("]");
		return builder.toString();
	}
}
