/**
 * 
 */
package com.fab.si.model.payment;

/**
 * @author o4359
 *
 */
public class SalikBalanceEnquiryRequest {

	private String accountNo;
	private String salikPinNo;
	private String customerIdentifier;

	/**
	 * @return the accountNo
	 */
	public String getAccountNo() {
		return accountNo;
	}

	/**
	 * @param accountNo
	 *            the accountNo to set
	 */
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	/**
	 * @return the salikPinNo
	 */
	public String getSalikPinNo() {
		return salikPinNo;
	}

	/**
	 * @param salikPinNo
	 *            the salikPinNo to set
	 */
	public void setSalikPinNo(String salikPinNo) {
		this.salikPinNo = salikPinNo;
	}

	/**
	 * @return the customerIdentifier
	 */
	public String getCustomerIdentifier() {
		return customerIdentifier;
	}

	/**
	 * @param customerIdentifier
	 *            the customerIdentifier to set
	 */
	public void setCustomerIdentifier(String customerIdentifier) {
		this.customerIdentifier = customerIdentifier;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("SalikBalanceEnquiryRequest [accountNo=");
		builder.append(accountNo);
		builder.append(", salikPinNo=");
		builder.append(salikPinNo);
		builder.append(", customerIdentifier=");
		builder.append(customerIdentifier);
		builder.append("]");
		return builder.toString();
	}
}
