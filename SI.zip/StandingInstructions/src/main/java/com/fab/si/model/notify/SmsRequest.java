
package com.fab.si.model.notify;

//@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class SmsRequest extends BaseRequest {

	private static final long serialVersionUID = -2757793075671404400L;
	private String mobileNo;
	private String smsText;
	private String sender;
	private String alertId;

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getSmsText() {
		return smsText;
	}

	public void setSmsText(String smsText) {
		this.smsText = smsText;
	}

	public String getSender() {
		return sender;
	}

	public void setSender(String sender) {
		this.sender = sender;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("SMSRequest [mobileNo=");
		builder.append(mobileNo);
		builder.append(", smsText=");
		builder.append(smsText);
		builder.append(", sender=");
		builder.append(sender);
		builder.append("]");
		return builder.toString();
	}

	public String getAlertId() {
		return alertId;
	}

	public void setAlertId(String alertId) {
		this.alertId = alertId;
	}


	
}
