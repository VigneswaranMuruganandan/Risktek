/**
 * 
 */
package com.fab.si.model.payment;

/**
 * @author o4359
 *
 */
public class BillerPaymentResponse extends BaseApiPaymentResponse {

	private String fgbTransactionRefNo;
	private String availableBalance;
	private String transactionDateTime;

	/**
	 * @return the fgbTransactionRefNo
	 */
	public String getFgbTransactionRefNo() {
		return fgbTransactionRefNo;
	}

	/**
	 * @param fgbTransactionRefNo
	 *            the fgbTransactionRefNo to set
	 */
	public void setFgbTransactionRefNo(String fgbTransactionRefNo) {
		this.fgbTransactionRefNo = fgbTransactionRefNo;
	}

	/**
	 * @return the availableBalance
	 */
	public String getAvailableBalance() {
		return availableBalance;
	}

	/**
	 * @param availableBalance
	 *            the availableBalance to set
	 */
	public void setAvailableBalance(String availableBalance) {
		this.availableBalance = availableBalance;
	}

	/**
	 * @return the transactionDateTime
	 */
	public String getTransactionDateTime() {
		return transactionDateTime;
	}

	/**
	 * @param transactionDateTime
	 *            the transactionDateTime to set
	 */
	public void setTransactionDateTime(String transactionDateTime) {
		this.transactionDateTime = transactionDateTime;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BillerPaymentResponse [fgbTransactionRefNo=");
		builder.append(fgbTransactionRefNo);
		builder.append(", availableBalance=");
		builder.append(availableBalance);
		builder.append(", transactionDateTime=");
		builder.append(transactionDateTime);
		builder.append("]");
		return builder.toString();
	}
}
