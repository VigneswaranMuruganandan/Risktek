import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BaseViewComponent }   from '../shared/Components/baseView.component';
import { DashboardComponent} from './Components/dashboard.component';

import { AuthGuard } from '../auth-guard.service';



const routes: Routes = [{
        path: '',
        component: BaseViewComponent,
        children: [
        	{
			    path: 'dashboard',
			    component: DashboardComponent,
			    canActivate: [AuthGuard]			    	
			},
			{
		        path: 'accounts',
		        loadChildren: 'app/accounts/accounts.module#AccountsModule'
		    },
			{
		        path: 'offers',
		        loadChildren: 'app/offers/offers.module#OffersModule'
		    },
		    {
		        path: 'payments',
		        loadChildren: 'app/payments/payments.module#PaymentsModule'
		    },
		    {
		        path: 'accountsettings',
		        loadChildren: 'app/accountSettings/accountSettings.module#AccountSettingsModule'
		    },
			{
			    path: '',
			    redirectTo: 'dashboard',
			    pathMatch: 'full'
			},
			{
		        path: 'others',
		        loadChildren: 'app/others/others.module#OthersModule'
		    },
		    {
		        path: 'investments',
		        loadChildren: 'app/investments/investments.module#InvestmentsModule'
		    },
		    {
		        path: 'cards',
		        loadChildren: 'app/cards/cards.module#CardsModule'
		    },
		    {
		        path: 'beneficiaries',
		        loadChildren: 'app/beneficiaries/beneficiaries.module#BeneficiariesModule'
		    },
		    {
		        path: 'transfers',
		        loadChildren: 'app/transfers/transfers.module#TransfersModule'
		    },
		    {
		        path: 'services',
		        loadChildren: 'app/services/services.module#ServicesModule'
		    },
		    {
		        path: 'loans',
		        loadChildren: 'app/loans/loans.module#LoansModule'
		    },
		    {
		        path: '',
		        loadChildren: 'app/isave/isave.module#IsaveModule'
		    }
        ]
    }
];

export const DashboardRouting: ModuleWithProviders = RouterModule.forChild(routes);