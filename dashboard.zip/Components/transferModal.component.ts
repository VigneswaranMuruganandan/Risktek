import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Component({
  selector: 'transferModal-component',
  templateUrl: './../templates/transferModal.html'
})
export class TransferModalComponent implements OnInit {
	public title :string;
	public count :number;

	ngOnInit() {
        //this.errorService.resetErrorResp();
        this.title = '';
        this.count = 0;
    }
}