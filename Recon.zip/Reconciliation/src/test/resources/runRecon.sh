#================================================================================================
#Author : KAUSHIK MUKHERJEE
#DEV
#================================================================================================
JAVA_HOME=/pbapp/java8_sdk
export JAVA_HOME
export PATH=$PATH:/pbapp/java8_sdk/bin
JAVA_OPTS="-Xms512m -Xmx1024m -XX:MaxPermSize=512m"
export JAVA_OPTS
case "$1" in
start)
	PID=$(ps -ef | grep 'java -jar Reconciliation.jar' | grep 'java' | grep -v grep | awk '{print $2}')
	if [ "${PID}" != "" ]; then
		echo "Reconciliation Batch Process already running"
	else
		echo "Starting Reconciliation Batch Process"
		nohup java -jar Reconciliation.jar start &
	fi
	;;
status)
 	   PID=$(ps -ef | grep 'java -jar Reconciliation.jar' | grep 'java' | grep -v grep | awk '{print $2}')
       if [ "${PID}" == "" ]; then
      	echo "Reconciliation Batch not running"
       else
       	echo "Everything is fine, Reconciliation Batch is runnning with PID = "${PID}""
       fi
       ;;
stop)
	PID=$(ps -ef | grep 'java -jar Reconciliation.jar' | grep 'java' | grep -v grep | awk '{print $2}')
	if [ "${PID}" == "" ]; then
		echo "Reconciliation Batch Process not running"
	else
		echo "Stopping Reconciliation Batch Process"
		kill -9 $PID
	fi
	;;
*)
       echo "Invalid command: "$1" ! Supported commands: start|stop|status"
       ;;
esac