/**
 * 
 */
package com.fab.recon.helper;

import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fab.recon.common.ApplicationConstants;

/**
 * @author Kaushik Mukherjee
 *
 */
public final class TextUtils {

	private static final Logger log = LoggerFactory.getLogger(TextUtils.class);

	public static void main(String[] args) {
		String str = createTextFromTemplate("You have deregistered your mobile.");
		System.out.println("str " + str);

	}

	/**
	 * Create Text From Template
	 * 
	 * @param message
	 *            with placeholders as {0}, {1}, {2} etc
	 * @param arguments
	 *            values for the placeholders in same order
	 * @return
	 */
	public static String createTextFromTemplate(final String message, Object... arguments) {
		MessageFormat mf = new MessageFormat(message);
		return mf.format(arguments);
	}

	/**
	 * Mask Email
	 * 
	 * @param strEmail
	 * @param maskChar
	 * @return
	 * @throws Exception
	 */
	public static String maskEmailAddress(String strEmail, char maskChar) {
		if (Objects.isNull(strEmail))
			return StringUtils.EMPTY;
		String[] parts = strEmail.split("@");

		// mask first part
		String strId = "";
		if (parts[0].length() < 4) {
			strId = maskString(parts[0], 0, parts[0].length(), maskChar);
		} else {
			strId = maskString(parts[0], 1, parts[0].length() - 1, maskChar);
		}
		// now append the domain part to the masked id part
		return strId + "@" + parts[1];
	}

	/**
	 * Mask any string
	 * 
	 * @param strText
	 * @param start
	 * @param end
	 * @param maskChar
	 * @return
	 * @throws Exception
	 */
	public static String maskString(String strText, int start, int end, char maskChar) {

		if (strText == null || strText.equals(""))
			return "";

		if (start < 0)
			start = 0;

		if (end > strText.length())
			end = strText.length();

		/*if (start > end)
			throw new AppException(ErrorCodes.SYS_INVALID_CONDITION);*/

		int maskLength = end - start;

		if (maskLength == 0)
			return strText;

		StringBuilder sbMaskString = new StringBuilder(maskLength);

		for (int i = 0; i < maskLength; i++) {
			sbMaskString.append(maskChar);
		}

		return strText.substring(0, start) + sbMaskString.toString() + strText.substring(start + maskLength);
	}

	public static String convertToHexString(byte[] data) {
		StringBuffer buf = new StringBuffer();
		for (int i = 0; i < data.length; i++) {
			int halfbyte = (data[i] >>> 4) & 0x0F;
			int two_halfs = 0;
			do {
				if ((0 <= halfbyte) && (halfbyte <= 9))
					buf.append((char) ('0' + halfbyte));
				else
					buf.append((char) ('a' + (halfbyte - 10)));
				halfbyte = data[i] & 0x0F;
			} while (two_halfs++ < 1);
		}
		return buf.toString();
	}

	public static Date convertStringToDate(String date, String format) {
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		try {
			return sdf.parse(date);
		} catch (Exception e) {
			// log.error("Error in convertStringToDate() :
			// {}",e.getLocalizedMessage());
		}
		return null;
	}

	public static String convertDatetoString(Date date, String format) {
		if (date == null)
			return "";
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		return sdf.format(date);
	}

	public static Double getDoubleValue(String value) {
		if (value == null) {
			return 0.0d;
		} else {
			return Double.valueOf(value);
		}
	}

	public static String getBackDatedDate(int i, String format) {
		Date referenceDate = new Date();
		Calendar c = Calendar.getInstance();
		c.setTime(referenceDate);
		c.add(Calendar.MONTH, -3);

		SimpleDateFormat sdf = new SimpleDateFormat(format);
		return sdf.format(c.getTime());
	}

	public static Boolean convertBoolean(String input) {
		if (Objects.nonNull(input)) {
			input = input.trim();
			if (input.equalsIgnoreCase(ApplicationConstants.Y) || input.equalsIgnoreCase(ApplicationConstants.YES)
					|| input.equalsIgnoreCase("1")) {
				return true;
			}
		}
		return false;
	}

	public static String formatDate(String date, String format) {
		if (date == null)
			return "";
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		SimpleDateFormat targetSdf = new SimpleDateFormat(ApplicationConstants.DATE_DDMMYYYY);
		try {
			Date dt = sdf.parse(date);
			date = targetSdf.format(dt);
		} catch (ParseException e) {
			log.error("Parse Exception for date {}", date);
			date = null;
		}

		return date;
	}

	public static String formatDate(Long date, String format) {
		if (date == null)
			return "";
		String dateStr = "";
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		Date dt = new Date(date);
		dateStr = sdf.format(dt);
		return dateStr;
	}

	public static String formatDate(Date date, String format) {
		if (date == null)
			return "";
		String strDt = "";
		SimpleDateFormat targetSdf = new SimpleDateFormat(format);
		strDt = targetSdf.format(date);
		return strDt;
	}

	public static String formatSqlDate(java.sql.Date dateSql, final String pattern) {
		String dateString = dateSql.toString();
		if (StringUtils.isNotBlank(dateString)) {
			SimpleDateFormat sdf = new SimpleDateFormat(pattern);
			dateString = sdf.format(dateSql);
		}
		return dateString;
	}

	public static Double getDouble(Object value) {
		double d = 0.0;
		try {
			String valuInString = value.toString();
			d = Double.parseDouble(valuInString);
		} catch (Exception e) {

		}
		return d;
	}
}
