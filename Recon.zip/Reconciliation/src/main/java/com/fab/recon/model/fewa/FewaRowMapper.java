/**
 * 
 */
package com.fab.recon.model.fewa;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

/**
 * @author o4359
 *
 */
@Component("resultSetMapper")
public class FewaRowMapper implements RowMapper<FewaReconDetails> {

	@Override
	public FewaReconDetails mapRow(ResultSet rs, int rowNum) throws SQLException {

		int i = 0;
		FewaReconDetails obj = new FewaReconDetails();
		obj.setDateRequest(rs.getString(++i));
		obj.setDateResponse(rs.getString(++i));
		obj.setHostRefNbr(rs.getString(++i));
		obj.setTxnId(rs.getString(++i));
		obj.setPaymentType(rs.getString(++i));
		obj.setTxnAmount(rs.getString(++i));
		obj.setStatus(rs.getString(++i));
		return obj;
	}
}
