/**
 * 
 */
package com.fab.recon.config;

/*import java.util.HashMap;
import java.util.Map;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.support.MapJobRegistry;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;

import com.fab.recon.model.fewa.FewaHeaderValues;
import com.fab.recon.processor.FewaReconItemProcessor;
import com.fab.recon.reader.FewaReconJdbcReader;
import com.fab.recon.writer.FewaReconItemWriter;*/

/**
 * @author o4359
 *
 */
/*@Configuration
@EnableBatchProcessing
@EnableScheduling
@ComponentScan(value = { "com.fab.recon" })
@PropertySource({ "file:D:/E-Drive/Softwares-new/64Bit-Softwares/wlp/usr/shared/resources/Reconciliation/recon.properties" })*/
public class ReconJobs {/*

	@Autowired
	private JobLauncher jobLauncher;

	@Autowired
	private MapJobRegistry jobRegistry;

	@Autowired
	private JobBuilderFactory jobs;

	@Autowired
	private StepBuilderFactory steps;

	@Autowired
	private Environment environment;

	@Bean(name = "fewaJdbcItemReader")
	public ItemReader<FewaHeaderValues> fewaJdbcItemReader() {
		return new FewaReconJdbcReader();
	}

	@Bean(name = "fewaItemProcessor")
	public ItemProcessor<FewaHeaderValues, FewaHeaderValues> fewaItemProcessor() {
		return new FewaReconItemProcessor();
	}

	@Bean(name = "fewaItemWriter")
	public ItemWriter<FewaHeaderValues> fewaItemWriter() {
		return new FewaReconItemWriter();
	}

	@Bean(name = "fewaReconStep")
	protected Step fewaReconStep() {
		return steps.get("fewaReconStep").<FewaHeaderValues, FewaHeaderValues> chunk(5)
				.reader(this.fewaJdbcItemReader()).processor(this.fewaItemProcessor()).writer(this.fewaItemWriter()).build();
	}

	@Bean(name = "fewaReconJob")
	public Job fewaReconJob(@Qualifier("fewaReconStep") Step step) {
		return jobs.get("fewaReconJob").start(step).build();
	}

	@Bean(name = "fewaReconJobDetail")
	public JobDetailFactoryBean fewaReconJobDetail() {
		JobDetailFactoryBean factory = new JobDetailFactoryBean();
		factory.setJobClass(JobLauncherDetails.class);
		factory.setGroup("quartz-batch");
		factory.setJobDataAsMap(this.getJobDataAsMap("fewaReconJob", jobRegistry, jobLauncher));
		return factory;
	}

	private Map<String, Object> getJobDataAsMap(final String jobName, final JobRegistry jobRegistry, final JobLauncher jobLauncher) {
		Map<String, Object> map = new HashMap<>();
		map.put("jobName", jobName);
		map.put("jobLauncher", jobLauncher);
		map.put("jobLocator", jobRegistry);
		return map;
	}

	@Bean(name = "fewaReconCronTrigger")
	public CronTriggerFactoryBean fewaReconCronTrigger() {
		CronTriggerFactoryBean cronTrigFactoryBean = new CronTriggerFactoryBean();
		cronTrigFactoryBean.setJobDetail(this.fewaReconJobDetail().getObject());
		cronTrigFactoryBean.setCronExpression(environment.getRequiredProperty("FEWA_RECON_CRON_EXP"));
		return cronTrigFactoryBean;
	}

	public SchedulerFactoryBean schedulerFactory() {
		SchedulerFactoryBean schedulerTriggBean = new SchedulerFactoryBean();
		schedulerTriggBean.setSchedulerName("cronScheduler");
		schedulerTriggBean.setTriggers(this.fewaReconCronTrigger().getObject());
		return schedulerTriggBean;
	}

*/}
