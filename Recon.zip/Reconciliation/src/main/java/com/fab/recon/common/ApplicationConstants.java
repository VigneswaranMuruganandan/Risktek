/**
 * 
 */
package com.fab.recon.common;

/**
 * @author kaushikmukherjee
 *
 */
public interface ApplicationConstants {

	String JOB_NAME = "jobName";
	String POST = "POST";
	String GET = "GET";
	String PUT = "PUT";
	String HEAD = "HEAD";

	String XREF = "XREF";
	String CHANNELID = "CHANNELID";
	String ACCESSTOKEN = "ACCESSTOKEN";

	String ACCOUNT = "ACCOUNT";
	String CARD = "CARD";
	String SUCCESS = "SUCCESS";
	String ERROR = "ERROR";
	String DATE_DDMMMYYYYHHMISS = "dd/MMM/yyyy hh:mi:ss";
	String DATE_DDMMMYYYYHHMMSS = "dd/MMM/yyyy HH:mm:ss";
	String DATE_DDMMYYYHHMMSS = "dd/mm/yyyy HH:mm:ss";
	String DATE_DDMMYYYY = "dd/MM/yyyy";
	String DATE_YYYMMDD = "yyyy-MM-dd";
	String DATE_YYYYMMDD = "yyyyMMdd";
	String Y = "Y";
	String YES = "YES";
	String DOT = ".";
	String COMMA = ",";
	String EN = "EN";

	// BILLER
	String AADC = "AADC";
	String ADDC = "ADDC";
	String SEWA = "SEWA";
	String DEWA = "DEWA";
	String FEWA = "FEWA";
	String DU = "DU";
	String SALIK = "SALIK";
	String ETISALAT = "ETISALAT";

	// PROPERTY CONSTANTS
	String IIB_SERVICE = "IIB_SERVICE";
	String WAS_SERVICE = "WAS_SERVICE";

	// JOB DETAILS
	String MEDIATYPE_TXTPLAIN = "text/plain";

	// DATABASE PARAMETERS

	String FEWA_BANKID = "13";
	String FEWA_CHANNELID = "FGB123456789012";
	String FEWA_SERVICE_TYPE = "FewaBill";
	String FEWA_MACHINENO = "FGB";
	String FEWA_LOCATION_DETAIL = "2";
	String H = "H";
	String D = "D";
	String CSV_EXT = ".csv";
}
