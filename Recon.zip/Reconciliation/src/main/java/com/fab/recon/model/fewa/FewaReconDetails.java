/**
 * 
 */
package com.fab.recon.model.fewa;

/**
 * @author o4359
 *
 */
public class FewaReconDetails {

	private String dateRequest;
	private String dateResponse;
	private String hostRefNbr;
	private String txnId;
	private String paymentType;
	private String txnAmount;
	private String status;
	private String id;
	private String bankId;
	private String channelId;
	private String serviceType;
	private String machineNumber;
	private String locDetail;
	private String reason;

	/**
	 * @return the dateRequest
	 */
	public String getDateRequest() {
		return dateRequest;
	}

	/**
	 * @param dateRequest
	 *            the dateRequest to set
	 */
	public void setDateRequest(String dateRequest) {
		this.dateRequest = dateRequest;
	}

	/**
	 * @return the dateResponse
	 */
	public String getDateResponse() {
		return dateResponse;
	}

	/**
	 * @param dateResponse
	 *            the dateResponse to set
	 */
	public void setDateResponse(String dateResponse) {
		this.dateResponse = dateResponse;
	}

	/**
	 * @return the hostRefNbr
	 */
	public String getHostRefNbr() {
		return hostRefNbr;
	}

	/**
	 * @param hostRefNbr
	 *            the hostRefNbr to set
	 */
	public void setHostRefNbr(String hostRefNbr) {
		this.hostRefNbr = hostRefNbr;
	}

	/**
	 * @return the txnId
	 */
	public String getTxnId() {
		return txnId;
	}

	/**
	 * @param txnId
	 *            the txnId to set
	 */
	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}

	/**
	 * @return the paymentType
	 */
	public String getPaymentType() {
		return paymentType;
	}

	/**
	 * @param paymentType
	 *            the paymentType to set
	 */
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	/**
	 * @return the txnAmount
	 */
	public String getTxnAmount() {
		return txnAmount;
	}

	/**
	 * @param txnAmount
	 *            the txnAmount to set
	 */
	public void setTxnAmount(String txnAmount) {
		this.txnAmount = txnAmount;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the bankId
	 */
	public String getBankId() {
		return bankId;
	}

	/**
	 * @param bankId
	 *            the bankId to set
	 */
	public void setBankId(String bankId) {
		this.bankId = bankId;
	}

	/**
	 * @return the channelId
	 */
	public String getChannelId() {
		return channelId;
	}

	/**
	 * @param channelId
	 *            the channelId to set
	 */
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	/**
	 * @return the serviceType
	 */
	public String getServiceType() {
		return serviceType;
	}

	/**
	 * @param serviceType
	 *            the serviceType to set
	 */
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	/**
	 * @return the machineNumber
	 */
	public String getMachineNumber() {
		return machineNumber;
	}

	/**
	 * @param machineNumber
	 *            the machineNumber to set
	 */
	public void setMachineNumber(String machineNumber) {
		this.machineNumber = machineNumber;
	}

	/**
	 * @return the locDetail
	 */
	public String getLocDetail() {
		return locDetail;
	}

	/**
	 * @param locDetail
	 *            the locDetail to set
	 */
	public void setLocDetail(String locDetail) {
		this.locDetail = locDetail;
	}

	/**
	 * @return the reason
	 */
	public String getReason() {
		return reason;
	}

	/**
	 * @param reason
	 *            the reason to set
	 */
	public void setReason(String reason) {
		this.reason = reason;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("[");
		builder.append("id=");
		builder.append(id);
		builder.append(", bankId=");
		builder.append(bankId);
		builder.append(", channelId=");
		builder.append(channelId);
		builder.append(", serviceType=");
		builder.append(serviceType);
		builder.append(", dateRequest=");
		builder.append(dateRequest);
		builder.append(", dateResponse=");
		builder.append(dateResponse);
		builder.append("hostRefNbr=");
		builder.append(hostRefNbr);
		builder.append(", txnId=");
		builder.append(txnId);
		builder.append(", machineNumber=");
		builder.append(machineNumber);
		builder.append(", locDetail=");
		builder.append(locDetail);
		builder.append(", paymentType=");
		builder.append(paymentType);
		builder.append(", txnAmount=");
		builder.append(txnAmount);
		builder.append(", status=");
		builder.append(status);
		builder.append(", reason=");
		builder.append(reason);
		builder.append("]");
		return builder.toString();
	}
}
