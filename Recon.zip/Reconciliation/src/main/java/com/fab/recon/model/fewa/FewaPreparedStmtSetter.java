/**
 * 
 */
package com.fab.recon.model.fewa;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Component;

import com.fab.recon.common.ApplicationConstants;
import com.fab.recon.common.Frequency;
import com.fab.recon.helper.TextUtils;
import com.fab.recon.helper.Utility;

/**
 * @author o4359
 *
 */
@Component("preparedStmtSetter")
public class FewaPreparedStmtSetter implements PreparedStatementSetter {

	@Autowired
	private Utility Utility;

	@Override
	public void setValues(PreparedStatement setter) throws SQLException {
		int i = 0;
		setter.setString(++i, TextUtils.formatDate(Utility.getDateByFrequency(new Date(), Frequency.PREVIOUSDAY), ApplicationConstants.DATE_YYYYMMDD));
		// setter.setString(1, "20170821");
	}
}
