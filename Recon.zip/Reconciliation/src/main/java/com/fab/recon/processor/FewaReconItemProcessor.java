/**
 * 
 */
package com.fab.recon.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import com.fab.recon.common.ApplicationConstants;
import com.fab.recon.model.fewa.FewaReconDetails;

/**
 * @author o4359
 *
 */
@Component("fewaItemProcessor")
public class FewaReconItemProcessor implements ItemProcessor<FewaReconDetails, FewaReconDetails> {

	private Logger log = LoggerFactory.getLogger(getClass());

	@Override
	public FewaReconDetails process(FewaReconDetails fewaDetails) throws Exception {
		fewaDetails.setId(ApplicationConstants.D);
		fewaDetails.setBankId(ApplicationConstants.FEWA_BANKID);
		fewaDetails.setChannelId(ApplicationConstants.FEWA_CHANNELID);
		fewaDetails.setServiceType(ApplicationConstants.FEWA_SERVICE_TYPE);
		fewaDetails.setMachineNumber(ApplicationConstants.FEWA_MACHINENO);
		fewaDetails.setLocDetail(ApplicationConstants.FEWA_LOCATION_DETAIL);
		fewaDetails.setReason(ApplicationConstants.SUCCESS);
		log.info("FEWA Details for Recon Date: {} - {}", fewaDetails.getDateRequest(), fewaDetails);
		return fewaDetails;
	}
}
