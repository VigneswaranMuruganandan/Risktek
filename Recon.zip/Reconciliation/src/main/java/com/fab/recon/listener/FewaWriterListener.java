/**
 * 
 */
package com.fab.recon.listener;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ItemWriteListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fab.recon.model.fewa.FewaReconDetails;
import com.fab.recon.repository.CIRepository;

/**
 * @author o4359
 *
 */
@Component("fewaWriterListener")
public class FewaWriterListener implements ItemWriteListener<FewaReconDetails> {

	private Logger log = LoggerFactory.getLogger(getClass());

	@Autowired
	private CIRepository ciRepo;

	@Override
	public void afterWrite(List<? extends FewaReconDetails> arg0) {
		log.info("SUCCESSFULLY WRITE {} DETAILS FROM DATABASE", arg0.toString());
		ciRepo.updateFewaHistoryPosted();
	}

	@Override
	public void beforeWrite(List<? extends FewaReconDetails> arg0) {
		log.info("STARTING FEWA WRITE FOR {} DETAILS FROM DATABASE", arg0.toString());
	}

	@Override
	public void onWriteError(Exception exe, List<? extends FewaReconDetails> arg1) {
		log.error("ERROR WHILE WRITING {} FEWA DETAILS FROM DATABASE", arg1.toString(), exe);
	}
}
