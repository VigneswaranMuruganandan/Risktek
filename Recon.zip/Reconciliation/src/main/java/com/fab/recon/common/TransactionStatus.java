/**
 * 
 */
package com.fab.recon.common;

/**
 * @author o4359
 *
 */
public enum TransactionStatus {

	VALIDATE_RULES("Validate Rules"),
	VALIDATE_RULES_FAILED("Validate Rules Failed"),
	PAYMENT_SMS_SENT_FAILED("SMS Sent Failure Payment"), 
	PAYMENT_SMS_SENT_SUCCESS("SMS Sent for Successful Payment"),
	PAYMENT_SUCCESS("SI Payment Successful"),
	PAYMENT_FAILED("SI Payment Failure"),
	PAYMENT_PROCESSING("SI Payment In Progress"),
	PAYMENT_STATUS("Derive Payment Based on Response"),
	INTERNAL_ERROR("Internal Error"),
	PENDING("Pending"),
	SMS_FOR_PAYMENT_FAILURE("SMS for Failure Payment"),
	SMS_FOR_PAYMENT_SUCCESS("SMS for Success Payment");

	private String description;

	TransactionStatus(String description) {
		this.description = description;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
}
