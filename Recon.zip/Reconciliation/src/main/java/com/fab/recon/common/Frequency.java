/**
 * 
 */
package com.fab.recon.common;

/**
 * @author o4359
 *
 */
public enum Frequency {

	WEEKLY("WEEKLY"),
	FORTNIGHT("FORTNIGHT"),
	MONTHLY("MONTHLY"),
	QUARTERLY("QUARTERLY"),
	HALFYEARLY("HALFYEARLY"),
	PREVIOUSDAY("PREVIOUSDAY");

	private String code;
	private String description;

	Frequency(String description) {
		this.code = name();
		this.description = description;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @param code
	 *            the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
}
