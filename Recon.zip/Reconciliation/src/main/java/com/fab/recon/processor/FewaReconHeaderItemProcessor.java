/**
 * 
 */
package com.fab.recon.processor;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fab.recon.common.ApplicationConstants;
import com.fab.recon.common.Frequency;
import com.fab.recon.helper.TextUtils;
import com.fab.recon.helper.Utility;
import com.fab.recon.model.fewa.FewaReconHeaderDetails;

/**
 * @author o4359
 *
 */
@Component("fewaHeaderItemProcessor")
public class FewaReconHeaderItemProcessor implements ItemProcessor<FewaReconHeaderDetails, FewaReconHeaderDetails> {

	private Logger log = LoggerFactory.getLogger(getClass());

	@Autowired
	private Utility utility;

	@Override
	public FewaReconHeaderDetails process(FewaReconHeaderDetails fewaHeaderValues) throws Exception {
		fewaHeaderValues.setId(ApplicationConstants.H);
		fewaHeaderValues.setBankId(ApplicationConstants.FEWA_BANKID);
		fewaHeaderValues.setReconDate(TextUtils.formatDate(utility.getDateByFrequency(new Date(), Frequency.PREVIOUSDAY), ApplicationConstants.DATE_YYYYMMDD));
		fewaHeaderValues.setFileDate(TextUtils.formatDate(new Date(), ApplicationConstants.DATE_YYYYMMDD));
		log.info("FEWA Header Values for Recon Date: {} - {}", fewaHeaderValues.getReconDate(), fewaHeaderValues);
		return fewaHeaderValues;
	}
}
