/**
 * 
 */
package com.fab.recon.common;

/**
 * @author o4359
 *
 */
public enum BillerCodes {
	
	FEWA("FW");
	
	private String code;
	private String desc;
	
	BillerCodes(String description) {
		this.code = this.name();
		this.desc = description;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @return the desc
	 */
	public String getDesc() {
		return desc;
	}

	/**
	 * @param desc the desc to set
	 */
	public void setDesc(String desc) {
		this.desc = desc;
	}
}
