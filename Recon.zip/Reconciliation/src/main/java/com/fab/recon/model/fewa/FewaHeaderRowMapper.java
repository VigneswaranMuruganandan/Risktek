/**
 * 
 */
package com.fab.recon.model.fewa;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

/**
 * @author o4359
 *
 */
@Component("rowMapper")
public class FewaHeaderRowMapper implements RowMapper<FewaReconHeaderDetails> {

	@Override
	public FewaReconHeaderDetails mapRow(ResultSet rs, int rowNum) throws SQLException {

		int i = 0;
		FewaReconHeaderDetails obj = new FewaReconHeaderDetails();
		obj.setTotalAmount(rs.getString(++i));
		obj.setTotalCount(rs.getString(++i));
		return obj;
	}
}
