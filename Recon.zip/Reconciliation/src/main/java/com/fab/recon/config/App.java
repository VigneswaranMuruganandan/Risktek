package com.fab.recon.config;

//import org.springframework.boot.SpringApplication;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	private static final String START = "start";
	private static final String SPRING_CONTEXT_XML = "applicationContext.xml";

	public static void main(String[] args) {

		if (args.length > 0) {
			final String action = args[0];
			if (action.equalsIgnoreCase(START)) {
				new ClassPathXmlApplicationContext(SPRING_CONTEXT_XML);
				// SpringApplication.run(AppConfig.class, args);
			}
		}
	}
}
