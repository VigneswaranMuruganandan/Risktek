/**
 * 
 */
package com.fab.recon.reader;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.fab.recon.common.QueryConstants;
import com.fab.recon.model.fewa.FewaHeaderRowMapper;
import com.fab.recon.model.fewa.FewaPreparedStmtSetter;
import com.fab.recon.model.fewa.FewaReconHeaderDetails;

/**
 * @author o4359
 *
 */
@Component("fewaHeaderJdbcItemReader")
@Scope("job")
public class FewaReconHeaderJdbcReader extends JdbcCursorItemReader<FewaReconHeaderDetails> {

	private Logger log = LoggerFactory.getLogger(getClass());

	@Autowired
	private DataSource ciDs;

	@Autowired
	private FewaPreparedStmtSetter preparedStmtSetter;

	@Autowired
	private FewaHeaderRowMapper rowMapper;

	@Override
	public void afterPropertiesSet() throws Exception {
		setDataSource(ciDs);
		setSql(QueryConstants.SELECT_FEWA_TOTAL_AMT_COUNT_BYDATE);
		setPreparedStatementSetter(preparedStmtSetter);
		setRowMapper(rowMapper);
		log.info("########### FEWA HEADER RECON JOB INITIALIZED: START ##########");
		super.afterPropertiesSet();
	}
}
