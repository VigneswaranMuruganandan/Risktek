import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import {GlobalURL} from '../../shared/services/globalURL';
import {ServiceInvoker} from '../../shared/connector/serviceInvoker.service';
import {EncryptionService} from '../../shared/services/encryption.service';




@Injectable()
export class BeneficiariesService {

  	constructor(private serviceInvoker: ServiceInvoker, 
                private encryptionService: EncryptionService) {}

    /*updateNickName(req:NickNameReq): Observable <APIResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ACCOUNTSETTINGS.UPDATENICKNAME,req)
                                .map(resp => JSON.parse(resp));
    }*/

   
}


