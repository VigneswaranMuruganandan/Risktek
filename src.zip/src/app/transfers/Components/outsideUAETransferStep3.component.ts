import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'outsideUAETransferStep3-component',
  templateUrl: './../templates/outsideUAETransferStep3.html'
})
export class OutsideUAETransferStep3Component {

	@Output() validateOTPEvent = new EventEmitter();
	@Output() backOTPButtonEvent = new EventEmitter();

	validateOTP(){
		this.validateOTPEvent.emit();
	}

	backOTP(){
		this.backOTPButtonEvent.emit();
	}
    
}
