import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'addBeneOutsideUAETransferStep1-component',
  templateUrl: './../templates/addBeneOutsideUAETransferStep1.html'
})
export class AddBeneOutsideUAETransferStep1Component {

	@Output() validateBeneFormNextButtonEvent = new EventEmitter();

	validateBeneForm(event){
		this.validateBeneFormNextButtonEvent.emit();
	}
    
    
}
