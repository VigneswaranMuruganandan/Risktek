import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'addBeneOutsideUAETransferStep4-component',
  templateUrl: './../templates/addBeneOutsideUAETransferStep4.html'
})
export class AddBeneOutsideUAETransferStep4Component {

	@Output() validateOTPEvent = new EventEmitter();
	@Output() backOTPButtonEvent = new EventEmitter();

	validateOTP(){
		this.validateOTPEvent.emit();
	}

	backOTP(){
		this.backOTPButtonEvent.emit();
	}
    
}
