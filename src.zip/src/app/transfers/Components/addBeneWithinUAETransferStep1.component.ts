import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'addBeneWithinUAETransferStep1-component',
  templateUrl: './../templates/addBeneWithinUAETransferStep1.html'
})
export class AddBeneWithinUAETransferStep1Component {

	@Output() validateFormNextButtonEvent = new EventEmitter();

	validateForm(){
		this.validateFormNextButtonEvent.emit();
	}
    
    
}
