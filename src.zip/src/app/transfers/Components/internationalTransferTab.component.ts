import { Component, OnInit, Input} from '@angular/core';


@Component({
  selector: 'internationalTransfer-tab',
  templateUrl: './../templates/internationalTransferTab.html'
})
export class InternationalTransferTabComponent {

	
}