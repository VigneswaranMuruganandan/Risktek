import { Component, OnInit, Input} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'withinFAB-tab',
  templateUrl: './../templates/withinFABTab.html'
})
export class WithinFABTabComponent {

    
}
