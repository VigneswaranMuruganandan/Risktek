import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'outsideUAETransferStep1-component',
  templateUrl: './../templates/outsideUAETransferStep1.html'
})
export class OutsideUAETransferStep1Component {

	@Output() validateFormNextButtonEvent = new EventEmitter();

	validateForm(){
		this.validateFormNextButtonEvent.emit();
	}
    
    
}
