import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {CustomerData} from '../model/customerData';
import { ErrorService} from '../../shared/services/error.service';

@Component({
  selector: 'registrationstep3-component',
  templateUrl: './../templates/registrationStep3.html'
})
export class RegistrationStep3Component implements OnInit {
	@Input() validUsernameFlag: boolean;
	@Output() registrationBackEvent = new EventEmitter();
	@Output() validateRegistrationUsernameEvent = new EventEmitter();
	@Input() customerData: CustomerData;
	public userName:string;
	
	constructor( private errorService: ErrorService ){}

	ngOnInit() {
		if(this.customerData.userName){
			this.userName = this.customerData.userName;
			this.validUsernameFlag = true;
			(<any>$('.validate li')).addClass('success');
		}
	}

    usernameValidations(flag :boolean){
    	this.validUsernameFlag = flag;
    }

	validateUsername(valid: boolean){
		if(valid){
			this.errorService.resetErrorResp();
			this.validateRegistrationUsernameEvent.emit(this.userName);
		}		
	}
	back(){
		this.registrationBackEvent.emit(1);
	}
}