import { Component, Input, OnInit, AfterViewInit,ViewChild  } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService} from '@ngx-translate/core';
import { TemplateService} from '../../shared/services/template.service';
import { SharedService} from '../../shared/services/shared.service';
import { DashboardService} from '../services/dashboard.service';
import { DashBoardDetails } from '../model/dashBoardDetails';
import { CustomerProducts } from '../../shared/model/customerProducts';
import { UserDetails } from '../../shared/model/userDetails';
import { SpinnerService } from '../../shared/services/spinner.service';
import { FavouritesSettingsModalComponent } from './favouritesSettingsModal.component';
import { AppSession} from '../../shared/model/appSession';
import { UpdateFavoritesProduct } from '../model/updateFavoritesProduct';
import { Observable } from 'rxjs/Rx';
import { BeneficiaryCountMap } from '../model/beneficiaryCountMap';
import { BillerCountMap } from '../model/billerCountMap';
import { PaymentTypes } from '../model/paymentTypes';
import { TransferTypes } from '../model/transferTypes';
import { GlobalVariable} from '../../shared/services/global';


@Component({
  templateUrl: './../templates/dashboard.html'
})
export class DashboardComponent implements OnInit {
    @ViewChild(FavouritesSettingsModalComponent) favouritesSettingsModal: FavouritesSettingsModalComponent;
    public dashBoardDetails: DashBoardDetails;
    public fav_count: number ;
    public appSession: AppSession;
    public transferTemplateCount : BeneficiaryCountMap[];  
    public paymentTemplateCount : BillerCountMap[];
    GlobalVariable: any;   

    constructor( private dashboardService: DashboardService,
                 private spinnerService: SpinnerService, 
                 private sharedService: SharedService,
                 public templateService: TemplateService,
                 private router: Router) {}

    ngOnInit() {
        this.GlobalVariable = GlobalVariable;
    	this.appSession = AppSession.getInstance();
    	if(this.appSession.newcustomer == 'Y'){
    		(<any>$('#openWelcomeModal')).click();
            this.appSession.newcustomer = 'N';
    	}
        this.initTransferBillersTemplateCount();         
        this.initDashboardDetails();
        this.initTab('fav');
    }


    sliderRecreation(type){        
        (<any>$('#'+type+'CarouselRefresh')).click();
        this.initTab(type);
    }

    initTab(type){
        (<any>$('.favourite-tab-block .slick-carousel-arrows')).hide();
        (<any>$('#slick-carousel-dots-'+type)).show();
    }

    initTransferBillersTemplateCount(){
        this.transferTemplateCount = new Array();
        this.paymentTemplateCount = new Array();
        let transferCount = this.appSession.transferTypes,
        paymentCount = this.appSession.paymentTypes;
        /*
        * Dashboard Transfer Template count
        */
        transferCount.map((obj,index) => {
           let filteredData = this.appSession.beneficiaryCountMap.filter(data => data.paymentOrTransferProviderName == obj.paymentTransferName);
           let data = new BeneficiaryCountMap();
           data.paymentOrTransferProviderName = obj.paymentTransferName;
           if(filteredData.length > 0)
                data.numberOfpayments = filteredData[0].numberOfpayments;
           else
                data.numberOfpayments = 0;          
           this.transferTemplateCount.push(data);
        });
        /*
        * Dashboard Payment Billers Template count
        */
        paymentCount.map((obj,index) => {
           let filteredData = this.appSession.billerCountMap.filter(data => data.paymentOrTransferProviderName == obj.paymentTransferName);
           let data = new BillerCountMap();
           data.paymentOrTransferProviderName = obj.paymentTransferName;
           if(filteredData.length > 0)
                data.numberOfpayments = filteredData[0].numberOfpayments;
           else
                data.numberOfpayments = 0;          
           this.paymentTemplateCount.push(data);
        });  
        console.log(this.transferTemplateCount,this.paymentTemplateCount);      
    }
    /*
    * Init method to fetch the Dashboard Details service
    * will provide favourites, payment templates
    * Transfer Templates, offers and all products
    */
    initDashboardDetails(){
        this.spinnerService.startSpinner('dashboardFavShow');
        this.dashboardService.fetchDashBoardResults()
            .subscribe(
                resp => this.handleDashboardInitResp(resp),
                error => this.sharedService.handleError(error)
            );        
    }
    /*
    * Handling Dashboard Response
    */
    handleDashboardInitResp(resp: any){
        console.log("dashboard init result::"+resp);
        this.spinnerService.stopSpinner('dashboardFavShow');
        if(resp && resp.result.status == "success"){
            this.dashBoardDetails = new DashBoardDetails();
            this.dashBoardDetails = resp;
            this.calculateFavouriteCount(this.dashBoardDetails.favouriteProducts);
        }
    }
    /*
    * Calculate the Favourite count
    */
    calculateFavouriteCount(favouriteProducts :CustomerProducts){
        this.fav_count = 0;
    	if(favouriteProducts){
    		Object.getOwnPropertyNames(favouriteProducts)
    				.map((key: string) => {
    					switch(key) {
						    case 'accounts':
						        this.fav_count = this.fav_count + favouriteProducts[key].length;
						        break;
						    case 'loans':
						        this.fav_count = this.fav_count + favouriteProducts[key].length;
						        break;
						    case 'cards':
						    	favouriteProducts[key].map(obj => { 								   
								   obj['availableBalancePercentage'] = this.templateService.calAvailBalPercentage(obj.availableBalance.value,obj.cardLimit.value);
								});
						        this.fav_count = this.fav_count + favouriteProducts[key].length;
						        break;
						    case 'deposits':
						        this.fav_count = this.fav_count + favouriteProducts[key].length;
						        break;
						}
    				});
    	}
    }
    /*
    * Save the selected favourites
    */
    saveAsAllFavourites(){
        this.dashboardService.saveAsAllFavourites()
            .subscribe(
                resp => {
                    if(resp.result.status == 'success'){
                        let AppSess = AppSession.getInstance();
                        (<any>$('#welcomeDashboard-1')).modal('hide');
                        this.initDashboardDetails();
                    }
                },
                error => this.sharedService.handleError(error)
            );
    }

    unFavouriteSelectedIndex(data :any, type :string){
        this.spinnerService.startSpinner('dashboardFavShow');
        let updateFavoritesProduct = new UpdateFavoritesProduct();
        if(data && type){
            switch(type) {
                case 'ACC_DEP':
                    updateFavoritesProduct.productRef = data.number
                    break;
                case 'CARD':
                    updateFavoritesProduct.productRef = data.cardNumber;
                    break;
                case 'LOAN':
                    updateFavoritesProduct.productRef = data.loanNumber;
                    break;
            }
            updateFavoritesProduct.favoriteState = false;
        }
        this.sharedService.unFavouriteProduct(updateFavoritesProduct)
            .subscribe(
                resp => {
                    if(resp && resp.result.status == "success"){
                        this.router.navigate(['/dashboard']);
                    }
                },
                error => this.sharedService.handleError(error)
            );

    }
    /*
    * Show Favourite settings option to customer
    */    
    dashboardFavouritesSettings(){
        let el_flag = $('#hide:visible');
        if(el_flag.length > 0){
            (<any>$('#hide')).click();    
        }        
        this.favouritesSettingsModal.initFavouritesDetails();
        (<any>$('#openAddFavouritesModal')).click();
    }
    /*
    * Open Favourite Poup info modal
    */
    openFavouritesModal(){
        (<any>$('#close')).click();
        (<any>$('#openfavouritesModal')).click();        
    }
    /*
    * Show Favourite settings option to customer from Favourite Poup info
    */
    openFavouritesSettingsModal(){
        (<any>$('#close')).click();
        this.favouritesSettingsModal.initFavouritesDetails();
        (<any>$('#openAddFavouritesModal')).click();
    }
    /*
    * Navigating to Account page with selected Account Number
    */
    onSelectedAccount(accountNum:string){
        this.appSession.dashboardAccount = accountNum;
        this.router.navigate(['/accounts']);
    }   
}