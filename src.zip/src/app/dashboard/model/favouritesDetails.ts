import { APIResponse } from '../../shared/model/apiResponse';
import { ProductPreference } from './productPreference';

export class FavouritesDetails extends APIResponse{
    productPreference : ProductPreference[];
}


