import { Component, OnInit, Input} from '@angular/core';
import { SharedService } from '../../shared/services/shared.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { ErrorService } from '../../shared/services/error.service';
import { Router } from '@angular/router';

@Component({
  templateUrl: './../templates/loanDeferral.html'
})
export class LoanDeferralComponent implements OnInit {
	public loanAccount :any;
	constructor( private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService,
    			 private router: Router) {}
	ngOnInit() {
        this.loanAccount = [];
    }

	submitLoanDeferral(){
		//(<any>$('#defferal-message')).modal('show');
	}

}