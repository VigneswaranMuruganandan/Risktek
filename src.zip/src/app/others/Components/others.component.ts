import { Component, OnInit, Input} from '@angular/core';

@Component({
  templateUrl: './../templates/others.html'
})
export class OthersComponent {
	

}