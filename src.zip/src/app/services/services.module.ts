import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { routing } from './services.routing';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '../shared/shared.module';
import { SharedService} from '../shared/services/shared.service';
import { TemplateService} from '../shared/services/template.service';
import { ServicesService} from './services/services.service';
import { FormsModule } from '@angular/forms';

import { chequeBookRequestComponent } from './Components/chequeBookRequest.component';
import { chequeBookRequestFormComponent }   from './Components/chequeBookRequestForm.Component';
import { chequeBookRequestReviewComponent }   from './Components/chequeBookRequestReview.Component';
import { chequeBookRequestOtpComponent }   from './Components/chequeBookRequestOtp.Component';
import { chequeBookRequestSuccessComponent }   from './Components/chequeBookRequestSuccess.Component';

const SERVICES_COMPONENTS = [
    chequeBookRequestComponent,
    chequeBookRequestFormComponent,
    chequeBookRequestReviewComponent,
    chequeBookRequestOtpComponent,
    chequeBookRequestSuccessComponent    
];

const SERVICES_DIRECTIVES = [
    
];

const SERVICES_PROVIDERS = [
   SharedService,
   TemplateService,
   ServicesService
];

@NgModule({
  	imports: [
	    routing,
	    TranslateModule.forChild(),
	    SharedModule,
	    FormsModule,
      	CommonModule
	],
  	declarations: [
	    ...SERVICES_COMPONENTS/*,
      ...SERVICES_DIRECTIVES*/
	],
  	providers: [
  		...SERVICES_PROVIDERS
  	]
})
export class ServicesModule {}
