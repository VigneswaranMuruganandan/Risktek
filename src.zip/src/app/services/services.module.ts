import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { routing } from './services.routing';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '../shared/shared.module';
import { SharedService} from '../shared/services/shared.service';
import { TemplateService} from '../shared/services/template.service';
import { ServicesService} from './services/services.service';
import { FormsModule } from '@angular/forms';

import { ChequeBookRequestComponent } from './Components/chequeBookRequest.component';
import { ChequeBookRequestFormComponent }   from './Components/chequeBookRequestForm.component';
import { ChequeBookRequestReviewComponent }   from './Components/chequeBookRequestReview.component';
import { ChequeBookRequestOtpComponent }   from './Components/chequeBookRequestOtp.component';
import { ChequeBookRequestSuccessComponent }   from './Components/chequeBookRequestSuccess.component';

import {
  ValidateChequeBookRequestDirective
} from './directives/validateServices.directive'


const SERVICES_COMPONENTS = [
    ChequeBookRequestComponent,
    ChequeBookRequestFormComponent,
    ChequeBookRequestReviewComponent,
    ChequeBookRequestOtpComponent,
    ChequeBookRequestSuccessComponent    
];

const SERVICES_DIRECTIVES = [
    ValidateChequeBookRequestDirective
];

const SERVICES_PROVIDERS = [
   SharedService,
   TemplateService,
   ServicesService
];

@NgModule({
  	imports: [
	    routing,
	    TranslateModule.forChild(),
	    SharedModule,
	    FormsModule,
      	CommonModule
	],
  	declarations: [
	    ...SERVICES_COMPONENTS,
      ...SERVICES_DIRECTIVES
	],
  	providers: [
  		...SERVICES_PROVIDERS
  	]
})
export class ServicesModule {}
