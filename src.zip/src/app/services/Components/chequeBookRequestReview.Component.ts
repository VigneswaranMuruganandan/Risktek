import { Component, OnInit, Input, Output, EventEmitter, ViewChild, OnDestroy } from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { OTPComponent } from '../../shared/Components/otp.component';
import { ErrorService} from '../../shared/services/error.service';
import { SharedService } from '../../shared/services/shared.service';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'chequeBookRequestReview-component',
  templateUrl: './../templates/chequeBookRequestReview.html'
})
export class chequeBookRequestReviewComponent{
	@Output() reviewChequeBookReqEvent = new EventEmitter();

	constructor( private errorService: ErrorService,
				 private sharedService: SharedService){}

	confirm(){
		this.reviewChequeBookReqEvent.emit();
	}

	back(){
		this.reviewChequeBookReqEvent.emit(1);
	}
}