import { Component, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {TemplateService} from '../../shared/services/template.service';
import { ErrorService} from '../../shared/services/error.service';

@Component({
  selector: 'chequeBookRequestOtp-component',
  templateUrl: './../templates/chequeBookRequestOtp.html'
})
export class chequeBookRequestOtpComponent {
	@Output() validateOTPChequeBookReqEvent = new EventEmitter();
	
	constructor( public templateService: TemplateService,
				 private errorService: ErrorService) {}

	validateOTP(otp : string){
		this.errorService.resetErrorResp();
		this.validateOTPChequeBookReqEvent.emit(otp);
	}
}



