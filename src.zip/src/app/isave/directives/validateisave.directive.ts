import { Component, ElementRef, Directive, HostListener, NgZone, Input, Output, EventEmitter } from '@angular/core';
import * as $ from 'jquery';
import {TemplateService} from '../../shared/services/template.service';
import 'app/assets/js/jquery.validate.js';
import { CreateRegSavingRequest } from '../model/createRegSavingRequest';


@Directive({
    selector: '[validateCreateIsaveDirective]',
})
export class ValidateCreateIsave {
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let validateCreateIsaveValidationSubmit;
        this.zone.runOutsideAngular(() => {
            var validateCreateIsaveValidation = (<any>$("#validateCreateIsaveForm")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input,select")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    accountNumber: {
                        required: true
                    },
                    accountPurpose: {
                        required: true
                    },
                    ifOthers: {
                        required: true
                    },
                    nickName: {
                        required: true
                    },
                    openingAmount: {
                        required: true
                    },
                    termsAndCond: {
                        required: true
                    }

                },
                messages: {
                    customerIdentificationNo: {
                        required: "Please enter Customer Identification Number"
                    },
                    accountNumber: {
                        required: "Please make a selection"
                    },
                    accountPurpose: {
                        required: "Please make a selection"
                    },
                    ifOthers: {
                        required: "Please fill"
                    },
                    nickName: {
                        required: "Please fill"
                    },
                    openingAmount: {
                        required: "Please fill"
                    },
                    termsAndCond: {
                        required: "Please fill"
                    }
                }
            });
            validateCreateIsaveValidationSubmit = validateCreateIsaveValidation.form();
            this.templateService.setFormValidatorFlag(validateCreateIsaveValidationSubmit);
        });
    }
}

@Directive({
    selector: '[validateEditIsaveDirective]',
})
export class ValidateEditIsave {
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let validateEditIsaveValidationSubmit;
        this.zone.runOutsideAngular(() => {
            var validateEditIsaveValidation = (<any>$("#validateEditIsaveForm")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input,select")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    accountDescription: {
                        required: true
                    },
                    accountPurpose: {
                        required: true
                    },
                    ifOthers: {
                        required: true
                    }
                },
                messages: {
                    accountDescription: {
                        required: "Please fill in"
                    },
                    accountPurpose: {
                        required: "Please fill in"
                    },
                    ifOthers: {
                        required: "Please fill in"
                    }
                }
            });
            validateEditIsaveValidationSubmit = validateEditIsaveValidation.form();
            this.templateService.setFormValidatorFlag(validateEditIsaveValidationSubmit);
        });
    }
}


@Directive({
    selector: '[validateCreateRegularSavingsDirective]',
})
export class ValidateCreateRegularSavings {
    @Input() createRegSavingRequest: CreateRegSavingRequest;

    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let validateCreateRegularSavingsValidationSubmit;
        this.zone.runOutsideAngular(() => {
            (<any>$).validator.addMethod("notEqual", 
            function (value :any, element :any, param :any) {
                var flag = false;
                if(value != null){
                    flag = (value != param) ? true : false;
                }
                return flag;
            });

            var validateCreateRegularSavingsValidation = (<any>$("#validateCreateRegularSavingsForm")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input,select")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    sourceAccount: {
                        required: true
                    },
                    destinationAccount: {
                        required: true,
                        notEqual: this.createRegSavingRequest.sourceAccount,
                    },
                    openingAmount: {
                        required: true
                    },
                    frequency: {
                        required: true
                    },
                    startDate: {
                        required: true
                    },
                    endDate: {
                        required: true
                    },
                    termsAndCond: {
                        required: true
                    }
                },
                messages: {
                    sourceAccount: {
                        required: "Please make a selection"
                    },
                    destinationAccount: {
                        required: "Please make a selection",
                        notEqual: "Source Account and Destination Account cannot be same",

                    },
                    openingAmount: {
                        required: "Please fill in"
                    },
                    frequency: {
                        required: "Please make a selection"
                    },
                    startDate: {
                        required: "Please make a selection"
                    },
                    endDate: {
                        required: "Please make a selection"
                    },
                    termsAndCond: {
                        required: "Please fill"
                    }
                }
            });
            validateCreateRegularSavingsValidationSubmit = validateCreateRegularSavingsValidation.form();
            this.templateService.setFormValidatorFlag(validateCreateRegularSavingsValidationSubmit);
        });
    }
}

@Directive({
    selector: '[validateEditRegularSavingsDirective]',
})
export class ValidateEditRegularSavings {
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let validateEditRegularSavingsValidationSubmit;
        this.zone.runOutsideAngular(() => {
            var validateEditRegularSavingsValidation = (<any>$("#validateEditRegularSavingsForm")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input,select")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    customerIdentificationNo: {
                        required: true
                    }
                },
                messages: {
                    customerIdentificationNo: {
                        required: "Please enter Customer Identification Number"
                    }
                }
            });
            validateEditRegularSavingsValidationSubmit = validateEditRegularSavingsValidation.form();
            this.templateService.setFormValidatorFlag(validateEditRegularSavingsValidationSubmit);
        });
    }
}