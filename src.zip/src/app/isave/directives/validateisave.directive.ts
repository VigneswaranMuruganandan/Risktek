import { Component, ElementRef, Directive, HostListener, NgZone, Input, Output, EventEmitter } from '@angular/core';
import * as $ from 'jquery';
import {TemplateService} from '../../shared/services/template.service';
import 'app/assets/js/jquery.validate.js';


@Directive({
    selector: '[validateCreateIsaveDirective]',
})
export class ValidateCreateIsave {
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let validateCreateIsaveValidationSubmit;
        this.zone.runOutsideAngular(() => {
            var validateCreateIsaveValidation = (<any>$("#validateCreateIsaveForm")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    customerIdentificationNo: {
                        required: true
                    }
                },
                messages: {
                    customerIdentificationNo: {
                        required: "Please enter Customer Identification Number"
                    }
                }
            });
            validateCreateIsaveValidationSubmit = validateCreateIsaveValidation.form();
            this.templateService.setFormValidatorFlag(validateCreateIsaveValidationSubmit);
        });
    }
}

@Directive({
    selector: '[validateEditIsaveDirective]',
})
export class ValidateEditIsave {
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let validateEditIsaveValidationSubmit;
        this.zone.runOutsideAngular(() => {
            var validateEditIsaveValidation = (<any>$("#validateEditIsaveForm")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    customerIdentificationNo: {
                        required: true
                    }
                },
                messages: {
                    customerIdentificationNo: {
                        required: "Please enter Customer Identification Number"
                    }
                }
            });
            validateEditIsaveValidationSubmit = validateEditIsaveValidation.form();
            this.templateService.setFormValidatorFlag(validateEditIsaveValidationSubmit);
        });
    }
}


@Directive({
    selector: '[validateCreateRegularSavingsDirective]',
})
export class ValidateCreateRegularSavings {
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let validateCreateRegularSavingsValidationSubmit;
        this.zone.runOutsideAngular(() => {
            var validateCreateRegularSavingsValidation = (<any>$("#validateCreateRegularSavingsForm")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    customerIdentificationNo: {
                        required: true
                    }
                },
                messages: {
                    customerIdentificationNo: {
                        required: "Please enter Customer Identification Number"
                    }
                }
            });
            validateCreateRegularSavingsValidationSubmit = validateCreateRegularSavingsValidation.form();
            this.templateService.setFormValidatorFlag(validateCreateRegularSavingsValidationSubmit);
        });
    }
}

@Directive({
    selector: '[validateEditRegularSavingsDirective]',
})
export class ValidateEditRegularSavings {
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let validateEditRegularSavingsValidationSubmit;
        this.zone.runOutsideAngular(() => {
            var validateEditRegularSavingsValidation = (<any>$("#validateEditRegularSavingsForm")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    customerIdentificationNo: {
                        required: true
                    }
                },
                messages: {
                    customerIdentificationNo: {
                        required: "Please enter Customer Identification Number"
                    }
                }
            });
            validateEditRegularSavingsValidationSubmit = validateEditRegularSavingsValidation.form();
            this.templateService.setFormValidatorFlag(validateEditRegularSavingsValidationSubmit);
        });
    }
}