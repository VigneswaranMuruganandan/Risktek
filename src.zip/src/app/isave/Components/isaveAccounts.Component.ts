import { Component, Input, Output, EventEmitter, ViewChild, OnInit } from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { TemplateService} from '../../shared/services/template.service';
import { ErrorService} from '../../shared/services/error.service';
import { ISaveResponse } from '../model/isaveResponse';
import { RegularSavingResponse } from '../model/regularSavingResponse';
import { ISave } from '../model/isave';
import { RegularSaving } from '../model/regularSaving';
import { CreateIsaveRequest } from '../model/createIsaveRequest';
import { CreateIsaveResponse } from '../model/createIsaveResponse';
import { CloseIsaveRequest } from '../model/closeIsaveRequest';
import { IsaveService } from '../services/isave.service';
import { SharedService } from '../../shared/services/shared.service';
import { SetupIsaveResponse } from '../model/setupIsaveResponse';
import { Router } from '@angular/router';
import { CloseIsaveComponent } from './closeIsave.Component';
import { SpinnerService } from '../../shared/services/spinner.service';

@Component({
  templateUrl: './../templates/isaveAccounts.html'
})
export class IsaveAccountsComponent implements OnInit {
	isaveList: ISave[];
	regularSavingList :RegularSaving[];
	setupIsaveResponse :any;
	closeIsaveRequest :CloseIsaveRequest;
	@ViewChild('table') tableElem: any;
	loadingIndicatorIsave :boolean = true;
	loadingIndicatorRegSav :boolean = true;

	@ViewChild(CloseIsaveComponent) closeIsaveModal: CloseIsaveComponent;

	constructor( public templateService: TemplateService,
				 private sharedService: SharedService,
				 public isaveService: IsaveService,
				 private errorService: ErrorService,
				 private spinnerService: SpinnerService,
				 private router: Router) {}

	ngOnInit() {
		this.fetchIsaveList();
		this.fetchRegularSavingList();
		this.fetchIsaveInit();
		this.tableElem.offset = 0;
		this.closeIsaveRequest = new CloseIsaveRequest();
		this.errorService.resetErrorResp();
	}

	/*
	* Isave INIT service for dropdown values
	*/
	fetchIsaveInit(){
		this.isaveService.setupIsave()
            .subscribe(
                resp => this.handleIsaveInit(resp),
                error => this.sharedService.handleError(error)
            );
	}
	/*
	* Handle Isave init service
	*/
	handleIsaveInit(resp :SetupIsaveResponse){
        if(resp.result.status == 'success'){
            this.setupIsaveResponse = resp;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
    }

	/*
	* Fetch the Isave List
	*/
	fetchIsaveList(){
		this.isaveService.fetchIsaveList()
            .subscribe(
                resp => this.handleIsaveListResp(resp),
                error => this.sharedService.handleError(error)
            );
	}
	/*
	* Handle the Isave List Response
	*/
	handleIsaveListResp(resp :ISaveResponse){
		this.loadingIndicatorIsave = false;
		if(resp.result.status == 'success'){
            this.isaveList = resp.isaveList;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
	}
	/*
	* Fetch the Regular Saving List
	*/
	fetchRegularSavingList(){
		this.isaveService.fetchRegularSavingList()
            .subscribe(
                resp => this.handleRegularSavingListResp(resp),
                error => this.sharedService.handleError(error)
            );
	}
	/*
	* Handle the Regular Saving List Response
	*/
	handleRegularSavingListResp(resp :any){
		this.loadingIndicatorRegSav = false;
		if(resp.result.status == 'success'){
            this.regularSavingList = resp.iSaveSIList;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
	}
	/*
	* View Isave Account
	*/
	viewIsave(isave : ISave){
		if(isave){
			this.errorService.resetErrorResp();
			delete isave.$$index;
			this.isaveService.setISaveData(isave);
			this.router.navigate(['/viewiSaveAccount']);
		}		
	}
	/*
	* Close Isave Account
	*/
	closeIsave(isave : ISave){
		if(isave){
			this.closeIsaveRequest.iSaveAccountNumber = isave.isaveAccountIdentifier;
			this.closeIsaveRequest.nickName = isave.accountDescription;
			this.closeIsaveRequest.accountPurpose = isave.accountPurpose;
			this.closeIsaveModal.init();
			this.isaveService.setISaveData(isave);
			(<any>$('#close-isave')).modal('show');
		}
	}
	/*
	* Close Isave Account confirmation
	*/
	closeIsaveconfirmation(){
		this.spinnerService.startSpinner('closeIsave');
		this.isaveService.deleteIsave(this.closeIsaveRequest)
            .subscribe(
                resp => this.handleCloseIsave(resp),
                error => this.sharedService.handleError(error)
            );
	}

	handleCloseIsave(resp :any){
		this.spinnerService.stopSpinner('closeIsave');
		if(resp.result.status == 'success'){
            (<any>$('#close-isave')).modal('hide');
			(<any>$('#confirmCloseAccount')).modal('show');
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
	}
	/*
	* View Regular Savings Plan
	*/
	viewRegularSavingsPlan(regularSaving :RegularSaving){
		if(regularSaving){
			this.errorService.resetErrorResp();
			delete regularSaving.$$index;
			this.isaveService.setRegSavData(regularSaving);
			this.router.navigate(['/viewSavingsPlan']);
		}
	}
}