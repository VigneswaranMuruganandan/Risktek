import { Component, Input, Output, EventEmitter, ViewChild, OnInit } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {TemplateService} from '../../shared/services/template.service';
import { ErrorService} from '../../shared/services/error.service';

@Component({
  templateUrl: './../templates/isaveAccounts.html'
})
export class IsaveAccountsComponent implements OnInit {
	rows: any;
	regularSavings :any;
	@ViewChild('table') tableElem: any;

	constructor( public templateService: TemplateService,
				 private errorService: ErrorService) {}

	ngOnInit() {
		this.regularSavings = [{"id":"1","nickName":"Buy my Dream House","sourceNumber":"Savings Account (AED 28,856.00)","endDate":"30/08/17","amountSaved":"AED"},{"id":"2","nickName":"Buy my Dream House","sourceNumber":"Savings Account (AED 28,856.00)","endDate":"30/08/17","amountSaved":"AED"},{"id":"3","nickName":"Buy my Dream House","sourceNumber":"Savings Account (AED 28,856.00)","endDate":"30/08/17","amountSaved":"AED"},{"id":"4","nickName":"Buy my Dream House","sourceNumber":"Savings Account (AED 28,856.00)","endDate":"30/08/17","amountSaved":"AED"},{"id":"5","nickName":"Buy my Dream House","sourceNumber":"Savings Account (AED 28,856.00)","endDate":"30/08/17","amountSaved":"AED"},{"id":"6","nickName":"Buy my Dream House","sourceNumber":"Savings Account (AED 28,856.00)","endDate":"30/08/17","amountSaved":"AED"}];
		this.rows = [{"id":"1","nickName":"Buy my Dream House","accountNumber":"1234 2345 3456 4567","purposeofSavings":"Buy A House","currency":"AED","balance":"200,000.98"},{"id":"2","nickName":"Buy my Dream House","accountNumber":"1234 2345 3456 4567","purposeofSavings":"Buy A House","currency":"AED","balance":"200,000.98"},{"id":"3","nickName":"Buy my Dream House","accountNumber":"1234 2345 3456 4567","purposeofSavings":"Buy A House","currency":"AED","balance":"200,000.98"},{"id":"4","nickName":"Buy my Dream House","accountNumber":"1234 2345 3456 4567","purposeofSavings":"Buy A House","currency":"AED","balance":"200,000.98"},{"id":"5","nickName":"Buy my Dream House","accountNumber":"1234 2345 3456 4567","purposeofSavings":"Buy A House","currency":"AED","balance":"200,000.98"},{"id":"6","nickName":"Buy my Dream House","accountNumber":"1234 2345 3456 4567","purposeofSavings":"Buy A House","currency":"AED","balance":"200,000.98"},{"id":"7","nickName":"Buy my Dream House","accountNumber":"1234 2345 3456 4567","purposeofSavings":"Buy A House","currency":"AED","balance":"200,000.98"},{"id":"8","nickName":"Buy my Dream House","accountNumber":"1234 2345 3456 4567","purposeofSavings":"Buy A House","currency":"AED","balance":"200,000.98"},{"id":"9","nickName":"Buy my Dream House","accountNumber":"1234 2345 3456 4567","purposeofSavings":"Buy A House","currency":"AED","balance":"200,000.98"},{"id":"10","nickName":"Buy my Dream House","accountNumber":"1234 2345 3456 4567","purposeofSavings":"Buy A House","currency":"AED","balance":"200,000.98"},{"id":"11","nickName":"Buy my Dream House","accountNumber":"1234 2345 3456 4567","purposeofSavings":"Buy A House","currency":"AED","balance":"200,000.98"},{"id":"12","nickName":"Buy my Dream House","accountNumber":"1234 2345 3456 4567","purposeofSavings":"Buy A House","currency":"AED","balance":"200,000.98"},{"id":"13","nickName":"Buy my Dream House","accountNumber":"1234 2345 3456 4567","purposeofSavings":"Buy A House","currency":"AED","balance":"200,000.98"}];
		this.tableElem.offset = 0;
	}

	closeIsave(){
		(<any>$('#close-isave')).modal('show');
	}

	closeIsaveconfirmation(){
		(<any>$('#close-isave')).modal('hide');
		(<any>$('#confirmCloseAccount')).modal('show');
	}

	closeRegularSavingsPlan(){
		//(<any>$('#welcomeDashboard-1')).modal('hide');
	}
}



