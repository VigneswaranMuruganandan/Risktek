import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  templateUrl: './../templates/baseCreateSavingsPlan.html'
})
export class BaseCreateSavingsPlanComponent implements OnInit {
	public stepValue: number;
	
	ngOnInit() {
        this.stepValue = 1;
    }

    createSavingsPlanAccount(){
    	this.stepValue = 2;
    }

    submitSavingsPlan(){
    	this.stepValue = 3;
    }

    backSavingsPlan(value: number){
        this.stepValue = value;
    }
       
}