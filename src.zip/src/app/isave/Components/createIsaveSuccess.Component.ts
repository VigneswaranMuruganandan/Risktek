import { Component, OnInit, Input, Output, EventEmitter, ViewChild, OnDestroy } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ErrorService } from '../../shared/services/error.service';
import { SharedService } from '../../shared/services/shared.service';
import { SetupIsaveResponse } from '../model/setupIsaveResponse';
import { CreateIsaveRequest } from '../model/createIsaveRequest';
import { TemplateService } from '../../shared/services/template.service';
import { Product } from '../../shared/model/product';
import { CreateIsaveResponse } from '../model/createIsaveResponse';

@Component({
  selector: 'createIsaveSuccess-component',
  templateUrl: './../templates/createIsaveSuccess.html'
})
export class CreateIsaveSuccessComponent implements OnInit{
	@Input() createIsaveResponse :CreateIsaveResponse;
	@Input() setupIsaveResponse :SetupIsaveResponse;
	@Input() createIsaveRequest :CreateIsaveRequest;
	product :Product;
	
	constructor( private templateService: TemplateService,
				 private errorService: ErrorService) {}

	ngOnInit() {
		this.product = this.setupIsaveResponse.fundingSources[this.templateService.getSelectIndex(this.setupIsaveResponse.fundingSources,'prodRef',this.createIsaveRequest.sourceAccount)];
	}

}