import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {TemplateService} from '../../shared/services/template.service';
import { SpinnerService} from '../../shared/services/spinner.service';
import { ErrorService } from '../../shared/services/error.service';

@Component({
  selector: 'createIsaveSuccess-component',
  templateUrl: './../templates/createIsaveSuccess.html'
})
export class CreateIsaveSuccessComponent implements OnInit{

	constructor( private templateService: TemplateService,
				 private errorService: ErrorService,
				 private spinnerService: SpinnerService) {}

	ngOnInit() {
		//test
	}

}