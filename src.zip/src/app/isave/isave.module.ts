import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { routing } from './isave.routing';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '../shared/shared.module';
import { SharedService} from '../shared/services/shared.service';
import { TemplateService} from '../shared/services/template.service';
import { IsaveService} from './services/isave.service';
import { FormsModule } from '@angular/forms';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { IsaveWelcomeComponent } from './Components/isaveWelcome.component';
import { IsaveAccountsComponent } from './Components/isaveAccounts.Component';
import { BaseCreateIsaveComponent } from './Components/baseCreateIsave.Component';
import { CreateIsaveComponent } from './Components/createIsave.Component';
import { CreateIsaveReviewComponent } from './Components/createIsaveReview.Component';
import { CreateIsaveSuccessComponent } from './Components/createIsaveSuccess.Component';
import { EditIsaveComponent } from './Components/editIsave.Component';
import { ViewIsaveComponent } from './Components/viewIsave.Component';
import { BaseCreateSavingsPlanComponent } from './Components/baseCreateSavingsPlan.Component';
import { CreateSavingsPlanComponent } from './Components/createSavingsPlan.Component';
import { CreateSavingsPlanReviewComponent } from './Components/createSavingsPlanReview.Component';
import { CreateSavingsPlanSuccessComponent } from './Components/createSavingsPlanSuccess.Component';
import { EditSavingsPlanComponent } from './Components/editSavingsPlan.Component';
import { ViewSavingsPlanComponent } from './Components/viewSavingsPlan.Component';
import { CloseIsaveComponent } from './Components/closeIsave.Component';
import { CloseIsaveConfirmationComponent } from './Components/closeIsaveConfirmation.Component';

import {
  ValidateCreateIsave, 
  ValidateEditIsave, 
  ValidateCreateRegularSavings, 
  ValidateEditRegularSavings
} from './directives/validateisave.directive'


const ISAVE_COMPONENTS = [
    IsaveWelcomeComponent,
    IsaveAccountsComponent,
    BaseCreateIsaveComponent,
    BaseCreateSavingsPlanComponent,
    ViewIsaveComponent,
    ViewSavingsPlanComponent,
    CreateIsaveComponent,
    CreateIsaveReviewComponent,
    CreateIsaveSuccessComponent,
    EditIsaveComponent,
    CreateSavingsPlanComponent,
    CreateSavingsPlanReviewComponent,
    CreateSavingsPlanSuccessComponent,
    EditSavingsPlanComponent,
    CloseIsaveComponent,
    CloseIsaveConfirmationComponent
];

const ISAVE_DIRECTIVES = [
  ValidateCreateIsave, 
  ValidateEditIsave, 
  ValidateCreateRegularSavings, 
  ValidateEditRegularSavings
];

const ISAVE_PROVIDERS = [
   SharedService,
   TemplateService,
   IsaveService
];

@NgModule({
  	imports: [
	    routing,
	    TranslateModule.forChild(),
	    SharedModule,
	    FormsModule,
      CommonModule,
      NgxDatatableModule
	],
  	declarations: [
	    ...ISAVE_COMPONENTS/*,
      ...ISAVE_DIRECTIVES*/
	],
  	providers: [
  		...ISAVE_PROVIDERS
  	]
})
export class IsaveModule {}
