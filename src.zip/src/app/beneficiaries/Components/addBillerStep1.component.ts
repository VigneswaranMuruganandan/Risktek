import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { Router } from '@angular/router';
import { GlobalVariable} from '../../shared/services/global';
import { CreateBillerBeneRequest} from '../model/createBillerBeneRequest';
import {TemplateService} from '../../shared/services/template.service';
import { SetupForPaymentResponse} from '../model/setupForPaymentResponse';

@Component({
  selector: 'addBillerStep1-component',
  templateUrl: './../templates/addBillerStep1.html'
})
export class AddBillerStep1Component implements OnInit{

	@Input() billerTypes:any;
	@Input() createBillerBeneRequest:CreateBillerBeneRequest;
	@Input() setupForPaymentResponse:SetupForPaymentResponse;
	@Output() validateAddBillerFormEvent = new EventEmitter();
	public billerDescription:any;
	

	constructor( public templateService: TemplateService) {}

	ngOnInit() { 
    	this.billerDescription = GlobalVariable.BILLER_DESCRIPTION;
    	this.createBillerBeneRequest.agency=this.billerTypes[0].paymentTransferName;
    }

    datePicker(date :string){
    	this.createBillerBeneRequest.autoPayDate = date;
    }

	validateBillerForm(valid:boolean){
		if(valid){
            this.templateService.resetFormValidatorFlag();
            this.validateAddBillerFormEvent.emit();
        }  
		
	}
    
}
