import { Component, OnInit, Input} from '@angular/core';
import { Router } from '@angular/router';
import { CreateBillerBeneRequest} from '../model/createBillerBeneRequest';
import { CreateBillerBeneResponse} from '../model/createBillerBeneResponse';
import { GlobalVariable} from '../../shared/services/global';

@Component({
  selector: 'addBillerStep4-component',
  templateUrl: './../templates/addBillerStep4.html'
})
export class AddBillerStep4Component implements OnInit {
 	
 	public imageUrl:any;
 	
 	@Input() createBillerBeneRequest:CreateBillerBeneRequest;
 	@Input() createBillerBeneResponse:CreateBillerBeneResponse;

 	constructor( private router: Router) {}

 	ngOnInit() { 
	  this.imageUrl = GlobalVariable.IMAGE_URL;
	}

	backToAddPayment(){
		this.router.navigate(['/beneficiaries/addBiller']);
	}
    
    backToAddAutoPayment(){
		this.router.navigate(['/beneficiaries/addBiller']);
	}
}
