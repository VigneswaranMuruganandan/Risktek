import { Component, OnInit, Input} from '@angular/core';
import { Router } from '@angular/router';
import { BeneficiariesService} from '../services/beneficiaries.service';
import { SharedService} from '../../shared/services/shared.service';
import { TemplateService} from '../../shared/services/template.service';
import { BillerListResp} from '../model/billerListResp';
import { Biller} from '../model/biller';
import { ErrorService } from '../../shared/services/error.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { GlobalVariable} from '../../shared/services/global';
import * as $ from 'jquery';

@Component({
  selector: 'beneficiaries-payments',
  templateUrl: './../templates/beneficiariesPayments.html'
})
export class BeneficiariesPaymentsComponent implements OnInit{

	billerListResp:BillerListResp;
	biller:Biller
	transferTypes:any;
	temp: any = [];
	rows: any = [];

	constructor(private beneficiariesService:BeneficiariesService,
	          private sharedService: SharedService,
	          public templateService: TemplateService,
	          private errorService: ErrorService,
	          private spinnerService: SpinnerService,
	          private router: Router) {}

	ngOnInit() { 
	  this.spinnerService.startSpinner('loader');
	  this.getBillerList();
	  this.errorService.resetErrorResp();
	}

	getBillerList(){
      this.beneficiariesService.fetchBenePaymentList()
        .subscribe(
            resp => this.handleBenePaymentResp(resp),
            error => this.sharedService.handleError(error)
        );
  }

	handleBenePaymentResp(resp:BillerListResp){
	  this.spinnerService.stopSpinner('loader');
	  if (resp.result.status == "success") {
	      this.billerListResp = new BillerListResp();
	      this.billerListResp = resp;
	      //this.initTableData(resp);
	  }else if (resp.result.status == 'error') {
	      this.errorService.setErrorResp(resp.result);
	  }
	}

}