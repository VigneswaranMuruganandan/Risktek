import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'outsideUAEAddBeneStep1-component',
  templateUrl: './../templates/outsideUAEAddBeneStep1.html'
})
export class OutsideUAEAddBeneStep1Component {

	@Output() validateBeneFormNextButtonEvent = new EventEmitter();

	validateBeneForm(event){
		this.validateBeneFormNextButtonEvent.emit();
	}
    
    
}
