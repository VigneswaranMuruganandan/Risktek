import { Component, OnInit, Input} from '@angular/core';
import { SharedService} from '../../shared/services/shared.service';
import { ErrorService } from '../../shared/services/error.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { GlobalVariable} from '../../shared/services/global';
import { BeneficiariesService} from '../services/beneficiaries.service';
import {CreateBeneficiaryRequest} from '../model/createBeneficiaryRequest';
import {CreateBeneficiaryResponse} from '../model/createBeneficiaryResponse';
import { SendOtpRequest} from '../../shared/model/sendOtpRequest';
import { SendOtpResponse} from '../../shared/model/sendOtpResponse';

@Component({
  templateUrl: './../templates/withinUAEAddBene.html'
})
export class WithinUAEAddBeneComponent implements OnInit{

  public stepValue: number;
  public sendOtpRequest:SendOtpRequest;
  public sendOtpResponse:SendOtpResponse;
  createBeneficiaryRequest:CreateBeneficiaryRequest;
  createBeneficiaryResponse:CreateBeneficiaryResponse;

  constructor(private beneficiariesService:BeneficiariesService,
              private sharedService: SharedService,
              private errorService: ErrorService,
              private spinnerService: SpinnerService){}

    ngOnInit() { 
        this.stepValue = 1;
        this.createBeneficiaryRequest = new CreateBeneficiaryRequest();
        this.errorService.resetErrorResp();
    }

    validateFormNextButton(){
    	this.stepValue = 2;
    }

    confirmReviewButton(){
      this.errorService.resetErrorResp();
      this.spinnerService.startSpinner('loader');
      this.sendOtpRequest = new SendOtpRequest();
      this.sendOtpRequest.txnCode = GlobalVariable.TRANSACTION_CODES.BENEF_ADD_WITHIN_UAE_FUNDS_TRANSFER;
      this.sharedService.sendOTP(this.sendOtpRequest)
        .subscribe(
            resp => this.handleSendOTPResp(resp),
            error => this.sharedService.handleError(error)
        );
    }

    handleSendOTPResp(resp:SendOtpResponse){
      this.spinnerService.stopSpinner('loader');
      if (resp.result.status == "success") {
          this.sendOtpResponse = new SendOtpResponse();
          this.sendOtpResponse = resp;
          this.stepValue = 3;
      }else if (resp.result.status == 'error') {
          this.errorService.setErrorResp(resp.result);
      }
    }

    backReviewButton(){
        this.stepValue = 1;
    }

    validateOTP(){
      this.errorService.resetErrorResp();
      this.spinnerService.startSpinner('loader');
      this.beneficiariesService.createBeneficiary(this.createBeneficiaryRequest)
        .subscribe(
            resp => this.handleAddBeneResp(resp),
            error => this.sharedService.handleError(error)
        );
    }

    handleAddBeneResp(resp:CreateBeneficiaryResponse){
      this.spinnerService.stopSpinner('loader');
      if (resp.result.status == "success") {
          this.createBeneficiaryResponse = new CreateBeneficiaryResponse();
          this.createBeneficiaryResponse = resp;
          this.stepValue = 4;
      }else if (resp.result.status == 'error') {
          this.errorService.setErrorResp(resp.result);
      }
    }


    backOTPButton(){
        this.stepValue = 2;
    }
    

   
    
}
