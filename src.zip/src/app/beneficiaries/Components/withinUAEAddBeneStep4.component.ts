import { Component, OnInit, Input} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'withinUAEAddBeneStep4-component',
  templateUrl: './../templates/withinUAEAddBeneStep4.html'
})
export class WithinUAEAddBeneStep4Component {
 
    
}
