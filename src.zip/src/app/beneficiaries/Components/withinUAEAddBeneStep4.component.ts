import { Component, OnInit, Input} from '@angular/core';
import { Router } from '@angular/router';
import {CreateBeneficiaryRequest} from '../model/createBeneficiaryRequest';
import {CreateBeneficiaryResponse} from '../model/createBeneficiaryResponse';

@Component({
  selector: 'withinUAEAddBeneStep4-component',
  templateUrl: './../templates/withinUAEAddBeneStep4.html'
})
export class WithinUAEAddBeneStep4Component {
 	
 	@Input() createBeneficiaryRequest:CreateBeneficiaryRequest;
	@Input() createBeneficiaryResponse:CreateBeneficiaryResponse;
    
}
