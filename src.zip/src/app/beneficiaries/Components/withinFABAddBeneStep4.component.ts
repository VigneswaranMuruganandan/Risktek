import { Component, OnInit, Input} from '@angular/core';
import { Router } from '@angular/router';
import {CreateBeneficiaryRequest} from '../model/createBeneficiaryRequest';
import {CreateBeneficiaryResponse} from '../model/createBeneficiaryResponse';

@Component({
  selector: 'withinFABAddBeneStep4-component',
  templateUrl: './../templates/withinFABAddBeneStep4.html'
})
export class WithinFABAddBeneStep4Component {

	@Input() createBeneficiaryRequest:CreateBeneficiaryRequest;
	@Input() createBeneficiaryResponse:CreateBeneficiaryResponse;

    
}
