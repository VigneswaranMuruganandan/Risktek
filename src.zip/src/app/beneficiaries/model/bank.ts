
export class Bank{
	
  bankName:string;
  bankCode:string;

}

