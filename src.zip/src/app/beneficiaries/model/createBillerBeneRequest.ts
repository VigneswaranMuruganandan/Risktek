
export class CreateBillerBeneRequest{
	authKey:string;
	txnRef:string;
    agency:string;
    consumerNo:string;
    salikPinNo:string
    nickName:string;
    autopayEnabled:boolean;
    accountOrCardNo:string;
    autoPayDate:string;
    autoPayAmount:string;
}

