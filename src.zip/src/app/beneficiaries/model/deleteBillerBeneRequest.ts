
export class DeleteBillerBeneRequest{
	nickName:string;
}

