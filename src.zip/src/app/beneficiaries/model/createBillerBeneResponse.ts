import {APIResponse} from '../../shared/model/apiResponse';

export class CreateBillerBeneResponse extends APIResponse{

  	

}

