import { Directive, ElementRef, Output, EventEmitter, Input} from '@angular/core';
import * as $ from 'jquery';
import 'app/assets/js/jquery-ui.min.js';

@Directive({
    selector: '[datePicker]'
})
export class DatePicker {
    constructor(private el: ElementRef) {}

    ngOnInit() {}

    ngAfterViewInit() {
        let dateFormat = "dd/mm/yy",
            from = ( < any > $("#from"))
            .datepicker({
                //defaultDate: "+1w",
                maxDate: "+0D" ,
                dateFormat: 'dd/mm/yy'
                // changeMonth: true,
                // showButtonPanel: true
               // numberOfMonths: 3
            })
            .on("change", function() {
                to.datepicker("option", "minDate", getDate(this));
                $('#dateButton').trigger( "click" );

            }),
            to = ( < any > $("#to")).datepicker({
                //defaultDate: "+1w",
                maxDate: "+0D" ,
                dateFormat: 'dd/mm/yy'
                // changeMonth: true,
                // showButtonPanel: true
                // numberOfMonths: 3
            })
            .on("change", function() {
                from.datepicker("option", "maxDate", getDate(this));
                 $('#dateButton').trigger( "click" );
            });

        function getDate(element: any) {
            var date;
            try {
                date = ( < any > $).datepicker.parseDate(dateFormat, element.value);
            } catch (error) {
                date = null;
            }
            return date;
        }
    }
}

@Directive({
    selector: '[singleDatePicker]'
})
export class SingleDatePicker {
    @Output() datePickerEvent = new EventEmitter();

    constructor(private el: ElementRef) {}

    ngAfterViewInit() {
        let el = (<any>$(this.el.nativeElement));
        el.datepicker({
          changeMonth: true,
          changeYear: true,
          minDate: "+0D",
          dateFormat: 'dd/mm/yy'
        }).on('change', e => {
            this.datePickerEvent.emit(e.target.value);
        });
    }
}

@Directive({
    selector: '[datePickerGroup]'
})
export class DatePickerGroup {
    @Output() datePickerGroupEvent = new EventEmitter();
    datePickerGroup :string = "dd/mm/yy";
    @Input() startDateOption :any ; 
    @Input() endDateOption :any ;


    constructor(private el: ElementRef) {}

    ngAfterViewInit() {        
        let startDate = (<any>$("input[name*='startDate']"))
            .datepicker(this.startDateOption)
            .on("change", e => {
                console.log("calling");
                endDate.datepicker("option", "minDate", this.getDate(e.target.value));
                this.datePickerGroupEvent.emit({ event:e.target.value, type: 'startDate'});


            }),
        endDate = (<any>$("input[name*='endDate']"))
            .datepicker(this.startDateOption)
            .on("change", e => {
                console.log("calling");
                startDate.datepicker("option", "maxDate", this.getDate(e.target.value));
                this.datePickerGroupEvent.emit({ event:e.target.value, type: 'endDate'});
            });
    }
    getDate(value: any){
        let date;
        try {
            date = (<any>$).datepicker.parseDate(this.datePickerGroup, value);
        } catch (error) {
            date = null;
        }
        return date;
    }
}