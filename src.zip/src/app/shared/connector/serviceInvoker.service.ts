import { Injectable } from '@angular/core';
import { Http, Response, Headers , URLSearchParams, RequestOptions,ResponseContentType} from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/catch';
import {AppSession} from '../model/appSession';
import {SessionContext} from '../model/sessionContext';
import {StubResponse} from './stubResponse';
import {EncryptionService} from '../services/encryption.service';
import {GlobalURL} from '../services/globalURL';
import * as CryptoJS from 'crypto-js';


@Injectable()
export class ServiceInvoker {
    private apiUrl = GlobalURL.SERVICE_URL.SHARED.API_URL; 
    private apiUrl_Download = GlobalURL.SERVICE_URL.SHARED.API_URL_DOWNLOAD;
    private stubEnabled = GlobalURL.PROPERTIES.STUBS;
    private encServ: EncryptionService = null;

    constructor( private http: Http, 
                 private encryptionService: EncryptionService) {
        this.encServ = encryptionService;
    }

    invoke(op: string, data: any): Observable < any > {
        console.log("executing " + op + " with data " + data);
        let invResult = this.getHttpReq(op, data)
            .map(res => this.extractData(res, this.encryptionService))
            .catch(this.handleError);
        return invResult;
    }

    invokeDownLoad(op: string, data: any): Observable < any > {
        console.log("executing " + op + " with data " + data);
        let invResult = this.getHttpReqWithoutEncryp(op, data)
            .map(res => {return res})
            .catch(this.handleError);
        return invResult;
    }


    getHttpReqWithoutEncryp(op: string, data: any){
        var headers = this.prepareHeaders(op);
        const options = new RequestOptions({
            headers: headers
        });
        options.responseType= ResponseContentType.Blob;
        const body: URLSearchParams = new URLSearchParams();
        let req ="";
        if (data != null) {
            req = JSON.stringify(data);
            console.log("without enc req sent: " + req + " " + this.apiUrl_Download);
            body.set('request', req);
        }
        return this.http.post(this.apiUrl_Download, req, options);  
    }

    private getHttpReq(op: string, data: any) {
        var headers = this.prepareHeaders(op);
        var sessCtx = SessionContext.getInstance();
        const options = new RequestOptions({
            headers: headers
        });
        const body: URLSearchParams = new URLSearchParams();
        var encReq = '';
        if (data != null) {
            const req = JSON.stringify(data);
            if (sessCtx.authKey == null) {
                console.log("encoding req..." + req);
                let words = this.encryptionService.getEncodedKey(req);
                encReq = this.encryptionService.convertToBase64(words);
            } else {
                console.log("encryt req...");
                let key = sessCtx.authKey.encKey;
                let iv = sessCtx.authKey.encIV;
                SessionContext.incrementCounter();
                console.log('eventCtr getHttpReq' + sessCtx.authKey.ec);
                encReq = this.encryptionService.encrypt(req, key, iv);
            }
            console.log("enc req sent: " + encReq + " " + this.apiUrl);
            body.set('request', encReq);
        }
        return this.http.post(this.apiUrl, encReq, options);  
    }

     private extractData(res: Response, encServ: EncryptionService) {
        console.log("extracting data " + res);
        let body = res.text();
        console.log("enc serv " + encServ);
        console.log("body " + body);
        var sessCtx = SessionContext.getInstance();
        var jsonResp = "";
        if (sessCtx.authKey == null) {
            console.log("decoding resp..." + encServ);
            jsonResp = atob(body);
            console.log("decoded jsonResp  " + jsonResp);
        } else {
            console.log("decr req...");
            let key = sessCtx.authKey.encKey;
            let iv = sessCtx.authKey.encIV;
            jsonResp = encServ.decrypt(body, key, iv);
            console.log('afer decrypt ' + jsonResp);
        }
        return jsonResp;
    }

    private prepareHeaders(op: string): Headers{
        let headers = new Headers();
        var date = this.getTodaysDate();
        headers.append('Content-type', 'text/plain');
        headers.append('Accept', 'application/json');
        headers.append('op', op);
        headers.append('d', date);
        headers.append('dv', "b");
        headers.append('rc', this.createGuid());
        var sessCtx = SessionContext.getInstance();
        if (sessCtx.authKey != null) {
            headers.append('Authorization', sessCtx.authKey.convID + this.generateHMAC(date));
        }
        return headers;
    }

    private createGuid(): string {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            var r = Math.random() * 16 | 0,
                v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }

    private handleError(error: Response | any) {
        console.log("in error " + error);
        let errMsg: string;
        if (error instanceof Response) {
            const body = error.json() || '';
            const err = body.error || JSON.stringify(body);
            errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
        } else {
            errMsg = error.message ? error.message : error.toString();
        }
        console.error(errMsg);
        return Observable.throw(errMsg);
    }

    private getTodaysDate(): string {
        var d = new Date();
        var datestring = ("0"+d.getDate()).slice(-2)+("0"+(d.getMonth()+1)).slice(-2)+d.getFullYear()+("0"+d.getHours()).slice(-2)+("0" + d.getMinutes()).slice(-2);
        return datestring
    }

   private generateHMAC(date :string): string{
        var sessCtx = SessionContext.getInstance();
        var macKey = sessCtx.authKey.macKey;
        var counter = sessCtx.authKey.ec;
        var inputMessage = sessCtx.deviceID +date+counter; 
        var hash = CryptoJS.HmacSHA256(inputMessage, macKey).toString(CryptoJS.enc.Hex);
        return hash;
    }
}