import { Component } from '@angular/core';
import { GlobalVariable} from '../../shared/services/global';
import {TranslateService} from '@ngx-translate/core';
import jsPDF from 'jspdf';

@Component({
  selector: 'download-pdf',
  template: '<a href="javascript:void(0);" class="button border-only btn-md btn-blue" (click)="downloadPDF();">SAVE AS PDF</a>'
})
export class DownloadPDFComponent {
	downloadPDF(){
 		let parent_el = (<any>$('.printArea'));
 		let source = '';
 		for(let el of parent_el){
	        let header = (<any>$(el)).find('.col-md-3 h3');
	        source = source + "<h3>"+header.text()+"<h3>";

	        let child_el = (<any>$(el)).find('.col-md-9 p');
	        if(child_el.length > 0){
		        source = source + "<table width='100%'><tbody>";
		        source = source + "<tr><td>Title</td><td>Description</td></tr>";
		        for(let cel of child_el){	        	
		        	source = source + "<tr>";
		        	let label = (<any>$(cel)).clone().children().remove().end();
		        	source = source + "<td>"+label.text().trim()+"</td>";
		        	let value = (<any>$(cel)).find('span');
		        	source = source + "<td>"+value.text().trim()+"</td>";
		        	source = source + "</tr>";
		        }
		        source = source + "</tbody></table>";
	    	}
	    }
	    console.log(source);

		var pdf = new jsPDF('p', 'pt', 'letter');
		var source1 = source;
		var specialElementHandlers = {
		    '#bypassme': function(element, renderer) {
		        return true
		    }
		};
		var margins = {
		    top: 80,
		    bottom: 60,
		    left: 40,
		    width: 522
		};
		pdf.fromHTML(
		    source1,
		    margins.left,
		    margins.top, {
		        'width': margins.width,
		        'elementHandlers': specialElementHandlers
		    },
		    function(dispose) {
		        pdf.save(GlobalVariable.DOWNLOAD_FILE_NAME);
		    }, margins);
 	}	
}