export class ServerError {
	backButton: BackButton;
	errorDetails: ErrorDetails;
	errorDescription :string;
}

export class BackButton {
	text :string;
	router :string;
}

export class ErrorDetails {
	param1 :string;
	param2 :string;
	param3 :string;
}