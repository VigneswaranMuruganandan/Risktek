
export class SendOtpRequest {
	txnCode:string;
	txnRef:string;
}