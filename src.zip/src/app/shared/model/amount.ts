export class Amount{
    value :number;
	valueFmt:string;
	currency:string;
}