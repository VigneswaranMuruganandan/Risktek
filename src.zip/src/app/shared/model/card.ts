import { Amount } from './amount';

export class Card{
   	cardNumber : string;
	cardHolderName : string;
	cardType : string;
	status : string;
	ownerType : string;
	cardLimit : Amount;
	availableCashWithdrawalLimit : Amount;
	availableBalance : Amount;
	currentTotalOutstanding : Amount;
	outstandingBalance : Amount;
	minimumPaymentDue : Amount;
	paymentDueDate : string;
	nextStatementDate : string;
	firstPoints : string;
	firstMiles : string;
	greenPoints : string;
	greenContributionAmount : Amount;
	currency : string;
	nickName : string;
	displaySequence : string;
	isFavorite : boolean;
	availableBalancePercentage: string;
}