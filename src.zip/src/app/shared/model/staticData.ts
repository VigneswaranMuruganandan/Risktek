export class StaticData {
            shortCode:string;
            description:string;
            entityCode:string;
    sortingOrder:number;
}