export class NameObject {
  Id :number;
  Name :string;
  NameAR :string;
  GeoPoint :string;
}