import { BeneficiaryCountMap } from '../../dashboard/model/beneficiaryCountMap';
import { BillerCountMap } from '../../dashboard/model/billerCountMap';
import { PaymentTypes } from '../../dashboard/model/paymentTypes';
import { TransferTypes } from '../../dashboard/model/transferTypes';


export class AppSession{
    private static _instance:AppSession;

    lastSucessLoginTime: string;
    lastFailedLoginTime: string;
    hasFavorites: string;
    dashboardAccount:string;
    accountOfferMerchant:string;
    newcustomer : string;
    auth2Factor: string;
    beneficiaryCountMap : BeneficiaryCountMap[];
    billerCountMap : BillerCountMap[];
    paymentTypes : PaymentTypes[];
    transferTypes : TransferTypes[];
    productsOwned: any;

    public static getInstance():AppSession{
        return AppSession._instance||(AppSession._instance = new AppSession());
    };
}