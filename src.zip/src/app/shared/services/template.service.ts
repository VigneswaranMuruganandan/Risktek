import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import * as $ from 'jquery';
import {GlobalVariable} from './global';
import { Amount } from '../model/amount';

@Injectable()
export class TemplateService{
  validFormFlag : boolean;
  errorFlag : boolean;
  serviceErrorMessage : any;
  action : string;
  beneAddType:string;
  
  constructor(private http : Http){
    this.validFormFlag = false;
    this.errorFlag = true;
    this.serviceErrorMessage = {"flag":"true","message":""}; 
  }

  /* Setting the Flag for form validation */
  setFormValidatorFlag(flag: boolean){
    this.validFormFlag = flag;
  }

  /* Setting the Flag for form validation */
  resetFormValidatorFlag(){
    this.validFormFlag = false;
  }

  /* Setting the Flag for form validation */
  setErrorFlag(flag: boolean){
    this.errorFlag = flag;
  }

  /* Setting the Flag for form validation */
  resetErrorFlag(){
    this.errorFlag = false;
  }

  /* Setting the Flag for Beneficary ADD Type */
  setBeneAddType(type:string){
    this.beneAddType = type;
  }

  getServiceError(){
    return this.serviceErrorMessage;
  }

  setServiceError(flag: boolean, message: string){
    this.serviceErrorMessage = {"flag": flag ,"message": message}; 
  }

  setAction(value: string){
    this.action = value;
  }

  getAction(){
    return this.action;
  }

  /* Getting the Image source*/
  getImageURL(id:string){
    return 'app/assets/images/'+GlobalVariable.IMAGE_URL[id];
  }

  calAvailBalPercentage(availableBalance :number,cardLimit :number){
    let value = Math.round((availableBalance/cardLimit)*100)+"%";
    return value;
  }

  /* Checking the Menu status to 
  make the alignment for Navigation bar*/
  checkMenuState(){
    /*if( $( '.hamburger').hasClass( "animate" ) ){
      if ($(window).width() >= 960) {
         $('.main').addClass('push');
      }
      $('.sidebar').css('left','0');
    }else{
      $('.main').removeClass('push');
      $('.sidebar').css('left','-300px');
    }*/

    if( $( '.hamburger').hasClass( "animate" ) ){
    if ($(window).width() <= 991) {
       $('.main').addClass('mobile-menu');
    }
    $('.sidebar').addClass('push-sidebar');
    }else{
      $('.main').removeClass('mobile-menu');
      $('.sidebar').removeClass('push-sidebar');
    }
    if( $( '.arabic-design .hamburger').hasClass( "animate" ) ){
      if ($(window).width() <= 991) {
        $('.arabic-design .main').addClass('mobile-menu');
      }
      $('.arabic-design .sidebar').css('right','0');
    }else{
      $('.arabic-design .main').removeClass('mobile-menu');
      $('.arabic-design .sidebar').css({'right':'-100%'});
    }

  }

  /* Show or hide menu */
  showHideMenu(){
    /*if ($(window).width() < 959) {
       $('.hamburger').removeClass('animate');
    }
    else {
       $('.hamburger').addClass('animate');
    }*/
    if ($(window).width() < 991) {
     $('.hamburger').removeClass('animate');
    }
    else {
       $('.hamburger').addClass('animate');
    }
    if ($(window).width() < 991) {
      $('.arabic-design .hamburger').removeClass('animate');
    }
    else {
      $('.arabic-design .hamburger').addClass('animate');
    }
  }
    
}