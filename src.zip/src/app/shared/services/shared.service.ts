import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { Subject } from 'rxjs/Subject';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import 'rxjs/add/operator/toPromise';
import { AppSession} from '../model/appSession';
import { APIResponse} from '../model/apiResponse';
import { AuthRequest} from '../../register/model/authRequest';
import { VerifyCustomerResponse} from '../../register/model/verifyCustomerResponse';
import { RegisterPwdResponse} from '../../register/model/registerPwdResponse';
import { SendOtpRequest} from '../model/sendOtpRequest';
import { SendOtpResponse} from '../model/sendOtpResponse';
import { VerifyOtpResponse} from '../model/verifyOtpResponse';
import { ResendOtpResponse} from '../../register/model/resendOtpResponse';
import { AuthKey} from '../model/authKey';
import { AuthData} from '../model/authData';
import { UserDetails} from '../model/userDetails';
import { ServiceInvoker} from '../connector/serviceInvoker.service';
import { SpinnerService} from './spinner.service';
import { EncryptionService} from '../services/encryption.service';
import { SessionContext} from '../model/sessionContext';
import { UserContext} from '../model/userContext';
import { GlobalURL} from '../services/globalURL';
import { GlobalVariable} from './global';
import { StaticDataResponse } from '../../shared/model/staticDataResponse';
import { Entity } from '../model/entity';
import { LeadRequest } from '../../investments/model/leadRequest';
import { LeadResponse } from '../../investments/model/leadResponse';
import { Categories } from '../../offers/model/categories';
import { UpdateFavoritesProduct } from '../../dashboard/model/UpdateFavoritesProduct';

@Injectable()
export class SharedService {
    public otp_timer = new Subject<string>();
    public $timer = this.otp_timer.asObservable();

    constructor( private serviceInvoker: ServiceInvoker,
                 private spinnerService: SpinnerService,
                 private encryptionService: EncryptionService) {}

    registerDevice(authRequest: AuthRequest): Observable < AuthData > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.REGISTRATION.REGISTERDEVICE, authRequest)
            .map(resp => this.populateAuthReq(resp, authRequest));
    }

    resendOTP(): Observable < VerifyOtpResponse > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.REGISTRATION.RESENDOTP, null)
                                  .map(resp => JSON.parse(resp));
    }

    logout(authRequest: AuthRequest): Observable < AuthData > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.LOGIN.LOGOUT, authRequest)
                                  .map(resp => JSON.parse(resp));
    }
    
    fetchStaticData(data: Entity): Observable < StaticDataResponse > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.SHARED.STATICDATA, data)
                                  .map(resp => JSON.parse(resp));
    }

    saveLead(data: LeadRequest): Observable < LeadResponse > {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.INVESTMENTS.APPLY_NOW, data)
                                .map(resp => JSON.parse(resp));
    }

    multipleLoginSession(): Observable < APIResponse > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.LOGIN.MULTILGNVERIFY, null)
                                  .map(resp => JSON.parse(resp));
    }

    fetchCategories() : Observable < Categories >{
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.OFFERS.CATEGORIES, null)
                                  .map(resp => JSON.parse(resp));
    }

    unFavouriteProduct(data: UpdateFavoritesProduct) : Observable < any >{
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.DASHBOARD.UN_FAVOURITIE, data)
                                  .map(resp => JSON.parse(resp));
    }
	
    fetchATMBranch() : Observable < any >{
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.DASHBOARD.ATMBRANCH, null)
                                  .map(resp => JSON.parse(resp));
    }
    
    sendOTP(data: SendOtpRequest): Observable < SendOtpResponse >{
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.OTP.SEND_TRAN_OTP, data)
                                  .map(resp => JSON.parse(resp));
    }

    private populateAuthReq(resp: string, authRequest: AuthRequest) {
        var authData = new AuthData();
        let respObj = JSON.parse(resp);
        console.log("result " + respObj.result.status);
        if (respObj.result.status == 'success') {
            authData.authKey = new AuthKey();
            authData.authKey.encIV = respObj.data.encIV;
            authData.authKey.encKey = respObj.data.encKey;
            authData.authKey.convID = respObj.data.convID;
            authData.authKey.macKey = respObj.data.macKey;
            authData.authKey.ec = respObj.data.eventCtr;
            console.log("convid " + authData.authKey.convID);
            var sessCtx = SessionContext.getInstance();
            sessCtx.authKey = authData.authKey;
            sessCtx.deviceID = authRequest.deviceID;
        }
        return authData;
    }

    setupAuthKeys() {
        let data = new AuthRequest();
        let sessCtx = SessionContext.getInstance();
        let jsonResp = "";
        if (sessCtx.authKey == null) {
            data.deviceID = "br_" + this.createGuid();
            console.log("in constructor dev id " + data.deviceID);
        }
        return data;
    }

    createGuid(): string {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            var r = Math.random() * 16 | 0,
                v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }

    updateUserContext(data: UserDetails){ 
        if(data && !data.email){
            data['email'] = '';
            data['unmaskedEmail'] = '';
        }
        let userCtx = UserContext.getInstance();
        userCtx.userDetails = new UserDetails();
    	let temp =  Object.getOwnPropertyNames(data)
    				.map((key: string) => {    					
    					userCtx.userDetails[key] = data[key];
    				});	
    }

    updateTimer(timer: string){
        this.otp_timer.next(timer);
    }

    updateSessionContext(respObj: any){
    	if (respObj.result.status == 'success') {
            // Update the Appsession Context value
            let AppSess = AppSession.getInstance();
            AppSess.lastSucessLoginTime = respObj.lastSucessLoginTime;
            AppSess.lastFailedLoginTime = respObj.lastFailedLoginTime;
            AppSess.hasFavorites = respObj.hasFavorites;
            this.updatedashboardTemplate(respObj);
            // Update the User Context value
            if(respObj.userDetails){
              this.updateUserContext(respObj.userDetails);      
            }
            let authData = new AuthData();
            authData.authKey = new AuthKey();
            authData.authKey.encIV = respObj.data.encIV;
            authData.authKey.encKey = respObj.data.encKey;
            authData.authKey.convID = respObj.data.convID;
            authData.authKey.macKey = respObj.data.macKey;
            authData.authKey.ec = respObj.data.eventCtr;
            authData.authKey.sessionType = respObj.data.sessionType;
            let sessCtx = SessionContext.getInstance();
            sessCtx.authKey = authData.authKey;
        }
    }
    /*
    * Update Dashboard Billers and Transfer Template
    */
    updatedashboardTemplate(respObj: any){
        let AppSess = AppSession.getInstance();
        AppSess.beneficiaryCountMap = respObj.beneficiaryCountMap;  
        AppSess.billerCountMap = respObj.billerCountMap; 
        AppSess.paymentTypes = respObj.paymentTypes; 
        AppSess.transferTypes = respObj.transferTypes;
    }
    
    handleError(error: any){
        this.spinnerService.stopSpinner('loader');
        console.log('handleVerifyCustIDError ' + error);
    }
}