export const GlobalURL = Object.freeze({
    SERVICE_URL: {
        REGISTRATION: {
            REGISTERDEVICE: "/registration/device/register",
            VERIFYCUSTOMER: "/registration/customer/verify",
            VERIFYOTP: "/registration/otp/verify",
            RESENDOTP: "/registration/otp/resend",
            VERIFYUSERNAME: "/registration/uname/verify",
            REGISTERPASSWORD: "/registration/pwd/register",
            SAVETNC:"/registration/tnc/save"
            
        },
        LOGIN: {
             VERIFYLOGIN: "/accesscontrol/cred/verify",
             AUTHENTICATIONMETHOD: "/registration/auth2/update",
             VERIFYCUSTOMERID:"/registration/customer/id/verify",
             MULTILGNVERIFY:"/accesscontrol/multi/login/verify",
             LOGOUT: "/accesscontrol/cred/logout"
        },
        FORGOT_PASSWORD: {
             RESETPASSWORD:"/accesscontrol/cred/reset",
             VERIFYPASSWORD: "/authcred/pwd/verify",
             VERIFYOTPCRED:"/authcred/otp/cred/verify",             
             CUST_PWDRECOVERY:"/registration/customer/pwdrecovery"
        },
        DASHBOARD: {
            DASHBOARD_DETAILS: "/cust/dashboard",
            ALL_PRODUCTS: "/pref/products/fetch",
            SAVE_FAVOURITIES: "/pref/products/update",
            UN_FAVOURITIE: "/pref/prodfavstate/update",
            UPDATE_ALL_FAVOURITIES: "/pref/update/all/favourite",
            ATMBRANCH: "/bnk/atmbranch/fetch"
        },
        SHARED: {
            //PROXY
            //API_URL: "../PersonalBankingWeb/rest/api",
            //API_URL_DOWNLOAD: "../PersonalBankingWeb/rest/api/content/",
            //LOCAL
            //API_URL: "http://localhost:9080/PersonalBankingAPI/pbapp/",
            //API_URL_DOWNLOAD: "http://localhost:9080/PersonalBankingAPI/content/",
            //BUILD
            //API_URL: "http://172.20.238.125:9081/PersonalBankingAPI/pbapp/",
            //API_URL_DOWNLOAD: "http://172.20.238.125:9081/PersonalBankingAPI/content/",
            //DEV
            API_URL: "http://172.20.238.125:9080/PersonalBankingAPI/pbapp/",
            API_URL_DOWNLOAD: "http://172.20.238.125:9080/PersonalBankingAPI/content/",
            //SIT
            //API_URL: "http://172.20.223.91:9080/PersonalBankingAPI/pbapp/", 
            //API_URL_DOWNLOAD: "http://172.20.223.91:9080/PersonalBankingAPI/content/",  
            //SIT HTTPS
            //API_URL: "https://172.20.223.91:9443/PersonalBankingAPI/pbapp/", 
            //API_URL_DOWNLOAD: "https://172.20.223.91:9443/PersonalBankingAPI/content/",   
            //Ashu
            //API_URL: "http://10.230.9.41:9080/PersonalBankingAPI/pbapp/",
            //API_URL_DOWNLOAD: "http://10.230.9.41:9080/PersonalBankingAPI/content/",
            ATM_BRANCH_LOCATIONS: "https://www.fgbgroup.com/fgb-group/about-fgb/branch-locator",
            STATICDATA:"/bnk/data"
        },
        ACCOUNTS: {
            CUSTOMERACCOUNTS: "/account/custpos/fetch",
            ACCOUNTDETAIL: "/account/detail/fetch",
            ACCOUNT_TRANSACTIONS:"/account/txn/history",
            FT_DETAIL:"/account/ft/detail",
            POS_TRANSACTIONS:"/account/unbilledpos",
            DOWNLOAD_ACCOUNT_ESTATEMENT:"/statement/accountstatement",
            DOWNLOAD_ACCOUNT_TRANSACTIONS:"/statement/accounthistory"
        },
        CARDS:{
            FETCH_DEBIT_CARDS:"/card/debit/fetch",
            ACTIVATE:"/card/activate",
            PIN_RESET:"/card/pin/reset",
            BLOCK:"/card/block",
            REPLACE_DEBIT_CARD:"/card/debit/replacement"
        },
        ISAVE: {
            SETUP_ISAVE: "/isave/setupcreate",
            ISAVE_LIST: "/isave/fetch",
            ISAVE_CREATE: "/isave/create",
            ISAVE_UPDATE: "/isave/update",
            ISAVE_CLOSE: "/isave/close",
            SETUP_REGULAR_SAVINGS: "/isave/regsaving/setup",
            REGULAR_SAVINGS_LIST: "/isave/regsaving/fetch",
            REGULAR_SAVINGS_CREATE: "/isave/regsaving/create",
            REGULAR_SAVINGS_UPDATE: "/isave/regsaving/modify",
            REGULAR_SAVINGS_CLOSE: "/isave/close"
        },
        ACCOUNTSETTINGS: {
            UPDATENICKNAME: "/pref/update/nickname/fav",
            UPDATEEMAILID: "/pref/email/update",
            ACTIVATEESTATEMENT:"/pref/estmt/activate",
            DEACTIVATEESTATEMENT:"/pref/estmt/deactivate" ,
            ALERTS_PREFERENCE_FETCH:"/pref/alerts/fetch",
            ALERTS_PREFERENCE_UPDATE:"/pref/alerts/activity/update",
            GET_ALERTS_HISTORY:"/pref/alerts/history"
        },
        LOANS: {
            FETCH_LOAN_DETAILS : "/loan/detail/fetch",
            FETCH_LOANS_LISTS : "/loan/alldetail/fetch",
            SETUP_LOAN_DEFERRAL: "/loan/setup/deferral",
            SAVE_LOAN_DEFERRAL: "/loan/deferral"
        },
        INVESTMENTS: {
            VIEW_PRODUCTS: "/bnk/data",
            APPLY_NOW:"/lead/apply",
            ASSET_ALLOCATION:"/wealth/assetallocation",
            PRODUCT_ALLOCATION:"/wealth/productallocation",
            SECURITY_HOLDING:"/wealth/securityholding",
            PENDING_ORDER:"/wealth/pendingorder"
        },
        SERVICES: {
            FETCHACCOUNTS: "/rba/evaluateRisk",
            CHEQUEBOOKREQUESTACCOUNTS: "/account/setup/chequebook",
            FETCHCHEQUEBOOKCHARGES_INITIAL:"/account/v2/setup/chequebook",
            FETCHCHEQUEBOOKCHARGES: "/account/chequebook/charge",
            REQUESTCHEQUEBOOK: "/account/chequebook/request"
        }, 
        OFFERS: {
            SEARCHOFFERS: "/campaign/offers",
            MERHCHANTS: "/campaign/merchants",
            CATEGORIES: "/campaign/categories"
        },
        RBA: {
            EVALUATERISK: "/rba/evaluateRisk",
            POSTEVALUATE: "/rba/postEvaluate"
        }, 
        BENEFICIARIES: {
            BENE_CHARITY_FETCH: "/benef/charity/fetch",
            BENE_TRANSFER_FETCH: "/benef/transfersetup/fetch",
            BENE_PAYMENT_FETCH: "/benef/paymentsetup/fetch",
            CREATE_BENEF:"/benef/transfertemplate/add",
            DELETE_BENEF: "/benef/transfertemplate/delete",
            CREATE_BILLPAY_TEMPLATE:"/benef/billpaytemplate/add",
            DELETE_BILLPAY_TEMPLATE:"/benef/billpaytemplate/delete"
        },
        TRANSFERS: {
            SETUP_FOR_TRANSFER: "/ft/setup",
            EXECUTE_TRANSFER:"/ft/execute",
            FETCH_FX_RATE:"/ft/fxrate/fetch"
        },
        PAYMENTS:{
            SETUP_FOR_PAYMENT:"/payment/setup",
            BALANCE_FETCH_FOR_PAYMENT:"/payment/balance/fetch"
        },
        OTP:{
            SEND_TRAN_OTP:"/registration/txnotp/send",
            RESEND_TRAN_OTP:"/registration/txnotp/resend"
        }          
    },
    PROPERTIES: {
        STUBS: "N",
        TIMEOUT:120000,
        ALLOWMULTIPLELOGIN:"N",
        MULTILOGININTERVAL:30000
    }
 });

