import { Component, OnInit, Input,Output,EventEmitter} from '@angular/core';
import { StaticData } from '../../shared/model/StaticData';
import { LeadRequest } from '../model/leadRequest';
import {TemplateService} from '../../shared/services/template.service';


@Component({
  selector: 'applyproductstep2-component',
  templateUrl: './../templates/applyProductStep2.html'
})
export class ApplyProductStep2Component implements OnInit{

	constructor(public templateService: TemplateService) {}
	
	@Output() applyProductsNowEvent = new EventEmitter();
	@Input() leadRequest:LeadRequest;
	@Input() emirates:StaticData[];
	
	ngOnInit(){
		this.leadRequest.emirates="";
	}

	/*
    * Step 2: Can remove the selected Products
    */
	removeSelectedProducts(value:string){
		this.leadRequest.products = this.leadRequest.products.filter(product => product!=value);
		if(!(this.leadRequest.products.length>0)){
			this.applyProductsNow(true);
		}
	}

	/*
    * Step 2: On submission of lead
    */
	applyProductsNow(valid:boolean){
		if(valid){
			this.applyProductsNowEvent.emit();
			this.templateService.resetFormValidatorFlag();
		}
	}
}