import { Component, OnInit, Input,Output,EventEmitter} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'investmentsAboutUs-component',
  templateUrl: './../templates/investmentsAboutUs.html'
})
export class InvestmentsAboutUsComponent {
@Output() nextToInvestmentMainEvent = new EventEmitter();


	nextToInvestmentMain(){
		this.nextToInvestmentMainEvent.emit();
	}
}