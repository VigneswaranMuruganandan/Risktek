import { Component, OnInit, Input} from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { SharedService } from '../../shared/services/shared.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { ErrorService } from '../../shared/services/error.service';
import { InvestmentsService } from '../services/investments.service';
import { AssetProductAllocationResponse } from '../model/assetProductAllocationResponse';

@Component({
	templateUrl: './../templates/assetsAndProductAllocation.html'
})
export class AssetsAndProductAllocationComponent implements OnInit {
	public assetAllocation :any;
	public productAllocation :any;

	constructor( private investmentsService: InvestmentsService, 
    			 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService) {}

	ngOnInit(){
		this.initProductAllocation();
		this.initAssetAllocation();
	}
	/*
	* Product Allocation service call
	*/
	initProductAllocation(){
		/*let data = {"customerIdentifier":"1006860","asOnDate":"20170920"};
		this.investmentsService.fetchProductAllocation(data)
            .subscribe(
                resp => this.handleProductAllocation(resp),
                error => this.sharedService.handleError(error)
            );*/
		this.productAllocation = {"responseStatus":{"status":"SUCCESS"},"assetProductAllocationInfo":{"assets":1403435.36,"liabilities":941259.4,"netPostion":462175.96,"currencyCode":"AED","assetLiablitiesList":[{"productClassName":"Cash & Cash Equivalent","productClassCode":"CASH","type":"Asset","currencyCode":"AED","amount":20327.18},{"productClassName":"Platform Product","productClassCode":"PP","type":"Asset","currencyCode":"AED","amount":1383108.18},{"productClassName":"Total Liabilities","productClassCode":"LOAN","type":"Liability","currencyCode":"AED","amount":941259.4}]}}
	}
	/*
	* Handle the Product Allocation
	*/
	handleProductAllocation(resp :any){
		if(resp.result.status == 'success'){
            this.productAllocation = resp;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
	}
	/*
	* Asset Allocation Service call
	*/
	initAssetAllocation(){
		/*let data = {"customerIdentifier":"1006860","asOnDate":"20170920"};
		this.investmentsService.fetchAssetAllocation(data)
            .subscribe(
                resp => this.handlefetchAssetAllocation(resp),
                error => this.sharedService.handleError(error)
            );*/
		this.assetAllocation = {"responseStatus":{"status":"SUCCESS"},"assetProductAllocationInfo":{"assets":1403435.36,"liabilities":941259.4,"netPostion":462175.96,"currencyCode":"AED","assetLiablitiesList":[{"productClassName":"Cash & Cash Equivalent","productClassCode":"CASH","type":"Asset","currencyCode":"AED","amount":20327.18},{"productClassName":"Hybrid","productClassCode":"HYBD","type":"Asset","currencyCode":"AED","amount":1383108.18},{"productClassName":"Total Liabilities","productClassCode":"LOAN","type":"Liability","currencyCode":"AED","amount":941259.4}]}}
	}
	/*
	* Handle the Asset allocation service call
	*/
	handlefetchAssetAllocation(resp :any){
		if(resp.result.status == 'success'){
            this.productAllocation = resp;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
	}
}