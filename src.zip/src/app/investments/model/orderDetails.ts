export class OrderDetails {
	orderDate :string;
	orderNumber :string;
	orderType :string;
	securityName :string;
	ccy :string;
	quantity :string;
	amount :string;
	userName :string;
}
