import {APIResponse} from '../../shared/model/apiResponse';
import {ProductDetails} from './productDetails';

export class ProductInfo extends APIResponse{
	productClassName :string;
	productClassCode :string;
	sumOfMvinAED :number;
	sumPercAsset :number;
	productDetailsList :ProductDetails[];
}
