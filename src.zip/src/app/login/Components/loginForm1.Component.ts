import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import {User} from '../model/user';
import { FormsModule} from '@angular/forms';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    TranslateService,
    ServerError
} from '../../shared';

@Component({
  selector: 'loginform1-component',
  templateUrl: './../templates/loginform1.html'
})
export class LoginForm1Component implements OnInit {
    @Output() validateCredentialsEvent = new EventEmitter();
    @Input() user: User;

    public serverError :ServerError ;

    constructor( public templateService: TemplateService,
                 public errorService: ErrorService,
                 public translate: TranslateService) {}

    ngOnInit() {
      this.generateError();
    }

    validateUserNamePwd(valid: boolean){
        if(valid){
            this.errorService.resetErrorResp();
            this.templateService.resetFormValidatorFlag();
            this.validateCredentialsEvent.emit();
        }        
    }

    generateError(){
      this.serverError = new ServerError();
      this.serverError.backButton = {"text":"Back to Cheque Book Request","router":"/services/chequeBookRequest"};
      this.translate.get('SERVERERROR.ADDBILLER', {param1: 'SALIK', param2: 'vigneswaranm'})
      .subscribe((value: string) => {
          this.serverError.errorDescription = value;
      });
    }
}