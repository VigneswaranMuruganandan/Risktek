import { Component, OnInit, Input } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { LoginService } from '../services/login.service';
import { Router } from '@angular/router';
import { LoginRequest } from '../model/loginrequest';
import { SessionContext} from '../../shared/model/sessionContext';
import { TemplateService } from '../../shared/services/template.service';
import { SharedService } from '../../shared/services/shared.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { ErrorService } from '../../shared/services/error.service';
import { User } from '../model/user';
import { CIFData } from '../model/cifdata';
import { AuthKey } from '../../shared/model/authKey';
import { AuthData } from '../../shared/model/authData';
import {AppSession} from '../../shared/model/appSession';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Component({
    templateUrl: './../templates/login.html'
})
export class LoginComponent implements OnInit {
    public user: User;

    constructor( private loginService: LoginService, 
                 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private templateService: TemplateService,
                 private errorService: ErrorService,
                 private router: Router) {}

    ngOnInit() {
      this.errorService.resetErrorResp();
      this.user = new User();
    }
    /*
    * Step 1: Initate the Register Device before verifying the Credentials
    */
    validateCredentials() {
      /*this.spinnerService.startSpinner('loader');
      console.log("Login Username::"+this.user.userName);
      let registerDeviceData = this.sharedService.setupAuthKeys();
      console.log("Register Device Data ::"+registerDeviceData);
      if(registerDeviceData && registerDeviceData.deviceID != null){
        this.sharedService.registerDevice(registerDeviceData)
          .subscribe(
              resp => this.handleRegisterDeviceDataResp(resp),
              error => this.sharedService.handleError(error)
          );
      }else{
        let sessCtx = SessionContext.getInstance();
        this.handleRegisterDeviceDataResp(sessCtx)
      }      */
      this.router.navigate(['/dashboard']);
    }
    /*
    * Step 2: With Username , fetch the CIF ID
    */
    private handleRegisterDeviceDataResp(resp: any){
      if(resp.authKey && resp.authKey.convID != null){
        let data = new LoginRequest();
        data.customerID = this.user.userName;
        this.loginService.fetchCIFNumber(data)
          .subscribe(
              resp => this.handleFetchCIFNumberLogin(resp),
              error => this.sharedService.handleError(error)
          );
      }
    }
    /*
    * Step 3: Verify the Username and Password
    */
    private handleFetchCIFNumberLogin(respObj: any) {
      if (respObj && respObj.cif != null) {
        this.loginService.verifyLogin(this.user)
            .subscribe(
                resp => this.handleVerifyLogin(resp),
                error => this.sharedService.handleError(error)
            );
      }
    }
    /*
    * Step 4: Mange the Succes of verify Login
    */
    private handleVerifyLogin(resp: any) {      
      this.spinnerService.stopSpinner('loader');
      if (resp && resp.action[0]) {
        this.templateService.setAction(resp.action);
        this.router.navigate(['/dashboard']);
      }else{
        this.user.pwd = '';
      }
    }
}