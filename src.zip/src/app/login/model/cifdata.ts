import {APIResponse} from '../../shared/model/apiresponse';


export class CIFData extends APIResponse{
	otpDuration :number;
	cif: string;
}