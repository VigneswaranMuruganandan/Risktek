import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import {GlobalURL} from '../../shared/services/globalURL';
import {ServiceInvoker} from '../../shared/connector/serviceInvoker.service';
import {EncryptionService} from '../../shared/services/encryption.service';
import { NickNameReq } from '../model/nickNameReq';
import { APIResponse } from '../../shared/model/apiResponse';
import { ProfileAlertRes } from '../model/profileAlertRes';
import { ProfileAlertReq } from '../model/profileAlertReq';
import { AlertCentreResp } from '../model/alertCentreResp';


@Injectable()
export class AccountSettingsService {

  	constructor(private serviceInvoker: ServiceInvoker, 
                private encryptionService: EncryptionService) {}

    updateNickName(req:NickNameReq): Observable <APIResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ACCOUNTSETTINGS.UPDATENICKNAME,req)
                                .map(resp => JSON.parse(resp));
    }

    activateEstatement(): Observable <APIResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ACCOUNTSETTINGS.ACTIVATEESTATEMENT,null)
                                .map(resp => JSON.parse(resp));
    }

    deactivateEstatement(): Observable <APIResponse> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ACCOUNTSETTINGS.DEACTIVATEESTATEMENT,null)
                                .map(resp => JSON.parse(resp));
    }
    
    updateEmailID(req:any): Observable <any> {
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ACCOUNTSETTINGS.UPDATEEMAILID,req)
                                .map(resp => JSON.parse(resp));
    }
    fetchAlertPref():Observable <ProfileAlertRes>{
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ACCOUNTSETTINGS.ALERTS_PREFERENCE_FETCH,null)
                                .map(resp => JSON.parse(resp));
    }
    updateAlertPref(req:ProfileAlertReq):Observable <ProfileAlertRes>{
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ACCOUNTSETTINGS.ALERTS_PREFERENCE_UPDATE,req)
                                .map(resp => JSON.parse(resp));
    }

    fetchAlertsHistory():Observable <AlertCentreResp>{
      return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.ACCOUNTSETTINGS.GET_ALERTS_HISTORY,null)
                                .map(resp => JSON.parse(resp));
    }

}


