import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AccountSettingsComponent } from './Components/accountSettings.component';

import { PersonalInformationComponent } from './Components/personalInformation.component';
import { MyAccountsComponent } from './Components/myAccounts.component';
import { MyCardsComponent } from './Components/myCards.component';
import { MyAlertsComponent } from './Components/myAlerts.component';

import { AuthGuard } from '../auth-guard.service';

const routes: Routes = [
    {
        path: '',
        component: AccountSettingsComponent,
        children: [
            {
                path: '',
                redirectTo: 'personalInformation',
                pathMatch: 'full'
            },
            {
                path: 'personalInformation',
                component: PersonalInformationComponent,
                canActivate: [AuthGuard]
            },
            {
                path: 'myAccounts',
                component: MyAccountsComponent,
                canActivate: [AuthGuard]
            },
            {
                path: 'myCards',
                component: MyCardsComponent,
                canActivate: [AuthGuard]
            },
            {
                path: 'myAlerts',
                component: MyAlertsComponent,
                canActivate: [AuthGuard]
            }
        ]
    },
    {
        path: '',
        redirectTo: '',
        pathMatch: 'full'
    }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
