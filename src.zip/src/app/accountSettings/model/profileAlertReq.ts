import { Alert } from './alert';

export class ProfileAlertReq{
	profileAlert :Alert ;
	maketingAlert:Alert;
	loginAlert:Alert;
}