export class UpdateEmailReq{
	email :string;
}