import { Component, OnInit, Input} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { TemplateService } from '../../shared/services/template.service';
import { AccountSettingsService } from '../services/accountSettings.service';
import { APIResponse } from '../../shared/model/apiResponse';
import { ErrorService } from '../../shared/services/error.service';
import { SharedService } from '../../shared/services/shared.service';
import {SpinnerService } from '../../shared/services/spinner.service';
import { UserContext} from '../../shared/model/userContext';

@Component({
  selector: 'personalinformation-component',
  templateUrl: './../templates/personalInformation.html'
})
export class PersonalInformationComponent implements OnInit{

	constructor( private templateService: TemplateService,
				 private errorService: ErrorService,
				 private sharedService: SharedService,
				 private accountSettingsService: AccountSettingsService,
				 private spinnerService: SpinnerService) {}

	ngOnInit() {
        //test
    }
}