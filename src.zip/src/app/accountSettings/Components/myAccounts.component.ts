import { Component, OnInit, Input, OnChanges,SimpleChanges} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { Account } from '../../shared/model/account';
import { NickNameReq } from '../model/nickNameReq';
import {AccountSettingsService} from '../services/accountSettings.service';
import {ErrorService } from '../../shared/services/error.service';
import {SpinnerService } from '../../shared/services/spinner.service';
import {SharedService} from '../../shared/services/shared.service';
import { APIResponse } from '../../shared/model/apiResponse';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';


@Component({
  selector: 'myaccounts-component',
  templateUrl: './../templates/myAccounts.html'
})
export class MyAccountsComponent implements OnInit{
	
	constructor(private accountSettingsService: AccountSettingsService,
				private sharedService: SharedService,
				private errorService: ErrorService,
				private spinnerService: SpinnerService) {}

	
	ngOnInit(){
		//test	
	}


}