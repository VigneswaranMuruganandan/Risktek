import { Component, OnInit, Input,Output, EventEmitter} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'updateEmail-component',
  templateUrl: './../templates/updateEmail.html'
})
export class UpdateEmailComponent implements OnInit{
	public stepValue: number;

	constructor() {}
	
	ngOnInit(){
		this.stepValue = 1;
	}

	confirmUpdateEmail(otp :string){
		this.stepValue = 2;
	}

	validateUpdateEmail(){
		this.stepValue = 3;
	}

	backUpdateEmail(step :number){
		this.stepValue = step;
	}

}