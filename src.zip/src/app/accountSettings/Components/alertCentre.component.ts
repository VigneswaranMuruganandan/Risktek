import { Component, OnInit, Input,Output, EventEmitter} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { AlertDetail } from '../model/alertDetail';

@Component({
  selector: 'alertcentre-component',
  templateUrl: './../templates/alertCentre.html'
})
export class AlertCentreComponent implements OnInit{
	constructor() {}

	@Input() alertHistory: AlertDetail[];
	@Output() backButtonEvent = new EventEmitter();
	
	ngOnInit(){}
	
	backButton(){
		this.backButtonEvent.emit();
	}

}