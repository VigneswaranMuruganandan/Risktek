import { Component, OnInit, Input,Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { ProfileAlertRes } from '../model/profileAlertRes';
import { ProfileAlertReq } from '../model/profileAlertReq';
import {AccountSettingsService} from '../services/accountSettings.service';
import {ErrorService } from '../../shared/services/error.service';
import {SpinnerService } from '../../shared/services/spinner.service';
import {SharedService} from '../../shared/services/shared.service';

@Component({
    selector: 'myalerts-component',
    templateUrl: './../templates/myAlerts.html'
})
export class MyAlertsComponent implements OnInit {

    constructor(private accountSettingsService: AccountSettingsService,
        private sharedService: SharedService,
        private errorService: ErrorService,
        private spinnerService: SpinnerService) {}

    ngOnInit() {
        //test
    }
}
