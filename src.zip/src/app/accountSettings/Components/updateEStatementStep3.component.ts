import { Component, OnInit, Input,Output, EventEmitter} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'updateEStatementStep3-component',
  templateUrl: './../templates/updateEStatementStep3.html'
})
export class UpdateEStatementStep3Component implements OnInit{
	
	constructor() {}
	
	ngOnInit(){}

}