import { Component, OnInit, Input} from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { AccountsService} from '../../accounts/services/accounts.service';
import { ErrorService } from '../../shared/services/error.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { SharedService} from '../../shared/services/shared.service';
import { CustomerAccountsResponse} from '../../accounts/model/customerAccountsResponse';
import { UserDetails } from '../../shared/model/userDetails';
import { UserContext} from '../../shared/model/userContext';
import {AccountSettingsService} from '../services/accountSettings.service';
import { AlertCentreResp } from '../model/alertCentreResp';
import * as $ from 'jquery';
import { Router } from '@angular/router';
import { GlobalVariable } from '../../shared/services/global';

@Component({
    templateUrl: './../templates/accountSettings.html'
})
export class AccountSettingsComponent implements OnInit {
    public currentTab :string;
    public tabList :any;
    constructor(private accountsService: AccountsService,
                private accountSettingsService: AccountSettingsService,
                private sharedService: SharedService,
                private errorService: ErrorService,
                private spinnerService: SpinnerService,
                private router: Router) {}
    
    ngOnInit() {
        this.tabList = GlobalVariable.ACCOUNTSETTINGSTAB;
        this.handleCurrentTab(this.router.url);
    }

    handleCurrentTab(url :string){
        switch(url) {
            case '/accountsettings/personalInformation':
                this.currentTab = this.tabList[0].id;
                break;
            case '/accountsettings/myAccounts':
                this.currentTab = this.tabList[1].id;
                break;
            case '/accountsettings/myCards':
                this.currentTab = this.tabList[2].id;
                break;
            case '/accountsettings/myAlerts':
                this.currentTab = this.tabList[3].id;
                break;
        }
        console.log(this.currentTab);
    }
}