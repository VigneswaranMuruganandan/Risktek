import { Component, OnInit, Input} from '@angular/core';
import { SharedService } from '../../shared/services/shared.service';
import { TemplateService } from '../../shared/services/template.service';
import { ErrorService } from '../../shared/services/error.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { LoansService } from '../services/loans.service';
import { Router } from '@angular/router';
import { SetupLoanDeferralResponse } from '../model/setupLoanDeferralResponse';
import { LoanDeferralRequest } from '../model/loanDeferralRequest';

@Component({
  templateUrl: './../templates/loanDeferral.html'
})
export class LoanDeferralComponent implements OnInit {
	public setupLoanDeferralResponse :SetupLoanDeferralResponse;
	public loanDeferralRequest :LoanDeferralRequest;

	constructor( private loansService: LoansService,
				 private templateService: TemplateService,
				 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService,
    			 private router: Router) {}

	ngOnInit() {
        this.initLoanDeferral();
        this.loanDeferralRequest = new LoanDeferralRequest();
        this.errorService.resetErrorResp();
    }

    /*
    * Fetch the init Loan Deferral
    */
    initLoanDeferral(){
    	this.spinnerService.startSpinner('loanDeferralRequest');
    	this.loansService.setupLoanDeferral()
        .subscribe(
            resp => this.handleSetupLoanDeferral(resp),
            error => this.sharedService.handleError(error)
            //error => this.handleSetupLoanDeferral(error)
        );
    }

    /*
	* Handle the response for init Loan Deferral
	*/
    handleSetupLoanDeferral(resp :any){
        this.spinnerService.stopSpinner('loanDeferralRequest');
        this.setupLoanDeferralResponse = new SetupLoanDeferralResponse();
    	if(resp && resp.result.status == 'success'){
            this.setupLoanDeferralResponse = resp;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
    }

    /*
	* submit the Loan Deferral
	*/
	submitLoanDeferral(valid :boolean){
		if(valid){
			this.spinnerService.startSpinner('loanDeferralRequest');
            this.loanDeferralRequest.accountNumber = '1001381262603131';
            this.loanDeferralRequest.loanType = 'Car Loan';
            this.loansService.saveLoanDeferral(this.loanDeferralRequest)
            .subscribe(
                resp => this.handlesubmitLoanDeferral(resp),
                error => this.sharedService.handleError(error)
            );           
		}
	}

    handlesubmitLoanDeferral(resp :any){
    	this.spinnerService.stopSpinner('loanDeferralRequest');
        if(resp && resp.result.status == 'success'){
            (<any>$('#defferal-message')).modal('show');
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
    }
}