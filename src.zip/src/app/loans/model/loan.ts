import { Amount } from '../../shared/model/amount';

export class Loan {
    loanHolderName :string;
	loanAccountNumber :string;
	typeOfLoan :string;
	outstandingBalance : Amount;
	principalAmount : Amount;
	paymentFrequency :string;
	fundingAccountnumber :string;
	interestRate :string;
	tenorInMonths :string;
	numberOfReceivedInstallments :string;
	installmentAmount : Amount;
	nextInstallmentAmount : Amount;
	nextPaymentDate :string;
	maturityDate :string;
	startDate :string;
}