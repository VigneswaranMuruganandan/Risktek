import { Amount } from '../../shared/model/amount';

export class AccountTransactions{

	txnDate:string;
	txnID:string;
	txnDesc:string;
	txnAmount:Amount;
	balanceBeforeTxn:Amount;
	balanceAfterTxn:Amount;
	branchName:string;
	debitCreditIndicator:string;
	txnRef:string;
	index:number;
	showFT:boolean;

}

