import { Component, OnInit, Input} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {TemplateService} from '../../shared/services/template.service';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Component({
  selector: 'activateDebitCardStep5-component',
  templateUrl: './../templates/activateDebitCardStep5.html'
})
export class ActivateDebitCardStep5Component{
	
	constructor(private templateService: TemplateService) {}	
}