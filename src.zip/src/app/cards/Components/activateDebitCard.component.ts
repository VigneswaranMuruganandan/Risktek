import { Component, OnInit, Input} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Component({
  templateUrl: './../templates/activateDebitCard.html'
})
export class ActivateDebitCardComponent implements OnInit{
	public stepNumber: number;
	
	
	ngOnInit() { 
    	this.stepNumber = 1;
    }

    validateDebitCardActivation(){
    	this.stepNumber = 2;
    	console.log("begin debit card activitation process");
    }

    validateOTPDebitCardActivation(){
        this.stepNumber = 3;
    }

    validatePinDebitCard(pin:string){
        console.log("pin:"+ pin);
        this.stepNumber = 4;
    }
    validateConfirmPinDebitCard(pin:string){
       console.log("Confirm pin:"+ pin);
        this.stepNumber = 5;
    }
	
}