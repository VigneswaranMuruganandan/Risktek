import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import {DebitCardDetail} from '../model/debitCardDetail';
import {ReplaceCardRequest} from '../model/replaceCardRequest';
import { SharedService} from '../../shared/services/shared.service';
import { ErrorService } from '../../shared/services/error.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { CardsService } from '../services/cards.service';
import {TemplateService} from '../../shared/services/template.service';

@Component({
  templateUrl: './../templates/replaceDebitCardStep1.html',
  selector:'replaceDebitCardStep1-component'
})
export class ReplaceDebitCardStep1Component implements OnInit{


	@Input() debitCard:DebitCardDetail;
	@Input() replaceCardRequest:ReplaceCardRequest;
	@Output() proceedReplaceCardButtonEvent = new EventEmitter();

	constructor( private sharedService: SharedService,
	             private errorService: ErrorService,
	             private spinnerService: SpinnerService,
	             public cardsService: CardsService,
	             public templateService: TemplateService){}


	ngOnInit() { 

    	
    }

    proceedReplaceCardButton(valid:boolean){
    	if(valid){
    		this.proceedReplaceCardButtonEvent.emit();
    	}
    }
}