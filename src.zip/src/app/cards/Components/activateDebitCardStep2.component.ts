import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {TemplateService} from '../../shared/services/template.service';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Component({
  selector: 'activateDebitCardStep2-component',
  templateUrl: './../templates/activateDebitCardStep2.html'
})
export class ActivateDebitCardStep2Component implements OnInit{
	@Output() validateOTPDebitCardActivationEvent = new EventEmitter();
	constructor(private templateService: TemplateService) {}
	public otp:string;
	public otpList :Array<string>;
	ngOnInit() { 
    	this.otpList = ['','','','','','']
    }
	validateOTP(event:any){
		this.otp = this.otpList.join('');
		this.validateOTPDebitCardActivationEvent.emit();
	}
	
}