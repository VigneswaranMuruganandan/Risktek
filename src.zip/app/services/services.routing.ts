import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ChequeBookRequestComponent } from './Components/chequeBookRequest.component';

const routes: Routes = [
	{
        path: 'chequeBookRequest',
        component: ChequeBookRequestComponent
    },
    {
	    path: '',
	    redirectTo: '/chequeBookRequest',
	    pathMatch: 'full'
	}
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);