import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { ErrorService} from '../../shared/services/error.service';
import { ChequeBookRequest } from '../model/chequeBookRequest';
import { Product } from '../../shared/model/product';
import { TemplateService } from '../../shared/services/template.service';
import { ChequeBookAccountsResponse } from '../model/chequeBookAccountsResponse';
import { RequestChequeBookResponse } from '../model/requestChequeBookResponse';

@Component({
  selector: 'chequeBookRequestSucess-component',
  templateUrl: './../templates/chequeBookRequestSuccess.html'
})
export class ChequeBookRequestSuccessComponent implements OnInit {
	@Input() chequeBookRequest: ChequeBookRequest;
	@Input() chequeBookAccounts: ChequeBookAccountsResponse;
	@Input() requestChequeBookResponse :RequestChequeBookResponse;
	product :Product;
	
	constructor( private errorService: ErrorService,
				 public templateService: TemplateService ){}

	ngOnInit() {
		this.product = this.chequeBookAccounts.fundingSources[this.templateService.getSelectIndex(this.chequeBookAccounts.fundingSources,'prodRef',this.chequeBookRequest.accountIdentifier)];
	}
}