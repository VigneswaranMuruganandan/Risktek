import { Component, OnInit, Input, ViewChild, AfterViewInit } from '@angular/core';
import { ServicesService } from '../services/services.service';
import { SharedService } from '../../shared/services/shared.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { ErrorService } from '../../shared/services/error.service';
import { SessionContext } from '../../shared/model/sessionContext';
import { ChequeBookAccountsResponse } from '../model/chequeBookAccountsResponse';
import { ChequeBookRequest } from '../model/chequeBookRequest';
import { ChequeBookChargeResponse } from '../model/chequeBookChargeResponse';
import { RequestChequeBookResponse } from '../model/requestChequeBookResponse';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Rx';
import { SendOtpRequest} from '../../shared/model/sendOtpRequest';
import { SendOtpResponse} from '../../shared/model/sendOtpResponse';
import { AppSession} from '../../shared/model/appSession';
import { GlobalVariable} from '../../shared/services/global';

@Component({
    templateUrl: './../templates/chequeBookRequest.html'
})
export class ChequeBookRequestComponent implements OnInit, AfterViewInit {
	public stepValue: number;
    public chequeBookRequest: ChequeBookRequest;
    public chequeBookAccounts: ChequeBookAccountsResponse;
    public chequeBookcharges: ChequeBookChargeResponse;
    public sendOtpRequest:SendOtpRequest;
    public sendOtpResponse:SendOtpResponse;
    public requestChequeBookResponse :RequestChequeBookResponse;
    
    constructor( private servicesService: ServicesService, 
    			 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService,
    			 private router: Router) {}

    ngOnInit() {        
        this.stepValue = 1;
        this.chequeBookcharges = new ChequeBookChargeResponse();
        this.chequeBookRequest = new ChequeBookRequest();
        this.fetchAccounts();
        this.errorService.resetErrorResp();
    }

    ngAfterViewInit() {
        $('#verifyChequeBook').prop('disabled', true);
    }
    /*
    * Fetch the inital call for cheque book request
    */
    fetchAccounts(){
        this.spinnerService.startSpinner('chequebookRequest');
        let data = {'accountNumber':''}
        this.servicesService.fetchChequeBookAccounts(data)
            .subscribe(
                resp => this.handleAccountsResp(resp),
                error => this.sharedService.handleError(error)
            );
    }
    /*
    * Handle the Initial cheque book request service call
    */
    handleAccountsResp(resp: any) {
        this.spinnerService.stopSpinner('chequebookRequest');
        if(resp.result.status == 'success'){
            this.chequeBookAccounts = resp;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
    }
    /*
    * Calculate the charges for cheque book Request
    */
    calculateChequeBookCharges(){
        this.errorService.resetErrorResp();
        this.spinnerService.startSpinner('chequebookRequest');
        this.servicesService.fetchChequeBookCharges(this.chequeBookRequest)
            .subscribe(
                resp => this.handleChequeBookChargeResp(resp),
                error => this.sharedService.handleError(error)
            );
    }
    /*
    * Handle the cheque Book Request service call
    */
    handleChequeBookChargeResp(resp :any){
        this.spinnerService.stopSpinner('chequebookRequest');
        if(resp.result.status == 'success'){
            $('#verifyChequeBook').prop('disabled', false);
            this.chequeBookcharges = resp;           
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
    }
    /*
    * Validate the cheque book request form
    */
    validateChequeBookReq(){
        this.stepValue = 2;
    }
    /*
    * Reveiw the Cheque Book Request
    */
    reviewChequeBookReq(){        
        this.sendOtpRequest = new SendOtpRequest();
        this.sendOtpRequest.txnCode = GlobalVariable.TRANSACTION_CODES.CHEQUE_BOOK_REQUEST;
        this.sendOtpRequest.txnRef = this.chequeBookAccounts.txnRef;
        if(AppSession.getInstance().auth2Factor == GlobalVariable.AUTH2FACTOR[0]){
            this.sharedService.sendOTP(this.sendOtpRequest)
                .subscribe(
                    resp => this.handleSendOtpResp(resp),
                    error => this.sharedService.handleError(error)
                );
        }else{
            this.stepValue = 3;
        }        
    }
    /*
    * Handle the reveiw cheque book Request
    */
    handleSendOtpResp(resp :SendOtpResponse){        
        if(resp.result.status == 'success'){
            this.sendOtpResponse = new SendOtpResponse();
            this.sendOtpResponse = resp;
            this.stepValue = 3;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
    }
    /*
    * valid OTP for Cheque Book Request
    */
    validateOTPChequeBookReq(otp: string){
        if(otp){
            this.chequeBookRequest.authKey = otp;
            this.submitChequeBookReq();
        }                
    }
    /*
    * submit the cheque Book Request
    */
    submitChequeBookReq(){
        this.chequeBookRequest.txnRef = this.chequeBookAccounts.txnRef;
        this.servicesService.requestChequeBook(this.chequeBookRequest)
            .subscribe(
                resp => this.handleChequeBookRequest(resp),
                error => this.sharedService.handleError(error)
            );
    }
    /*
    * Handle the Cheque book request submit
    */
    handleChequeBookRequest(resp :RequestChequeBookResponse){
        this.requestChequeBookResponse = new RequestChequeBookResponse();
        this.requestChequeBookResponse = resp;
        if(resp.result.status == 'success'){
            this.stepValue = 4;
        }else if (resp.result.status == 'error') {
            let nextStep = this.errorService.handleOTPError(resp.result);
            if(nextStep) {
                this.stepValue = 4;
            }
      }
    }
    /*
    * back method in cheque book request
    */
    backChequeBookReq(step){
        this.stepValue = step;
        this.errorService.resetErrorResp();
    }
    
}