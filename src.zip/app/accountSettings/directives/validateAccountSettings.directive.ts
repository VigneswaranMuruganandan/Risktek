import { Component, ElementRef, Directive, HostListener, NgZone, Input, Output, EventEmitter } from '@angular/core';
import * as $ from 'jquery';
import {TemplateService} from '../../shared/services/template.service';

/*
* Personal Information Email Update for Registration
*/
@Directive({
    selector: '[ValidatePersonalInfoDirective]',
})
export class ValidatePersonalInfo {
    //private x = require('jquery-validator');
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let personalInfoValidationSubmit ;
        this.zone.runOutsideAngular(() => {
            var personalInfoValidation = (<any>$("#personalInfoForm")).validate({
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    email: {
                        required: true,
                        email: true
                    }
                },
                messages: {
                    email: {
                        required: "Please enter the email ID to be updated",
                        email: "Please enter valid email ID"
                    }
                }
            });
            personalInfoValidationSubmit = personalInfoValidation.form();
            this.templateService.setFormValidatorFlag(personalInfoValidationSubmit);
        });
    }
}

