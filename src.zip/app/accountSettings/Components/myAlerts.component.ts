import { Component, OnInit, Input,Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { ProfileAlertRes } from '../model/profileAlertRes';
import { ProfileAlertReq } from '../model/profileAlertReq';
import {AccountSettingsService} from '../services/accountSettings.service';
import {ErrorService } from '../../shared/services/error.service';
import {SpinnerService } from '../../shared/services/spinner.service';
import {SharedService} from '../../shared/services/shared.service';

@Component({
    selector: 'myalerts-component',
    templateUrl: './../templates/myAlerts.html'
})
export class MyAlertsComponent implements OnInit {
	profileAlertReq: ProfileAlertReq;
    profileAlertRes: ProfileAlertRes;
    
    saveButtonShow = false;

    constructor( private accountSettingsService: AccountSettingsService,
		         private sharedService: SharedService,
		         private errorService: ErrorService,
		         private spinnerService: SpinnerService) {}

    ngOnInit() {
        this.initAlertsPrefFetch();
    }

    /*
    * Fetch Alerts Preference
    */
    initAlertsPrefFetch() {
        this.errorService.resetErrorResp();
        //this.spinnerService.startSpinner("loader")
        this.accountSettingsService.fetchAlertPref()
            .subscribe(
                resp => this.handleAlertPrefFetchResp(resp),
                error => this.sharedService.handleError(error)
            );
    }
    handleAlertPrefFetchResp(resp: ProfileAlertRes) {
        //this.spinnerService.stopSpinner("loader");
        if (resp && resp.result.status == 'success') {
            console.log(resp);
            this.profileAlertRes = new ProfileAlertRes();
            this.profileAlertRes = resp;
            this.setAlertProfileReq();
        } else if (resp.result.status == 'error') {
            this.errorService.setErrorResp(resp.result);
        }
    }

    setAlertProfileReq() {
        this.profileAlertReq = new ProfileAlertReq();
        Object.getOwnPropertyNames(this.profileAlertRes)
            .map((key: string) => {                     
                this.profileAlertReq[key] = this.profileAlertRes[key];
            });
    }


    onAlertChange(checked: boolean, channel: string, type: string) {
        if (checked) {
            this.profileAlertReq[type][channel] = true;
        } else {
            this.profileAlertReq[type][channel] = false;
        }
        this.saveButtonShow = true;
    }



    /*
    * Save Alert Preference
    */
    saveAlertPref() {
        console.log(this.profileAlertReq);
        this.errorService.resetErrorResp();
        //this.spinnerService.startSpinner("loader");
        this.accountSettingsService.updateAlertPref(this.profileAlertReq)
            .subscribe(
                resp => this.handleAlertPrefUpdateResp(resp),
                error => this.sharedService.handleError(error)
            );
    }
    
    handleAlertPrefUpdateResp(resp: ProfileAlertRes) {
        this.spinnerService.stopSpinner("loader");
        if (resp && resp.result.status == 'success') {
            this.profileAlertRes = resp;
            this.saveButtonShow = false;
        } else if (resp.result.status == 'error') {
            this.errorService.setErrorResp(resp.result);
            this.saveButtonShow = true;
        }
    }
}
