import { Component, OnInit, Input,Output, EventEmitter} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { UserDetails } from '../../shared/model/userDetails';
import { UserContext} from '../../shared/model/userContext';
import { AccountSettingsService } from '../services/accountSettings.service';
import { UpdateEmailReq} from '../model/updateEmailReq';
import { SendOtpRequest} from '../../shared/model/sendOtpRequest';
import { SendOtpResponse} from '../../shared/model/sendOtpResponse';
import { SharedService } from '../../shared/services/shared.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { ErrorService } from '../../shared/services/error.service';
import { GlobalVariable} from '../../shared/services/global';
import { AppSession} from '../../shared/model/appSession';

@Component({
  selector: 'updateEmail-component',
  templateUrl: './../templates/updateEmail.html'
})
export class UpdateEmailComponent implements OnInit{
	public stepValue: number;
	public userDetails: UserDetails;
	public updateEmailReq :UpdateEmailReq;
	public sendOtpRequest:SendOtpRequest;
    public sendOtpResponse:SendOtpResponse;

	constructor( private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private accountSettingsService: AccountSettingsService,
                 private errorService: ErrorService) {}
	
	ngOnInit(){
		this.init();
	}

	init(){
		this.spinnerService.startSpinner('updateEmail');
		this.stepValue = 1;
		this.updateEmailReq = new UpdateEmailReq();
		this.userDetails = UserContext.getInstance().userDetails;
		this.updateEmailReq.email = this.userDetails.unmaskedEmail;
		this.spinnerService.stopSpinner('updateEmail');
	}

	confirmUpdateEmail(){
		this.spinnerService.startSpinner('updateEmail');		
		this.sendOtpRequest = new SendOtpRequest();
        this.sendOtpRequest.txnCode = GlobalVariable.TRANSACTION_CODES.UPDATE_EMAIL;
        if(AppSession.getInstance().auth2Factor == GlobalVariable.AUTH2FACTOR[0]){
            this.sharedService.sendOTP(this.sendOtpRequest)
                .subscribe(
                    resp => this.handleSendOtpResp(resp),
                    error => this.sharedService.handleError(error)
                );
        }else{
        	this.spinnerService.stopSpinner('updateEmail');
            this.stepValue = 2;
        }
	}

	handleSendOtpResp(resp :SendOtpResponse){
		this.spinnerService.stopSpinner('updateEmail');        
        if(resp.result.status == 'success'){
            this.sendOtpResponse = new SendOtpResponse();
            this.sendOtpResponse = resp;
            this.stepValue = 2;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
    }

	validateUpdateEmail(otp :string){
		this.spinnerService.startSpinner('updateEmail');
		//this.updateEmailReq.authKey = otp;
		this.accountSettingsService.updateEmailID(this.updateEmailReq)
        .subscribe(
           resp => this.handleUpdateEmailIDResp(resp),
           error => this.sharedService.handleError(error) 
        );
	}

	handleUpdateEmailIDResp(resp: any){
		this.spinnerService.stopSpinner('updateEmail');
		if(resp && resp.result.status == 'success'){
            this.userDetails.email = resp.email;
            this.userDetails.unmaskedEmail = resp.unmaskedEmail;
            this.stepValue = 3;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
	}

	backUpdateEmail(step :number){
		this.stepValue = step;
	}

}