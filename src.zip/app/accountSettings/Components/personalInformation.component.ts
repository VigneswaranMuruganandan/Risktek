import { Component, OnInit, Input, ViewChild} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { UserDetails } from '../../shared/model/userDetails';
import { UserContext} from '../../shared/model/userContext';
import { TemplateService } from '../../shared/services/template.service';
import { AccountSettingsService } from '../services/accountSettings.service';
import { APIResponse } from '../../shared/model/apiResponse';
import { ErrorService } from '../../shared/services/error.service';
import { SharedService } from '../../shared/services/shared.service';
import {SpinnerService } from '../../shared/services/spinner.service';
import { UpdateEmailComponent } from './updateEmail.component';

@Component({
  selector: 'personalinformation-component',
  templateUrl: './../templates/personalInformation.html'
})
export class PersonalInformationComponent implements OnInit{
	userDetails: UserDetails;
	@ViewChild(UpdateEmailComponent) updateEmail: UpdateEmailComponent;

	constructor( private templateService: TemplateService,
				 private errorService: ErrorService,
				 private sharedService: SharedService,
				 private accountSettingsService: AccountSettingsService,
				 private spinnerService: SpinnerService) {}

	ngOnInit() {
        this.userDetails = UserContext.getInstance().userDetails;
    }

    changeEmailId(){
    	this.updateEmail.init();
    	(<any>$('#changeEmail')).modal('show');
    }
}