import { Component, OnInit, Input,Output, EventEmitter} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'updateEStatementStep2-component',
  templateUrl: './../templates/updateEStatementStep2.html'
})
export class UpdateEStatementStep2Component implements OnInit{
	@Output() validateUpdateEStatementEvent = new EventEmitter();
	@Output() backUpdateEStatementEvent = new EventEmitter();

	constructor() {}
	
	ngOnInit(){}

	validateOTP(otp : string){
		//this.errorService.resetErrorResp();
		this.validateUpdateEStatementEvent.emit(otp);
	}

	back(){
		this.backUpdateEStatementEvent.emit(1);
	}

}