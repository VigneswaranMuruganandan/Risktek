import { Component, ElementRef, Directive, HostListener, NgZone, Input, Output, EventEmitter } from '@angular/core';
import * as $ from 'jquery';
import {TemplateService} from '../../shared/services/template.service';


/*
* Block Reasons Validations
*/
@Directive({
    selector: '[validateBlockReasonSelection]',
})
export class ValidateBlockReasonSelection {
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let blockReasonSelection:boolean;
        this.zone.runOutsideAngular(() => {
            var blockReasonSelectionValidation = (<any>$("#selectBlockReasonForm")).validate({
                ignore: [],
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("select")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    lostReason: {
                        required: true
                    },
                },
                messages: {
                    lostReason: {
                        required: "Please make a selection"
                    }
                }
            });
            blockReasonSelection = blockReasonSelectionValidation.form();
            this.templateService.setFormValidatorFlag(blockReasonSelection);
        });
    }
}


/*
* Replace Card Embossing Name validation
*/
@Directive({
    selector: '[validateEmbossingName]',
})
export class ValidateEmbossingName {
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let embossingName:boolean;
        this.zone.runOutsideAngular(() => {
            var embossingNameValidation = (<any>$("#replaceCardForm")).validate({
                ignore: [],
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("select")) {
                        element.parent().append(error);
                    }
                    if (element.is("input")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    embossingName: {
                        required: true
                    },
                },
                messages: {
                    embossingName: {
                        required: "Please fill in"
                    }
                }
            });
            embossingName = embossingNameValidation.form();
            this.templateService.setFormValidatorFlag(embossingName);
        });
    }
}


