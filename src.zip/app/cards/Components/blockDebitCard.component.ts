import { Component, OnInit, Input, ViewChild} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { DebitCardDetail} from '../model/debitCardDetail';
import { BlockCardRequest} from '../model/blockCardRequest';
import { BlockCardResponse} from '../model/blockCardResponse';
import { ErrorService } from '../../shared/services/error.service';
import { BlockDebitCardStep1Component} from './blockDebitCardStep1.component';

@Component({
  templateUrl: './../templates/blockDebitCard.html',
  selector:'blockDebitCard-component'
})
export class BlockDebitCardComponent implements OnInit{

    public blockCardRequest:BlockCardRequest;
    public blockCardResponse:BlockCardResponse;
    public flowType:string;
    public reasonForReissuance:string;
    public txnRef:string;
	@Input() debitCard:DebitCardDetail;
    @ViewChild(BlockDebitCardStep1Component) blockDebitCardStep1Component: BlockDebitCardStep1Component;

    constructor( private errorService: ErrorService){}
	
	ngOnInit() { 
       this.initBlockCode(); 
    }

    initBlockCode(){
        this.flowType ='BLOCK';    
        this.blockCardRequest = new BlockCardRequest();
        this.blockCardResponse = new BlockCardResponse();
        this.blockCardRequest.cardNumber = this.debitCard.cardNumber;
        this.blockCardRequest.cardType = "DEBIT";
        this.errorService.resetErrorResp();
        this.reasonForReissuance="";
        this.blockDebitCardStep1Component.modalStepValue=1;
    }
    replaceDebitCard(data:any){
        this.flowType ='REPLACE'; 
        this.reasonForReissuance=data.reason;
        this.txnRef=data.txnRef;
    }
    
}