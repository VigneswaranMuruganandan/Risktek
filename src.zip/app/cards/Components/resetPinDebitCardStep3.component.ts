import { Component, OnInit, Input,EventEmitter,Output} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {TemplateService} from '../../shared/services/template.service';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Component({
  selector: 'resetPinDebitCardStep3-component',
  templateUrl: './../templates/resetPinDebitCardStep3.html'
})
export class ResetPinDebitCardStep3Component{
	@Output() validatePinDebitCardEvent = new EventEmitter();
	constructor(private templateService: TemplateService) {}
	
	validatePin(event:any){
		this.validatePinDebitCardEvent.emit();
	}
}