import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {TemplateService} from '../../shared/services/template.service';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Component({
  selector: 'activateDebitCardStep1-component',
  templateUrl: './../templates/activateDebitCardStep1.html'
})
export class ActivateDebitCardStep1Component implements OnInit{
	public acceptActivation: boolean;
	@Output() validateDebitCardActivationEvent = new EventEmitter();
	
	constructor(private templateService: TemplateService) {}

	ngOnInit() { 
    	this.acceptActivation = false;
    }
	beginDbtCardActivation(event:any){
		if(event.currentTarget.checked)
		this.validateDebitCardActivationEvent.emit();
	}
}