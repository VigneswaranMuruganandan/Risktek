import { Component, OnInit, Input, ViewChild, AfterViewInit} from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { DebitCardDetail} from '../model/debitCardDetail';
import { BlockDebitCardComponent} from './blockDebitCard.component';


@Component({
  selector: '[debitcarddetails-component]',
  templateUrl: './../templates/debitCardsDetails.html'
})
export class DebitCardsDetailsComponent implements AfterViewInit{
	
	@ViewChild(BlockDebitCardComponent) blockDebitCardComponent: BlockDebitCardComponent;
	@Input() debitCard:DebitCardDetail;
	
	ngAfterViewInit() {
    	this.enableOrDisableButton();
  	}

  	enableOrDisableButton(){

	    $('ul.debitCardOptions li a').removeClass('disabled');
	    if(this.debitCard.status=="NEW"){
	      $("#resetPinButton").addClass('disabled');
	      $("#blockButton").addClass('disabled');
	    }else{
	      $("#activeButton").addClass('disabled');
	    }
 	}
	blockCardPopup(){
		(<any>$('#block-card-modal')).modal('show');
		this.blockDebitCardComponent.initBlockCode();
	}
}