export class ProductPreference{
    enableEStatement : boolean;
    showAccountOnDashboard : boolean;
    nickName : string;
    isFavorite : boolean;
    prodRef : string;
    displaySequence : number;
}