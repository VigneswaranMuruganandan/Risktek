import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { Product } from '../../shared/model/product';
import { SetupIsaveResponse } from '../model/setupIsaveResponse';
import { CreateRegSavingRequest } from '../model/createRegSavingRequest';
import { ErrorService } from '../../shared/services/error.service';
import { SharedService } from '../../shared/services/shared.service';
import { TemplateService } from '../../shared/services/template.service';
import { CreateRegSavingResponse } from '../model/createRegSavingResponse';

@Component({
  selector: 'createSavingsPlanSuccess-component',
  templateUrl: './../templates/createSavingsPlanSuccess.html'
})
export class CreateSavingsPlanSuccessComponent implements OnInit {
	@Input() setupRegularSavingResponse :SetupIsaveResponse;
	@Input() createRegSavingRequest :CreateRegSavingRequest;
	@Input() createRegSavingResponse :CreateRegSavingResponse;
	sourceProduct :Product;
	destinationProduct :Product;

	constructor( private templateService: TemplateService,
		     private errorService: ErrorService,
		     private sharedService: SharedService) {}

	ngOnInit() { 
    	this.sourceProduct = this.setupRegularSavingResponse.fundingSources[this.templateService.getSelectIndex(this.setupRegularSavingResponse.fundingSources,'prodRef',this.createRegSavingRequest.sourceAccount)];
		this.destinationProduct = this.setupRegularSavingResponse.fundingSources[this.templateService.getSelectIndex(this.setupRegularSavingResponse.fundingSources,'prodRef',this.createRegSavingRequest.isaveAccountNo)];
    }
}