import { Component, OnInit, Input, Output, EventEmitter, ViewChild, OnDestroy } from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { ErrorService} from '../../shared/services/error.service';
import { SharedService } from '../../shared/services/shared.service';
import { TemplateService } from '../../shared/services/template.service';
import { Router } from '@angular/router';
import { ISave } from '../model/isave';
import { IsaveService } from '../services/isave.service';
import { SetupIsaveResponse } from '../model/setupIsaveResponse';
import { SpinnerService } from '../../shared/services/spinner.service';

@Component({
  selector: 'editIsave-component',
  templateUrl: './../templates/editIsave.html'
})
export class EditIsaveComponent implements OnInit{
	public isave: ISave;
	public setupIsaveResponse :SetupIsaveResponse;
	public temp :any;

	constructor( private errorService: ErrorService,
				 public isaveService: IsaveService,
				 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private templateService: TemplateService,
				 private router: Router){}

	ngOnInit() {
        this.isave = this.isaveService.getISaveData();
        this.initIsave();
    }

    initIsave(){
        this.spinnerService.startSpinner('editIsave');
        this.isaveService.setupIsave()
            .subscribe(
                resp => this.handleSetupIsave(resp),
                error => this.sharedService.handleError(error)
            );
    }

    handleSetupIsave(resp :SetupIsaveResponse){
        this.spinnerService.stopSpinner('editIsave');
        if(resp.result.status == 'success'){
            this.setupIsaveResponse = resp;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
    }

	ConfirmEditIsave(valid :boolean){
        if(valid){
            this.spinnerService.startSpinner('editIsave');
            this.templateService.resetFormValidatorFlag();
            this.isaveService.updateIsave(this.isave)
                .subscribe(
                    resp => this.handleUpdateIsave(resp),
                    error => this.sharedService.handleError(error)
                );
        }
    }

    handleUpdateIsave(resp :any){
        this.spinnerService.stopSpinner('editIsave');
        if(resp.result.status == 'success'){
            this.isaveService.resetISaveData();
            this.router.navigate(['/iSaveAccount']);
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
    }

}