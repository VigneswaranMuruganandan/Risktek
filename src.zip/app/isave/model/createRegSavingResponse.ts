import { APIResponse } from '../../shared/model/apiResponse';

export class CreateRegSavingResponse extends APIResponse {
   siRefNumber :string;
}