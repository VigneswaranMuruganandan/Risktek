export class RegularSaving {
   siRefNumber :string;
   debitAccountNo :string;
   debitAccountNickname :string;
   debitAccountPurpose :string;
   isaveAccountIdentifier :string;
   isaveAccountNickname :string;
   frequency :string;
   transactionAmount :string;
   startDate :string;
   endDate :string;
   isaveAccountPurpose :string;
   $$index :number
}