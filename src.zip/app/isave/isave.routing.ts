import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { IsaveWelcomeComponent } from './Components/isaveWelcome.component';
import { IsaveAccountsComponent } from './Components/isaveAccounts.Component';
import { BaseCreateIsaveComponent } from './Components/baseCreateIsave.Component';
import { EditIsaveComponent } from './Components/editIsave.Component';
import { BaseCreateSavingsPlanComponent } from './Components/baseCreateSavingsPlan.Component';
import { EditSavingsPlanComponent } from './Components/editSavingsPlan.Component';
import { ViewIsaveComponent } from './Components/viewIsave.Component';
import { ViewSavingsPlanComponent } from './Components/viewSavingsPlan.Component';

const routes: Routes = [
	{
        path: 'welcomeIsave',
        component: IsaveWelcomeComponent
    },
    {
        path: 'iSaveAccount',
        component: IsaveAccountsComponent
    },
    {
        path: 'createiSaveAccount',
        component: BaseCreateIsaveComponent
    },
    {
        path: 'editiSaveAccount',
        component: EditIsaveComponent
    },
    {
        path: 'viewiSaveAccount',
        component: ViewIsaveComponent
    },
    {
        path: 'createSavingsPlan',
        component: BaseCreateSavingsPlanComponent
    },
    {
        path: 'editSavingsPlan',
        component: EditSavingsPlanComponent
    },
    {
        path: 'viewSavingsPlan',
        component: ViewSavingsPlanComponent
    },
    {
	    path: '',
	    redirectTo: '/welcomeIsave',
	    pathMatch: 'full'
	}
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);