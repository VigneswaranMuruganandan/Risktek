import {APIResponse} from '../../shared/model/apiResponse';
import {Amount} from '../../shared/model/amount';

export class FetchBalanceForPaymentResponse  extends APIResponse{

	transactionID:string;
	availableBalance:Amount;
	minimumAmount:Amount;
	maximumAmount:Amount;
	inMultiplesOf:string;
	amountDue:Amount;

}

