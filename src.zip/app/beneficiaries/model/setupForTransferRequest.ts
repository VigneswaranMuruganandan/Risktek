export class SetupForTransferRequest {

	transferType:string;

}

