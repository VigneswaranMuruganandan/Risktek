
export class DeleteBeneficiaryRequest {

  	transferType:string;
    authKey:string;
    nickName:string;
}

