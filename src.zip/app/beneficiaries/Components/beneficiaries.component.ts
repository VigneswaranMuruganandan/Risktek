import { Component, OnInit, Input} from '@angular/core';
import { Router } from '@angular/router';


@Component({
  templateUrl: './../templates/beneficiaries.html'
})
export class BeneficiariesComponent implements OnInit{

    constructor(private router: Router) {}

	ngOnInit() { 
       
    }

   /* beneficiariesTabs(event:any){
        let tab = $('ul.beneficiariesTabs li a');
        for (let i = 0; i <= tab.length; i++) {
            $(tab[i]).removeClass('active');
        }
        $(event.currentTarget).addClass('active');
        //this.router.navigate(['/bene/'+event.currentTarget.id]);
    }*/
    
    
}
