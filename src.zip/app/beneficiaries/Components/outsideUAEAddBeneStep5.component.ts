import { Component, OnInit, Input} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'outsideUAEAddBeneStep5-component',
  templateUrl: './../templates/outsideUAEAddBeneStep5.html'
})
export class OutsideUAEAddBeneStep5Component {
 
    
}
