import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {TemplateService} from '../../shared/services/template.service';
import {User} from '../model/user';
import { FormsModule} from '@angular/forms';
import { ErrorService} from '../../shared/services/error.service';

@Component({
  selector: 'loginform2-component',
  templateUrl: './../templates/loginform2.html'
})
export class LoginForm1Component{

    constructor( public templateService: TemplateService,
                 public errorService: ErrorService) {}

    
    
}