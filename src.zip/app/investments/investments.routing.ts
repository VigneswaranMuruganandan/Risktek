import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ApplyProductComponent }   from './Components/applyProduct.component';
import { InvestmentsMainComponent }   from './Components/investmentsMain.component';
import { TransactionHistoryComponent }   from './Components/transactionHistory.component';
import { AssetsAndProductAllocationComponent }   from './Components/assetsAndProductAllocation.component';
import { HoldingSummaryComponent }   from './Components/holdingSummary.component';
import { PendingOrderStatusComponent }   from './Components/pendingOrderStatus.component';
import { AuthGuard } from '../auth-guard.service';

const routes: Routes = [   
    {
        path: '',
        component: InvestmentsMainComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'applyProducts',
        component: ApplyProductComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'transactionHistory',
        component: TransactionHistoryComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'assetsAndProductAllocation',
        component: AssetsAndProductAllocationComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'pendingOrderStatus',
        component: PendingOrderStatusComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'holdingSummaryComponent',
        component: HoldingSummaryComponent,
        canActivate: [AuthGuard]
    },
    {
        path: '',
        redirectTo: '',
        pathMatch: 'full'
    }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
