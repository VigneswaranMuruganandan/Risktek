import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import {GlobalVariable} from '../../shared/services/global';
import {ServiceInvoker} from '../../shared/connector/serviceInvoker.service';
import {EncryptionService} from '../../shared/services/encryption.service';
import {ErrorService} from '../../shared/services/error.service';
import {SessionContext} from '../../shared/model/sessionContext';
import {GlobalURL} from '../../shared/services/globalURL';
import { StaticDataResponse } from '../../shared/model/staticDataResponse';


@Injectable()
export class InvestmentsService {

    constructor(private serviceInvoker: ServiceInvoker,
        private encryptionService: EncryptionService,
        private errorService: ErrorService) {}

    fetchProducts(data: any): Observable < StaticDataResponse > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.INVESTMENTS.VIEW_PRODUCTS, data)
            .map(resp => JSON.parse(resp));
    }

    fetchAssetAllocation(data: any): Observable < StaticDataResponse > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.INVESTMENTS.ASSET_ALLOCATION, data)
            .map(resp => JSON.parse(resp));
    }

    fetchProductAllocation(data: any): Observable < StaticDataResponse > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.INVESTMENTS.PRODUCT_ALLOCATION, data)
            .map(resp => JSON.parse(resp));
    }

    fetchSecurityHolding(data: any): Observable < StaticDataResponse > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.INVESTMENTS.SECURITY_HOLDING, data)
            .map(resp => JSON.parse(resp));
    }
    
    fetchPendingOrder(data: any): Observable < StaticDataResponse > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.INVESTMENTS.PENDING_ORDER, data)
            .map(resp => JSON.parse(resp));
    }
}