import { Component, OnInit, Input,Output,EventEmitter} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { StaticData } from '../../shared/model/staticData';


@Component({
  selector: 'investmentsOurProducts-component',
  templateUrl: './../templates/investmentsOurProducts.html'
})
export class InvestmentsOurProductsComponent {
@Input() ourProducts:StaticData[];;
@Output() nextToInvestmentsDetailsEvent = new EventEmitter();
  
    nextToInvestmentsDetails(){
    	this.nextToInvestmentsDetailsEvent.emit();
    }
    
}