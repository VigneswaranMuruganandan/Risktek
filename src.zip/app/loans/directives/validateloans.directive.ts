import { Component, ElementRef, Directive, HostListener, NgZone, Input, Output, EventEmitter } from '@angular/core';
import * as $ from 'jquery';
import {TemplateService} from '../../shared/services/template.service';
import 'app/assets/js/jquery.validate.js';

@Directive({
    selector: '[validateLoanDeferral]',
})
export class ValidateLoanDeferral {
    constructor(private el: ElementRef, private zone: NgZone, private templateService: TemplateService) {}
    ngAfterViewInit() {
    }
    @HostListener('click', ['$event'])
    onClick(event: any) {
        var el = $(this.el.nativeElement);
        let validateCreateIsaveValidationSubmit;
        this.zone.runOutsideAngular(() => {
            var validateCreateIsaveValidation = (<any>$("#loanDeferral")).validate({
                ignore: [],
                highlight: function(element:any) {
                    var field = $(element);
                    field.addClass("field-error");
                },
                unhighlight: function(element:any, errorClass:any) {
                    var field = $(element);
                    field.removeClass("field-error");
                },
                errorPlacement: function(error:any, element:any) {
                    if (element.is("input,select")) {
                        element.parent().append(error);
                    }
                },
                rules: {
                    loanAccountNumber: {
                        required: true
                    },
                    monthPostpone: {
                        required: true
                    },
                    withInterest:{
                        required: true
                    }
                },
                messages: {
                    loanAccountNumber: {
                        required: "Please make a selection"
                    },
                    monthPostpone: {
                        required: "Please make a selection"
                    },
                    withInterest:{
                        required: "Please make a selection"
                    }
                }
            });
            validateCreateIsaveValidationSubmit = validateCreateIsaveValidation.form();
            this.templateService.setFormValidatorFlag(validateCreateIsaveValidationSubmit);
        });
    }
}
