export class LoanDeferralRequest{
	loanType :string;
	accountNumber :string;
	deferalMonth :string;      
	loanNumber :string;
	constructor() { 
 		this.loanNumber = "";
	}
}