import { Component } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'login-header',
  templateUrl: './../templates/loginHeader.html'
})
export class LoginHeaderComponent {
	
	constructor(private translate: TranslateService) {}
  
	changeLanguage(lang : string){
    	this.translate.use(lang);
    	(lang == 'en') ? $('body').removeClass('arabic-design') :$('body').addClass('arabic-design');
	}
}