import { Component, Input, ElementRef, ContentChild, Renderer, Directive, HostListener, Host, 
         NgZone, Output, EventEmitter, OnDestroy, ViewChild } from '@angular/core';
import { Observable} from 'rxjs/Rx';
import { SharedService } from '../services/shared.service';
import { Subscription } from 'rxjs/Subscription';
import { SpinnerService } from '../services/spinner.service';
import { ErrorService } from '../services/error.service';
import { SessionContext} from '../model/sessionContext';
import { AuthRequest} from '../../register/model/authRequest';
import { AuthData} from '../model/authData';
import {GlobalURL} from '../services/globalURL';
import { Router } from '@angular/router'

@Component({
    selector: 'loginSession-component',
    templateUrl: './../templates/multipleLoginSession.html'
})
export class MultipleLoginSessionComponent {
    @Output() sessionAlertEvent = new EventEmitter();
    public subscription: Subscription;

    constructor( private el: ElementRef, 
                 private errorService: ErrorService, 
                 public sharedService: SharedService, 
                 private router: Router) {}  

    watch() {
        if(GlobalURL.PROPERTIES.ALLOWMULTIPLELOGIN == 'Y'){
            this.subscription = Observable.interval(GlobalURL.PROPERTIES.MULTILOGININTERVAL)
                            .takeWhile(() => true)
                            .subscribe(() => this.verifyMultipleLoginSession());
        }
    }

    verifyMultipleLoginSession(){
        this.sharedService.multipleLoginSession()
            .subscribe(
                resp => {
                    if(resp.result.status == 'error' && resp.result.errorInfo.code == 'IB_MULTIPLE_LGN'){
                        this.destroy();
                        (<any>$('#multipleLogin')).modal('show'); 
                        setTimeout(()=>{
                            (<any>$('.modal-backdrop ')).remove();
                            (<any>$('body')).removeClass('modal-open');
                            this.router.navigate(['/login']);
                            this.logout();
                        }, 5000);
                    }
                },
                error => this.sharedService.handleError(error)
            );
    }

    logout(){
        let data = new AuthRequest();
        data.deviceID = SessionContext.getInstance().deviceID
        this.sharedService.logout(data)
          .subscribe(
              resp => this.handleLogout(resp),
              error => this.sharedService.handleError(error)
          );
    }

    handleLogout(resp : AuthData){
        this.errorService.resetErrorResp();
        if(resp && resp.result.status == 'success'){
            SessionContext.destroyInstance(resp);
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
        }
    }

    destroy() {
        this.subscription.unsubscribe();
    }
}