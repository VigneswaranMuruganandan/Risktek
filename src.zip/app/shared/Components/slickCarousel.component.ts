import { Component, ElementRef, NgZone, Host, Directive, Input, HostListener, OnInit } from '@angular/core';
import * as $ from 'jquery';
import 'app/assets/js/slick.js';
import { TranslateService} from '@ngx-translate/core';
import {GlobalVariable} from '../services/global';

@Component({
  selector: 'slick-carousel',
  template: `<ng-content></ng-content>`
})
export class SlickCarouselComponent implements OnInit {
  @Input() dataConfig: string;
  @Input() length: number;
  $carousel: JQuery | any;
  initialized = false;
  configuration: any;
  slides:any[] = [];

  constructor( private el: ElementRef, 
               private zone: NgZone, 
               private translate: TranslateService) {}

  ngOnInit() {
    this.configuration = GlobalVariable.SLIDER_PROPERTIES;
  }  
  
  /*
  * Initalize the slider
  */
  initCarousel() {
    this.zone.runOutsideAngular(() => {
      let flag = true;
      if(this.length){
        if(this.length > 3){
          flag = true;
        }else{
          flag = false;
        }
      }else{
        flag = true;
      }
      if(flag){
        this.updateConfiguration();
        let slider_el = $(this.el.nativeElement).find('#'+this.dataConfig); 
        this.$carousel = (<any>$(slider_el)).slick(this.configuration[this.dataConfig]);
        setTimeout(()=> {
          this.resize();
        }, 2000);
      }  
    });
    this.initialized = true;
  }

  updateConfiguration(){
    this.translate.currentLang == 'en' ? this.configuration[this.dataConfig].rtl = false : this.configuration[this.dataConfig].rtl = true ; 
  }

  resize(){
    this.$carousel.slick('slickGoTo', 0);
  }

  /*
  * push the item when we add new slider
  */
  addSlide(slide: any) {
    /*switch(this.dataConfig) {
        case 'favourites':
            if(this.length > 2){
              !this.initialized && this.initCarousel();
              this.slides.push(slide);
              this.$carousel.slick('slickAdd', slide.el.nativeElement);
              this.$carousel.slick('slickGoTo', 0);
            }
            break;
        default:
            
    }  */
    let flag = true;
    if(this.length){
      if(this.length > 3){
        flag = true;
      }else{
        flag = false;
      }
    }else{
      flag = true;
    }
    !this.initialized && this.initCarousel();
    this.slides.push(slide);
    if(flag){
    this.$carousel.slick('slickAdd', slide.el.nativeElement);
    }
  }

  removeSlide(slide:any) {
    const idx = this.slides.indexOf(slide);
  }

  pauseSlide(){
    this.$carousel.slick('slickPause');
  }

  playSlide(){
    this.$carousel.slick('slickPlay');
  }

  destroySlide(){
    this.$carousel.slick('unslick');
  }

  reinitalise(){
    this.$carousel.slick(this.configuration[this.dataConfig]);
  }

  refresh(){
    this.destroySlide();
    this.reinitalise();
    this.resize();
  }
}
/*
* Add and update the slick Slider 
*/
@Directive({
  selector: '[slick-carousel-item]',
})
export class SlickCarouselItem {
  constructor(private el: ElementRef, @Host() public carousel: SlickCarouselComponent) {
  }
  ngAfterViewInit() {
    this.carousel.addSlide(this);
  }
  ngOnDestroy() {
    this.carousel.removeSlide(this);
  }
}
/*
* Pause the slick Slider
*/
@Directive({
    selector: '[slickPause]',
})
export class SlickCarouselPause {
  constructor(private el: ElementRef, @Host() public carousel: SlickCarouselComponent) {}

  @HostListener('click', ['$event'])
  onClick(event: any) {
    let pause = $(this.el.nativeElement);
    let play = $(pause).next();
    $(pause).hide();
    $(play).show();
    this.carousel.pauseSlide();   
  }
}
/*
* Play the slick Slider
*/
@Directive({
    selector: '[slickPlay]',
})
export class SlickCarouselPlay {
  constructor(private el: ElementRef, @Host() public carousel: SlickCarouselComponent) {}

  @HostListener('click', ['$event'])
  onClick(event: any) {
    let play = $(this.el.nativeElement);
    let pause = $(play).prev();
    $(play).hide();
    $(pause).show();
    this.carousel.playSlide();     
  }
}
/*
* Destroy the slick Slider
*/
@Directive({
    selector: '[slickDestroy]',
})
export class SlickCarouselDestroy {
  $carousel: JQuery | any;
  constructor(private el: ElementRef, @Host() public carousel: SlickCarouselComponent) {}

  @HostListener('click', ['$event'])
  onClick(event: any) {
        let showAll = $(this.el.nativeElement);
        let hide = $(showAll).next();
        $(showAll).hide();
        $(hide).show();
        this.carousel.destroySlide();
  }
}
/*
* Reinitalise the slick slider
*/
@Directive({
    selector: '[slickInit]',
})
export class SlickCarouselInit {
  $carousel: JQuery | any;
  constructor(private el: ElementRef, @Host() public carousel: SlickCarouselComponent) {}

  @HostListener('click', ['$event'])
  onClick(event: any) {
        let hide = $(this.el.nativeElement);
        let showAll = $(hide).prev();
        $(showAll).show();
        $(hide).hide();
        this.carousel.reinitalise();
  }
}
/*
* Refresh the slick Slider
*/
@Directive({
    selector: '[slickRefresh]',
})
export class SlickCarouselRefresh {
  constructor(private el: ElementRef, @Host() public carousel: SlickCarouselComponent) {
  }
  @HostListener('click', ['$event'])
  onClick(event: any) {
    setTimeout(()=>{ 
      this.carousel.refresh();
    }, 500);        
  }
}
/*
* resize the slick Slider
*/
@Directive({
    selector: '[slickResize]',
})
export class SlickCarouselResize {
  @Input() slickResize: string;

  $carousel: JQuery | any;
  constructor(private el: ElementRef, private zone: NgZone) {}

  @HostListener('click', ['$event'])
  onClick(event: any) {
      this.zone.runOutsideAngular(() => {
        this.$carousel = $('#'+this.slickResize);
        setTimeout(()=>{ 
          this.$carousel.slick('slickGoTo', 0);
        }, 500);        
      });     
  }
}