import { Injectable, ElementRef } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import * as $ from 'jquery';
import {GlobalVariable} from './global';

@Injectable()
export class SpinnerService{

  
  constructor( private http : Http){}
  
  /*
  * Start Spinner
  */
  startSpinner(element : any){
    let el = '#'+element;
    $(el).show().delay(1000);
  }
  /*
  * Stop the spinner
  */
  stopSpinner(element : any){
    let el = '#'+element;
    $(el).fadeOut();
  }
    
}