export const GlobalVariable = Object.freeze({
    ROUTE_MAPPING: {
     	DASHBOARD:"/dashboard",
      ACCOUNT:"/accounts",
      DEBITCARDS:"/cards",
      CREDITCARDS:"javascript:void(0);",
      LOANS:"/loans",
      INVESTMENTS:"/investments",
      APPLY_FOR_PRODUCT:"apply-for-product",
      TRANSFER_MONEY:"/transfers",
      PAYMENTS:"javascript:void(0);",
      BENEFICIARIES:"/beneficiaries",
      ATM_BRANCH_LOCATIONS:"atm",
      CONTACT_US:"/others/contactUs",
      FAB_OFFERS:"/offers",
      ISAVE:"/iSaveAccount",
      ISAVE_WELCOME:"/welcomeIsave",
      CHEQUE_BOOK_REQUEST:"/services/chequeBookRequest",
      LANGUAGE:"",
      LOAN_DEFERRAL:"/loans/loanDeferral"
    },
    URL_MAPPING: {
     	ACCOUNT:{
     		OPEN_TERM_DEPOSIT: "opentermdeposit.json",
     		OFFER_BANNER: "offer_content.json",
     		VERIFY_ACCESS_TOKEN: "verifyaccesstoken.json"
     	}
    },
    IMAGE_URL: {
    	ACTIVATE_DEBIT_CARD: "fgb-activation-credit-card.png",
      OWN_ACCT_FUNDS_TRANSFER: "app/assets/images/svg-icons/between-accounts.svg",
      WITHIN_BANK_FUNDS_TRANSFER: "app/assets/images/svg-icons/within-fab.svg",
      WITHIN_UAE_FUNDS_TRANSFER: "app/assets/images/svg-icons/within-uae.svg",
      INTERNATIONAL_FUNDS_TRANSFER: "app/assets/images/svg-icons/international-transfer.svg",
      SMS_CASH: "app/assets/images/svg-icons/sms-cash.svg",
      ETISALAT : "app/assets/images/utility-billers/etisalat.png",
      ADDC : "app/assets/images/utility-billers/addc.png",
      DEWA : "app/assets/images/utility-billers/dewa.png",
      AADC : "app/assets/images/utility-billers/aadc.png",
      SEWA : "app/assets/images/utility-billers/sewa.png",
      SALIK : "app/assets/images/utility-billers/salik.png",
      DU : "app/assets/images/utility-billers/du.png",
      FEWA : "app/assets/images/utility-billers/fewa.png",
      GEMS : "app/assets/images/utility-billers/fewa.png"
    },
    ACCOUNTSETTINGSTAB: [
      {
        "id": "PERSONALINFORMATION",
        "description": "Personal Information"
      },
      {
        "id": "MYACCOUNTS",
        "description": "My Accounts"
      },
      {
        "id": "MYCARDS",
        "description": "My Cards"
      },
      {
        "id": "MYALERTS",
        "description": "My Alerts"
      }
    ],
    NO_OF_PAYMENTS: [1,2,3,4,5],
    NO_OF_CHEQUEBOOK: [1,2,3,4,5],
    DATE_OPTION: {
      STARTDATE :{ "minDate": "+0D", "dateFormat": "dd/mm/yy" },
      ENDDATE: { "minDate": "+0D", "dateFormat": "dd/mm/yy" } 
    },
    AUTH2FACTOR:['SMS_OTP','SOFT_OTP'],
    LOANS_COLOR: [  '#FF6182','#FFA032','#44C0C1', 
                    "#305496", "#475E90", "#305496", "#8998b8",
                    "#a1adc6", "#b4bdd1", "#c3cada", "#d0e4f3",
                    "#6c7ea6", "#475E90", "#b1e4f9", "#b4bdd1",
                    "#8998b8", "#70ad47", "#85d5f5", "#117ac6",
                    "#4195d1", "#67aada", "#85bbe1", "#11afeb",
                    "#11afeb", "#11afeb", "#11afeb",
                    "#b1d4ec", "#c1ddf0", "#11afeb", "#41bfef",
                    "#67cbf2", "#91cd54", "#7030a0", "#c00000",
                    "#ffc000", "#ed7d31", "#b8337c", "#a8a8a8",
                    "#6aa046", "#c00000", "#305496", "#a8a8a8",
                    "#c96767", "#70ad47", "#fc000", "#6aa046",
                    "#c00000", "#d48585", "#e4b1b1", "#7030a0",
                    "#c00000", "#ed7d31", "#ed7d31", "#475E90",
                    "#6aa046", "#91cd54", "#c00000", "#4872CF",
                    "#777777", "#777777"
    ],
    MENU_ICON_MAPPING:{
    	DASHBOARD:"home",
    	ACCOUNT:"accounts",
    	DEBITCARDS:"debit-cards",
    	CREDITCARDS:"credit-cards",
    	LOANS:"loans",
    	INVESTMENTS:"investments",
    	APPLY_FOR_PRODUCT:"apply-for-product",
      TRANSFER_MONEY:"transfer",
      PAYMENTS:"payments",
      BENEFICIARIES:"beneficiaries",
      ATM_BRANCH_LOCATIONS:"atm",
      CONTACT_US:"contact",
      FAB_OFFERS:"offers",
      LANGUAGE:"language",
      ISAVE:"isave-coin"
    },
    OFFER_MERCHANTS:{      
      "CAR_RENTAL":"Car_Rental.png",
      "SERVICES":"Services.png",
      "FURNITURE":"Furniture.png",
      "FASHION":"Fashion.png",
      "HEALTH_AND__WELLNESS":"Health.png",
      "FUN_&_ADVENTURE":"Adventure.png",
      "CAKES_AND_CONFECTIONARIES":"Cakes.png",
      "ENTERTAINMENT":"Entertainment.png",
      "FLOWERS":"Flowers.png",
      "GIFT_IDEAS":"Gifts.png",
      "HOTELS":"Hotel.png",
      "LEARNING":"Learning.png",
      "OPTICAL_AND_SUNGLASSES":"Opticals.png",
      "SPA":"Spa.png",
      "DINING":"Dining.png",
      "GENERAL":"General.png",
      "0%_OFFERS":"0 Offers.png",
      "BUY_1_GET_1_OFFERS":"Buy_1_get_1.png",
      "BEST_OF_THE_MONTH":"Best_of_the_month.png"
    },
    SLIDER_PROPERTIES:{
                  'favourites': {
                      'rtl': false,
                      'dots':false,
                      'arrows': true,
                      'appendArrows': '#slick-carousel-dots-fav',
                      'slidesToShow': 3,
                      'slidesToScroll': 3,
                      'responsive': [{
                              'breakpoint': 1500,
                              'settings': {
                                  'slidesToShow': 3,
                                  'slidesToScroll': 3,
                                  'infinite': true,
                                  'dots': false
                              }
                          },
                          {
                              'breakpoint': 1100,
                              'settings': {
                                  'slidesToShow': 2,
                                  'slidesToScroll': 2,
                                  'infinite': true,
                                  'dots': false
                              }
                          },
                          {
                              'breakpoint': 600,
                              'settings': {
                                  'slidesToShow': 2,
                                  'slidesToScroll': 2
                              }
                          },
                          {
                              'breakpoint': 520,
                              'settings': {
                                  'slidesToShow': 1,
                                  'slidesToScroll': 1
                              }
                          }
                      ]
                  },
                  'accountsInfo': {
                      'rtl': false,
                      'dots':false,
                      'arrows': true,
                      'appendArrows': '#slick-carousel-dots-acc',
                      'slidesToShow': 3,
                      'slidesToScroll': 3,
                      'responsive': [{
                              'breakpoint': 1500,
                              'settings': {
                                  'slidesToShow': 3,
                                  'slidesToScroll': 3,
                                  'infinite': true,
                                  'dots': false
                              }
                          },
                          {
                              'breakpoint': 1100,
                              'settings': {
                                  'slidesToShow': 2,
                                  'slidesToScroll': 2,
                                  'infinite': true,
                                  'dots': false
                              }
                          },
                          {
                              'breakpoint': 600,
                              'settings': {
                                  'slidesToShow': 2,
                                  'slidesToScroll': 2
                              }
                          },
                          {
                              'breakpoint': 520,
                              'settings': {
                                  'slidesToShow': 1,
                                  'slidesToScroll': 1
                              }
                          }
                      ]
                  },
                  'cardsInfo': {
                      'rtl': false,
                      'dots':false,
                      'arrows': true,
                      'appendArrows': '#slick-carousel-dots-card',
                      'slidesToShow': 3,
                      'slidesToScroll': 3,
                      'responsive': [{
                              'breakpoint': 1500,
                              'settings': {
                                  'slidesToShow': 3,
                                  'slidesToScroll': 3,
                                  'infinite': true,
                                  'dots': false
                              }
                          },
                          {
                              'breakpoint': 1100,
                              'settings': {
                                  'slidesToShow': 2,
                                  'slidesToScroll': 2,
                                  'infinite': true,
                                  'dots': false
                              }
                          },
                          {
                              'breakpoint': 600,
                              'settings': {
                                  'slidesToShow': 2,
                                  'slidesToScroll': 2
                              }
                          },
                          {
                              'breakpoint': 520,
                              'settings': {
                                  'slidesToShow': 1,
                                  'slidesToScroll': 1
                              }
                          }
                      ]
                  },
                  'loansInfo': {
                      'rtl': false,
                      'dots':false,
                      'arrows': true,
                      'appendArrows': '#slick-carousel-dots-loan',
                      'slidesToShow': 3,
                      'slidesToScroll': 3,
                      'responsive': [{
                              'breakpoint': 1500,
                              'settings': {
                                  'slidesToShow': 3,
                                  'slidesToScroll': 3,
                                  'infinite': true,
                                  'dots': false
                              }
                          },
                          {
                              'breakpoint': 1100,
                              'settings': {
                                  'slidesToShow': 2,
                                  'slidesToScroll': 2,
                                  'infinite': true,
                                  'dots': false
                              }
                          },
                          {
                              'breakpoint': 600,
                              'settings': {
                                  'slidesToShow': 2,
                                  'slidesToScroll': 2
                              }
                          },
                          {
                              'breakpoint': 520,
                              'settings': {
                                  'slidesToShow': 1,
                                  'slidesToScroll': 1
                              }
                          }
                      ]
                  },
                  'depositsInfo': {
                      'rtl': false,
                      'dots':false,
                      'arrows': true,
                      'appendArrows': '#slick-carousel-dots-deposit',
                      'slidesToShow': 3,
                      'slidesToScroll': 3,
                      'responsive': [{
                              'breakpoint': 1500,
                              'settings': {
                                  'slidesToShow': 3,
                                  'slidesToScroll': 3,
                                  'infinite': true,
                                  'dots': false
                              }
                          },
                          {
                              'breakpoint': 1100,
                              'settings': {
                                  'slidesToShow': 2,
                                  'slidesToScroll': 2,
                                  'infinite': true,
                                  'dots': false
                              }
                          },
                          {
                              'breakpoint': 600,
                              'settings': {
                                  'slidesToShow': 2,
                                  'slidesToScroll': 2
                              }
                          },
                          {
                              'breakpoint': 520,
                              'settings': {
                                  'slidesToShow': 1,
                                  'slidesToScroll': 1
                              }
                          }
                      ]
                  },
                  'dashboard_transfers': {
                      'dots':false,
                      'rtl': false,
                      'arrows': true,
                      'appendArrows': '#sliderArrows-transfers',
                      'dotsClass': 'carousel-dots',
                      'slidesToShow': 3,
                      'slidesToScroll': 3,
                      'infinite': false,
                      'responsive': [
                        {
                          'breakpoint': 1500,
                          'settings': {
                            'slidesToShow': 4,
                            'slidesToScroll': 3,
                            'infinite': true,
                            'dots': true
                          }
                        },
                        {
                          'breakpoint': 1100,
                          'settings': {
                            'slidesToShow': 3,
                            'slidesToScroll': 3,
                            'infinite': true,
                            'dots': true
                          }
                        },
                        {
                          'breakpoint': 500,
                          'settings': {
                            'slidesToShow': 3,
                            'slidesToScroll': 1,
                            'infinite': true,
                          }
                        },
                      ]
                  },
                  'dashboard_payments': {
                      'dots':false,
                      'rtl': false,
                      'arrows': true,
                      'appendArrows': '#sliderArrows-payments',
                      'dotsClass': 'carousel-dots',
                      'slidesToShow': 4,
                        'slidesToScroll': 3,
                      'infinite': false,
                      'responsive': [
                        {
                          'breakpoint': 1500,
                          'settings': {
                            'slidesToShow': 4,
                            'slidesToScroll': 3,
                            'infinite': true,
                            'dots': true
                          }
                        },
                        {
                          'breakpoint': 1100,
                          'settings': {
                            'slidesToShow': 3,
                            'slidesToScroll': 3,
                            'infinite': true,
                            'dots': true
                          }
                        },
                        {
                          'breakpoint': 500,
                          'settings': {
                            'slidesToShow': 3,
                            'slidesToScroll': 1,
                            'infinite': true,
                          }
                        },
                      ]
                  },
                  'dashboard_offers':{
                    'dots':false,
                    'rtl': false,
                    'arrows': true,
                    'appendArrows': '#sliderArrows-offers',
                    'dotsClass': 'carousel-dots',
                    'slidesToShow': 2,
                    'slidesToScroll': 2,
                    'infinite': false,
                    'rows': 2,
                    'responsive': [
                      {
                        'breakpoint': 1500,
                        'settings': {
                          'slidesToShow': 2,
                          'slidesToScroll': 2,
                          'infinite': true,
                          'dots': true
                        }
                      },
                      {
                        'breakpoint': 1100,
                        'settings': {
                          'slidesToShow': 1,
                          'slidesToScroll': 1,
                          'infinite': true,
                          'dots': true
                        }
                      },
                      {
                        'breakpoint': 900,
                        'settings': {
                          'slidesToShow': 2,
                          'slidesToScroll': 2,
                          'infinite': true,
                          'dots': true
                        }
                      },
                      {
                        'breakpoint': 500,
                        'settings': {
                          'slidesToShow': 2,
                          'slidesToScroll': 2,
                          'infinite': true,
                        }
                      },
                    ]
                  },
                  'bulletins': {
                    'rtl': false,
                    'arrows': false,
                    'slidesToShow': 1,
                    'slidesToScroll': 1,
                    'autoplay': true,
                    'autoplaySpeed': 2000
                  },
                  'rightContent':{
                    'rtl': false,
                    'dots':true,
                    'appendDots': '#accountRightContent',
                    'dotsClass': 'carousel-dots',
                    'slidesToShow': 1,
                    'slidesToScroll': 1,
                    'arrows': false
                  },
                  'rightContentOffer':{
                    'rtl': false,
                    'dots':true,
                    'appendDots': '#accountRightContentOffer',
                    'dotsClass': 'carousel-dots',
                    'slidesToShow': 1,
                    'slidesToScroll': 1,
                    'arrows': false
                  },
                  'rightContentDebitCard':{
                    'rtl': false,
                    'dots':false,
                    'dotsClass': 'carousel-dots',
                    'slidesToShow': 1,
                    'slidesToScroll': 1,
                    'arrows': true,
                    'appendArrows': '#debitCardRightContent',
                  },
                  'downloadApp':{
                    'rtl': false,
                    'dots':true,
                    'appendDots': '#carousel-dots-downloadapp',
                    'dotsClass': 'carousel-dots',
                    'slidesToShow': 1,
                    'slidesToScroll': 1,
                    'arrows': false,
                    'refresh': true
                  }
    },
    ERROR_CODES:{
    	USERNAME_PASSWORD_WRONG : "Invalid username/password. You have MESSAGE_DISPLAY remaining attempts for login",
    	VRFY_OTP_MTCH_FLD : "Invalid OTP. You have MESSAGE_DISPLAY remaining attempts"
    },
    PRODUCT_TYPES:{
      ACCOUNT:"ACCOUNT",
      CARD:"CARD",
      LOAN:"LOAN",
      DEPOSIT:"DEPOSIT"
    },
    TRANSFER_TYPES:{
      OWN_ACCT_FUNDS_TRANSFER:"OWN_ACCT_FUNDS_TRANSFER",
      WITHIN_BANK_FUNDS_TRANSFER : "WITHIN_BANK_FUNDS_TRANSFER",
      WITHIN_UAE_FUNDS_TRANSFER : "WITHIN_UAE_FUNDS_TRANSFER",
      INTERNATIONAL_FUNDS_TRANSFER:"INTERNATIONAL_FUNDS_TRANSFER",
      SMS_CASH:"SMS_CASH"
    },
    TRANSFER_TYPE_DESCRIPTION:{
      OWN_ACCT_FUNDS_TRANSFER:"Own Account",
      WITHIN_BANK_FUNDS_TRANSFER : "Within FAB",
      WITHIN_UAE_FUNDS_TRANSFER : "Within UAE",
      INTERNATIONAL_FUNDS_TRANSFER:"Outside UAE",
      SMS_CASH:"SMS Cash"
    },
    BENE_ADD_TYPE:{
      BENE_ADD_WITHOUT_TRANSFER:"B",
      BENE_ADD_WITH_TRANSFER:"B_T"
    },
    TRANSACTION_CODES :{
      BENEF_ADD_OWN_ACCT_FUNDS_TRANSFER:"BENEF_ADD_OWN_ACCT_FUNDS_TRANSFER",
      BENEF_ADD_WITHIN_BANK_FUNDS_TRANSFER:"BENEF_ADD_WITHIN_BANK_FUNDS_TRANSFER",
      BENEF_ADD_WITHIN_UAE_FUNDS_TRANSFER:"BENEF_ADD_WITHIN_UAE_FUNDS_TRANSFER",
      BENEF_ADD_INTERNATIONAL_FUNDS_TRANSFER:"BENEF_ADD_INTERNATIONAL_FUNDS_TRANSFER",
      BENEF_ADD_SMS_CASH:"BENEF_ADD_SMS_CASH",
      CHEQUE_BOOK_REQUEST: "CHEQUE_BOOK_REQUEST",
      BENEF_ADD_ETISALAT_BILLPAYMENT:"BENEF_ADD_ETISALAT_BILLPAYMENT",
      BENEF_ADD_ADDC_BILLPAYMENT:"BENEF_ADD_ADDC_BILLPAYMENT",
      BENEF_ADD_DEWA_BILLPAYMENT:"BENEF_ADD_DEWA_BILLPAYMENT",
      BENEF_ADD_AADC_BILLPAYMENT:"BENEF_ADD_AADC_BILLPAYMENT",
      BENEF_ADD_SEWA_BILLPAYMENT:"BENEF_ADD_SEWA_BILLPAYMENT",
      BENEF_ADD_FEWA_BILLPAYMENT:"BENEF_ADD_FEWA_BILLPAYMENT",
      BENEF_ADD_DU_BILLPAYMENT:"BENEF_ADD_DU_BILLPAYMENT",
      BENEF_ADD_SALIK_BILLPAYMENT:"BENEF_ADD_SALIK_BILLPAYMENT",
      BENEF_ADD_SALIK_BILLPAYMENT_BYAMOUNT:"BENEF_ADD_SALIK_BILLPAYMENT_BYAMOUNT",
      BENEF_ADD_SALIK_BILLPAYMENT_BYDATE:"BENEF_ADD_SALIK_BILLPAYMENT_BYDATE",
      UPDATE_EMAIL: "UPDATE_EMAIL",
      DEBIT_CARD_REPLACEMENT:"DEBIT_CARD_REPLACEMENT"
    },
    BILLER_DESCRIPTION:{
      ETISALAT : "Etisalat",
      ADDC : "AADC",
      DEWA : "DEWA",
      AADC : "AADC",
      SEWA : "SEWA",
      SALIK : "Salik",
      DU : "DU",
      FEWA : "FEWA"
    },
    OTP_ERROR_CODES:["VRFY_OTP_MTCH_FLD","VRFY_OTP_MAX_ATTEMPTS_EXCEEDED","VRFY_OTP_RESEND_TIMES_EXCEEDED"],
    STUBS: {
      LOGIN : true
    }      
 });

