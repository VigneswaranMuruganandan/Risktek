import { Amount } from './amount';

export class Account{
    productName :string ;
    nickName:string;
    number:string;
    balance: Amount;
    accountCurrency:string;
    swiftCode:string;
    iban:string;
    holderName:string;
    currentBalance: Amount;
    blockedAmount:string;
    unclearedAmount:string;
    limitAmount:string;
    overDraftLimit:string;
    accountType:string;
    productType:string;
    branch:string;
    openingDate:string;
    displaySequence:string;
    isFavorite:boolean;
}
