import { Amount } from './amount';

export class Product {
   productType :string;
   prodRef :string;
   balance :Amount;
   nickName :string;
   currency :string;
   useable :boolean;
}