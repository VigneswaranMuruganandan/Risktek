import {APIResponse} from './apiResponse';
import {StaticData} from './staticData';

export class StaticDataResponse extends APIResponse{
   staticMasterDataMap  : Map<string,Array<StaticData>>;
}