import {AuthKey} from './authKey';
import {AuthData} from './authData';

export class SessionContext{
    private static _instance:SessionContext;

    authKey:AuthKey;
    data:any[] = [];
    userID :string;
    deviceID: string;

    public static getInstance():SessionContext{
        return SessionContext._instance||(SessionContext._instance = new SessionContext());
    };

    public static destroyInstance(response : any){
        delete SessionContext._instance;
        let authData = new AuthData();
        authData.authKey = new AuthKey();
        authData.authKey.encIV = response.data.encIV;
        authData.authKey.encKey = response.data.encKey;
        authData.authKey.convID = response.data.convID;
        authData.authKey.macKey = response.data.macKey;
        authData.authKey.ec = response.data.eventCtr;
        authData.authKey.sessionType = response.data.sessionType;
        let sessCtx = SessionContext.getInstance();
        sessCtx.authKey = authData.authKey;
        sessCtx.deviceID = response.data.deviceID;
    };

    public static incrementCounter():SessionContext{
        var sessCtx = SessionContext._instance;
        var ec = sessCtx.authKey.ec;
        ec = ec +1;
        sessCtx.authKey.ec=ec;
        console.log("ec incremented" +sessCtx.authKey.ec);
        return sessCtx;
    }
}