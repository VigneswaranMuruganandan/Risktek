import {APIResponse} from '../../shared/model/apiResponse';
export class VerifyOtpResponse extends APIResponse{
	userName: string;
	name: string;
	otpRef:string;
	otpDuration:number;
	emailMasked:string;
	mobileNumberMasked:string;
	remainingOtpAttempts:number;
}