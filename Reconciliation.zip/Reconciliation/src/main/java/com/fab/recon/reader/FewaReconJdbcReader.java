/**
 * 
 */
package com.fab.recon.reader;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fab.recon.common.QueryConstants;
import com.fab.recon.model.fewa.FewaPreparedStmtSetter;
import com.fab.recon.model.fewa.FewaReconDetails;
import com.fab.recon.model.fewa.FewaRowMapper;

/**
 * @author o4359
 *
 */
@Component
public class FewaReconJdbcReader extends JdbcCursorItemReader<FewaReconDetails> {

	private Logger log = LoggerFactory.getLogger(getClass());

	@Autowired
	private DataSource ciDs;

	@Autowired
	private FewaPreparedStmtSetter preparedStmtSetter;

	@Autowired
	private FewaRowMapper resultSetMapper;

	@Override
	public void afterPropertiesSet() throws Exception {
		setDataSource(ciDs);
		setSql(QueryConstants.SELECT_FEWA_RECON_DETAILS);
		setPreparedStatementSetter(preparedStmtSetter);
		setRowMapper(resultSetMapper);
		log.info("########### FEWA RECON JOB INITIALIZED: START ##########");
		super.afterPropertiesSet();
	}
}
