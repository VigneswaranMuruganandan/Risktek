/**
 * 
 */
package com.fab.recon.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fab.recon.common.ApplicationConstants;
import com.fab.recon.common.Frequency;
import com.fab.recon.common.QueryConstants;
import com.fab.recon.helper.TextUtils;
import com.fab.recon.helper.Utility;

/**
 * @author o4359
 *
 */
@Component
public class CIRepository {

	private Logger log = LoggerFactory.getLogger(getClass());

	@Autowired
	private DataSource ciDs;

	@Autowired
	private Utility utility;

	public void updateFewaHistoryPosted() {
		try (Connection con = ciDs.getConnection();
				PreparedStatement ps = con.prepareStatement(QueryConstants.UPDATE_HIST_FEWA_RECON_DETAILS);
				PreparedStatement ps1 = con.prepareStatement(QueryConstants.UPDATE_POSTED_FEWA_RECON_DETAILS);) {

			// UPDATE HISTORY
			int historyUpdated = ps.executeUpdate();
			log.info("Fewa History Updated: {}", historyUpdated);

			// UPDATE POSTED
			ps1.setString(1, "20170821");
			//ps1.setString(1, TextUtils.formatDate(utility.getDateByFrequency(new Date(), Frequency.PREVIOUSDAY), ApplicationConstants.DATE_YYYYMMDD));
			int postedUpdated = ps1.executeUpdate();
			log.info("Fewa Posted Updated: {}", postedUpdated);

		} catch (SQLException exe) {
			log.error("Exception Occured in updateFewaHistoryPosted: {} ", exe);
		}
	}
}
