/**
 * 
 */
package com.fab.recon.helper;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author o4359
 *
 */
@Component
public class PropertyConfig {

	@Value("${FEWA_FILE_PATH}")
	private String fewaFilePath;

	/**
	 * @return the fewaFilePath
	 */
	public String getFewaFilePath() {
		return fewaFilePath;
	}

	/**
	 * @param fewaFilePath
	 *            the fewaFilePath to set
	 */
	public void setFewaFilePath(String fewaFilePath) {
		this.fewaFilePath = fewaFilePath;
	}

}
