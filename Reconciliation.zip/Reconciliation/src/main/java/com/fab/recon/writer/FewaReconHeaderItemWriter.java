/**
 * 
 */
package com.fab.recon.writer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.transform.BeanWrapperFieldExtractor;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.batch.item.file.transform.FieldExtractor;
import org.springframework.batch.item.file.transform.LineAggregator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;

import com.fab.recon.common.ApplicationConstants;
import com.fab.recon.helper.Utility;
import com.fab.recon.model.fewa.FewaReconHeaderDetails;

/**
 * @author o4359
 *
 */
@Component
public class FewaReconHeaderItemWriter extends FlatFileItemWriter<FewaReconHeaderDetails> {

	private Logger log = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private Utility utility;

	private LineAggregator<FewaReconHeaderDetails> createFewaLineAggregator() {
		DelimitedLineAggregator<FewaReconHeaderDetails> lineAggregator = new DelimitedLineAggregator<>();
		lineAggregator.setDelimiter(ApplicationConstants.COMMA);
		lineAggregator.setFieldExtractor(this.createFewaFieldExtractor());
		return lineAggregator;
	}

	private FieldExtractor<FewaReconHeaderDetails> createFewaFieldExtractor() {
		BeanWrapperFieldExtractor<FewaReconHeaderDetails> extractor = new BeanWrapperFieldExtractor<>();
		extractor.setNames(new String[] { "id", "bankId", "reconDate", "fileDate", "totalAmount", "totalCount" });
		return extractor;
	}
	
	@Override
	public void afterPropertiesSet() throws Exception {
		setResource(new FileSystemResource(utility.buildFileName(ApplicationConstants.FEWA)));
		setShouldDeleteIfExists(true);
		setLineAggregator(this.createFewaLineAggregator());
		log.info("########### FEWA HEADER RECON JOB INITIALIZED: END ##########");
		super.afterPropertiesSet();
	}
}
