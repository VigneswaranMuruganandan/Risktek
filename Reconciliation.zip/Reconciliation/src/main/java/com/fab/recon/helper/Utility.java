/**
 * 
 */
package com.fab.recon.helper;

import java.io.File;
import java.util.Date;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fab.recon.common.ApplicationConstants;
import com.fab.recon.common.Frequency;

/**
 * @author o4359
 *
 */
@Component
public class Utility {

	@Autowired
	private PropertyConfig propConfig;
	
	public String buildFileName(final String agency) {
		StringBuilder builder = new StringBuilder();
		if (ApplicationConstants.FEWA.equalsIgnoreCase(agency)) {
			builder.append(propConfig.getFewaFilePath());
			builder.append(File.separator);
			builder.append(ApplicationConstants.FEWA_BANKID);
			builder.append(TextUtils.formatDate(this.getDateByFrequency(new Date(), Frequency.PREVIOUSDAY), ApplicationConstants.DATE_YYYYMMDD));
			builder.append(TextUtils.formatDate(new Date(), ApplicationConstants.DATE_YYYYMMDD));
			builder.append(ApplicationConstants.CSV_EXT);
		}
		return builder.toString();
	}
	
	public Date getDateByFrequency(final Date initialDate, final Frequency frequency) {
		DateTime dt = new DateTime(initialDate);
		switch (frequency) {
		
		case PREVIOUSDAY:
			dt = dt.plusDays(-1);
			break;
			
		case WEEKLY:
			dt = dt.plusWeeks(1);
			break;

		case MONTHLY:
			dt = dt.plusMonths(1);
			break;

		case FORTNIGHT:
			dt = dt.plusWeeks(2);
			break;

		case QUARTERLY:
			dt = dt.plusMonths(3);
			break;

		case HALFYEARLY:
			dt = dt.plusMonths(6);
			break;

		default:
			break;
		}
		return new Date(dt.getMillis());
	}
}
