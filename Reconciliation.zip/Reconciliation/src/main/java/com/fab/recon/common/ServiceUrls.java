/**
 * 
 */
package com.fab.recon.common;

/**
 * @author o4359
 *
 */
public enum ServiceUrls {

	
	// FEWA RECON IIB SERVICE
	FEWA_RECON_URL(ApplicationConstants.IIB_SERVICE, "");

	private String url;
	private String targetSystem;

	private ServiceUrls(String targetSystem, String url) {
		this.targetSystem = targetSystem;
		this.url = url;
	}
	public String getUrl() {
		return url;
	}

	public String getTargetSystem() {
		return targetSystem;
	}
}
