/**
 * 
 */
package com.fab.recon.model.fewa;

/**
 * @author o4359
 *
 */
public class FewaReconHeaderDetails {

	private String id;
	private String bankId;
	private String reconDate;
	private String fileDate;
	private String totalAmount;
	private String totalCount;

	/**
	 * @return the totalAmount
	 */
	public String getTotalAmount() {
		return totalAmount;
	}

	/**
	 * @param totalAmount
	 *            the totalAmount to set
	 */
	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}

	/**
	 * @return the totalCount
	 */
	public String getTotalCount() {
		return totalCount;
	}

	/**
	 * @param totalCount
	 *            the totalCount to set
	 */
	public void setTotalCount(String totalCount) {
		this.totalCount = totalCount;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the bankId
	 */
	public String getBankId() {
		return bankId;
	}

	/**
	 * @param bankId
	 *            the bankId to set
	 */
	public void setBankId(String bankId) {
		this.bankId = bankId;
	}

	/**
	 * @return the reconDate
	 */
	public String getReconDate() {
		return reconDate;
	}

	/**
	 * @param reconDate
	 *            the reconDate to set
	 */
	public void setReconDate(String reconDate) {
		this.reconDate = reconDate;
	}

	/**
	 * @return the fileDate
	 */
	public String getFileDate() {
		return fileDate;
	}

	/**
	 * @param fileDate
	 *            the fileDate to set
	 */
	public void setFileDate(String fileDate) {
		this.fileDate = fileDate;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("[");
		builder.append("id=");
		builder.append(id);
		builder.append(", bankId=");
		builder.append(bankId);
		builder.append(", reconDate=");
		builder.append(reconDate);
		builder.append(", fileDate=");
		builder.append(fileDate);
		builder.append(", totalAmount=");
		builder.append(totalAmount);
		builder.append(", totalCount=");
		builder.append(totalCount);
		builder.append("]");
		return builder.toString();
	}
}
