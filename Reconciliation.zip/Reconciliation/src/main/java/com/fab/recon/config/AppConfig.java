/**
 * 
 */
package com.fab.recon.config;

/*import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.support.JobRegistryBeanPostProcessor;
import org.springframework.batch.core.configuration.support.MapJobRegistry;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.support.MapJobRepositoryFactoryBean;
import org.springframework.batch.support.transaction.ResourcelessTransactionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import oracle.ucp.jdbc.PoolDataSource;
import oracle.ucp.jdbc.PoolDataSourceFactory;*/

/**
 * @author o4359
 *
 */
/*@Configuration
@EnableBatchProcessing
@EnableScheduling
@ComponentScan(value = { "com.fab.recon" })
@PropertySource({ "file:D:/E-Drive/Softwares-new/64Bit-Softwares/wlp/usr/shared/resources/Reconciliation/recon.properties" })*/
public class AppConfig {/*

	@Autowired
	private Environment environment;

	 CI JDBC DATASOURCE 
	@Bean(name = "ciDs")
	public DataSource ciDs() throws SQLException {
		PoolDataSource poolDataSource = PoolDataSourceFactory.getPoolDataSource();
		poolDataSource.setConnectionFactoryClassName("oracle.jdbc.pool.OracleDataSource");
		poolDataSource.setURL(environment.getRequiredProperty("ci.jdbc.url"));
		poolDataSource.setUser(environment.getRequiredProperty("ci.jdbc.user"));
		poolDataSource.setPassword(environment.getRequiredProperty("ci.jdbc.password"));
		poolDataSource.setMaxPoolSize(Integer.valueOf(environment.getRequiredProperty("jdbc.max.pool.size")));
		poolDataSource.setMinPoolSize(Integer.valueOf(environment.getRequiredProperty("jdbc.min.pool.size")));
		poolDataSource.setInitialPoolSize(Integer.valueOf(environment.getRequiredProperty("jdbc.intial.pool.size")));
		poolDataSource.setConnectionPoolName("CI_CONN_POOL");
		poolDataSource.setConnectionWaitTimeout(10);
		poolDataSource.setValidateConnectionOnBorrow(true);
		return poolDataSource;
	}

	 TRANSACTION MANAGER 
	@Bean(name = "transactionManager")
	public ResourcelessTransactionManager transactionManager() {
		ResourcelessTransactionManager txnManager = new ResourcelessTransactionManager();
		return txnManager;
	}

	 JOB REPOSITORY 
	@Bean(name = "jobRepository")
	public MapJobRepositoryFactoryBean jobRepository() throws Exception {
		MapJobRepositoryFactoryBean jobRepo = new MapJobRepositoryFactoryBean();
		jobRepo.setTransactionManager(transactionManager());
		return jobRepo;
	}

	 TASK EXECUTOR :- PARALLEL JOBS RUNNING CONFIG 
	@Bean(name = "taskExecutor")
	public ThreadPoolTaskExecutor taskExecutor() {
		ThreadPoolTaskExecutor taskExec = new ThreadPoolTaskExecutor();
		taskExec.setCorePoolSize(Integer.valueOf(environment.getRequiredProperty("spring.task.thread.core.pool")));
		taskExec.setMaxPoolSize(Integer.valueOf(environment.getRequiredProperty("spring.task.thread.max.pool")));
		taskExec.setWaitForTasksToCompleteOnShutdown(true);
		return taskExec;
	}

	 JOB LAUNCHER 
	@Bean(name = "jobLauncher")
	public SimpleJobLauncher jobLauncher() throws Exception {
		SimpleJobLauncher jobLaunch = new SimpleJobLauncher();
		jobLaunch.setJobRepository(jobRepository().getObject());
		jobLaunch.setTaskExecutor(taskExecutor());
		return jobLaunch;
	}

	 JOB REGISTRY 
	@Bean(name = "jobRegistry")
	public MapJobRegistry jobRegistry() {
		MapJobRegistry jobRegistry = new MapJobRegistry();
		return jobRegistry;
	}

	 JOB REGISTRY BEAN POST PROCESSOR 
	@Bean(name = "jobRegistryBeanPostProcessor")
	public JobRegistryBeanPostProcessor jobRegistryBeanPostProcessor() {
		JobRegistryBeanPostProcessor jobRegBean = new JobRegistryBeanPostProcessor();
		jobRegBean.setJobRegistry(jobRegistry());
		return jobRegBean;
	}
*/}
