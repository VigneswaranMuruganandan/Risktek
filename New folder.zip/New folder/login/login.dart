import 'package:fabhr/utils/style.dart';
import 'package:flutter/material.dart';

class Login extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _LoginState();
  }
}

class _LoginState extends State<Login> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      backgroundColor: Colors.white,
      resizeToAvoidBottomInset: false,
      body: _buildLoginBody(context),
    );
  }

  Widget _buildLoginBody(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          SizedBox(
            height: 78,
          ),
          _imageContainer(),
          _textContainer(),
          _formFields(),
          _buttonsContainer(),
          SizedBox(
            height: 20,
          ),
        ],
      ),
    );
  }

  Widget _imageContainer() {
    return Container(
        margin: EdgeInsets.only(left: 29),
        width: 90,
        height: 52,
        child: Image.asset('assets/images/logoCopy@2x.png'));
  }

  Widget _textContainer() {
    return Container(
      margin: EdgeInsets.only(left: 29),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  'Sign In to',
                  style: LoginTextStyle1,
                ),
                Text(
                  'FAB HR App',
                  style: LoginTextStyle2,
                ),
                SizedBox(
                  height: 12,
                ),
                Text(
                  'Access all services in one account',
                  style: LoginTextStyle3,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _formFields() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 21),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Container(
            decoration: inputBoxDecorationLogin,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Padding(
                  padding: EdgeInsets.all(20),
                  child: Icon(
                    Icons.person_outline,
                    size: 24,
                    color: Color.fromRGBO(113, 123, 135, 1.0),
                  ),
                ),
                Expanded(
                  child: Container(
                    child: TextField(
                      decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: 'Email or username*',
                          hintStyle: formHintTextStyle),
                    ),
                  ),
                )
              ],
            ),
          ),
          Container(
            decoration: inputBoxDecorationLogin,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Padding(
                  padding: EdgeInsets.all(20),
                  child: Icon(
                    Icons.vpn_key,
                    size: 24,
                    color: Color.fromRGBO(113, 123, 135, 1.0),
                  ),
                ),
                Expanded(
                  child: Container(
                    child: TextField(
                      decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: 'Password',
                          hintStyle: formHintTextStyle),
                    ),
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buttonsContainer() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 29),
      child: Row(
        children: <Widget>[
          Expanded(
            flex: 4,
            child: FlatButton(
              onPressed: () {},
              textColor: Color.fromRGBO(255, 255, 255, 1.0),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              padding: EdgeInsets.symmetric(vertical: 25),
              color: Color.fromRGBO(0, 43, 122, 1.0),
              child: Text('Log In',
                  style: TextStyle(
                      fontSize: 17,
                      fontFamily: 'Graphik-Medium',
                      letterSpacing: 0.04)),
            ),
          ),
          SizedBox(
            width: 16,
          ),
          Expanded(
            flex: 1,
            child: FlatButton(
                onPressed: () {},
                textColor: Color.fromRGBO(255, 255, 255, 1.0),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
                padding: EdgeInsets.symmetric(vertical: 8),
                color: Color.fromRGBO(12, 35, 64, 1.0),
                child: Icon(
                  Icons.fingerprint,
                  size: 50,
                )),
          )
        ],
      ),
    );
  }
}
