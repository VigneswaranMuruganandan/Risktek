import 'package:flutter/material.dart';
import 'package:fabhr/utils/style.dart';
import 'package:fabhr/utils/router.dart';

const EdgeInsets employeeNamePadding = EdgeInsets.only(top: 66);
