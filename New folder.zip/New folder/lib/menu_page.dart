import 'package:fabhr/utils/style.dart';
import 'package:flutter/material.dart';
import 'package:fabhr/utils/constants.dart';
import 'package:fabhr/models/MenuItem.dart';

class MenuScreen extends StatelessWidget {
  final List<MenuItem> options = [
    MenuItem(Icons.search, '/applyLeave', 'Apply leave'),
    MenuItem(Icons.shopping_basket, '/approvalRequests', 'Approve leave'),
    MenuItem(Icons.favorite, 'APPROVALREQUESTS', 'Approve expenses'),
    MenuItem(Icons.code, 'APPROVALREQUESTS', 'Approve requsition'),
    MenuItem(Icons.format_list_bulleted, 'APPROVALREQUESTS', 'Contact us'),
  ];

  Widget fABLogo(BuildContext context) {
    return new Container(
        child: Row(
      children: <Widget>[
        Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Container(
              height: 43.0,
              width: 74.0,
              decoration: BoxDecoration(
                  image: DecorationImage(
                image: AssetImage('assets/images/logo.png'),
                fit: BoxFit.fill,
              )),
            )),
        Spacer(),
      ],
    ));
  }

  Widget staffName(BuildContext context) {
    return new Container(
        child: Row(
      children: <Widget>[
        Padding(
            padding: const EdgeInsets.only(top: 66),
            child: Text(
              'Elizabeth Cruz',
              style: EmployeeName,
            )),
      ],
    ));
  }

  Widget staffTitle(BuildContext context) {
    return new Container(
        child: Row(
      children: <Widget>[
        Padding(
            padding: const EdgeInsets.only(top: 7),
            child: Text(
              'Project Manager',
              style: EmployeeRole,
            )),
      ],
    ));
  }

  Widget menuItems(BuildContext context) {
    return new Container(
        child: Column(
      children: options.map((item) {
        return ListTile(
          onTap: () {
            Navigator.of(context).pushNamed(item.id);
            //Navigator.of(context).pop();
          },
          leading: Icon(
            item.icon,
            color: Colors.white,
            size: 20,
          ),
          title: Text(
            item.title,
            style: MenuText,
          ),
        );
      }).toList(),
    ));
  }

  Widget logout(BuildContext context) {
    return new Container(
        child: Column(
      children: <Widget>[
        ListTile(
          leading: Icon(
            Icons.headset_mic,
            color: Colors.white,
            size: 20,
          ),
          title: Text('Logout', style: MenuText),
        )
      ],
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
          top: 68,
          left: 15,
          bottom: 81,
          right: MediaQuery.of(context).size.width / 2.9),
      decoration: MenuGradient,
      child: Column(
        children: <Widget>[
          fABLogo(context),
          staffName(context),
          staffTitle(context),
          Spacer(),
          menuItems(context),
          Spacer(),
          logout(context),
        ],
      ),
    );
  }
}
