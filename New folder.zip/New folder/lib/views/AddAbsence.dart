import 'package:flutter/material.dart';

class AddAbsence extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return _AddAbsenceState();
  }
}

class _AddAbsenceState extends State<AddAbsence>{

  final _formKey = new GlobalKey<FormState>();
  List<String> _leaveTypes = ['Annual leave','Maternity Leave','Unpaid Leave','Sick Leave'];
  String _leaveType;

  _onChanged (String value){
    setState(() {
      _leaveType =value;
    });
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Form(
      key: _formKey,
      child: Container(
        margin: EdgeInsets.symmetric(horizontal:34 ),
        child: Column(
          children: <Widget>[
            Container(
              decoration: BoxDecoration(
                //color: Color.fromRGBO(214 ,218 ,225, 1.0),
                borderRadius: BorderRadius.circular(8)
              ),
              child:  DropdownButtonFormField(
                decoration: InputDecoration(
                  border: InputBorder.none,
                ),
                value: _leaveType,
                onChanged: (String newValue){ _onChanged(newValue);},
                items: _leaveTypes.map((String value){
                  return DropdownMenuItem(
                    value: value,
                    child: Text(value),
                  ); 
                }).toList(),
              ),
            )
           
          ],
        ),
      )
    );
  }
}