enum MenuState {
  closed,
  opening,
  open,
  closing,
}
