export class DepositCreateRequest {
	renewWithInterest :string;
    interestRedeemAccount :string;
    interestRate :string;
    sourceAccountNumber :string;
    principalRedeemAccount :string;
    depositAmount :string;
    tenor :string;
    depositCurrency :string;
    renewOnMaturity :string;

}