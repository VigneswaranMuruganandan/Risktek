import { APIResponse } from '../../shared/model/apiResponse';
import { Amount } from '../../shared/model/amount';
import { Product } from '../../shared/model/product';

export class DepositCreateSetupResponse  extends APIResponse {
	sourceAccounts :Product[];
	principalRedeemAccounts :Product[];
	interestRedeemAccounts :Product[];
	depositCurrencies :string[];
	minAmount :Amount;
	maxAmount :Amount;
	notes :string;
}