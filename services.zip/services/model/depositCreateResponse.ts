import { APIResponse } from '../../shared/model/apiResponse';

export class DepositCreateResponse  extends APIResponse {
	depositId :string;
}