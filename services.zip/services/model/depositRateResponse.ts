import { APIResponse } from '../../shared/model/apiResponse';
import { DepositRate } from './depositRate';

export class DepositRateResponse extends APIResponse {
   rates : DepositRate[];
}