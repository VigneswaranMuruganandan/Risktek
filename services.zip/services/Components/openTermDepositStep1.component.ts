import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    TranslateService,
    GlobalVariable
} from '../../shared';
import { DepositCreateSetupResponse } from '../model/depositCreateSetupResponse';

@Component({
    selector: 'openTermDepositStep1-component',
    templateUrl: './../templates/openTermDepositStep1.html'
})
export class OpenTermDepositStep1Component implements OnInit {
    @Output() validateTermDepositEvent = new EventEmitter();
    @Input() depositCreateSetupResponse: DepositCreateSetupResponse;
    
    constructor( private templateService: TemplateService, 
                 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService,
                 private router: Router) {}

    ngOnInit() {        
        
    }

    validate(valid :boolean){
        if(valid){
            this.validateTermDepositEvent.emit();
        }
    }
}