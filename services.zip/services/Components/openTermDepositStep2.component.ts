import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    TranslateService,
    GlobalVariable
} from '../../shared';

@Component({
    selector: 'openTermDepositStep2-component',
    templateUrl: './../templates/openTermDepositStep2.html'
})
export class OpenTermDepositStep2Component implements OnInit {
    @Output() confirmTermDepositEvent = new EventEmitter();
    @Output() backTermDepositEvent = new EventEmitter();
    
    constructor( private templateService: TemplateService, 
                 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService,
                 private router: Router) {}

    ngOnInit() {        
        
    }

    confirm(){
        this.confirmTermDepositEvent.emit();
    }

    back(){
        this.backTermDepositEvent.emit(1);
    }
}