import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    TranslateService,
    GlobalVariable
} from '../../shared';

@Component({
    selector: 'creditShieldActivationStep2-component',
    templateUrl: './../templates/creditShieldActivationStep2.html'
})
export class CreditShieldActivationStep2Component implements OnInit {
    @Output() validateOTPCreditShieldActivationEvent = new EventEmitter();
    @Output() backCreditShieldActivationEvent = new EventEmitter();

    constructor( private templateService: TemplateService, 
                 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService,
                 private router: Router) {}

    ngOnInit() {        
        
    }

    validateOTP(otp : string){
        this.errorService.resetErrorResp();
        this.validateOTPCreditShieldActivationEvent.emit(otp);
    }

    back(){
        this.backCreditShieldActivationEvent.emit(2);
    }

}