import { Component, Input, Output, EventEmitter } from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { ServicesService } from '../services/services.service';
import { SharedService } from '../../shared/services/shared.service';
import { TemplateService} from '../../shared/services/template.service';
import { ErrorService} from '../../shared/services/error.service';
import { GlobalVariable} from '../../shared/services/global';

@Component({
  selector: 'updateMobileNumberStep1-component',
  templateUrl: './../templates/updateMobileNumberStep1.html'
})
export class UpdateMobileNumberStep1Component {
	

	constructor( public servicesService: ServicesService, 
				 public sharedService: SharedService,
				 public templateService: TemplateService,
				 private errorService: ErrorService) {}


}



