import { Component, OnInit, Input} from '@angular/core';
import { ServicesService } from '../services/services.service';
import { SharedService } from '../../shared/services/shared.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { ErrorService } from '../../shared/services/error.service';
import { Router } from '@angular/router';
import { AppSession} from '../../shared/model/appSession';
import { GlobalVariable} from '../../shared/services/global';
import { TranslateService} from '@ngx-translate/core';

@Component({
    templateUrl: './../templates/updateMobileNumber.html'
})
export class UpdateMobileNumberComponent implements OnInit {

    public stepValue:number;
    
    constructor( private servicesService: ServicesService, 
    			 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService,
    			 private router: Router) {}

    ngOnInit() {        
        this.stepValue=1;
    }

    
}