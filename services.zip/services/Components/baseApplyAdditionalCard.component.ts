import { Component, OnInit, Input, Output } from '@angular/core';
import { ServicesService } from '../services/services.service';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    TranslateService,
    GlobalVariable
} from '../../shared';

@Component({
    templateUrl: './../templates/baseApplyAdditionalCard.html'
})
export class BaseApplyAdditionalCardComponent implements OnInit {
    public stepValue: number;
    constructor( private servicesService: ServicesService, 
                 private templateService: TemplateService, 
    			 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService,
    			 private router: Router) {}

    ngOnInit() {        
        this.stepValue = 1;
    }

    proceedCreditShieldActivation(){
        this.stepValue = 2;
    }

    confirmCreditShieldActivation(){
        this.stepValue = 3;
    }

    validateOTPCreditShieldActivation(otp: string){
        this.errorService.resetErrorResp();
        if(otp){
            //this.chequeBookRequest.authKey = otp;
            this.stepValue = 4;
        } 
    }

    backCreditShieldActivation(step){
        this.stepValue = step;
        this.errorService.resetErrorResp();
    }

    
}