import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    TranslateService,
    GlobalVariable
} from '../../shared';

@Component({
    selector: 'creditShieldActivationStep1-component',
    templateUrl: './../templates/creditShieldActivationStep1.html'
})
export class CreditShieldActivationStep1Component implements OnInit {
    @Output() proceedCreditShieldActivationEvent = new EventEmitter();
    @Output() confirmCreditShieldActivationEvent = new EventEmitter();
    @Output() backCreditShieldActivationEvent = new EventEmitter();
    @Input() stepValue: number;
    
    constructor( private templateService: TemplateService, 
                 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService,
                 private router: Router) {}

    ngOnInit() {        
        
    }

    proceed(){
        this.proceedCreditShieldActivationEvent.emit();
    }

    confirm(){
        this.confirmCreditShieldActivationEvent.emit();
    }

    back(){
        this.backCreditShieldActivationEvent.emit(1);
    }
}