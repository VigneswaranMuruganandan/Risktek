import { Component, OnInit, Input, Output } from '@angular/core';
import { ServicesService } from '../services/services.service';
import {
    SharedService,
    SpinnerService,
    ErrorService,
    TemplateService,
    Router,
    TranslateService,
    GlobalVariable
} from '../../shared';
import { DepositRate } from '../model/depositRate';
import { DepositRateResponse } from '../model/depositRateResponse';
import { DepositRateRequest } from '../model/depositRateRequest';

import { DepositCreateRequest } from '../model/depositCreateRequest';
import { DepositCreateResponse } from '../model/depositCreateResponse';
import { DepositCreateSetupResponse } from '../model/depositCreateSetupResponse';

@Component({
    templateUrl: './../templates/baseOpenTermDeposit.html'
})
export class BaseOpenTermDepositComponent implements OnInit {
	public stepValue :number;
    public depositRate :DepositRate[];
    public depositRateRequest :DepositRateRequest;
    public depositCreateRequest: DepositCreateRequest;
    public depositCreateResponse: DepositCreateResponse;
    public depositCreateSetupResponse: DepositCreateSetupResponse;
    
    constructor( private servicesService: ServicesService, 
                 private templateService: TemplateService, 
    			 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService,
    			 private router: Router) {}

    ngOnInit() {        
        this.init();
    }

    init(){
        this.stepValue = 1;
        this.fetchDepositRates();
        this.fetchSetupDeposit();
    }

    fetchSetupDeposit(){
        this.servicesService.setupTermDeposit()
            .subscribe(
                resp => this.handleSetupDeposit(resp),
                error => this.sharedService.handleError(error)
            );
    }

    handleSetupDeposit(resp :DepositCreateSetupResponse){
        if(resp.result.status == 'success'){
            this.depositCreateSetupResponse = new DepositCreateSetupResponse();
            this.depositCreateSetupResponse = resp;
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
            
        }
    }
    
    fetchDepositRates(){
        this.depositRateRequest = new DepositRateRequest();
        this.depositRateRequest.currency = 'AED';
        this.servicesService.fetchDepositRates(this.depositRateRequest)
            .subscribe(
                resp => this.handleDepositRates(resp),
                error => this.sharedService.handleError(error)
            );
    }

    handleDepositRates(resp :DepositRateResponse){
        if(resp.result.status == 'success'){
            this.depositRate = resp.rates;
            console.log(resp.rates);
        }else if(resp.result.status == 'error'){
            this.errorService.setErrorResp(resp.result);
            
        }
    }

    validateTermDeposit(){
        this.stepValue = 2;
    }

    confirmTermDeposit(){
        this.stepValue = 3;
    }

    backTermDeposit(step :number){
        if(step){
            this.stepValue = step;
        }
    }
}