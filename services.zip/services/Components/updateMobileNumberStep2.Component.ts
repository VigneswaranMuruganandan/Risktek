import { Component, Input, Output, EventEmitter } from '@angular/core';
import { TranslateService} from '@ngx-translate/core';


@Component({
  selector: 'updateMobileNumberStep2-component',
  templateUrl: './../templates/updateMobileNumberStep2.html'
})
export class UpdateMobileNumberStep2Component {

}



