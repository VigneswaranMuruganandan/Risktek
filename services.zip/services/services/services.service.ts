import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';
import { AppSession} from '../../shared/model/appSession';
import { ServiceInvoker} from '../../shared/connector/serviceInvoker.service';
import { SharedService } from '../../shared/services/shared.service';
import { ErrorService} from '../../shared/services/error.service';
import { SessionContext} from '../../shared/model/sessionContext';
import { GlobalURL} from '../../shared/services/globalURL';
import { ChequeBookRequest } from '../model/chequeBookRequest';
import { ChequeBookChargeResponse } from '../model/chequeBookChargeResponse';
import { ChequeBookAccountsResponse } from '../model/chequeBookAccountsResponse';
import { RequestChequeBookResponse } from '../model/requestChequeBookResponse';
import { DepositRateResponse } from '../model/depositRateResponse';
import { DepositRateRequest } from '../model/depositRateRequest';
import { DepositCreateSetupResponse } from '../model/depositCreateSetupResponse'; 

@Injectable()
export class ServicesService {
    
    constructor(private serviceInvoker: ServiceInvoker, 
                private errorService: ErrorService,
                private sharedService: SharedService) {}

    fetchChequeBookAccounts(data :any): Observable < ChequeBookAccountsResponse > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.SERVICES.CHEQUEBOOKREQUESTACCOUNTS, data)
                                  .map(resp => JSON.parse(resp));
    }

    fetchChequeBookCharges(chequeBookRequest: ChequeBookRequest): Observable < ChequeBookChargeResponse > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.SERVICES.FETCHCHEQUEBOOKCHARGES, chequeBookRequest)
                                  .map(resp => JSON.parse(resp));
    }

    requestChequeBook(chequeBookRequest: ChequeBookRequest): Observable < RequestChequeBookResponse > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.SERVICES.REQUESTCHEQUEBOOK, chequeBookRequest)
                                  .map(resp => JSON.parse(resp));
    }

    fetchDepositRates(depositRateRequest :DepositRateRequest): Observable < DepositRateResponse > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.SERVICES.DEPOSITRATES, depositRateRequest)
                                  .map(resp => JSON.parse(resp));
    }

    setupTermDeposit(): Observable < DepositCreateSetupResponse > {
        return this.serviceInvoker.invoke(GlobalURL.SERVICE_URL.SERVICES.SETUP_TERMDEPOSIT, null)
                                  .map(resp => JSON.parse(resp));
    }
}