import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { routing } from './services.routing';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '../shared/shared.module';
import { SharedService} from '../shared/services/shared.service';
import { TemplateService} from '../shared/services/template.service';
import { ServicesService} from './services/services.service';
import { FormsModule } from '@angular/forms';
import { ChequeBookRequestComponent } from './Components/chequeBookRequest.component';
import { ChequeBookRequestFormComponent }   from './Components/chequeBookRequestForm.component';
import { ChequeBookRequestReviewComponent }   from './Components/chequeBookRequestReview.component';
import { ChequeBookRequestOtpComponent }   from './Components/chequeBookRequestOtp.component';
import { ChequeBookRequestSuccessComponent }   from './Components/chequeBookRequestSuccess.component';
import { BaseOpenTermDepositComponent } from './Components/baseOpenTermDeposit.component';
import { OpenTermDepositStep1Component } from './Components/openTermDepositStep1.component';
import { OpenTermDepositStep2Component } from './Components/openTermDepositStep2.component';
import { OpenTermDepositStep3Component } from './Components/openTermDepositStep3.component';
import { BaseCreditShieldActivationComponent } from './Components/baseCreditShieldActivation.component';
import { CreditShieldActivationStep1Component } from './Components/creditShieldActivationStep1.component';
import { CreditShieldActivationStep2Component } from './Components/creditShieldActivationStep2.component';
import { CreditShieldActivationStep3Component } from './Components/creditShieldActivationStep3.component';



import { RatesComponent } from './Components/rates.component';
import { UpdateMobileNumberComponent } from './Components/updateMobileNumber.component';
import { UpdateMobileNumberStep1Component } from './Components/updateMobileNumberStep1.component';
import { UpdateMobileNumberStep2Component } from './Components/updateMobileNumberStep2.component';
import { UpdateMobileNumberStep3Component } from './Components/updateMobileNumberStep3.component';

import {
  ValidateChequeBookRequestDirective,
  ValidateTermDpositDirective
} from './directives/validateServices.directive'


const SERVICES_COMPONENTS = [
    ChequeBookRequestComponent,
    ChequeBookRequestFormComponent,
    ChequeBookRequestReviewComponent,
    ChequeBookRequestOtpComponent,
    ChequeBookRequestSuccessComponent,
    BaseOpenTermDepositComponent,
    OpenTermDepositStep1Component,
    OpenTermDepositStep2Component,
    OpenTermDepositStep3Component,
    BaseCreditShieldActivationComponent,
    CreditShieldActivationStep1Component,
    CreditShieldActivationStep2Component,
    CreditShieldActivationStep3Component,
    RatesComponent,
    UpdateMobileNumberComponent,
    UpdateMobileNumberStep1Component,
    UpdateMobileNumberStep2Component,
    UpdateMobileNumberStep3Component    
];

const SERVICES_DIRECTIVES = [
    ValidateChequeBookRequestDirective,
    ValidateTermDpositDirective
];

const SERVICES_PROVIDERS = [
   SharedService,
   TemplateService,
   ServicesService
];

@NgModule({
  	imports: [
	    routing,
	    TranslateModule.forChild(),
	    SharedModule,
	    FormsModule,
      	CommonModule
	],
  	declarations: [
	    ...SERVICES_COMPONENTS,
      ...SERVICES_DIRECTIVES
	],
  	providers: [
  		...SERVICES_PROVIDERS
  	]
})
export class ServicesModule {}
