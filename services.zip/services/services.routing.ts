import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ChequeBookRequestComponent } from './Components/chequeBookRequest.component';
import { BaseOpenTermDepositComponent } from './Components/baseOpenTermDeposit.component';
import { RatesComponent } from './Components/rates.component';
import { UpdateMobileNumberComponent } from './Components/updateMobileNumber.component';
import { BaseCreditShieldActivationComponent } from './Components/baseCreditShieldActivation.component';

const routes: Routes = [
	{
        path: 'chequeBookRequest',
        component: ChequeBookRequestComponent
    },
    {
        path: 'openTermDeposit',
        component: BaseOpenTermDepositComponent
    },
    {
        path: 'creditShieldActivation',
        component: BaseCreditShieldActivationComponent
    },
    {
        path: 'rates',
        component: RatesComponent
    },
    {
        path: 'updateMobile',
        component: UpdateMobileNumberComponent
    },
    {
	    path: '',
	    redirectTo: '/chequeBookRequest',
	    pathMatch: 'full'
	}
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);