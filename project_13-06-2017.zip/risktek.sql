-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 13, 2017 at 01:55 PM
-- Server version: 5.6.24
-- PHP Version: 5.5.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `risktek`
--

-- --------------------------------------------------------

--
-- Table structure for table `master_data`
--

CREATE TABLE IF NOT EXISTS `master_data` (
  `id` int(11) NOT NULL,
  `description` varchar(600) NOT NULL,
  `code` varchar(500) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_data`
--

INSERT INTO `master_data` (`id`, `description`, `code`) VALUES
(1, 'xxxxx xxxxxx </br>\r\nxxxxxxx xxx , 79 xxxxx</br>\r\nxxxxxx , 88879</br>\r\nDUBAI', 'CONTACT_US'),
(2, '_assets/images/slider/contact-us.jpg', 'CONTACT_US_BANNER');

-- --------------------------------------------------------

--
-- Table structure for table `menu_list`
--

CREATE TABLE IF NOT EXISTS `menu_list` (
  `id` int(11) NOT NULL,
  `description` varchar(600) NOT NULL,
  `link` varchar(600) NOT NULL,
  `parent` int(11) NOT NULL,
  `position` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu_list`
--

INSERT INTO `menu_list` (`id`, `description`, `link`, `parent`, `position`) VALUES
(1, 'Home', '#page-top', 0, 1),
(2, 'About Us', '#about-us', 0, 2),
(3, 'Services', '#services', 0, 3),
(4, 'Corporate Profile', '#services', 0, 4),
(5, 'Career', '#testimonials', 0, 5),
(6, 'Contact Us', '#contact', 0, 6),
(7, 'Management Team', 'javascript:void(0);', 2, 1),
(8, 'Partners', 'javascript:void(0);', 2, 2),
(9, 'Testimonials', 'javascript:void(0);', 2, 3),
(10, 'News', 'javascript:void(0);', 2, 4),
(11, 'Nested Menu1', 'javascript:void(0);', 7, 1),
(12, 'Nested Menu2', 'javascript:void(0);', 7, 2),
(13, 'Nested Child3', 'javascript:void(0);', 7, 3);

-- --------------------------------------------------------

--
-- Table structure for table `slider_list`
--

CREATE TABLE IF NOT EXISTS `slider_list` (
  `id` int(11) NOT NULL,
  `slider_name` varchar(600) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `slider_url` varchar(600) NOT NULL,
  `position` int(11) NOT NULL,
  `action` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slider_list`
--

INSERT INTO `slider_list` (`id`, `slider_name`, `description`, `slider_url`, `position`, `action`) VALUES
(1, 'slider1', 'RISKTEK is a Leading Technology Consulting And Development Firm', '_assets/images/slider/slider5.jpg', 1, 'enable'),
(2, 'slider2', 'BANKING', '_assets/images/slider/slider4.jpg', 2, 'enable'),
(3, 'slider3', 'INSURANCE', '_assets/images/slider/slider6.jpg', 3, 'enable');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `master_data`
--
ALTER TABLE `master_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu_list`
--
ALTER TABLE `menu_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slider_list`
--
ALTER TABLE `slider_list`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `master_data`
--
ALTER TABLE `master_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `menu_list`
--
ALTER TABLE `menu_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `slider_list`
--
ALTER TABLE `slider_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
