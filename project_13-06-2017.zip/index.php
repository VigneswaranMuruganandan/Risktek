<?php include 'connection.php';?>
<!DOCTYPE html>
<html lang="en-US">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
  <!-- <title>Risktek - Solution Application - Risk consulting</title> -->
  <style type="text/css">
     img.wp-smiley,img.emoji 
     {
       display: inline !important;
       border: none !important;
       box-shadow: none !important;
       height: 1em !important;
       width: 1em !important;
       margin: 0 .07em !important;
       vertical-align: -0.1em !important;
       background: none !important;
       padding: 0 !important;
     }
  </style>
  <link rel='stylesheet' href='_assets/css/animate.css' type='text/css' media='all' />
  <link rel='stylesheet' href='_assets/css/font-awesome.min.css' type='text/css' media='all' />
  <link rel='stylesheet' href='_assets/css/bxslider.css' type='text/css' media='all' />
  <link rel='stylesheet' href='_assets/css/style.css' type='text/css' media='all' />
  <link rel='stylesheet' href='_assets/css/f-style.css' type='text/css' media='all' />
  <script type='text/javascript' src='_assets/js/jquery.js'></script>
  <script type='text/javascript' src='_assets/js/jquery-migrate.js'></script>
  <script type='text/javascript' src='_assets/js/classie.js'></script>
  <link rel="canonical" href="index.html" />
  <link rel='shortlink' href='index.html' />
  <style>
     #services{ background-color:#fff;  }
     .service-wrapper .svg-top-container { fill: #fff; }
     .team-wrapper #team{ background-color:#fff; }
     #latest-post{ background-color:#f7f7f7; }
     .post-wrapper .svg-top-container { fill: #f7f7f7; }
     #woo-section{ background-color:#fff }
     .woo-wrapper .svg-top-container { fill: #fff; }
     .testimonials { background-color:#1F1F1F; }
     .testimonials-wrapper .svg-top-container { fill: #1F1F1F; }
     .footer-wrapper .svg-top-container{ fill:#fff; }
     .foot-copyright .svg-top-container{ fill: #1F1F1F; }
     .footer{ background-color:#fff;}
     .foot-copyright { background-color:#1F1F1F; }
     #ribbon:before{ background:url(https://www.themehunk.com/wp-themes/oneline-lite/wp-content/uploads/sites/35/2017/04/ribbon.jpeg)}
  </style>
  <style type="text/css">
    .recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}
  </style>
</head>
<body id="page-top" class="home page-template page-template-home-template page-template-home-template-php page page-id-11 wp-custom-logo index"  >
   <?php
      $master_data = "SELECT * FROM master_data";
      $result_master_data = $conn->query($master_data);
   ?>
   <div class="overlayloader">
      <div class="loader">&nbsp;</div>
   </div>
   <div class="header"  id="header">
      <div class="container clearfix">
         <div id="logo">
            <!-- <a href="index.html" class="custom-logo-link" rel="home" itemprop="url">
              <img width="259" height="102" src="_assets/images/logo_1.0.png" class="custom-logo" alt="" itemprop="logo" />
            </a> -->          
         </div>
         <div id="main-menu-wrapper">
            <a href="javascript:void(0);" id="pull" class="toggle-mobile-menu"></a>
            <nav class="navigation clearfix mobile-menu-wrapper">
              <?php
                  echo "<ul id='menu' class='menu'>";
                      $menu_list = "SELECT * FROM menu_list WHERE parent = 0 ORDER BY position ASC";
                      $result_menu_list = $conn->query($menu_list);
                      if ($result_menu_list->num_rows > 0) {
                          while($row_list = $result_menu_list->fetch_assoc()) {
                              echo "<li class='menu-item menu-item-type-custom menu-item-object-custom'><a href='".$row_list["link"]."'>". $row_list["description"]."</a>";                            
                              $menu_childlist = "SELECT * FROM menu_list WHERE parent = ".$row_list["id"]." ORDER BY position ASC";
                              $result_menu_childlist= $conn->query($menu_childlist);
                              if ($result_menu_childlist->num_rows > 0) {
                                echo "<ul class='sub-menu'>";
                                while($row_childlist = $result_menu_childlist->fetch_assoc()) {
                                  echo "<li class='menu-item menu-item-type-post_type menu-item-object-page'><a class='page-scroll' href='".$row_childlist["link"]."'>".$row_childlist["description"]."</a>";                                 
                                  $menu_nestedchildlist = "SELECT * FROM menu_list WHERE parent = ".$row_childlist["id"]." ORDER BY position ASC";
                                  $result_menu_nestedchildlist = $conn->query($menu_nestedchildlist);
                                  if ($result_menu_nestedchildlist->num_rows > 0) {
                                    echo "<ul class='sub-menu'>";
                                    while($row_nestedchildlist = $result_menu_nestedchildlist->fetch_assoc()) {
                                        echo "<li class='menu-item menu-item-type-post_type menu-item-object-page'><a class='page-scroll' href='".$row_nestedchildlist["link"]."'>".$row_nestedchildlist["description"]."</a></li>";
                                    }
                                    echo "</ul>";
                                  }
                                  echo "</li>";
                                }
                                echo "</ul>";
                              }                              
                              echo "</li>";
                          }
                      }
                  echo "</ul>";
              ?>               
            </nav>
         </div>
      </div>
   </div>
   <div class="clearfix"></div>
   <div id="slider-div">
      <div class="slider">
         <div class="flexslider">
            <ul class="slides">
              <?php
                  /*$banner_list = "SELECT * FROM slider_list WHERE action = 'enable' ORDER BY position ASC";
                  $result_banner_list = $conn->query($banner_list);
                  if ($result_banner_list->num_rows > 0) {
                      while($row_banner = $result_banner_list->fetch_assoc()) {
                          echo "<li data-center='background-position: 50% 0px;' data-top-bottom='background-position: 50% -100px;' style='background:url(".$row_banner["slider_url"].");'>";
                          echo "<div class='over-lay'><div class='fs-caption wow fadeInDown' data-wow-delay='1s'>";
                          echo "<div class='caption-container' data-center='opacity: 1' data-106-top='opacity: 0' data-anchor-target='#slider-div h4'>";
                          echo "<h4 class='title overtext'>".$row_banner["description"]."</h4>";
                          echo "<div class='slider-button'><a href='javascript:void(0);' class='theme-slider-button'>More</a></div></div></div></div>";
                      }
                  }*/
              ?>              
            </ul>
         </div>
      </div>
   </div>
   <div class="clearfix"></div>
   <!-- -----ABOUT-US SECTION START------- -->
  <div class="about-us-wrapper">
     <section id="about-us" class="svg_enable" data-center="background-position: 50% 0px;" data-top-bottom="background-position: 50% -100px;" >
        <div class="container">
           <div class="page-about-us" >
              <h2 class="main-heading wow fadeInRight" data-wow-delay="0s">About Us</h2>
              <!-- <p class="sub-heading wow fadeInRight" data-wow-delay="0s">Subtitle Goes Here</p> -->
              <div class="about-us-block">
                 <div class="about-us-paragraph wow fadeInLeft" data-wow-delay="0s">
                    <p>Risktek is a leading technology consulting and development firm based in United Arab Emirates and is a regional provider of Enterprise Risk Management, Analytics and Capital Markets for various business segments and industries.</p>
                    <br/>
                    <p>Risktek addresses the Financial Risk Management requirement of Financial Institutions through a mixture of services and product offerings in managing the Credit, Market and Operational Risks. Risktek engagement model involves a combination of Consulting, Application Development and Implementation.</p>
                    <br/>
                    <p>Risktek's unique "Solution Approach" brings to institutions the methodology and tools to quantify and manage risk. Institutions not only require systems and tools that quantify and manage risks but also needs best practices, methodologies to implement solutions while implanting them that suit the institutional culture and work ethics and environmental framework.
                    </p>
                 </div>
              </div>


              <h2 class="main-heading wow fadeInRight margintop60" data-wow-delay="0s">VISION AND OBJECTIVE</h2>
              <div class="about-us-block">
                 <div class="about-us-paragraph wow fadeInLeft" data-wow-delay="0s">
                    <p>We aim to address the financial risk management requirements of institutions through a mixture of services and product offerings – on what we call as "Solutioning approach" to manage their risks</p>
                    <br/>
                    <p>Our unique "solutioning approach", brings to institutions the methodology and tools to quantify and manage those risk. Thecompanies not only require systems/ tools that needs to be implemented to manage the risks but also consulting on what is the best method of implementing given the operating environment that they have along with the future aspirations.</p>
                    <br/>
                    <p>We aim at quick turn-around time, demonstration of value add at each level and bring the best practices to the door steps of small and medium enterprises.</p>
                 </div>
              </div>              
           </div>
        </div>
     </section>
  </div>
  <div class="clearfix"></div>
  <!-- -----ABOUT-US SECTION END------- -->
   <div class="service-wrapper">
      <div class="svg-top-container">
         <svg xmlns="http://www.w3.org/2000/svg" width="0" version="1.1" viewBox="0 0 100 100" preserveAspectRatio="none">
            <path d="M0 100 L100 100 L100 2 L0 100 Z" stroke-width="0"></path>
         </svg>
      </div>
      <section id="services" class="svg_enable" data-center="background-position: 50% 0px;" data-top-bottom="background-position: 50% -100px;" >
         <div class="container">
            <div class="page-services">
               <h2 class="main-heading wow fadeInRight" data-wow-delay="0s">Our Services</h2>
               <p class="sub-heading wow fadeInRight" data-wow-delay="0s">RISKTEK IS A LEADING TECHNOLOGY CONSULTING AND DEVELOPMENT FIRM based in United Arab Emirates and is a regional rovider of Enterprise Risk Management, Governance and Compliance Management Solutions for the Financial Services Sector.</p>
               <div class="service-block">
                  <ul class="service-grid wow fadeInLeft" data-wow-delay="0s">
                     <li class="service-list">
                        <div class="service-icon"><a  href="javascript:void(0);"><i  class="fa fa-bank"></i></a></div>
                        <div class="service-title"><a href="javascript:void(0);">BANKING</a></div>
                        <div class="service-content">
                           <p >Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                        </div>
                     </li>
                     <li class="service-list">
                        <div class="service-icon"><a  href="javascript:void(0);"><i  class="fa fa-umbrella"></i></a></div>
                        <div class="service-title"><a href="javascript:void(0);">INSURANCE</a></div>
                        <div class="service-content">
                           <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                        </div>
                     </li>
                     <li class="service-list">
                        <div class="service-icon"><a  href="javascript:void(0);"><i  class="fa fa-bar-chart"></i></a></div>
                        <div class="service-title"><a href="javascript:void(0);">COMMODITY TRADING</a></div>
                        <div class="service-content">
                           <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                        </div>
                     </li>
                     <li class="service-list">
                        <div class="service-icon"><a  href="javascript:void(0);"><i  class="fa fa-money"></i></a></div>
                        <div class="service-title"><a href="javascript:void(0);">FINANCIAL SERVICES</a></div>
                        <div class="service-content">
                           <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                        </div>
                     </li>
                  </ul>
               </div>
            </div>
         </div>
      </section>
   </div>
   <div class="clearfix"></div>
   <!-- TEAM SECTION START -->
   <div class="team-wrapper">
      <section id="team" class="svg_enable" data-center="background-position: 50% 0px;" data-top-bottom="background-position: 50% -100px;">
         <div class="container">
            <div class="page-team">
               <h2 class="main-heading wow fadeInLeft" data-wow-delay="0s">Our Team </h2>
               <p class="sub-heading wow fadeInLeft" data-wow-delay="0s">We have a powerful &amp; hardworking team which works for you.</p>
               <div class="team-block">
                  <ul class="team-grid wow fadeInRight" data-wow-delay="0s">
                     <li class="team-list">
                        <figure class="team-content">
                           <img src="_assets/images/teams/team1.jpg">
                           <figcaption>
                              <a href="javascript:void(0);">
                                 <h3>John Smith</h3>
                              </a>
                              <h4>
                                 Co founder            
                              </h4>
                              <div class="team-social-meta">
                                 <ul>
                                    <li class="team-social-social"><a href="javascript:void(0);"><i  class="fa fa-facebook"></i></a></li>
                                    <li class="team-social-social"><a href="javascript:void(0);"><i  class="fa fa-twitter"></i></a></li>
                                    <li class="team-social-social"><a href="javascript:void(0);"><i  class="fa fa-linkedin"></i></a></li>
                                    <li class="team-social-social"><a href="javascript:void(0);"><i  class="fa fa-google"></i></a></li>
                                 </ul>
                              </div>
                           </figcaption>
                        </figure>
                     </li>
                     <li class="team-list">
                        <figure class="team-content">
                           <img src="_assets/images/teams/team2.jpg">
                           <figcaption>
                              <a href="javascript:void(0);">
                                 <h3>Mariya tennis</h3>
                              </a>
                              <h4>
                                 Manager            
                              </h4>
                              <div class="team-social-meta">
                                 <ul>
                                    <li class="team-social-social"><a href="javascript:void(0);"><i  class="fa fa-facebook"></i></a></li>
                                    <li class="team-social-social"><a href="javascript:void(0);"><i  class="fa fa-twitter"></i></a></li>
                                    <li class="team-social-social"><a href="javascript:void(0);"><i  class="fa fa-linkedin"></i></a></li>
                                    <li class="team-social-social"><a href="javascript:void(0);"><i  class="fa fa-google"></i></a></li>
                                 </ul>
                              </div>
                           </figcaption>
                        </figure>
                     </li>
                     <li class="team-list">
                        <figure class="team-content">
                           <img src="_assets/images/teams/team3.jpg">
                           <figcaption>
                              <a href="javascript:void(0);">
                                 <h3>John smith</h3>
                              </a>
                              <h4>
                                 Support Manager            
                              </h4>
                              <div class="team-social-meta">
                                 <ul>
                                    <li class="team-social-social"><a href="javascript:void(0);"><i  class="fa fa-facebook"></i></a></li>
                                    <li class="team-social-social"><a href="javascript:void(0);"><i  class="fa fa-twitter"></i></a></li>
                                    <li class="team-social-social"><a href="javascript:void(0);"><i  class="fa fa-linkedin"></i></a></li>
                                    <li class="team-social-social"><a href="javascript:void(0);"><i  class="fa fa-google"></i></a></li>
                                 </ul>
                              </div>
                           </figcaption>
                        </figure>
                     </li>
                     <li class="team-list">
                        <figure class="team-content">
                           <img src="_assets/images/teams/team4.jpg">
                           <figcaption>
                              <a href="javascript:void(0);">
                                 <h3>Mariya tennis</h3>
                              </a>
                              <h4>
                                 Hr manager            
                              </h4>
                              <div class="team-social-meta">
                                 <ul>
                                    <li class="team-social-social"><a href="javascript:void(0);"><i  class="fa fa-facebook"></i></a></li>
                                    <li class="team-social-social"><a href="javascript:void(0);"><i  class="fa fa-twitter"></i></a></li>
                                    <li class="team-social-social"><a href="javascript:void(0);"><i  class="fa fa-linkedin"></i></a></li>
                                    <li class="team-social-social"><a href="javascript:void(0);"><i  class="fa fa-google"></i></a></li>
                                 </ul>
                              </div>
                           </figcaption>
                        </figure>
                     </li>
                  </ul>
               </div>
            </div>
         </div>
      </section>
   </div>
   <div class="clearfix"></div>
   <input type="hidden" id="testimonial_slidespeed" value="3000"/>
   <div class="testimonials-wrapper">
      <div class="svg-top-container">
         <svg xmlns="http://www.w3.org/2000/svg" width="0" version="1.1" viewBox="0 0 100 100" preserveAspectRatio="none">
            <path d="M0 100 L100 100 L100 2 L0 100 Z" stroke-width="0"></path>
         </svg>
      </div>
      <section class="testimonials svg_enable" id="testimonials" data-center="background-position: 50% 0px;" data-top-bottom="background-position: 50% -100px;">
         <div class="container" >
            <div class="testimonials-box">
               <div class="testimonials-div">
                  <ul class="bxslider wow fadeInUp" data-wow-delay=".5s">
                     <li>
                        <div class="image-test wow fadeInLeft" data-wow-delay="0s">
                           <img src="_assets/images/test3.png">
                        </div>
                        <div class="test-cont-heading">
                           <h2>Alex</h2>
                        </div>
                        <div class="test-cont wow fadeInRight" data-wow-delay="0s">
                           <a href="javascript:void(0);">
                              <p>www.mywebsite.com</p>
                           </a>
                           <p>I develop lots of websites with a vaiety of themes….the support I have had from ThemeHunk has been first class. Very quick, good support and always ready to correct my css errors!. They have tweaked the theme for me and have been great. Great support guys</p>
                        </div>
                     </li>
                     <li>
                        <div class="image-test wow fadeInLeft" data-wow-delay="0s">
                           <img src="_assets/images/test2.png">
                        </div>
                        <div class="test-cont-heading">
                           <h2>Josh</h2>
                        </div>
                        <div class="test-cont wow fadeInRight" data-wow-delay="0s">
                           <a href="javascript:void(0);">
                              <p>www.abc.com</p>
                           </a>
                           <p>I’m having issues with receiving a message from the contact form. I can send it successfully but I’m not receiving the test message. I was told to change my email address and it works. Thank you ThemeHunk for the great service. Excellent!</p>
                        </div>
                     </li>
                     <li>
                        <div class="image-test wow fadeInLeft" data-wow-delay="0s">
                           <img src="_assets/images/test1.png">
                        </div>
                        <div class="test-cont-heading">
                           <h2>Maria</h2>
                        </div>
                        <div class="test-cont wow fadeInRight" data-wow-delay="0s">
                           <a href="javascript:void(0);">
                              <p>www.mywebsite.com</p>
                           </a>
                           <p>I am a newbie to WordPress, with limited html and css experience. The Themehunk team has been there every step of the way to help me make a web site that I am truly proud of, and have helped to make me a better developer in the process.</p>
                        </div>
                     </li>
                  </ul>
               </div>
            </div>
         </div>
      </section>
   </div>
   <div class="clearfix"></div>
   <!-- LATEST POST START-->
   <div class="post-wrapper">
      <div class="svg-top-container">
         <svg xmlns="http://www.w3.org/2000/svg" width="0" version="1.1" viewBox="0 0 100 100" preserveAspectRatio="none">
            <path d="M0 100 L100 100 L100 2 L0 100 Z" stroke-width="0"></path>
         </svg>
      </div>
   </div>
   <section id="latest-post" class="svg_enable" data-center="background-position: 50% 0px;" data-top-bottom="background-position: 50% -100px;">
      <div class="container">
         <div class="page-post">
            <h2 class="main-heading wow fadeInRight" data-wow-delay="0s">Latest Post</h2>
            <p class="sub-heading wow fadeInRight" data-wow-delay="0s">Your latest post displayed in a beautiful way and you can also customize it.</p>
            <div class="post-block">
               <ul class="post-grid wow fadeInLeft" data-wow-delay="0s">
                  <li class="post-list">
                     <figure class="post-content">
                        <a href="javascript:void(0);"> <img width="275" height="184" src="wp-content/uploads/sites/35/2017/01/oneline-lite-post-missed.jpg" class="attachment-oneline-lite-custom-blog size-oneline-lite-custom-blog wp-post-image" alt="" srcset="https://themehunk.com/wp-themes/oneline-lite/wp-content/uploads/sites/35/2017/01/oneline-lite-post-missed.jpeg 1280w, https://themehunk.com/wp-themes/oneline-lite/wp-content/uploads/sites/35/2017/01/oneline-lite-post-missed-300x200.jpeg 300w, https://themehunk.com/wp-themes/oneline-lite/wp-content/uploads/sites/35/2017/01/oneline-lite-post-missed-768x512.jpeg 768w, https://themehunk.com/wp-themes/oneline-lite/wp-content/uploads/sites/35/2017/01/oneline-lite-post-missed-1024x682.jpeg 1024w, https://themehunk.com/wp-themes/oneline-lite/wp-content/uploads/sites/35/2017/01/oneline-lite-post-missed-275x184.jpeg 275w" sizes="(max-width: 275px) 100vw, 275px" /></a>
                        <div class="date"><span class="day">06</span><span class="month">Jan</span></div>
                        <i class="fa fa-paper-plane-o"></i>
                        <figcaption>
                           <a href="2017/01/06/what-you-missing/index.html">
                              <h3>What you missing</h3>
                           </a>
                           <p>Fusce ac ante a dolor facilisis auctor. Pellentesque nunc orci, maximus eu</p>
                           <span class="read-more"><a href="2017/01/06/what-you-missing/index.html" >Read More</a></span>              
                        </figcaption>
                     </figure>
                  </li>
                  <li class="post-list">
                     <figure class="post-content">
                        <a href="2017/01/06/street-tell-me/index.html"> <img width="275" height="184" src="wp-content/uploads/sites/35/2017/01/oneline-lite-post-street.jpg" class="attachment-oneline-lite-custom-blog size-oneline-lite-custom-blog wp-post-image" alt="" srcset="https://themehunk.com/wp-themes/oneline-lite/wp-content/uploads/sites/35/2017/01/oneline-lite-post-street.jpg 1280w, https://themehunk.com/wp-themes/oneline-lite/wp-content/uploads/sites/35/2017/01/oneline-lite-post-street-300x200.jpg 300w, https://themehunk.com/wp-themes/oneline-lite/wp-content/uploads/sites/35/2017/01/oneline-lite-post-street-768x512.jpg 768w, https://themehunk.com/wp-themes/oneline-lite/wp-content/uploads/sites/35/2017/01/oneline-lite-post-street-1024x683.jpg 1024w, https://themehunk.com/wp-themes/oneline-lite/wp-content/uploads/sites/35/2017/01/oneline-lite-post-street-275x184.jpg 275w" sizes="(max-width: 275px) 100vw, 275px" /></a>
                        <div class="date"><span class="day">06</span><span class="month">Jan</span></div>
                        <i class="fa fa-paper-plane-o"></i>
                        <figcaption>
                           <a href="2017/01/06/street-tell-me/index.html">
                              <h3>Street tell me</h3>
                           </a>
                           <p>Fusce ac ante a dolor facilisis auctor. Pellentesque nunc orci, maximus eu</p>
                           <span class="read-more"><a href="2017/01/06/street-tell-me/index.html" >Read More</a></span>              
                        </figcaption>
                     </figure>
                  </li>
                  <li class="post-list">
                     <figure class="post-content">
                        <a href="2017/01/06/near-to-nature/index.html"> <img width="275" height="155" src="wp-content/uploads/sites/35/2017/01/oneline-post-nature.jpg" class="attachment-oneline-lite-custom-blog size-oneline-lite-custom-blog wp-post-image" alt="oneline lite" srcset="https://themehunk.com/wp-themes/oneline-lite/wp-content/uploads/sites/35/2017/01/oneline-post-nature.jpg 1600w, https://themehunk.com/wp-themes/oneline-lite/wp-content/uploads/sites/35/2017/01/oneline-post-nature-300x169.jpg 300w, https://themehunk.com/wp-themes/oneline-lite/wp-content/uploads/sites/35/2017/01/oneline-post-nature-768x432.jpg 768w, https://themehunk.com/wp-themes/oneline-lite/wp-content/uploads/sites/35/2017/01/oneline-post-nature-1024x576.jpg 1024w" sizes="(max-width: 275px) 100vw, 275px" /></a>
                        <div class="date"><span class="day">06</span><span class="month">Jan</span></div>
                        <i class="fa fa-paper-plane-o"></i>
                        <figcaption>
                           <a href="2017/01/06/near-to-nature/index.html">
                              <h3>Near to nature</h3>
                           </a>
                           <p>Fusce ac ante a dolor facilisis auctor. Pellentesque nunc orci, maximus eu</p>
                           <span class="read-more"><a href="2017/01/06/near-to-nature/index.html" >Read More</a></span>              
                        </figcaption>
                     </figure>
                  </li>
                  <li class="post-list">
                     <figure class="post-content">
                        <a href="2017/01/06/she-like-my-beard/index.html"> <img width="275" height="184" src="wp-content/uploads/sites/35/2017/01/oneline-lite-post.jpg" class="attachment-oneline-lite-custom-blog size-oneline-lite-custom-blog wp-post-image" alt="" srcset="https://themehunk.com/wp-themes/oneline-lite/wp-content/uploads/sites/35/2017/01/oneline-lite-post.jpeg 1920w, https://themehunk.com/wp-themes/oneline-lite/wp-content/uploads/sites/35/2017/01/oneline-lite-post-300x200.jpeg 300w, https://themehunk.com/wp-themes/oneline-lite/wp-content/uploads/sites/35/2017/01/oneline-lite-post-768x512.jpeg 768w, https://themehunk.com/wp-themes/oneline-lite/wp-content/uploads/sites/35/2017/01/oneline-lite-post-1024x683.jpeg 1024w, https://themehunk.com/wp-themes/oneline-lite/wp-content/uploads/sites/35/2017/01/oneline-lite-post-275x184.jpeg 275w" sizes="(max-width: 275px) 100vw, 275px" /></a>
                        <div class="date"><span class="day">06</span><span class="month">Jan</span></div>
                        <i class="fa fa-paper-plane-o"></i>
                        <figcaption>
                           <a href="2017/01/06/she-like-my-beard/index.html">
                              <h3>She like my beard</h3>
                           </a>
                           <p>Fusce ac ante a dolor facilisis auctor. Pellentesque nunc orci, maximus eu</p>
                           <span class="read-more"><a href="2017/01/06/she-like-my-beard/index.html" >Read More</a></span>              
                        </figcaption>
                     </figure>
                  </li>
               </ul>
            </div>
         </div>
      </div>
   </section>
   </div>
   <!-- LATEST POST END -->
   <div class="clearfix"></div>
   <!-- LATEST POST START-->
   </div>
   <!-- LATEST POST END -->
   <div class="clearfix"></div>
   <div class="contact-wrapper">
      <section id="contact" class="" data-center="background-position: 50% 0px;" data-top-bottom="background-position: 50% -100px;" >
         <div class="container">
            <div class="page-contact">
               <h2 class="cnt-main-heading">Contact us</h2>
               <p class="cnt-sub-heading">Being in contact is become very easy. Our Contact Form is will help you in generating leads.</p>
               <p>
                 <?php
                   if ($result_master_data->num_rows > 0) {
                      while($row_master = $result_master_data->fetch_assoc()) {
                          if($row_master["code"] == "CONTACT_US_BANNER"){
                              echo "<img src='".$row_master["description"]."' width='80%'>";
                          }
                      }
                    }
                  ?>  
                </p>


               <div class="contact-block ">
                  <div class="addrs wow fadeInLeft" data-wow-delay="0s">
                     <div class="add-heading">
                        <h3>Address</h3>
                     </div>
                     <p>
                     <?php
                       if ($result_master_data->num_rows > 0) {
                          while($row_master = $result_master_data->fetch_assoc()) {
                              if($row_master["code"] == "CONTACT_US"){
                                echo $row_master["description"];
                              }
                          }
                        }
                      ?>          
                     </p>
                  </div>
                  <div class="addrs googlemap wow fadeInLeft" data-wow-delay="0s" id="map">
                    <script>
                      function initMap() {
                        var uluru = {lat: 24.490423, lng: 54.362855};
                        var map = new google.maps.Map(document.getElementById('map'), {
                          zoom:16,
                          center: uluru
                        });
                        var marker = new google.maps.Marker({
                          position: uluru,
                          map: map
                        });
                      }
                    </script>
                    <script async defer
                    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBcKKlF0HVLQO43v5I5j8mFXeSOeNxuwfs&callback=initMap">
                    </script>
                  </div>
                  <div class="cnt-div  wow fadeInRight" data-wow-delay="0s">
                     <div class="leadform-show-form medium lf-form-default leadform-lite">
                        <form action="#" method="post" class="lead-form-front" id="form_1" enctype="multipart/form-data">
                           <h1>Contact Us</h1>
                           <div class="name-type lf-field"><label>Name</label>
                              <span><input id="1" type="text" name="Name" class="lf-form-name" value="" required placeholder="Name" />
                              </span>
                           </div>
                           <div class="text-type lf-field"><label>Email</label>
                              <span><input id="2" type="email" class="lf-form-text " name="Email" required value="" placeholder="Email" />
                              </span>
                           </div>
                           <div class="text-type lf-field"><label>Contact No</label>
                              <span><input id="3" type="number" class="lf-form-text " name="Contact No" required value="" placeholder="Contact number" />
                              </span>
                           </div>
                           <div class="textarea-type lf-field"><label>Message</label>
                              <span><textarea id="4" name="Message" class="lf-form-textarea" value="Message" placeholder="Message" required></textarea>
                              </span>
                           </div>
                           <div class="lf-form-panel">
                              <div class="submit-type lf-field"><label><input id="0" class="lf-form-submit" type="submit" name="submit" value="Submit"/>
                                 </label>
                              </div>
                           </div>
                           <div class="leadform-show-loading front-loading leadform-show-message-form-1"></div>
                           <div class="lf-loading"><img src="_assets/images/load.gif" style="display: none;" id="loading_image"></div>
                        </form>
                     </div>
                  </div>
               </div>
            </div>
         </div>
   </div>
   </section>
   </div>
   <div class="clearfix"></div>
   <div class="footer-wrapper">
      <!-- Footer wrapper start -->
   </div>
   <div class="foot-copyright">
   <div class="svg-top-container">
      <svg xmlns="http://www.w3.org/2000/svg" width="0" version="1.1" viewBox="0 0 100 100" preserveAspectRatio="none">
         <path d="M0 100 L100 100 L100 2 L0 100 Z" stroke-width="0"></path>
      </svg>
   </div>
   <span class="text-footer">
   <!-- <a href="javascript:void(0);"> Powered by webvizards.com</a> -->
   </span>
   <div class="social-ft">
   <ul>
      <li><a target='_blank' href="javascript:void(0);" ><i class='fa fa-facebook'></i></a></li>
      <li><a target='_blank' href="javascript:void(0);" ><i class='fa fa-google-plus'></i></a></li>
      <li><a target='_blank' href="javascript:void(0);" ><i class='fa fa-linkedin'></i></a></li>
      <li><a target='_blank' href="javascript:void(0);" ><i class='fa fa-pinterest'></i></a></li>
      <li><a target='_blank' href="javascript:void(0);" ><i class='fa fa-twitter'></i></a></li>
   </ul>
   <div>
   </div>
<script type='text/javascript' src='_assets/js/wow.js'></script>
<script type='text/javascript' src='_assets/js/jquery.flexslider.js'></script>
<script type='text/javascript' src='_assets/js/jquery.bxslider.js'></script>
<script type='text/javascript' src='_assets/js/skrollr.js'></script>
<script type='text/javascript' src='_assets/js/imagesloaded.js'></script>
<script type='text/javascript' src='_assets/js/custom.js'></script>
<script type='text/javascript' src='_assets/js/wp-embed.min66f2.js'></script>
<a href="javascript:void(0);" id="scroll" title="Scroll to Top" style="display: none;"><span></span></a>
</body>
</html>