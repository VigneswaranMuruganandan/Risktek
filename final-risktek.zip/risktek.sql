-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 03, 2017 at 03:26 PM
-- Server version: 5.6.24
-- PHP Version: 5.5.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `risktek`
--

-- --------------------------------------------------------

--
-- Table structure for table `master_data`
--

CREATE TABLE IF NOT EXISTS `master_data` (
  `id` int(11) NOT NULL,
  `description` varchar(600) NOT NULL,
  `code` varchar(500) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_data`
--

INSERT INTO `master_data` (`id`, `description`, `code`) VALUES
(1, 'P.O.Box 334155 </br>Level-14,Boulevard PlazaTower 1, </br>Dubai, United Arab Emirates </br><i class="fa fa-envelope" aria-hidden="true"></i> satya.tripathy@risktek.co</br><i class="fa fa-mobile" aria-hidden="true"></i> +971 555781708 </br><i class="fa fa-phone" aria-hidden="true"></i> +971 04 424 5134</br><i class="fa fa-fax" aria-hidden="true"></i> +971 04 455 8556 </br>', 'CONTACT_US'),
(2, '_assets/images/slider/contact-us.jpg', 'CONTACT_US_BANNER');

-- --------------------------------------------------------

--
-- Table structure for table `menu_list`
--

CREATE TABLE IF NOT EXISTS `menu_list` (
  `id` int(11) NOT NULL,
  `description` varchar(600) NOT NULL,
  `link` varchar(600) NOT NULL,
  `parent` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  `module` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu_list`
--

INSERT INTO `menu_list` (`id`, `description`, `link`, `parent`, `position`, `module`) VALUES
(1, 'About US', '#about-us', 0, 1, 'YES'),
(2, 'Solutions', '#services', 0, 2, 'YES'),
(3, 'Innovation Lab\r\n', 'javascript:void(0);', 0, 3, 'NO'),
(4, 'Reach US\r\n', '#contact', 0, 4, 'YES'),
(5, 'Our Team', '#team', 1, 1, 'NO'),
(6, 'Mission and  Vision', 'javascript:void(0);', 1, 2, 'NO'),
(7, 'Services', '#services', 2, 1, 'YES'),
(8, 'Products', '#products', 2, 2, 'YES'),
(9, 'Careers', 'careers.php', 4, 1, 'NO'),
(10, 'Location', '#map', 4, 2, 'NO'),
(11, 'Analytics', '#services', 7, 1, 'NO'),
(12, 'Capital Markets\r\n', '#services', 7, 2, 'NO'),
(13, 'Risk Management\r\n', '#services', 7, 3, 'NO'),
(14, 'Payment Solution', '#products', 8, 1, 'NO'),
(15, 'Remittance', '#products', 8, 2, 'NO'),
(16, 'Vendor & Channel', '#products', 8, 3, 'NO'),
(17, 'Financing', '#products', 8, 4, 'NO');

-- --------------------------------------------------------

--
-- Table structure for table `products_list`
--

CREATE TABLE IF NOT EXISTS `products_list` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` varchar(500) NOT NULL,
  `parent` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products_list`
--

INSERT INTO `products_list` (`id`, `name`, `description`, `parent`) VALUES
(1, 'Payment_Solution', 'Our Fintech Solution on payment system covers the consumer and the ecommerce market. The solution brings a different way of doing the same thing, which is fast, secure and cost efficient. Innovation is the corner stone of the solution.', '0'),
(2, 'Remittance', 'Real time transaction covering multiple jurisdiction with compliance and security.', '0'),
(3, 'Vendor_and_Channel_Financing', 'Building the ecosystem and market making for the Small and Medium Enterprises.', '0');

-- --------------------------------------------------------

--
-- Table structure for table `services_list`
--

CREATE TABLE IF NOT EXISTS `services_list` (
  `id` int(11) NOT NULL,
  `name` varchar(500) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `parent` varchar(500) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `services_list`
--

INSERT INTO `services_list` (`id`, `name`, `description`, `parent`) VALUES
(1, 'Big Data', 'Business cases to demonstrate value creation through big data analytics. Increased focus on risk management, account churning and value-added services.', 'Analytics'),
(2, 'Reporting', 'Unified reporting, dashboard creation, risk treatment plan measurement and monitoring, BCBS 239 framework and IFRS 9 reporting.', 'Analytics'),
(3, 'Framework (Governance)', 'Development of the risk management framework, quantifiable and measurable matrix for effective treatment (measurement, mitigant, monitoring and reporting) of the risks covering the financial and non-financial risk. Our risk management framework is developed on the basis of ISO31000 standards and such other industry standards that we tweaked to the need of your organization.', 'Risk_Management'),
(4, 'Process', 'The process of risk management is identification, measurement, treatment, feedback and reporting which is based on the "Risk Ownership", "Risk control" and "Risk Assurance". Through our proven methodology we cover both, Financial risk and Non-financial risk. The financial risk consists of Credit Risk, Market Risk, Liquidity Risk. The non-financial risk consists of Security Risk, IT Systems Risk, Human Resources Risk, Operational Control Risk, Project Risk, Business Disruption Risk, Compliances and Business Practices Risk, Legal Risk and Analytical and Policy Risk. Our Risk treatment consists of setting matrices for the Key Risk Indicators, Key Performance Indicators and measurement of the same. Our Governance, Risk and Compliance (GRC) solution takes a holistic enterprise-wide risk management approach.', 'Risk_Management'),
(5, 'Risk_Management', 'Our capital market solutions cover "Price distribution & ecommerce", "Market Risk Modeling", "Counterparty Credit risk", "Asset Liability Management", "Back office Reconciliation", & "Compliance". Our Solution Partners regularly features in the list of "magic quadrants" and best in industry lists. We Design, Implement and Support Solutions.', '0'),
(6, 'Capital_Market', 'we view Risk Management for any organization a culmination of the Governance (framework) &Process. We partner with you and work closely on these three aspects.', '0');

-- --------------------------------------------------------

--
-- Table structure for table `slider_list`
--

CREATE TABLE IF NOT EXISTS `slider_list` (
  `id` int(11) NOT NULL,
  `slider_name` varchar(600) NOT NULL,
  `header` varchar(400) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `title` varchar(500) NOT NULL,
  `slider_url` varchar(600) NOT NULL,
  `position` int(11) NOT NULL,
  `action` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slider_list`
--

INSERT INTO `slider_list` (`id`, `slider_name`, `header`, `description`, `title`, `slider_url`, `position`, `action`) VALUES
(1, 'slider1', 'Innovation', 'we believe innovation is enormously important. It is the only insurance against irrelevance and guarantee to long term stakeholder loyalty. At risktek, we practice innovation as a strategy,thereby devising business models and creating new markets.', 'Innovation', '_assets/images/slider/slider1.jpg', 1, 'enable'),
(2, 'slider2', 'Team Work', 'At Risktek, we strive towards the common goal of innovation and stakeholder value creation. It’s the team that creates the value.', 'Team Work', '_assets/images/slider/slider2.jpg', 2, 'enable'),
(3, 'slider3', 'Focus', 'we are niche player working with the industries and subject matter that we understand. Banking, Financial Services, Insurance.', 'Focus', '_assets/images/slider/slider3.jpg', 3, 'enable');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `master_data`
--
ALTER TABLE `master_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu_list`
--
ALTER TABLE `menu_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products_list`
--
ALTER TABLE `products_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services_list`
--
ALTER TABLE `services_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slider_list`
--
ALTER TABLE `slider_list`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `master_data`
--
ALTER TABLE `master_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `menu_list`
--
ALTER TABLE `menu_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `products_list`
--
ALTER TABLE `products_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `services_list`
--
ALTER TABLE `services_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `slider_list`
--
ALTER TABLE `slider_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
