<?php
include("connection.php");
$string = ''; 


if($_POST['serviceId'])
{
    $ServiceDetails = "SELECT * FROM services_list WHERE name='".$_POST['serviceId']."' and parent = '0'";
    $result_ServiceDetails = $conn->query($ServiceDetails);
    if ($result_ServiceDetails->num_rows > 0) {
        while($row_ServiceDetails = $result_ServiceDetails->fetch_assoc()) {
            $string = $string . "<p>".$row_ServiceDetails['description']."</p>";
            $ServiceDetailsChild = "SELECT * FROM services_list WHERE parent='".$_POST['serviceId']."'";
            $result_ServiceDetailsChild = $conn->query($ServiceDetailsChild);
            if ($result_ServiceDetailsChild->num_rows > 0) {        
                while($row_ServiceDetailsChild = $result_ServiceDetailsChild->fetch_assoc()) {
                    $string = $string . "<h6 class='main-heading'>".$row_ServiceDetailsChild['name']."</h6>";
                    $string = $string . "<ul>";
                    $string = $string . "<li>".$row_ServiceDetailsChild['description']."</li>";
                    $string = $string . "</ul>";
                }
            }
        }
    }else{
        $ServiceDetailsChild = "SELECT * FROM services_list WHERE parent='".$_POST['serviceId']."'";
        $result_ServiceDetailsChild = $conn->query($ServiceDetailsChild);
        if ($result_ServiceDetailsChild->num_rows > 0) {        
            while($row_ServiceDetailsChild = $result_ServiceDetailsChild->fetch_assoc()) {
                $string = $string . "<h6 class='main-heading'>".$row_ServiceDetailsChild['name']."</h6>";
                $string = $string . "<ul>";
                $string = $string . "<li>".$row_ServiceDetailsChild['description']."</li>";
                $string = $string . "</ul>";
            }
            
        }
    }
    echo $string;
}  
?>          

