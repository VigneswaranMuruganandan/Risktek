<?php
include("connection.php");
$string = ''; 


if($_POST['productId'])
{
    $ProductDetails = "SELECT * FROM products_list WHERE name='".$_POST['productId']."' and parent = '0'";
    $result_ProductDetails = $conn->query($ProductDetails);
    if ($result_ProductDetails->num_rows > 0) {
        while($row_ProductDetails = $result_ProductDetails->fetch_assoc()) {
            $string = $string . "<p>".$row_ProductDetails['description']."</p>";           
        }
    }
    echo $string;
}  
?>          

