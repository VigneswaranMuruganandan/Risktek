<?php include 'connection.php';?>
<!DOCTYPE html>
<html lang="en-US">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
  <title>Risktek - Solution Application - Risk consulting</title>
  <style type="text/css">
     img.wp-smiley,img.emoji 
     {
       display: inline !important;
       border: none !important;
       box-shadow: none !important;
       height: 1em !important;
       width: 1em !important;
       margin: 0 .07em !important;
       vertical-align: -0.1em !important;
       background: none !important;
       padding: 0 !important;
     }
     .g-recaptcha{    display: inline-block; float: left;}
     .home #contact .leadform-show-form input[type="submit"]{
        margin: 35px 0px 0px 0px !important;
        font-size: 14px !important;
        padding: 0px 45px !important;
        background: #f68933 !important;
        border: none !important;
     }
     .home #contact .leadform-show-form input, .home #contact .leadform-show-form .select-type select{
      height: 40px !important;
     }
  </style>
  <link rel='stylesheet' href='_assets/css/animate.css' type='text/css' media='all' />
  <link rel='stylesheet' href='_assets/css/font-awesome.min.css' type='text/css' media='all' />
  <link rel='stylesheet' href='_assets/css/bxslider.css' type='text/css' media='all' />
  <link rel='stylesheet' href='_assets/css/style.css' type='text/css' media='all' />
  <link rel='stylesheet' href='_assets/css/f-style.css' type='text/css' media='all' />
  <script type='text/javascript' src='_assets/js/jquery.js'></script>
  <script type='text/javascript' src='_assets/js/jquery-migrate.js'></script>
  <script type='text/javascript' src='_assets/js/classie.js'></script>
  <script src='https://www.google.com/recaptcha/api.js'></script>
  <link rel="canonical" href="index.html" />
  <link rel='shortlink' href='index.html' />
  <style>
     #services{ background-color:#fff;  }
     .service-wrapper .svg-top-container { fill: #fff; }
     .team-wrapper #team{ background-color:#fff; }
     #latest-post{ background-color:#f7f7f7; }
     .post-wrapper .svg-top-container { fill: #f7f7f7; }
     #woo-section{ background-color:#fff }
     .woo-wrapper .svg-top-container { fill: #fff; }
     .testimonials { background-color:#1F1F1F; }
     .testimonials-wrapper .svg-top-container { fill: #1F1F1F; }
     .footer-wrapper .svg-top-container{ fill:#fff; }
     .foot-copyright .svg-top-container{ fill: #1F1F1F; }
     .footer{ background-color:#fff;}
     .foot-copyright { background-color:#1F1F1F; }
     #ribbon:before{ background:url(https://www.themehunk.com/wp-themes/oneline-lite/wp-content/uploads/sites/35/2017/04/ribbon.jpeg)}
  </style>
  <style type="text/css">
    .recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}
  </style>
</head>
<body id="page-top" class="home page-template page-template-home-template page-template-home-template-php page page-id-11 wp-custom-logo index"  >
   <div class="overlayloader">
      <div class="loader">&nbsp;</div>
   </div>
   <div class="header"  id="header">
      <div class="container clearfix">
         <div id="logo">
            <a href="index.html" class="custom-logo-link" rel="home" itemprop="url">
              <img width="180" height="60" src="_assets/images/logo_1.0.png" class="custom-logo" alt="" itemprop="logo" />
            </a>          
         </div>
      </div>
   </div>
   <div class="clearfix"></div>
   <!-- -----ABOUT-US SECTION START------- -->
  <div class="about-us-wrapper">
     <section id="career" class="svg_enable paddingTop57 paddingBottom60" data-center="background-position: 50% 0px;" data-top-bottom="background-position: 50% -100px;" >
        <div class="container">
          <div class='career-heading'>
            <h2>CAREERS</h2>
            <img src="_assets/images/careers-banner.jpg">
          </div>
           <div class="career-about-us" >
              <h6 class="main-heading wow fadeInRight" data-wow-delay="0s">The Risktek Advantage</h6>
              <div class="about-us-block paddingTop0">
                 <div class="career-paragraph wow fadeInLeft" data-wow-delay="0s">
                    <p>We are performance driven, fast paced organization  constantly looking for individuals with right attitude, who aspire  to make a difference and thrive on change, if this is what motivates you,then Risktek is the place for you to grow At Risktek you will get to work, learn and grow with a team of talented, enthusiastic professionals for a reputed financial institution.</p>
                 </div>
              </div>
              <h6 class="main-heading wow fadeInRight margintop5" data-wow-delay="0s">Opportunities</h6>
              <div class="about-us-block paddingTop0">
                 <div class="career-paragraph wow fadeInLeft" data-wow-delay="0s">
                    <p></p>
                    <p> With multiple assignments  and domains to choose from, Risktek provides opportunities to succeed in a dynamic and challenging work environment.</p>
                 </div>
              </div>
              <h6 class="main-heading wow fadeInRight margintop5 " data-wow-delay="0s">Org Structure</h6>
              <div class="about-us-block paddingTop0 paddingBottom30">
                 <div class="career-paragraph wow fadeInLeft" data-wow-delay="0s">
                    <p></p>
                    <p>Our goal is to create teams that are driven to get results based not solely on the influences of leadership, but more so on being accountable to peers. In that regard, we do not create complex hierarchies, We believe in a flat organizational structure within the company to achieve awesome results.</p>
                 </div>
              </div>              
           </div>



        <div class='career-accordin'>
        <button class="accordion"><b>Credit Risk Modelling</b>  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  SaS - United Arab Emirates | 4 yrs to 8 yrs</button>
        <div class="panel">
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
        </div>

        <button class="accordion"><b>Credit Risk Modelling</b>  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  SaS - United Arab Emirates | 3 yrs to 6 yrs</button>
        <div class="panel">
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
        </div>

        <button class="accordion"><b>Credit Risk Modelling</b>  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  SaS - United Arab Emirates | 0 yrs to 2 yrs</button>
        <div class="panel">
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
        </div>
        </div>


        </div>
     </section>
  </div>
  <div class="clearfix"></div>
  <!-- -----ABOUT-US SECTION END------- -->
 <!--   <div class="service-wrapper">
      <div class="svg-top-container">
         <svg xmlns="http://www.w3.org/2000/svg" width="0" version="1.1" viewBox="0 0 100 100" preserveAspectRatio="none">
            <path d="M0 100 L100 100 L100 2 L0 100 Z" stroke-width="0"></path>
         </svg>
      </div>
   </div> -->
   <!-- LATEST POST END -->
   <div class="clearfix"></div>
   <div class="contact-wrapper">
      <section id="contact" class="paddingTop57" data-center="background-position: 50% 0px;" data-top-bottom="background-position: 50% -100px;" >
         <div class="container">
            <div class="page-contact">
               <h5 class="cnt-main-heading">Submit your application</h5>
               <p class="cnt-sub-heading">Incase you don't find jobs matching your relevant profile, please send us your profile and you would be notified for future openings.</p>
               
               <div class="contact-block">
                  <div class="contact-form  wow fadeInRight" data-wow-delay="0s">
                     <div class="leadform-show-form medium lf-form-default leadform-lite">
                        <form action="#" method="post" class="lead-form-front" id="form_1" enctype="multipart/form-data">
                           <h1>Contact Us</h1>
                           <div class="name-type lf-field"><label>Name</label>
                              <span><input id="1" type="text" name="Name" class="lf-form-name" value="" required placeholder="Name" />
                              </span>
                           </div>
                           <div class="text-type lf-field"><label>Email ID</label>
                              <span><input id="2" type="email" class="lf-form-text " name="Email" required value="" placeholder="Email ID" />
                              </span>
                           </div>

                           <div class="text-type lf-field"><label>Positions</label>
                              <span class="">
                                <select>
                                    <option value="" selected="selected">Select Positions</option>
                                    <option value="0" >Credit Risk Modelling | 4 yrs to 8 yrs</option>
                                    <option value="1" >Credit Risk Modelling | 3 yrs to 6 yrs</option>
                                    <option value="2" >Credit Risk Modelling | 0 yrs to 2 yrs</option>
                                    <option value="Others" >Others</option>
                                </select> 
                              </span>
                           </div>
                           <div class="text-type lf-field"><label>Experience in years</label>
                              <span><input id="3" type="number" class="lf-form-text " name="Contact No" required value="" placeholder="Experience in years" />
                              </span>
                           </div>
                           <div class="custom-file-upload">
                                <input type="file" id="file" name="myfiles[]" multiple />
                            </div>
                           <div class="textarea-type lf-field"><label>Comment</label>
                              <span><textarea id="4" name="Comment" class="lf-form-textarea" value="Comment" placeholder="Comment" required></textarea>
                              </span>
                           </div>
                           <div class="text-type lf-field">
                              <div class="g-recaptcha" data-sitekey="6LcR1yUUAAAAAJPaQMdC9_JovnPcEMfYZZGUGOAU"></div>
                           </div>
                           <div class="lf-form-panel">
                              <div class="submit-type lf-field"><label><input id="0" class="lf-form-submit" type="submit" name="submit" value="Submit"/>
                                 </label>
                              </div>
                           </div>
                           
                           <div class="leadform-show-loading front-loading leadform-show-message-form-1"></div>
                           <div class="lf-loading"><img src="_assets/images/load.gif" style="display: none;" id="loading_image"></div>
                        </form>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
   </div>
   <div class="clearfix"></div>
   <div class="footer-wrapper">
      <!-- Footer wrapper start -->
   </div>
   <div class="foot-copyright">
   <div class="svg-top-container">
      <svg xmlns="http://www.w3.org/2000/svg" width="0" version="1.1" viewBox="0 0 100 100" preserveAspectRatio="none">
         <path d="M0 100 L100 100 L100 2 L0 100 Z" stroke-width="0"></path>
      </svg>
   </div>
   <span class="text-footer">
   <!-- <a href="javascript:void(0);"> Powered by webvizards.com</a> -->
   </span>
   <div class="social-ft">
   <ul>
      <li><a target='_blank' href="javascript:void(0);" ><i class='fa fa-facebook'></i></a></li>
      <li><a target='_blank' href="javascript:void(0);" ><i class='fa fa-google-plus'></i></a></li>
      <li><a target='_blank' href="javascript:void(0);" ><i class='fa fa-linkedin'></i></a></li>
      <li><a target='_blank' href="javascript:void(0);" ><i class='fa fa-pinterest'></i></a></li>
      <li><a target='_blank' href="javascript:void(0);" ><i class='fa fa-twitter'></i></a></li>
   </ul>
   <div>
   </div>
<script type='text/javascript' src='_assets/js/wow.js'></script>
<script type='text/javascript' src='_assets/js/jquery.flexslider.js'></script>
<script type='text/javascript' src='_assets/js/jquery.bxslider.js'></script>
<script type='text/javascript' src='_assets/js/skrollr.js'></script>
<script type='text/javascript' src='_assets/js/imagesloaded.js'></script>
<script type='text/javascript' src='_assets/js/custom.js'></script>
<script type='text/javascript' src='_assets/js/wp-embed.min66f2.js'></script>
<a href="javascript:void(0);" id="scroll" title="Scroll to Top" style="display: none;"><span></span></a>
</body>
</html>