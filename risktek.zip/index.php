<?php include 'connection.php';?>
<!DOCTYPE html>
<html lang="en-US">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
  <title>Risktek - Solution Application - Risk consulting</title>
  <style type="text/css">
     img.wp-smiley,img.emoji 
     {
       display: inline !important;
       border: none !important;
       box-shadow: none !important;
       height: 1em !important;
       width: 1em !important;
       margin: 0 .07em !important;
       vertical-align: -0.1em !important;
       background: none !important;
       padding: 0 !important;
     }
  </style>
  <link rel='stylesheet' href='_assets/css/animate.css' type='text/css' media='all' />
  <link rel='stylesheet' href='_assets/css/font-awesome.min.css' type='text/css' media='all' />
  <link rel='stylesheet' href='_assets/css/bxslider.css' type='text/css' media='all' />
  <link rel='stylesheet' href='_assets/css/style.css' type='text/css' media='all' />
  <link rel='stylesheet' href='_assets/css/f-style.css' type='text/css' media='all' />
  <script type='text/javascript' src='_assets/js/jquery.js'></script>
  <script type='text/javascript' src='_assets/js/jquery-migrate.js'></script>
  <script type='text/javascript' src='_assets/js/classie.js'></script>
  <link rel="canonical" href="index.html" />
  <link rel='shortlink' href='index.html' />
  <style>
     #services{ background-color:#fff;  }
     .service-wrapper .svg-top-container { fill: #fff; }
     .team-wrapper #team{ background-color:#fff; }
     #latest-post{ background-color:#f7f7f7; }
     .post-wrapper .svg-top-container { fill: #f7f7f7; }
     #woo-section{ background-color:#fff }
     .woo-wrapper .svg-top-container { fill: #fff; }
     .testimonials { background-color:#1F1F1F; }
     .testimonials-wrapper .svg-top-container { fill: #1F1F1F; }
     .footer-wrapper .svg-top-container{ fill:#fff; }
     .foot-copyright .svg-top-container{ fill: #1F1F1F; }
     .footer{ background-color:#fff;}
     .foot-copyright { background-color:#1F1F1F; }
     #ribbon:before{ background:url(https://www.themehunk.com/wp-themes/oneline-lite/wp-content/uploads/sites/35/2017/04/ribbon.jpeg)}
  </style>
  <style type="text/css">
    .recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}
  </style>
</head>
<body id="page-top" class="home page-template page-template-home-template page-template-home-template-php page page-id-11 wp-custom-logo index"  >
   <div class="overlayloader">
      <div class="loader">&nbsp;</div>
   </div>
   <div class="header"  id="header">
      <div class="container clearfix">
         <div id="logo">
            <a href="index.html" class="custom-logo-link" rel="home" itemprop="url">
              <img width="180" height="60" src="_assets/images/logo_1.0.png" class="custom-logo" alt="" itemprop="logo" />
            </a>          
         </div>
         <div id="main-menu-wrapper">
            <a href="javascript:void(0);" id="pull" class="toggle-mobile-menu"></a>
            <nav class="navigation clearfix mobile-menu-wrapper">
              <?php
                echo "<ul id='menu' class='menu'>";
                    $menu_list = "SELECT * FROM menu_list WHERE parent = 0 ORDER BY position ASC";
                    $result_menu_list = $conn->query($menu_list);
                    if ($result_menu_list->num_rows > 0) {
                        while($row_list = $result_menu_list->fetch_assoc()) {
                            echo "<li class='menu-item menu-item-type-custom menu-item-object-custom parent'><a href='".$row_list["link"]."'>". $row_list["description"];                            
                            $menu_childlist = "SELECT * FROM menu_list WHERE parent = ".$row_list["id"]." ORDER BY position ASC";
                            $result_menu_childlist= $conn->query($menu_childlist);
                            if ($result_menu_childlist->num_rows > 0) {
                              echo " <i class='fa fa-caret-down' aria-hidden='true' ></i></a>";
                              echo "<ul class='sub-menu'>";
                              while($row_childlist = $result_menu_childlist->fetch_assoc()) {
                                echo "<li class='menu-item menu-item-type-post_type menu-item-object-page'><a class='page-scroll' href='".$row_childlist["link"]."'>".$row_childlist["description"];                                 
                                $menu_nestedchildlist = "SELECT * FROM menu_list WHERE parent = ".$row_childlist["id"]." ORDER BY position ASC";
                                $result_menu_nestedchildlist = $conn->query($menu_nestedchildlist);
                                if ($result_menu_nestedchildlist->num_rows > 0) {
                                  echo " <i class='fa fa-caret-right' aria-hidden='true' ></i></a>";
                                  echo "<ul class='sub-menu'>";
                                  while($row_nestedchildlist = $result_menu_nestedchildlist->fetch_assoc()) {
                                      echo "<li class='menu-item menu-item-type-post_type menu-item-object-page'><a class='page-scroll' href='".$row_nestedchildlist["link"]."'>".$row_nestedchildlist["description"]."</a></li>";
                                  }
                                  echo "</ul>";
                                }else{
                                  echo "</a>";
                                }
                                echo "</li>";
                              }
                              echo "</ul>";
                            }else{
                              echo "</a>";
                            }                              
                            echo "</li>";
                        }
                    }
                echo "</ul>";
              ?>                
            </nav>
         </div>
      </div>
   </div>
   <div class="clearfix"></div>
   <div id="slider-div">
      <div class="slider">
         <div class="flexslider">
            <ul class="slides">
              <?php
                  $banner_list = "SELECT * FROM slider_list WHERE action = 'enable' ORDER BY position ASC";
                  $result_banner_list = $conn->query($banner_list);
                  if ($result_banner_list->num_rows > 0) {
                      while($row_banner = $result_banner_list->fetch_assoc()) {
                          echo "<li data-center='background-position: 50% 0px;' data-top-bottom='background-position: 50% -100px;' style='background:url(".$row_banner["slider_url"].");'>";
                          echo "<div class='over-lay'><div class='fs-caption wow fadeInDown' data-wow-delay='1s'>";
                          echo "<div class='caption-container' data-center='opacity: 1' data-106-top='opacity: 0' data-anchor-target='#slider-div h4'>";
                          echo "<h4 class='title overtext'>".$row_banner["description"]."</h4>";
                          echo "</div></div></div>";
                      }
                  }
              ?>              
            </ul>
         </div>
      </div>
   </div>
   <div class="clearfix"></div>
   <!-- -----ABOUT-US SECTION START------- -->
  <div class="about-us-wrapper">
     <section id="about-us" class="svg_enable" data-center="background-position: 50% 0px;" data-top-bottom="background-position: 50% -100px;" >
        <div class="container">
           <div class="page-about-us" >
              <h2 class="main-heading wow fadeInRight" data-wow-delay="0s">About Us</h2>
              <!-- <p class="sub-heading wow fadeInRight" data-wow-delay="0s">Subtitle Goes Here</p> -->
              <div class="about-us-block">
                 <div class="about-us-paragraph wow fadeInLeft" data-wow-delay="0s">
                    <p>Risktek is a leading technology consulting and development firm based in United Arab Emirates and is a regional provider of Enterprise Risk Management, Analytics and Capital Markets for various business segments and industries.</p>
                    <br/>
                    <p>Risktek addresses the Financial Risk Management requirement of Financial Institutions through a mixture of services and product offerings in managing the Credit, Market and Operational Risks. Risktek engagement model involves a combination of Consulting, Application Development and Implementation.</p>
                    <br/>
                    <p>Risktek's unique "Solution Approach" brings to institutions the methodology and tools to quantify and manage risk. Institutions not only require systems and tools that quantify and manage risks but also needs best practices, methodologies to implement solutions while implanting them that suit the institutional culture and work ethics and environmental framework.
                    </p>
                 </div>
              </div>


              <h2 class="main-heading wow fadeInRight margintop60" data-wow-delay="0s">VISION AND OBJECTIVE</h2>
              <div class="about-us-block">
                 <div class="about-us-paragraph wow fadeInLeft" data-wow-delay="0s">
                    <p>We aim to address the financial risk management requirements of institutions through a mixture of services and product offerings – on what we call as "Solutioning approach" to manage their risks</p>
                    <br/>
                    <p>Our unique "solutioning approach", brings to institutions the methodology and tools to quantify and manage those risk. Thecompanies not only require systems/ tools that needs to be implemented to manage the risks but also consulting on what is the best method of implementing given the operating environment that they have along with the future aspirations.</p>
                    <br/>
                    <p>We aim at quick turn-around time, demonstration of value add at each level and bring the best practices to the door steps of small and medium enterprises.</p>
                 </div>
              </div>              
           </div>
        </div>
     </section>
  </div>
  <div class="clearfix"></div>
  <!-- -----ABOUT-US SECTION END------- -->
   <div class="service-wrapper">
      <div class="svg-top-container">
         <svg xmlns="http://www.w3.org/2000/svg" width="0" version="1.1" viewBox="0 0 100 100" preserveAspectRatio="none">
            <path d="M0 100 L100 100 L100 2 L0 100 Z" stroke-width="0"></path>
         </svg>
      </div>
   </div>
   <div class="clearfix"></div>
   <!-- TEAM SECTION START -->
   <div class="team-wrapper">
      <section id="team" class="svg_enable" data-center="background-position: 50% 0px;" data-top-bottom="background-position: 50% -100px;">
         <div class="container">
            <div class="page-team">
               <h2 class="main-heading wow fadeInLeft" data-wow-delay="0s">Our Team </h2>
               <p class="sub-heading wow fadeInLeft" data-wow-delay="0s">We have a powerful &amp; hardworking team which works for you.</p>
               <div class="team-block">
                  <ul class="team-grid wow fadeInRight" data-wow-delay="0s">
                     <li class="team-list">
                        <figure class="team-content">
                           <img src="_assets/images/teams/team1.jpg">
                           <figcaption>
                              <a href="javascript:void(0);">
                                 <h3>John Smith</h3>
                              </a>
                              <h4>
                                 Co founder            
                              </h4>
                              <div class="team-social-meta">
                                 <ul>
                                    <li class="team-social-social"><a href="javascript:void(0);"><i  class="fa fa-facebook"></i></a></li>
                                    <li class="team-social-social"><a href="javascript:void(0);"><i  class="fa fa-twitter"></i></a></li>
                                    <li class="team-social-social"><a href="javascript:void(0);"><i  class="fa fa-linkedin"></i></a></li>
                                    <li class="team-social-social"><a href="javascript:void(0);"><i  class="fa fa-google"></i></a></li>
                                 </ul>
                              </div>
                           </figcaption>
                        </figure>
                     </li>
                     <li class="team-list">
                        <figure class="team-content">
                           <img src="_assets/images/teams/team2.jpg">
                           <figcaption>
                              <a href="javascript:void(0);">
                                 <h3>Mariya tennis</h3>
                              </a>
                              <h4>
                                 Manager            
                              </h4>
                              <div class="team-social-meta">
                                 <ul>
                                    <li class="team-social-social"><a href="javascript:void(0);"><i  class="fa fa-facebook"></i></a></li>
                                    <li class="team-social-social"><a href="javascript:void(0);"><i  class="fa fa-twitter"></i></a></li>
                                    <li class="team-social-social"><a href="javascript:void(0);"><i  class="fa fa-linkedin"></i></a></li>
                                    <li class="team-social-social"><a href="javascript:void(0);"><i  class="fa fa-google"></i></a></li>
                                 </ul>
                              </div>
                           </figcaption>
                        </figure>
                     </li>
                     <li class="team-list">
                        <figure class="team-content">
                           <img src="_assets/images/teams/team3.jpg">
                           <figcaption>
                              <a href="javascript:void(0);">
                                 <h3>John smith</h3>
                              </a>
                              <h4>
                                 Support Manager            
                              </h4>
                              <div class="team-social-meta">
                                 <ul>
                                    <li class="team-social-social"><a href="javascript:void(0);"><i  class="fa fa-facebook"></i></a></li>
                                    <li class="team-social-social"><a href="javascript:void(0);"><i  class="fa fa-twitter"></i></a></li>
                                    <li class="team-social-social"><a href="javascript:void(0);"><i  class="fa fa-linkedin"></i></a></li>
                                    <li class="team-social-social"><a href="javascript:void(0);"><i  class="fa fa-google"></i></a></li>
                                 </ul>
                              </div>
                           </figcaption>
                        </figure>
                     </li>
                     <li class="team-list">
                        <figure class="team-content">
                           <img src="_assets/images/teams/team4.jpg">
                           <figcaption>
                              <a href="javascript:void(0);">
                                 <h3>Mariya tennis</h3>
                              </a>
                              <h4>
                                 Hr manager            
                              </h4>
                              <div class="team-social-meta">
                                 <ul>
                                    <li class="team-social-social"><a href="javascript:void(0);"><i  class="fa fa-facebook"></i></a></li>
                                    <li class="team-social-social"><a href="javascript:void(0);"><i  class="fa fa-twitter"></i></a></li>
                                    <li class="team-social-social"><a href="javascript:void(0);"><i  class="fa fa-linkedin"></i></a></li>
                                    <li class="team-social-social"><a href="javascript:void(0);"><i  class="fa fa-google"></i></a></li>
                                 </ul>
                              </div>
                           </figcaption>
                        </figure>
                     </li>
                  </ul>
               </div>
            </div>
         </div>
      </section>
   </div>
   <div class="clearfix"></div>
   <!-- LATEST POST START-->
   <section id="services" class="svg_enable" data-center="background-position: 50% 0px;" data-top-bottom="background-position: 50% -100px;">
      <div class="container">
         <div class="page-post">
            <h2 class="main-heading wow fadeInRight" data-wow-delay="0s">Our Services</h2>
            <p class="sub-heading wow fadeInRight" data-wow-delay="0s">RISKTEK IS A LEADING TECHNOLOGY CONSULTING AND DEVELOPMENT FIRM based in United Arab Emirates and is a regional rovider of Enterprise Risk Management, Governance and Compliance Management Solutions for the Financial Services Sector.</p>
            <div class="post-block">
               <ul class="post-grid wow fadeInLeft" data-wow-delay="0s">
                  <li class="post-list">
                     <figure class="post-content">
                        <a href="javascript:void(0);"> <img width="275" height="184" src="_assets/images/services/analytics.jpg" 
                          class="attachment-oneline-lite-custom-blog size-oneline-lite-custom-blog wp-post-image" 
                          alt="" srcset="_assets/images/services/analytics.jpg 1280w, _assets/images/services/analytics.jpg 300w, _assets/images/services/analytics.jpg 768w, _assets/images/services/analytics.jpg 1024w, _assets/images/services/analytics.jpg 275w" sizes="(max-width: 275px) 100vw, 275px" /></a>
                        <i class="fa fa-paper-plane-o"></i>
                        <figcaption>
                           <a href="javascirpt:void(0);">
                              <h3>Analytics</h3>
                           </a>
                        </figcaption>
                     </figure>
                  </li>
                  <li class="post-list">
                     <figure class="post-content">
                        <a href="javascript:void(0);"> <img width="275" height="184" src="_assets/images/services/credit_risk.jpg" 
                          class="attachment-oneline-lite-custom-blog size-oneline-lite-custom-blog wp-post-image" alt="" 
                          srcset="_assets/images/services/credit_risk.jpg 1280w, _assets/images/services/credit_risk.jpg 300w, _assets/images/services/credit_risk.jpg 768w, _assets/images/services/credit_risk.jpg 1024w, _assets/images/services/credit_risk.jpg 275w" sizes="(max-width: 275px) 100vw, 275px" /></a>
                        <i class="fa fa-paper-plane-o"></i>
                        <figcaption>
                           <a href="javascirpt:void(0);">
                              <h3>Credit Risk</h3>
                           </a>
                        </figcaption>
                     </figure>
                  </li>
                  <li class="post-list">
                     <figure class="post-content">
                        <a href="javascript:void(0);"> <img width="275" height="184" src="_assets/images/services/treasury_captial_markets.jpg" 
                        class="attachment-oneline-lite-custom-blog size-oneline-lite-custom-blog wp-post-image" alt="oneline lite" 
                        srcset="_assets/images/services/treasury_captial_markets.jpg 1280w, _assets/images/services/treasury_captial_markets.jpg 300w, _assets/images/services/treasury_captial_markets.jpg 768w, _assets/images/services/treasury_captial_markets.jpg 1024w" sizes="(max-width: 275px) 100vw, 275px" /></a>
                        <i class="fa fa-paper-plane-o"></i>
                        <figcaption>
                           <a href="javascirpt:void(0);">
                              <h3>Treasury & Captial Markets</h3>
                           </a>
                        </figcaption>
                     </figure>
                  </li>
                  <li class="post-list">
                     <figure class="post-content">
                        <a href="javascript:void(0);"> <img width="275" height="184" src="_assets/images/services/governace_risk_compilance.jpg" 
                          class="attachment-oneline-lite-custom-blog size-oneline-lite-custom-blog wp-post-image" alt="" 
                          srcset="_assets/images/services/governace_risk_compilance.jpg 1920w, _assets/images/services/governace_risk_compilance.jpg 300w, _assets/images/services/governace_risk_compilance.jpg 768w, _assets/images/services/governace_risk_compilance.jpg 1024w, _assets/images/services/governace_risk_compilance.jpg 275w" sizes="(max-width: 275px) 100vw, 275px" /></a>
                        <i class="fa fa-paper-plane-o"></i>
                        <figcaption>
                           <a href="javascirpt:void(0);">
                              <h3>Governace Risk & compilance</h3>
                           </a>
                        </figcaption>
                     </figure>
                  </li>
                  <li class="post-list">
                     <figure class="post-content">
                        <a href="javascript:void(0);"> <img width="275" height="184" src="_assets/images/services/reporting.jpg" 
                          class="attachment-oneline-lite-custom-blog size-oneline-lite-custom-blog wp-post-image" alt="" 
                          srcset="_assets/images/services/reporting.jpg 1920w, _assets/images/services/reporting.jpg 300w, _assets/images/services/reporting.jpg 768w, _assets/images/services/reporting.jpg 1024w, _assets/images/services/reporting.jpg 275w" sizes="(max-width: 275px) 100vw, 275px" /></a>
                        <i class="fa fa-paper-plane-o"></i>
                        <figcaption>
                           <a href="javascirpt:void(0);">
                              <h3>Reporting</h3>
                           </a>
                        </figcaption>
                     </figure>
                  </li>
                  <li class="post-list">
                     <figure class="post-content">
                        <a href="javascript:void(0);"> <img width="275" height="184" src="_assets/images/services/Consulting.jpg" 
                          class="attachment-oneline-lite-custom-blog size-oneline-lite-custom-blog wp-post-image" alt="" 
                          srcset="_assets/images/services/Consulting.jpg 1920w, _assets/images/services/Consulting.jpg 300w, _assets/images/services/Consulting.jpg 768w, _assets/images/services/Consulting.jpg 1024w, _assets/images/services/Consulting.jpg 275w" sizes="(max-width: 275px) 100vw, 275px" /></a>
                        <i class="fa fa-paper-plane-o"></i>
                        <figcaption>
                           <a href="javascirpt:void(0);">
                              <h3>Consulting</h3>
                           </a>
                        </figcaption>
                     </figure>
                  </li>
               </ul>
            </div>
         </div>
      </div>
   </section>
   <!-- LATEST POST END -->
   <div class="clearfix"></div>
   <section id="services" class="svg_enable" data-center="background-position: 50% 0px;" data-top-bottom="background-position: 50% -100px;" >
       <div class="container">
          <div class="page-services">
             <h2 class="main-heading wow fadeInRight" data-wow-delay="0s">Our Process</h2>
             <!-- <p class="sub-heading wow fadeInRight" data-wow-delay="0s">RISKTEK IS A LEADING TECHNOLOGY CONSULTING AND DEVELOPMENT FIRM based in United Arab Emirates and is a regional rovider of Enterprise Risk Management, Governance and Compliance Management Solutions for the Financial Services Sector.</p> -->
             <div class="service-block">
                <ul class="service-grid wow fadeInLeft" data-wow-delay="0s">
                   <li class="service-list">
                      <div class="service-title">
                         <!-- <a href="javascript:void(0);">Our Process</a> -->
                      </div>
                      <div class="service-content">
                         <img src="_assets/images/process.jpg" >
                         <!--  <p >Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p> -->
                         <p ><i>"It is not the strongest of the species that survies, not the most intelligent, but rather teh one most adaptable to chnage"</i>
                      </div>
                   </li>
                   <li class="service-list">
                      <div class="service-title"><a href="javascript:void(0);">Analysis</a></div>
                      <div class="service-content">
                         <p>Carefully understanding, defining, eliciting and transalting the requirements into design </p>
                      </div>
                      <div class="service-title"><a href="javascript:void(0);">Transparency</a></div>
                      <div class="service-content">
                         <p>Giving the customer insight into the process of the projects. The right picture is very essential for in time descion</p>
                      </div>
                      <div class="service-title"><a href="javascript:void(0);">Production</a></div>
                      <div class="service-content">
                         <p>Realizing a solution that confirms to the design and one that meets the customer needs.</p>
                      </div>
                   </li>
                   <li class="service-list">
                      <div class="service-title"><a href="javascript:void(0);">Planning</a></div>
                      <div class="service-content">
                         <p>Qualitative objevtives are achieved by testing the developments in a project against the business case and the objective and making changes, if necessary </p>
                      </div>
                      <div class="service-title"><a href="javascript:void(0);">Adaption</a></div>
                      <div class="service-content">
                         <p>The cooperation of all parties involved and teh ability to predict and react to changes</p>
                      </div>
                      <div class="service-title"><a href="javascript:void(0);">Feedback</a></div>
                      <div class="service-content">
                         <p>Making sure that the final result confirms to customer expectaions</p>
                      </div>
                   </li>
                </ul>
             </div>
          </div>
       </div>
    </section>
   <div class="clearfix"></div>
   <div class="contact-wrapper">
      <section id="contact" class="" data-center="background-position: 50% 0px;" data-top-bottom="background-position: 50% -100px;" >
         <div class="container">
            <div class="page-contact">
               <h2 class="cnt-main-heading">Contact us</h2>
               <p class="cnt-sub-heading">Being in contact is become very easy. Our Contact Form is will help you in generating leads.</p>
               <p>
                 <?php
                  $master_data = "SELECT * FROM master_data where code='CONTACT_US_BANNER'";
                  $result_master_data = $conn->query($master_data);
                   if ($result_master_data->num_rows > 0) {
                      echo "<img src='".$result_master_data->fetch_assoc()["description"]."' width='80%'>";
                    }
                  ?>  
                </p>


               <div class="contact-block ">
                  <div class="addrs wow fadeInLeft" data-wow-delay="0s">
                     <div class="add-heading">
                        <h3>Address</h3>
                     </div>
                     <p>
                     <?php
                      $master_data = "SELECT * FROM master_data where code='CONTACT_US'";
                      $result_master_data = $conn->query($master_data);
                       if ($result_master_data->num_rows > 0) {
                          echo $result_master_data->fetch_assoc()["description"];
                        }
                      ?>          
                     </p>
                  </div>
                  <div class="addrs googlemap wow fadeInLeft" data-wow-delay="0s" id="map">
                    <script>
                      function initMap() {
                        var uluru = {lat: 25.200328, lng: 55.275165};
                        var map = new google.maps.Map(document.getElementById('map'), {
                          zoom:16,
                          center: uluru
                        });
                        var marker = new google.maps.Marker({
                          position: uluru,
                          map: map
                        });
                      }
                    </script>
                    <script async defer
                    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBcKKlF0HVLQO43v5I5j8mFXeSOeNxuwfs&callback=initMap">
                    </script>
                  </div>
                  <div class="cnt-div  wow fadeInRight" data-wow-delay="0s">
                     <div class="leadform-show-form medium lf-form-default leadform-lite">
                        <form action="#" method="post" class="lead-form-front" id="form_1" enctype="multipart/form-data">
                           <h1>Contact Us</h1>
                           <div class="name-type lf-field"><label>Name</label>
                              <span><input id="1" type="text" name="Name" class="lf-form-name" value="" required placeholder="Name" />
                              </span>
                           </div>
                           <div class="text-type lf-field"><label>Email</label>
                              <span><input id="2" type="email" class="lf-form-text " name="Email" required value="" placeholder="Email" />
                              </span>
                           </div>
                           <div class="text-type lf-field"><label>Contact No</label>
                              <span><input id="3" type="number" class="lf-form-text " name="Contact No" required value="" placeholder="Contact number" />
                              </span>
                           </div>
                           <div class="textarea-type lf-field"><label>Message</label>
                              <span><textarea id="4" name="Message" class="lf-form-textarea" value="Message" placeholder="Message" required></textarea>
                              </span>
                           </div>
                           <div class="lf-form-panel">
                              <div class="submit-type lf-field"><label><input id="0" class="lf-form-submit" type="submit" name="submit" value="Submit"/>
                                 </label>
                              </div>
                           </div>
                           <div class="leadform-show-loading front-loading leadform-show-message-form-1"></div>
                           <div class="lf-loading"><img src="_assets/images/load.gif" style="display: none;" id="loading_image"></div>
                        </form>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
   </div>
   <div class="clearfix"></div>
   <div class="footer-wrapper">
      <!-- Footer wrapper start -->
   </div>
   <div class="foot-copyright">
   <div class="svg-top-container">
      <svg xmlns="http://www.w3.org/2000/svg" width="0" version="1.1" viewBox="0 0 100 100" preserveAspectRatio="none">
         <path d="M0 100 L100 100 L100 2 L0 100 Z" stroke-width="0"></path>
      </svg>
   </div>
   <span class="text-footer">
   <!-- <a href="javascript:void(0);"> Powered by webvizards.com</a> -->
   </span>
   <div class="social-ft">
   <ul>
      <li><a target='_blank' href="javascript:void(0);" ><i class='fa fa-facebook'></i></a></li>
      <li><a target='_blank' href="javascript:void(0);" ><i class='fa fa-google-plus'></i></a></li>
      <li><a target='_blank' href="javascript:void(0);" ><i class='fa fa-linkedin'></i></a></li>
      <li><a target='_blank' href="javascript:void(0);" ><i class='fa fa-pinterest'></i></a></li>
      <li><a target='_blank' href="javascript:void(0);" ><i class='fa fa-twitter'></i></a></li>
   </ul>
   <div>
   </div>
<script type='text/javascript' src='_assets/js/wow.js'></script>
<script type='text/javascript' src='_assets/js/jquery.flexslider.js'></script>
<script type='text/javascript' src='_assets/js/jquery.bxslider.js'></script>
<script type='text/javascript' src='_assets/js/skrollr.js'></script>
<script type='text/javascript' src='_assets/js/imagesloaded.js'></script>
<script type='text/javascript' src='_assets/js/custom.js'></script>
<script type='text/javascript' src='_assets/js/wp-embed.min66f2.js'></script>
<a href="javascript:void(0);" id="scroll" title="Scroll to Top" style="display: none;"><span></span></a>
</body>
</html>