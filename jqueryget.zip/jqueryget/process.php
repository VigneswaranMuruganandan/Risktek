<?php
      include_once('db_connect.php');
 
if($_POST) {
  $id = $_POST['id'];
  $username = $_POST['username'];
  $password = md5($_POST ['password']);
  $fname = $_POST['fname'];
  $lname = $_POST['lname'];
 

 
 
if( empty($username) || empty($password) )
 {
	echo "Username and Password are mandatory - from PHP!";
	exit();
 }
 
$con = db_connect();
        $res = "SELECT username FROM users WHERE id='$id'";
	 
         $add = mysqli_query($con, $res);
		 $row= $add->fetch_all(MYSQLI_ASSOC);
	  if( $row > 0 )
	    echo "Username $username has already been taken";
	  else
	  {
	   	  $sql = "INSERT INTO users VALUES('',
                                           '$username', 
                                           '$password', 
                                           '$fname', 
                                           '$lname')";
	    if( mysql_query($sql) )
	     echo "Inserted Successfully";
	   else
	     echo "Insertion Failed";
	}
}
?>