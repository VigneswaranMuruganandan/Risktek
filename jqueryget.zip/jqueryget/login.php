<?php
        include_once('db_connect.php');
 
		 $username = $_POST['username'];
         $password = md5($_POST ['password']);
 
		if( empty($username) || empty($password) )
			echo "Username and Password Mandatory - from PHP";
		else
		{
		$sql = "SELECT count(*) FROM users WHERE(
		        username='$username' 
				AND 
				password='$password')";
 
 
	   $addbook = mysqli_query($con, $sql);
		$row = mysql_fetch_array( $addbook);
 
		if( $row[0] > 0 )
		 echo "Login Successful";
		else
		 echo "Failed To Login";
   		}		
?>