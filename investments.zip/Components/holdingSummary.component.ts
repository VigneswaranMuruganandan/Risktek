import { Component, OnInit, Input} from '@angular/core';
import { TranslateService} from '@ngx-translate/core';
import { SharedService } from '../../shared/services/shared.service';
import { SpinnerService } from '../../shared/services/spinner.service';
import { ErrorService } from '../../shared/services/error.service';
import { InvestmentsService } from '../services/investments.service';

@Component({
	templateUrl: './../templates/holdingSummary.html'
})
export class HoldingSummaryComponent implements OnInit {

	constructor( private investmentsService: InvestmentsService, 
    			 private sharedService: SharedService,
                 private spinnerService: SpinnerService,
                 private errorService: ErrorService) {}

	ngOnInit(){
		//test
	}
}